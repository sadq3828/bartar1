import importlib.util
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile


spec = importlib.util.spec_from_file_location("release", Path(__file__).parents[1] / "scripts/release.py")
release = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release)


class ReleaseArchiveSecurityTest(unittest.TestCase):
    def archive(self, name, mode=None):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        path = Path(directory.name) / "release.zip"
        with zipfile.ZipFile(path, "w") as archive:
            item = zipfile.ZipInfo(name)
            if mode:
                item.external_attr = mode << 16
            archive.writestr(item, "synthetic fixture")
        return path

    def test_archive_cannot_escape_release_root(self):
        for name in ["bartar/../../outside", "/bartar/absolute", "bartar/dir\\file"]:
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, "unsafe_archive_path"):
                release.inspect_archive(self.archive(name))

    def test_archive_cannot_install_environment_secrets(self):
        with self.assertRaisesRegex(ValueError, "archive_contains_environment_secret"):
            release.inspect_archive(self.archive("bartar/.env"))

    def test_archive_cannot_install_symlinks(self):
        with self.assertRaisesRegex(ValueError, "archive_symlink_rejected"):
            release.inspect_archive(self.archive("bartar/public/link", stat.S_IFLNK | 0o777))

    def test_release_id_rejects_paths_and_options(self):
        for name in ["../current", "release/next", "--force", ""]:
            with self.subTest(name=name), self.assertRaises(ValueError):
                release.release_id(name)


if __name__ == "__main__":
    unittest.main()
