<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Tests\TestCase;

final class WebSessionUpgradeTest extends TestCase
{
    public function test_stage_nine_upgrade_adds_encrypted_database_sessions_without_changing_accounts(): void
    {
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $original = config('database.default');
        $name = 'bartar_session_test_'.strtolower(Str::random(10));
        DB::statement('CREATE DATABASE `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $connection = config('database.connections.'.$original);
        $connection['database'] = $name;
        config(['database.connections.session_upgrade' => $connection]);
        DB::setDefaultConnection('session_upgrade');
        try {
            $paths = array_values(array_filter(glob(database_path('migrations/*.php')), fn ($p) => basename($p) < '2026_10_21'));
            $this->assertSame(0, Artisan::call('migrate', ['--path' => $paths, '--realpath' => true, '--force' => true]));
            $account = Account::create(['kind' => 'admin', 'username' => 'session_upgrade', 'password_hash' => Str::random(40)]);
            $before = DB::table('accounts')->where('id', $account->id)->first();
            $this->assertFalse(Schema::hasTable('sessions'));
            $this->assertSame(0, Artisan::call('migrate', ['--force' => true]));
            $this->assertEquals($before, DB::table('accounts')->where('id', $account->id)->first());
            config(['session.driver' => 'database', 'session.connection' => 'session_upgrade', 'session.encrypt' => true]);
            app('session')->forgetDrivers();
            $session = app('session')->driver();
            $session->start();
            $marker = 'private-session-marker-'.Str::random(20);
            $session->put('test-marker', $marker);
            $id = $session->getId();
            $session->save();
            $payload = DB::table('sessions')->where('id', $id)->value('payload');
            $this->assertNotNull($payload);
            $this->assertStringNotContainsString($marker, base64_decode($payload));
            app('session')->forgetDrivers();
            $restored = app('session')->driver();
            $restored->setId($id);
            $restored->start();
            $this->assertSame($marker, $restored->get('test-marker'));
        } finally {
            DB::purge('session_upgrade');
            DB::setDefaultConnection($original);
            DB::statement('DROP DATABASE `'.$name.'`');
        }
    }
}
