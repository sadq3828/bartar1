<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\Signals\Models\SignalRevision;
use Carbon\CarbonImmutable;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class SignalFlowTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;

    private Market $market;

    private Asset $asset;

    private string $password;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'signal_owner_'.strtolower(Str::random(8)), 'password_hash' => $this->password]);
        $this->owner->roles()->attach(Role::where('key', 'owner')->firstOrFail());
        $this->market = Market::create(['key' => 'market_'.strtolower(Str::random(8)), 'title' => 'بازار آزمون', 'created_by' => $this->owner->id]);
        $this->asset = Asset::create(['market_id' => $this->market->id, 'symbol' => strtoupper(Str::random(6)), 'title' => 'دارایی آزمون', 'created_by' => $this->owner->id]);
    }

    private function sensitive(): array
    {
        return ['current_password' => $this->password, 'reason' => 'authorized signal integration test'];
    }

    private function fields(array $extra = []): array
    {
        return array_merge($this->sensitive(), ['title' => 'سیگنال امن آزمون', 'market_id' => $this->market->id, 'asset_id' => $this->asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100.000000000001', 'entry_high' => '105', 'stop_loss' => '90', 'timeframe' => '۴ ساعت', 'body' => 'توضیح قابل بررسی', 'risk_label' => 'متوسط', 'expires_at' => null, 'targets' => [['price' => '110', 'weight' => '0.5'], ['price' => '120', 'weight' => '0.5']]], $extra);
    }

    private function signal(): Signal
    {
        return app(ManageSignals::class)->create($this->owner, $this->fields());
    }

    private function publish(Signal $signal): Signal
    {
        return app(ManageSignals::class)->transition($this->owner, $signal, $this->sensitive() + ['status' => 'published', 'idempotency_key' => (string) Str::uuid(), 'announce_change' => false]);
    }

    private function adminLogin(Account $account, string $password): void
    {
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $account->username, 'password' => $password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    public function test_signal_uses_real_market_asset_fk_and_ordered_decimal_targets(): void
    {
        $signal = $this->signal();
        $this->assertSame('100.000000000001', $signal->entry_low);
        $this->assertSame(['110.000000000000', '120.000000000000'], $signal->targets->pluck('price')->all());
        $this->assertSame('draft', $signal->status);
        $this->assertDatabaseCount('signal_status_events', 1);

        $otherMarket = Market::create(['key' => 'other_'.strtolower(Str::random(8)), 'title' => 'بازار دیگر', 'created_by' => $this->owner->id]);
        $this->expectException(\Illuminate\Database\Eloquent\ModelNotFoundException::class);
        app(ManageSignals::class)->create($this->owner, $this->fields(['market_id' => $otherMarket->id]));
    }

    public function test_invalid_target_order_stop_and_exit_weight_are_rejected(): void
    {
        try {
            app(ManageSignals::class)->create($this->owner, $this->fields(['targets' => [['price' => '120'], ['price' => '110']]]));
            $this->fail('Descending buy targets must be rejected.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('targets.1.price', $exception->errors());
        }

        try {
            app(ManageSignals::class)->create($this->owner, $this->fields(['stop_loss' => '101']));
            $this->fail('Invalid buy stop must be rejected.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('stop_loss', $exception->errors());
        }

        $signal = $this->publish($this->signal());
        $this->expectException(ValidationException::class);
        app(ManageSignals::class)->recordResult($this->owner, $signal, $this->sensitive() + ['method' => 'partial', 'exits' => [['price' => '111', 'weight' => '0.7'], ['price' => '118', 'weight' => '0.4']], 'announce_change' => false, 'idempotency_key' => (string) Str::uuid()]);
    }

    public function test_published_edit_preserves_previous_targets_and_creates_optional_announcement(): void
    {
        $signal = $this->publish($this->signal());
        $updated = app(ManageSignals::class)->update($this->owner, $signal, $this->fields(['title' => 'عنوان اصلاح‌شده', 'entry_low' => '101', 'entry_high' => '106', 'targets' => [['price' => '115', 'weight' => '1']], 'announce_change' => true]));
        $revision = SignalRevision::where('signal_id', $signal->id)->sole();
        $this->assertSame(1, $revision->version);
        $this->assertSame('سیگنال امن آزمون', $revision->snapshot_json['signal']['title']);
        $this->assertSame('110.000000000000', $revision->snapshot_json['targets'][0]['price']);
        $this->assertSame(2, $updated->version);
        $this->assertSame('115.000000000000', $updated->targets->first()->price);
        $this->assertDatabaseHas('signal_announcements', ['signal_id' => $signal->id, 'signal_version' => 2, 'event_type' => 'changed']);
    }

    public function test_scheduled_publication_is_idempotent_and_never_exposes_scheduled_signal_early(): void
    {
        $this->travelTo(CarbonImmutable::parse('2026-10-20T08:00:00Z'));
        $signal = $this->signal();
        app(ManageSignals::class)->transition($this->owner, $signal, $this->sensitive() + ['status' => 'scheduled', 'scheduled_at' => '2026-10-20T12:00', 'idempotency_key' => (string) Str::uuid()]);
        $this->assertFalse(Signal::memberVisible()->whereKey($signal->id)->exists());
        $this->travelTo(CarbonImmutable::parse('2026-10-20T08:30:01Z'));
        $this->assertSame(1, app(ManageSignals::class)->publishDue());
        $this->assertSame(0, app(ManageSignals::class)->publishDue());
        $this->assertTrue(Signal::memberVisible()->whereKey($signal->id)->exists());
        $this->assertSame(1, SignalAnnouncement::where('signal_id', $signal->id)->where('event_type', 'published')->count());
        $this->assertSame(1, DB::table('signal_status_events')->where('signal_id', $signal->id)->where('to_status', 'published')->count());
    }

    public function test_result_corrections_are_append_only_and_history_is_not_silently_rewritten(): void
    {
        $signal = $this->publish($this->signal());
        $manager = app(ManageSignals::class);
        $first = $manager->recordResult($this->owner, $signal, $this->sensitive() + ['method' => 'partial', 'entry_execution_price' => '103', 'coverage_ratio' => '0.5', 'note' => 'خروج نخست', 'exits' => [['price' => '110', 'weight' => '0.5']], 'announce_change' => false, 'idempotency_key' => (string) Str::uuid()]);
        $second = $manager->recordResult($this->owner, $signal->fresh(), $this->sensitive() + ['method' => 'targets', 'entry_execution_price' => '103', 'coverage_ratio' => '1', 'note' => 'تکمیل نتیجه', 'exits' => [['price' => '110', 'weight' => '0.5'], ['price' => '120', 'weight' => '0.5']], 'announce_change' => true, 'idempotency_key' => (string) Str::uuid()]);
        $this->assertNotSame($first->version, $second->version);
        $this->assertDatabaseCount('signal_results', 2);
        $this->assertDatabaseCount('signal_revisions', 2);
        $this->assertDatabaseHas('signal_announcements', ['signal_id' => $signal->id, 'signal_version' => $second->version, 'event_type' => 'result_corrected']);

        $this->expectException(QueryException::class);
        DB::table('signal_results')->where('id', $first->id)->update(['note' => 'بازنویسی بی‌ردپا']);
    }

    public function test_viewer_cannot_mutate_signals_by_direct_request(): void
    {
        $viewerPassword = Str::random(32);
        $viewer = Account::create(['kind' => 'admin', 'username' => 'viewer_'.strtolower(Str::random(8)), 'password_hash' => $viewerPassword]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->firstOrFail());
        $this->adminLogin($viewer, $viewerPassword);
        $this->get('/admin/signals')->assertOk();
        $this->get('/admin/signals/create')->assertForbidden();
        $this->postJson('/admin/signals', $this->fields(['current_password' => $viewerPassword]))->assertForbidden();
        $this->postJson('/admin/markets', $this->sensitive() + ['current_password' => $viewerPassword, 'key' => 'blocked', 'title' => 'ممنوع'])->assertForbidden();
    }
}
