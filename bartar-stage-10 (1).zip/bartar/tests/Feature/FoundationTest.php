<?php

namespace Tests\Feature;

use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class FoundationTest extends TestCase
{
    public static function publicPages(): array
    {
        return array_map(fn ($url) => [$url], ['/', '/about', '/subscription', '/guide', '/terms', '/privacy', '/contact', '/announcements']);
    }

    #[DataProvider('publicPages')]
    public function test_public_pages_render_without_a_database(string $url): void
    {
        config(['content.database_enabled' => false]);
        $this->get($url)->assertOk()->assertSee('lang="fa" dir="rtl"', false)
            ->assertSee('رفتن به محتوای اصلی')->assertSee('برتر');
        $this->assertSame('mysql', config('database.default'));
        $this->assertSame([], app('db')->getConnections());
    }

    public function test_public_response_has_security_headers_and_local_assets(): void
    {
        $response = $this->get('/');
        $response->assertHeader('X-Content-Type-Options', 'nosniff')->assertHeader('X-Frame-Options', 'DENY');
        $this->assertStringContainsString("frame-ancestors 'none'", $response->headers->get('Content-Security-Policy'));
        $response->assertSee('/assets/site.css', false)->assertSee('/assets/site.js', false)
            ->assertDontSee('cdn.')->assertDontSee('fonts.googleapis');
    }

    public function test_member_login_fails_closed_without_sms_while_admin_login_is_real(): void
    {
        foreach (['/login'] as $url) {
            $this->get($url)->assertStatus(503)->assertSee('هنوز فعال نشده')->assertSee('disabled', false);
            $this->post($url, ['password' => 'not-a-real-password', 'otp' => '123456'])->assertStatus(503);
        }
        $this->get('/admin/login')->assertOk()->assertSee('<form', false)->assertSee('name="username"', false)->assertSee('name="password"', false);
        $this->get('/register')->assertNotFound();
        $this->post('/register')->assertNotFound();
    }

    public static function privatePages(): array
    {
        return [['/app', '/login'], ['/app/signals/anything', '/login'], ['/app/account', '/login'], ['/admin', '/admin/login'], ['/admin/members', '/admin/login']];
    }

    #[DataProvider('privatePages')]
    public function test_private_surfaces_stay_closed_even_with_forged_session_data(string $url, string $destination): void
    {
        $this->withSession(['member_id' => 1, 'admin_id' => 1, 'is_admin' => true])
            ->get($url)->assertRedirect($destination);
        $this->getJson($url)->assertUnauthorized();
    }

    public function test_preview_is_closed_in_production_even_if_enabled(): void
    {
        app()->instance('env', 'production');
        config(['bartar.preview_enabled' => true]);
        foreach (['/dev', '/dev/member/home', '/dev/member/signals', '/dev/admin/dashboard', '/dev/states'] as $url) {
            $this->get($url)->assertNotFound();
        }
    }

    public function test_preview_is_disabled_by_default_in_local_environment(): void
    {
        app()->instance('env', 'local');
        config(['bartar.preview_enabled' => false]);
        $this->get('/dev/member/home')->assertNotFound();
    }

    public function test_all_development_shell_pages_render_empty_without_database_access(): void
    {
        app()->instance('env', 'local');
        config(['bartar.preview_enabled' => true, 'content.database_enabled' => false]);
        $urls = ['/dev', '/dev/states'];
        foreach (array_keys(config('bartar.member_navigation')) as $page) {
            $urls[] = '/dev/member/'.$page;
        }
        foreach (['notifications', 'subscription'] as $page) {
            $urls[] = '/dev/member/'.$page;
        }
        foreach (array_keys(config('bartar.admin_navigation')) as $page) {
            $urls[] = '/dev/admin/'.$page;
        }
        foreach ($urls as $url) {
            $this->get($url)->assertOk()->assertSee('پیش‌نمایش توسعه')->assertHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
        }
        $this->assertSame([], app('db')->getConnections());
    }

    public function test_filters_persist_in_url_and_escape_search_input(): void
    {
        app()->instance('env', 'local');
        config(['bartar.preview_enabled' => true]);
        $payload = '<script>alert(1)</script>';
        $this->get('/dev/member/signals?'.http_build_query(['q' => $payload, 'direction' => 'buy', 'active' => '1']))
            ->assertOk()->assertSee(e($payload), false)->assertDontSee($payload, false)->assertSee('نتیجه‌ای پیدا نشد');
        $this->getJson('/dev/member/markets?market=unrecognized')->assertUnprocessable();
        $this->getJson('/dev/member/markets?q='.str_repeat('x', 101))->assertUnprocessable();
        $this->get('/dev/member/unknown')->assertNotFound();
    }

    public function test_unknown_and_private_media_paths_do_not_expose_files(): void
    {
        $this->get('/private/media/arbitrary')->assertRedirect('/login')->assertDontSee('Stack trace');
        $this->get('/unknown-page')->assertNotFound()->assertSee('صفحه پیدا نشد');
    }

    public function test_health_only_confirms_application_boot(): void
    {
        $this->get('/up')->assertOk();
        $this->assertSame([], app('db')->getConnections());
    }
}
