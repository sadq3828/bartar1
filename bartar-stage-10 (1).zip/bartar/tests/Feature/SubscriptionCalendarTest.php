<?php

namespace Tests\Feature;

use App\Modules\Members\Support\IranianPhone;
use App\Modules\Subscriptions\Support\SubscriptionCalendar;
use Carbon\CarbonImmutable;
use Illuminate\Validation\ValidationException;
use IntlCalendar;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class SubscriptionCalendarTest extends TestCase
{
    public function test_persian_end_of_long_month_clamps_to_destination_end(): void
    {
        $end = app(SubscriptionCalendar::class)->add(CarbonImmutable::parse('2023-09-22T06:45:12.123456Z'), 1, 'persian');
        $this->assertSame('2023-10-22 06:45:12.123456', $end->format('Y-m-d H:i:s.u'));
    }

    public function test_persian_leap_esfand_clamps_after_twelve_months(): void
    {
        $end = app(SubscriptionCalendar::class)->add(CarbonImmutable::parse('2021-03-20T05:30:00Z'), 12, 'persian');
        $this->assertSame('2022-03-20 05:30:00', $end->format('Y-m-d H:i:s'));
    }

    public function test_gregorian_leap_and_non_leap_preserve_tehran_time(): void
    {
        foreach ([['2024-01-31T06:04:56.123456Z', '2024-02-29 06:04:56.123456'], ['2025-01-31T06:04:56.123456Z', '2025-02-28 06:04:56.123456']] as [$start,$expected]) {
            $this->assertSame($expected, app(SubscriptionCalendar::class)->add(CarbonImmutable::parse($start), 1, 'gregorian')->format('Y-m-d H:i:s.u'));
        }
    }

    public static function durations(): array
    {
        return [[1], [3], [6], [12]];
    }

    #[DataProvider('durations')]
    public function test_all_supported_durations_use_calendar_months(int $months): void
    {
        $start = CarbonImmutable::parse('2023-04-04T21:00:00Z'); // 1402/01/16 00:30 Tehran
        $end = app(SubscriptionCalendar::class)->add($start, $months, 'persian');
        $cal = IntlCalendar::createInstance('Asia/Tehran', 'fa_IR@calendar=persian');
        $cal->setTime($end->getTimestamp() * 1000);
        $this->assertSame(1402 + intdiv($months, 12), $cal->get(IntlCalendar::FIELD_YEAR));
        $this->assertSame($months % 12, $cal->get(IntlCalendar::FIELD_MONTH));
        $this->assertSame(16, $cal->get(IntlCalendar::FIELD_DAY_OF_MONTH));
        $this->assertSame('00:30', $end->setTimezone('Asia/Tehran')->format('H:i'));
    }

    public function test_unsupported_duration_is_rejected(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        app(SubscriptionCalendar::class)->add(now(), 2, 'persian');
    }

    public function test_phone_variants_normalize_to_one_identity_and_invalid_is_rejected(): void
    {
        $body = '9'.random_int(100000000, 999999999);
        $expected = '+98'.$body;
        foreach (['0'.$body, '+98'.$body, '0098'.$body, '98'.$body, $body, ' (0'.substr($body, 0, 3).') '.substr($body, 3)] as $variant) {
            $this->assertSame($expected, IranianPhone::normalize($variant));
        }
        $persian = strtr('0'.$body, array_combine(str_split('0123456789'), preg_split('//u', '۰۱۲۳۴۵۶۷۸۹', -1, PREG_SPLIT_NO_EMPTY)));
        $this->assertSame($expected, IranianPhone::normalize($persian));
        $this->expectException(ValidationException::class);
        IranianPhone::normalize('invalid-phone');
    }
}
