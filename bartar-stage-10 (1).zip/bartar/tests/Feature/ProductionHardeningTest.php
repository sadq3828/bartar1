<?php

namespace Tests\Feature;

use App\Http\Middleware\TrustConfiguredProxies;
use App\Modules\SystemHealth\Actions\DeploymentReadiness;
use App\Modules\SystemHealth\Support\ReportProductionFailure;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

final class ProductionHardeningTest extends TestCase
{
    use DatabaseTransactions;

    public function test_production_rejects_untrusted_host_and_forwarded_host_poisoning(): void
    {
        app()->instance('env', 'production');
        config(['app.url' => 'https://bartar.test', 'content.database_enabled' => false]);
        $this->get('https://evil.test/')->assertStatus(400)->assertHeader('X-Frame-Options', 'DENY');
        $this->withHeaders(['X-Forwarded-Host' => 'evil.test'])->get('https://bartar.test/')->assertOk()->assertDontSee('evil.test');
    }

    public function test_only_explicit_proxy_can_supply_client_ip_and_secure_transport(): void
    {
        Route::get('/boundary-test', fn () => response()->json(['ip' => request()->ip(), 'secure' => request()->isSecure(), 'host' => request()->getHost()]));
        config(['security.trusted_proxies' => []]);
        $this->withHeaders(['X-Forwarded-For' => '198.51.100.42', 'X-Forwarded-Proto' => 'https', 'X-Forwarded-Host' => 'evil.test'])->get('/boundary-test')->assertJson(['ip' => '127.0.0.1', 'secure' => false, 'host' => 'localhost']);
        config(['security.trusted_proxies' => ['127.0.0.1/32']]);
        $this->get('/boundary-test')->assertJson(['ip' => '198.51.100.42', 'secure' => true, 'host' => 'localhost']);
        config(['security.trusted_proxies' => ['*', 'REMOTE_ADDR', '0.0.0.0/0', 'bad']]);
        $this->assertFalse(TrustConfiguredProxies::valid('*'));
        $this->assertFalse(TrustConfiguredProxies::valid('10.0.0.1/33'));
        $this->assertTrue(TrustConfiguredProxies::valid('2001:db8::/32'));
    }

    public function test_errors_are_non_disclosing_not_cached_and_keep_security_headers(): void
    {
        app()->instance('env', 'production');
        config(['app.url' => 'https://localhost', 'app.debug' => true, 'content.database_enabled' => false]);
        Route::get('/failure-test', fn () => throw new \RuntimeException('secret_provider_credential_and_otp'));
        $response = $this->get('https://localhost/failure-test');
        $response->assertStatus(500)->assertDontSee('secret_provider_credential_and_otp')->assertDontSee('Stack trace')->assertHeader('X-Content-Type-Options', 'nosniff')->assertHeader('Strict-Transport-Security', 'max-age=31536000');
        $this->assertStringContainsString('no-store', $response->headers->get('Cache-Control'));
        $this->assertMatchesRegularExpression('/\A[0-9a-f-]{36}\z/', $response->headers->get('X-Request-Id'));
        $this->get('https://localhost/missing-test')->assertNotFound()->assertHeader('Content-Security-Policy')->assertHeader('X-Robots-Tag', 'noindex, nofollow');
    }

    public function test_production_exception_log_keeps_type_and_correlation_only(): void
    {
        app()->instance('env', 'production');
        Log::spy();
        $result = (new ReportProductionFailure)(new \RuntimeException('password=private phone=private otp=private'));
        $this->assertFalse($result);
        Log::shouldHaveReceived('error')->once()->with('application_failure', \Mockery::on(fn ($context) => array_keys($context) === ['error_type', 'request_id'] && $context['error_type'] === 'RuntimeException' && ! str_contains(json_encode($context), 'private')));
    }

    public function test_preflight_blocks_ephemeral_stores_unsafe_url_keys_and_wildcard_proxies(): void
    {
        config(['app.debug' => true, 'app.url' => 'https://user@bartar.test', 'cache.default' => 'array', 'session.driver' => 'array', 'queue.default' => 'sync', 'security.trusted_proxies' => ['*']]);
        $result = app(DeploymentReadiness::class)->inspect(true);
        $this->assertSame('blocked', $result['status']);
        foreach (['environment', 'debug_disabled', 'https_canonical_url', 'persistent_cache', 'persistent_session', 'database_queue', 'proxy_allowlist'] as $key) {
            $this->assertSame('blocked', $result['checks'][$key], $key);
        }
        $this->assertSame('not_configured', $result['services']['otp_sms']);
        $this->assertStringNotContainsString((string) config('app.key'), json_encode($result));
    }

    public function test_state_changing_routes_keep_csrf_including_exports_and_backup_requests(): void
    {
        app()->instance('env', 'production');
        foreach (['/admin/reports/export' => 'post', '/admin/backups' => 'post', '/admin/content/settings' => 'put', '/app/notifications/read-all' => 'post'] as $url => $method) {
            $this->{$method}($url)->assertStatus(419)->assertHeader('X-Content-Type-Options', 'nosniff');
        }
    }
}
