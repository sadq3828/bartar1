<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use App\Modules\Content\Actions\ManageContent;
use App\Modules\Content\Actions\ManageContentMedia;
use App\Modules\Content\Models\Announcement;
use App\Modules\Content\Models\ContentPage;
use App\Modules\Content\Models\ContentPageRevision;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Notifications\Actions\DispatchNotifications;
use App\Modules\Notifications\Models\MemberNotification;
use App\Modules\Notifications\Models\NotificationDelivery;
use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\Plan;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Tests\Support\CapturingOtpSender;
use Tests\TestCase;

class ContentNotificationFlowTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;
    private string $password;
    private CapturingOtpSender $sender;
    private string $png;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        Storage::fake('signal-media');
        config(['membership.otp_key' => bin2hex(random_bytes(32)), 'notifications.sms_enabled' => false]);
        $this->sender = new CapturingOtpSender;
        app()->instance(OtpSender::class, $this->sender);
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'content_owner_'.strtolower(Str::random(8)), 'password_hash' => $this->password]);
        $this->owner->roles()->attach(Role::where('key', 'owner')->firstOrFail());
        $this->png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=', true);
    }

    private function sensitive(array $extra = []): array
    {
        return array_merge(['current_password' => $this->password, 'reason' => 'authorized content integration test'], $extra);
    }

    private function pageData(array $extra = []): array
    {
        return array_merge($this->sensitive(), ['slug' => 'about', 'eyebrow' => 'درباره آزمون', 'title' => 'عنوان مدیریت‌شده', 'intro' => 'مقدمه مدیریت‌شده', 'icon' => 'compass', 'sections' => [['kind' => 'text', 'title' => 'بخش آزمون', 'body' => '<script>alert(1)</script>', 'action_label' => 'راهنما', 'action_url' => '/guide', 'visible' => true]]], $extra);
    }

    private function page(array $extra = []): ContentPage
    {
        return app(ManageContent::class)->createPage($this->owner, $this->pageData($extra));
    }

    private function activeMember(): Member
    {
        $member = app(ManageMembers::class)->create($this->owner, $this->sensitive(['phone' => '+989'.random_int(100000000, 999999999), 'display_name' => 'عضو اعلان']));
        app(ManageSubscriptions::class)->grant($this->owner, $member, $this->sensitive(['operation' => 'activate', 'months' => 1, 'calendar' => 'persian', 'plan_id' => Plan::where('key', 'standard')->sole()->id, 'idempotency_key' => (string) Str::uuid()]));

        return $member->fresh();
    }

    private function memberLogin(Member $member): void
    {
        Auth::forgetGuards();
        $this->post('/login', ['phone' => $member->phone_e164])->assertRedirect('/login/verify');
        $this->withCookie('bartar_member_session', session()->getId());
        $this->post('/login/verify', ['code' => $this->sender->code()])->assertRedirect('/app');
        $this->withCookie('bartar_member_session', session()->getId());
    }

    private function adminLogin(Account $account, string $password): void
    {
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $account->username, 'password' => $password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    public function test_published_managed_page_replaces_fallback_and_escapes_html(): void
    {
        $page = $this->page();
        app(ManageContent::class)->publishPage($this->owner, $page, $this->sensitive());

        $response = $this->get('/about')->assertOk()->assertSee('عنوان مدیریت‌شده');
        $response->assertSee('&lt;script&gt;alert(1)&lt;/script&gt;', false)->assertDontSee('<script>alert(1)</script>', false);
        $this->assertDatabaseHas('audit_logs', ['action' => 'content.page.published', 'entity_id' => $page->public_id, 'scope' => 'cms']);
    }

    public function test_published_edit_preserves_revision_and_rejects_unsafe_link(): void
    {
        $page = $this->page();
        app(ManageContent::class)->publishPage($this->owner, $page, $this->sensitive());
        $updated = app(ManageContent::class)->updatePage($this->owner, $page->fresh(), $this->pageData(['title' => 'نسخه دوم']));
        $revision = ContentPageRevision::where('page_id', $page->id)->sole();
        $this->assertSame(1, $revision->version);
        $this->assertSame('عنوان مدیریت‌شده', $revision->snapshot_json['page']['title']);
        $this->assertSame(2, $updated->version);
        $this->get('/about')->assertOk()->assertSee('نسخه دوم');

        $bad = $this->pageData(['title' => 'نباید ذخیره شود']);
        $bad['sections'][0]['action_url'] = 'javascript:alert(1)';
        try {
            app(ManageContent::class)->updatePage($this->owner, $updated, $bad);
            $this->fail('Unsafe content link must be rejected.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('sections.0.action_url', $exception->errors());
        }
        $this->assertSame('نسخه دوم', $page->fresh()->title);
        $this->assertDatabaseCount('content_page_revisions', 1);
    }

    public function test_content_image_is_verified_private_until_page_publication(): void
    {
        $page = $this->page();
        $image = UploadedFile::fake()->createWithContent('hero.png', $this->png);
        $media = app(ManageContentMedia::class)->uploadHero($this->owner, $page, $image, $this->sensitive(['alt_text' => 'بنر توضیح‌دار']));
        Storage::disk('signal-media')->assertExists($media->mediaFile->object_key);
        $this->get('/content/media/'.$media->public_id)->assertNotFound();
        app(ManageContent::class)->publishPage($this->owner, $page->fresh(), $this->sensitive());
        $response = $this->get('/content/media/'.$media->public_id)->assertOk()->assertHeader('Content-Type', 'image/png');
        $this->assertSame($this->png, $response->streamedContent());

        $spoof = UploadedFile::fake()->createWithContent('fake.png', '<svg onload="alert(1)"></svg>');
        try {
            app(ManageContentMedia::class)->uploadHero($this->owner, $page->fresh(), $spoof, $this->sensitive(['alt_text' => 'نامعتبر']));
            $this->fail('Spoofed image must be rejected.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('image', $exception->errors());
        }
        $this->assertDatabaseCount('content_media', 1);
    }

    public function test_announcement_is_public_and_fanned_out_once_with_member_idor_blocked(): void
    {
        $member = $this->activeMember();
        $manager = app(ManageContent::class);
        $announcement = $manager->createAnnouncement($this->owner, $this->sensitive(['title' => 'اطلاعیه رسمی', 'body' => '<img src=x onerror=alert(1)>', 'audience' => 'all', 'expires_at' => null]));
        $manager->publishAnnouncement($this->owner, $announcement, $this->sensitive());
        $manager->publishAnnouncement($this->owner, $announcement->fresh(), $this->sensitive());
        $this->assertDatabaseCount('member_notifications', 1);
        $this->get('/announcements')->assertOk()->assertSee('اطلاعیه رسمی')->assertSee('&lt;img src=x onerror=alert(1)&gt;', false)->assertDontSee('<img src=x onerror=alert(1)>', false);

        $other = $this->activeMember();
        $otherNotification = MemberNotification::create(['recipient_id' => $other->account_id, 'kind' => 'announcement', 'title' => 'خصوصی', 'body' => 'برای عضو دیگر', 'dedupe_key' => hash('sha256', 'other-notification')]);
        $this->memberLogin($member);
        $this->get('/app/notifications')->assertOk()->assertSee('اطلاعیه رسمی');
        $own = MemberNotification::where('recipient_id', $member->account_id)->sole();
        $this->post('/app/notifications/'.$own->public_id.'/read')->assertRedirect();
        $this->assertNotNull($own->fresh()->read_at);
        $this->post('/app/notifications/'.$otherNotification->public_id.'/read')->assertNotFound();
    }

    public function test_signal_outbox_dispatch_is_idempotent(): void
    {
        $member = $this->activeMember();
        $market = Market::create(['key' => 'notify_'.strtolower(Str::random(8)), 'title' => 'بازار اعلان', 'created_by' => $this->owner->id]);
        $asset = Asset::create(['market_id' => $market->id, 'symbol' => 'NTF'.strtoupper(Str::random(3)), 'title' => 'دارایی اعلان', 'created_by' => $this->owner->id]);
        $signal = app(ManageSignals::class)->create($this->owner, $this->sensitive(['title' => 'سیگنال اعلان', 'market_id' => $market->id, 'asset_id' => $asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100', 'entry_high' => null, 'stop_loss' => '90', 'timeframe' => 'روزانه', 'body' => 'توضیح', 'risk_label' => null, 'expires_at' => null, 'targets' => [['price' => '110', 'weight' => '1']]]));
        app(ManageSignals::class)->transition($this->owner, $signal, $this->sensitive(['status' => 'published', 'idempotency_key' => (string) Str::uuid(), 'announce_change' => false]));

        $first = app(DispatchNotifications::class)->run();
        $second = app(DispatchNotifications::class)->run();
        $this->assertSame(1, $first['signals']);
        $this->assertSame(0, $second['signals']);
        $this->assertSame(1, MemberNotification::where('recipient_id', $member->account_id)->where('kind', 'signal')->count());
        $this->assertSame('dispatched', SignalAnnouncement::sole()->status);
    }

    public function test_expiry_member_and_admin_notifications_are_deduplicated(): void
    {
        $ending = $this->activeMember();
        $ending->subscription()->update(['ends_at' => now()->addDays(2)]);
        $expired = $this->activeMember();
        $expired->subscription()->update(['starts_at' => now()->subMonth(), 'ends_at' => now()->subMinute()]);

        $first = app(DispatchNotifications::class)->run();
        $second = app(DispatchNotifications::class)->run();
        $this->assertSame(2, $first['expiry']);
        $this->assertSame(0, $second['expiry']);
        $this->assertSame(1, MemberNotification::where('recipient_id', $ending->account_id)->where('kind', 'subscription')->count());
        $this->assertSame(1, MemberNotification::where('recipient_id', $this->owner->id)->where('kind', 'administrative')->count());
    }

    public function test_unavailable_notification_sms_records_failure_without_fake_success(): void
    {
        config(['notifications.sms_enabled' => true]);
        $member = $this->activeMember();
        $member->subscription()->update(['ends_at' => now()->addDay()]);

        $result = app(DispatchNotifications::class)->run();
        $delivery = NotificationDelivery::sole();
        $this->assertSame(0, $result['sms']);
        $this->assertSame('failed', $delivery->status);
        $this->assertSame('provider_unavailable', $delivery->error_code);
        $this->assertSame(1, $delivery->attempts);
        $this->assertNull($delivery->sent_at);
        $this->assertNotNull($delivery->next_retry_at);
    }

    public function test_content_manager_is_allowed_and_viewer_is_denied_by_server(): void
    {
        $contentPassword = Str::random(32);
        $content = Account::create(['kind' => 'admin', 'username' => 'content_manager_'.strtolower(Str::random(7)), 'password_hash' => $contentPassword]);
        $content->roles()->attach(Role::where('key', 'content_manager')->firstOrFail());
        $this->adminLogin($content, $contentPassword);
        $this->get('/admin/content')->assertOk();

        $viewerPassword = Str::random(32);
        $viewer = Account::create(['kind' => 'admin', 'username' => 'content_viewer_'.strtolower(Str::random(7)), 'password_hash' => $viewerPassword]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->firstOrFail());
        $this->adminLogin($viewer, $viewerPassword);
        $this->get('/admin/content')->assertForbidden();
        $this->postJson('/admin/content/pages', $this->pageData(['current_password' => $viewerPassword]))->assertForbidden();
    }
}
