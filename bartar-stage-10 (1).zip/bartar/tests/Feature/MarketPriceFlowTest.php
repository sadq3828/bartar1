<?php

namespace Tests\Feature;

use App\Modules\AuditLogs\Models\AuditLog;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use App\Modules\MarketPrices\Actions\ManageMarketPrices;
use App\Modules\MarketPrices\Actions\RefreshMarketPrices;
use App\Modules\MarketPrices\Actions\ResolveEffectivePrice;
use App\Modules\MarketPrices\Contracts\PriceProviderRegistry;
use App\Modules\MarketPrices\Models\PriceFetchRun;
use App\Modules\MarketPrices\Models\PriceObservation;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use Carbon\CarbonImmutable;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Tests\Support\StubPriceProviderRegistry;
use Tests\TestCase;
use PDO;

class MarketPriceFlowTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;
    private Market $market;
    private Asset $asset;
    private PriceSource $source;
    private string $password;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'price_owner_'.strtolower(Str::random(8)), 'password_hash' => $this->password]);
        $this->owner->roles()->attach(Role::where('key', 'owner')->firstOrFail());
        $this->market = Market::create(['key' => 'price_'.strtolower(Str::random(8)), 'title' => 'بازار قیمت', 'trade_type' => 'spot', 'created_by' => $this->owner->id]);
        $this->asset = Asset::create(['market_id' => $this->market->id, 'symbol' => strtoupper(Str::random(6)), 'title' => 'دارایی قیمت', 'price_unit' => 'IRT', 'quantity_unit' => 'COIN', 'price_scale' => 12, 'created_by' => $this->owner->id]);
        $this->source = PriceSource::create(['market_id' => $this->market->id, 'key' => 'source_'.strtolower(Str::random(8)), 'title' => 'منبع آزمون', 'driver' => 'unavailable', 'enabled' => true, 'refresh_seconds' => 60, 'stale_after_seconds' => 180, 'created_by' => $this->owner->id]);
    }

    private function sensitive(array $extra = []): array
    {
        return array_merge(['current_password' => $this->password, 'reason' => 'authorized market price integration test'], $extra);
    }

    private function manual(array $extra = [])
    {
        return app(ManageMarketPrices::class)->recordManualOverride($this->owner, $this->asset, $this->sensitive(array_merge(['value' => '9007199254740993.123456789012', 'observed_at' => now()->toImmutable(), 'starts_at' => now()->subMinute()->toImmutable(), 'ends_at' => now()->addHour()->toImmutable()], $extra)));
    }

    private function apiObservation(string $value, CarbonImmutable $observedAt): PriceObservation
    {
        return PriceObservation::create(['asset_id' => $this->asset->id, 'source_id' => $this->source->id, 'source_kind' => 'api', 'value' => $value, 'unit' => 'IRT', 'observed_at' => $observedAt, 'received_at' => now()]);
    }

    private function adminLogin(Account $account, string $password): void
    {
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $account->username, 'password' => $password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    public function test_manual_price_is_exact_audited_prioritized_and_append_only(): void
    {
        $this->apiObservation('120.000000000000', now()->subMinute()->toImmutable());
        $override = $this->manual();
        $quote = app(ResolveEffectivePrice::class)->for($this->asset);

        $this->assertSame('9007199254740993.123456789012', $quote['value']);
        $this->assertSame('IRT', $quote['unit']);
        $this->assertSame('manual', $quote['status']);
        $this->assertSame($this->owner->id, $override->actor_id);
        $this->assertDatabaseHas('audit_logs', ['actor_id' => $this->owner->id, 'action' => 'price.manual.activated', 'reason' => 'authorized market price integration test']);

        $this->expectException(QueryException::class);
        DB::table('price_observations')->where('id', $override->observation_id)->update(['value' => '1']);
    }

    public function test_override_overlap_is_rejected_and_revoke_falls_back_to_api(): void
    {
        $this->apiObservation('125.5', now()->subSeconds(10)->toImmutable());
        $override = $this->manual(['value' => '130']);
        try {
            $this->manual(['value' => '131', 'starts_at' => now()->toImmutable(), 'ends_at' => now()->addMinutes(30)->toImmutable()]);
            $this->fail('Overlapping overrides must be rejected.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('starts_at', $exception->errors());
        }

        app(ManageMarketPrices::class)->revokeOverride($this->owner, $this->asset, $override, $this->sensitive(['reason' => 'اصلاح قیمت دستی آزمون']));
        $quote = app(ResolveEffectivePrice::class)->for($this->asset);
        $this->assertSame('api', $quote['source_kind']);
        $this->assertSame('125.500000000000', $quote['value']);
        $this->assertNotNull($override->fresh()->revoked_at);
        $this->assertDatabaseHas('audit_logs', ['action' => 'price.manual.revoked', 'actor_id' => $this->owner->id]);
    }

    public function test_freshness_boundary_missing_data_and_future_manual_time_are_explicit(): void
    {
        $this->travelTo(CarbonImmutable::parse('2026-10-20T10:00:00Z'));
        $this->apiObservation('100', now()->subSeconds(179)->toImmutable());
        $this->assertSame('fresh', app(ResolveEffectivePrice::class)->for($this->asset)['status']);
        $this->travel(2)->seconds();
        $this->assertSame('stale', app(ResolveEffectivePrice::class)->for($this->asset)['status']);

        $other = Asset::create(['market_id' => $this->market->id, 'symbol' => 'EMPTY'.strtoupper(Str::random(3)), 'title' => 'بدون قیمت', 'price_unit' => 'IRT', 'created_by' => $this->owner->id]);
        $missing = app(ResolveEffectivePrice::class)->for($other);
        $this->assertFalse($missing['available']);
        $this->assertNull($missing['value']);

        $this->expectException(ValidationException::class);
        $this->manual(['observed_at' => now()->addMinutes(6)->toImmutable()]);
    }

    public function test_provider_success_and_malformed_failure_are_atomic_and_traceable(): void
    {
        $stub = new StubPriceProviderRegistry;
        app()->instance(PriceProviderRegistry::class, $stub);
        $stub->payload = [['asset_id' => $this->asset->public_id, 'value' => '123456.123456789012', 'unit' => 'IRT', 'observed_at' => now()->toIso8601String()]];
        $this->assertSame('succeeded', app(RefreshMarketPrices::class)->source($this->source));
        $this->assertDatabaseHas('price_fetch_runs', ['source_id' => $this->source->id, 'status' => 'succeeded', 'observation_count' => 1]);
        $this->assertSame('123456.123456789012', PriceObservation::where('source_id', $this->source->id)->sole()->value);

        $before = PriceObservation::count();
        $stub->payload = [['asset_id' => $this->asset->public_id, 'value' => '0', 'unit' => 'IRT', 'observed_at' => now()->toIso8601String()]];
        $this->assertSame('failed', app(RefreshMarketPrices::class)->source($this->source->fresh()));
        $this->assertSame($before, PriceObservation::count());
        $this->assertSame('invalid_payload', $this->source->fresh()->last_error_code);
        $this->assertNotNull(PriceFetchRun::latest('id')->first()->next_retry_at);
    }

    public function test_nobitex_public_api_converts_rials_to_exact_tomans(): void
    {
        $this->source->update(['driver' => 'nobitex_public']);
        Http::fake(['apiv2.nobitex.ir/market/stats*' => Http::response([
            'status' => 'ok',
            'stats' => [strtolower($this->asset->symbol).'-rls' => ['latest' => '1234567890']],
        ])]);

        $this->assertSame('succeeded', app(RefreshMarketPrices::class)->source($this->source->fresh()));
        $observation = PriceObservation::where('source_id', $this->source->id)->sole();
        $this->assertSame('123456789.000000000000', $observation->value);
        $this->assertSame('IRT', $observation->unit);
        Http::assertSent(fn ($request) => str_starts_with($request->url(), 'https://apiv2.nobitex.ir/market/stats?')
            && $request['srcCurrency'] === strtolower($this->asset->symbol)
            && $request['dstCurrency'] === 'rls');
    }

    public function test_binance_public_api_uses_keyless_market_data_endpoint(): void
    {
        $this->asset->update(['price_unit' => 'USDT']);
        $this->source->update(['driver' => 'binance_public']);
        Http::fake(['data-api.binance.vision/api/v3/ticker/price*' => Http::response([
            ['symbol' => $this->asset->symbol.'USDT', 'price' => '98765.123456789012'],
        ])]);

        $this->assertSame('succeeded', app(RefreshMarketPrices::class)->source($this->source->fresh()));
        $observation = PriceObservation::where('source_id', $this->source->id)->sole();
        $this->assertSame('98765.123456789012', $observation->value);
        $this->assertSame('USDT', $observation->unit);
        Http::assertSent(fn ($request) => str_starts_with($request->url(), 'https://data-api.binance.vision/api/v3/ticker/price?')
            && str_contains($request['symbols'], $this->asset->symbol.'USDT'));
    }

    public function test_public_provider_rate_limit_is_recorded_without_fake_observation(): void
    {
        $this->travelTo(CarbonImmutable::parse('2026-10-20T10:00:00Z'));
        $this->source->update(['driver' => 'nobitex_public', 'refresh_seconds' => 30]);
        Http::fake(['apiv2.nobitex.ir/*' => Http::response(['status' => 'failed'], 429)]);

        $this->assertSame('failed', app(RefreshMarketPrices::class)->source($this->source->fresh()));
        $this->assertSame('provider_rate_limited', $this->source->fresh()->last_error_code);
        $this->assertDatabaseCount('price_observations', 0);
        $this->assertNotNull(PriceFetchRun::latest('id')->first()->next_retry_at);
        $this->travel(31)->seconds();
        $this->assertSame([], app(RefreshMarketPrices::class)->due());
        Http::assertSentCount(1);
        $this->travel(30)->seconds();
        $this->assertSame('failed', app(RefreshMarketPrices::class)->due()[$this->source->key]);
        Http::assertSentCount(2);
    }

    public function test_unconfigured_provider_fails_closed_and_due_refresh_respects_interval(): void
    {
        $this->assertSame('failed', app(RefreshMarketPrices::class)->source($this->source));
        $this->assertSame('provider_unavailable', $this->source->fresh()->last_error_code);
        $this->assertSame([], app(RefreshMarketPrices::class)->due());
        $this->assertDatabaseCount('price_observations', 0);
        $this->assertTrue(AuditLog::where('action', 'price.fetch.failed')->where('actor_kind', 'system')->exists());
    }

    public function test_source_lock_skips_an_overlapping_refresh_without_calling_provider(): void
    {
        $database = config('database.connections.mysql');
        $pdo = new PDO('mysql:host='.$database['host'].';port='.$database['port'].';dbname='.$database['database'], $database['username'], $database['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $lockName = 'bartar-price-'.substr(hash('sha256', (string) $this->source->id), 0, 40);
        $statement = $pdo->prepare('SELECT GET_LOCK(?, 0)');
        $statement->execute([$lockName]);
        $this->assertSame(1, (int) $statement->fetchColumn());

        try {
            $this->assertSame('skipped', app(RefreshMarketPrices::class)->source($this->source));
            $this->assertDatabaseHas('price_fetch_runs', ['source_id' => $this->source->id, 'status' => 'skipped', 'error_code' => 'overlap']);
            $this->assertDatabaseCount('price_observations', 0);
        } finally {
            $release = $pdo->prepare('SELECT RELEASE_LOCK(?)');
            $release->execute([$lockName]);
        }
    }

    public function test_price_permissions_and_admin_member_views_do_not_fake_values(): void
    {
        $viewerPassword = Str::random(32);
        $viewer = Account::create(['kind' => 'admin', 'username' => 'price_viewer_'.strtolower(Str::random(8)), 'password_hash' => $viewerPassword]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->firstOrFail());
        $this->adminLogin($viewer, $viewerPassword);
        $this->get('/admin/markets')->assertOk()->assertSee('قیمت ناموجود');
        $this->postJson('/admin/assets/'.$this->asset->public_id.'/prices/manual', ['value' => '100', 'observed_at' => '2026-10-20T12:00', 'starts_at' => '2026-10-20T12:00', 'ends_at' => '2026-10-20T13:00'] + $this->sensitive(['current_password' => $viewerPassword]))->assertForbidden();

        $this->adminLogin($this->owner, $this->password);
        $this->get('/admin/markets')->assertOk()->assertSee('API عمومی واقعی')->assertDontSee('>0 IRT<', false);
    }
}
