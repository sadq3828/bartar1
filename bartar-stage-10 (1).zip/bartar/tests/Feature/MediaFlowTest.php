<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Media\Actions\ManageSignalMedia;
use App\Modules\Media\Models\MediaFile;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalRevision;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\Plan;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Tests\Support\CapturingOtpSender;
use Tests\TestCase;

class MediaFlowTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;
    private Market $market;
    private Asset $asset;
    private Signal $signal;
    private Member $member;
    private CapturingOtpSender $sender;
    private string $password;
    private string $png;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        Storage::fake('signal-media');
        config(['membership.otp_key' => bin2hex(random_bytes(32))]);
        $this->sender = new CapturingOtpSender;
        app()->instance(OtpSender::class, $this->sender);
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'media_owner_'.strtolower(Str::random(8)), 'password_hash' => $this->password]);
        $this->owner->roles()->attach(Role::where('key', 'owner')->firstOrFail());
        $this->market = Market::create(['key' => 'media_'.strtolower(Str::random(8)), 'title' => 'بازار رسانه', 'created_by' => $this->owner->id]);
        $this->asset = Asset::create(['market_id' => $this->market->id, 'symbol' => strtoupper(Str::random(6)), 'title' => 'دارایی رسانه', 'created_by' => $this->owner->id]);
        $this->signal = $this->publish(app(ManageSignals::class)->create($this->owner, $this->signalFields()));
        $this->member = app(ManageMembers::class)->create($this->owner, $this->sensitive() + ['phone' => '+989'.random_int(100000000, 999999999), 'display_name' => 'عضو رسانه']);
        $this->png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=', true);
    }

    private function sensitive(array $extra = []): array
    {
        return array_merge(['current_password' => $this->password, 'reason' => 'authorized media integration test'], $extra);
    }

    private function signalFields(): array
    {
        return $this->sensitive(['title' => 'سیگنال رسانه', 'market_id' => $this->market->id, 'asset_id' => $this->asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100', 'entry_high' => '105', 'stop_loss' => '90', 'timeframe' => 'روزانه', 'body' => 'تحلیل همراه رسانه', 'risk_label' => 'متوسط', 'expires_at' => null, 'targets' => [['price' => '110', 'weight' => '1']]]);
    }

    private function publish(Signal $signal): Signal
    {
        return app(ManageSignals::class)->transition($this->owner, $signal, $this->sensitive(['status' => 'published', 'idempotency_key' => (string) Str::uuid(), 'announce_change' => false]));
    }

    private function image(string $name = 'analysis.png'): UploadedFile
    {
        return UploadedFile::fake()->createWithContent($name, $this->png);
    }

    private function upload(string $caption = 'نمودار تحلیل')
    {
        return app(ManageSignalMedia::class)->upload($this->owner, $this->signal->fresh(), $this->image(), $this->sensitive(['kind' => 'image', 'caption' => $caption, 'announce_change' => false]));
    }

    private function adminLogin(?Account $account = null, ?string $password = null): void
    {
        $account ??= $this->owner;
        $password ??= $this->password;
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $account->username, 'password' => $password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    private function grantAndLogin(): void
    {
        app(ManageSubscriptions::class)->grant($this->owner, $this->member, $this->sensitive(['operation' => 'activate', 'months' => 1, 'calendar' => 'persian', 'plan_id' => Plan::where('key', 'standard')->sole()->id, 'idempotency_key' => (string) Str::uuid()]));
        Auth::forgetGuards();
        $this->post('/login', ['phone' => $this->member->phone_e164])->assertRedirect('/login/verify');
        $this->withCookie('bartar_member_session', session()->getId());
        $this->post('/login/verify', ['code' => $this->sender->code()])->assertRedirect('/app');
        $this->withCookie('bartar_member_session', session()->getId());
    }

    public function test_valid_image_is_verified_hashed_and_stored_only_on_private_disk(): void
    {
        $this->adminLogin();
        $this->post('/admin/signals/'.$this->signal->public_id.'/media', $this->sensitive(['kind' => 'image', 'caption' => 'نمودار معتبر', 'media' => $this->image()]))->assertRedirect();
        $media = MediaFile::sole();
        $this->assertSame('ready', $media->state);
        $this->assertSame('image/png', $media->mime);
        $this->assertSame(hash('sha256', $this->png), $media->sha256);
        $this->assertStringStartsWith('objects/', $media->object_key);
        Storage::disk('signal-media')->assertExists($media->object_key);
        Storage::disk('public')->assertMissing($media->object_key);
        $this->assertDatabaseHas('signal_media', ['signal_id' => $this->signal->id, 'media_file_id' => $media->id, 'position' => 1]);
        $this->assertStringNotContainsString('analysis.png', DB::table('audit_logs')->get()->toJson());
    }

    public function test_spoofed_and_oversized_uploads_are_rejected_without_residue(): void
    {
        $spoof = UploadedFile::fake()->createWithContent('attack.png', '<html><script>alert(1)</script></html>');
        try {
            app(ManageSignalMedia::class)->upload($this->owner, $this->signal, $spoof, $this->sensitive(['kind' => 'image']));
            $this->fail('Spoofed content must not be accepted by its extension.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('media', $exception->errors());
        }
        config(['media.max_upload_bytes' => 16]);
        try {
            app(ManageSignalMedia::class)->upload($this->owner, $this->signal, $this->image(), $this->sensitive(['kind' => 'image']));
            $this->fail('Oversized content must not be accepted.');
        } catch (ValidationException $exception) {
            $this->assertArrayHasKey('media', $exception->errors());
        }
        $this->assertDatabaseCount('media_files', 0);
        $this->assertSame([], Storage::disk('signal-media')->allFiles());
    }

    public function test_active_member_can_stream_full_and_single_ranges_but_anonymous_cannot(): void
    {
        $attachment = $this->upload();
        $url = '/private/media/'.$attachment->mediaFile->public_id;
        $this->get($url)->assertRedirect('/login');
        $this->grantAndLogin();
        $this->assertTrue(Signal::memberVisible()->whereKey($this->signal->id)->exists());
        $this->assertDatabaseHas('signal_media', ['media_file_id' => $attachment->mediaFile->id]);
        $this->assertTrue(Storage::disk('signal-media')->exists($attachment->mediaFile->object_key));
        $this->assertSame('ready', $attachment->mediaFile->fresh()->state);
        $this->assertNotNull($attachment->mediaFile->fresh()->verified_at);
        $full = $this->get($url)->assertOk()->assertHeader('Accept-Ranges', 'bytes')->assertHeader('Content-Type', 'image/png');
        $this->assertSame($this->png, $full->streamedContent());
        $partial = $this->withHeader('Range', 'bytes=0-9')->get($url)->assertStatus(206)->assertHeader('Content-Range', 'bytes 0-9/'.strlen($this->png));
        $this->assertSame(substr($this->png, 0, 10), $partial->streamedContent());
        $suffix = $this->withHeader('Range', 'bytes=-7')->get($url)->assertStatus(206);
        $this->assertSame(substr($this->png, -7), $suffix->streamedContent());
        $this->withHeader('Range', 'bytes=0-1,3-4')->get($url)->assertStatus(416)->assertHeader('Content-Range', 'bytes */'.strlen($this->png));
    }

    public function test_membership_cutoff_and_detach_immediately_remove_stream_access(): void
    {
        $attachment = $this->upload();
        $url = '/private/media/'.$attachment->mediaFile->public_id;
        $this->grantAndLogin();
        $this->get($url)->assertOk();
        app(ManageMembers::class)->block($this->owner, $this->member, $this->sensitive(['blocked' => true]));
        $this->get($url)->assertRedirect('/login');
        app(ManageSignalMedia::class)->remove($this->owner, $this->signal->fresh(), $attachment, $this->sensitive(['announce_change' => false]));
        $this->assertSame('deleted', $attachment->mediaFile->fresh()->state);
        Storage::disk('signal-media')->assertExists($attachment->mediaFile->object_key);
        $this->adminLogin();
        $this->get('/admin/media/'.$attachment->mediaFile->public_id)->assertNotFound();
    }

    public function test_reorder_and_delete_preserve_published_versions_and_viewer_cannot_mutate(): void
    {
        $first = $this->upload('اول');
        $second = $this->upload('دوم');
        app(ManageSignalMedia::class)->reorder($this->owner, $this->signal->fresh(), [$second->public_id, $first->public_id], $this->sensitive(['announce_change' => true]));
        $this->assertSame([$second->public_id, $first->public_id], $this->signal->mediaAttachments()->orderBy('position')->pluck('public_id')->all());
        $this->assertSame(4, $this->signal->fresh()->version);
        $revision = SignalRevision::where('signal_id', $this->signal->id)->where('version', 3)->sole();
        $this->assertSame([$first->public_id, $second->public_id], collect($revision->snapshot_json['media'])->pluck('public_id')->all());

        $viewerPassword = Str::random(32);
        $viewer = Account::create(['kind' => 'admin', 'username' => 'media_viewer_'.strtolower(Str::random(8)), 'password_hash' => $viewerPassword]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->firstOrFail());
        $this->adminLogin($viewer, $viewerPassword);
        $this->get('/admin/media/'.$first->mediaFile->public_id)->assertForbidden();
        $this->postJson('/admin/signals/'.$this->signal->public_id.'/media', $this->sensitive(['current_password' => $viewerPassword, 'kind' => 'image', 'media' => $this->image()]))->assertForbidden();
        $this->deleteJson('/admin/signals/'.$this->signal->public_id.'/media/'.$first->public_id, $this->sensitive(['current_password' => $viewerPassword]))->assertForbidden();
    }
}
