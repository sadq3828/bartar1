<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Reports\Actions\CalculateSignalReturn;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\Signals\Models\SignalResult;
use App\Modules\Signals\Models\SignalRevision;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\Plan;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Tests\TestCase;

final class StageNineUpgradeTest extends TestCase
{
    public function test_stage_eight_schema_upgrades_without_rewriting_business_or_result_history(): void
    {
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $original = config('database.default');
        $name = 'bartar_upgrade_test_'.strtolower(Str::random(10));
        DB::statement('CREATE DATABASE `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $connection = config('database.connections.'.$original);
        $connection['database'] = $name;
        config(['database.connections.upgrade_test' => $connection]);
        DB::setDefaultConnection('upgrade_test');
        try {
            // Original stage-eight migrations are byte-identical to the input ZIP.
            $paths = array_values(array_filter(glob(database_path('migrations/*.php')), fn ($p) => basename($p) < '2026_10_20_000007'));
            $this->assertSame(0, Artisan::call('migrate', ['--path' => $paths, '--realpath' => true, '--force' => true]));
            Artisan::call('db:seed', ['--force' => true]);
            // Simulate the actual stage-eight authorization metadata as well.
            $newPermission = DB::table('permissions')->where('key', 'backups.view')->value('id');
            DB::table('role_permissions')->where('permission_id', $newPermission)->delete();
            DB::table('permissions')->where('id', $newPermission)->delete();
            $this->assertFalse(Schema::hasTable('backup_runs'));
            $password = Str::random(40);
            $owner = Account::create(['kind' => 'admin', 'username' => 'upgrade_owner', 'password_hash' => $password]);
            $owner->roles()->attach(Role::where('key', 'owner')->sole());
            $sensitive = ['current_password' => $password, 'reason' => 'Authorized isolated upgrade test'];
            $member = app(ManageMembers::class)->create($owner, $sensitive + ['phone' => '+989'.random_int(100000000, 999999999), 'display_name' => 'عضو آزمون ارتقا']);
            app(ManageSubscriptions::class)->grant($owner, $member, $sensitive + ['operation' => 'activate', 'months' => 1, 'calendar' => 'persian', 'plan_id' => Plan::where('key', 'standard')->sole()->id, 'idempotency_key' => (string) Str::uuid()]);
            $market = Market::create(['key' => 'upgrade', 'title' => 'بازار ارتقا', 'created_by' => $owner->id]);
            $asset = Asset::create(['market_id' => $market->id, 'symbol' => 'UPG', 'title' => 'دارایی ارتقا', 'created_by' => $owner->id]);
            $signal = Signal::create(['title' => 'سیگنال قدیمی', 'market_id' => $market->id, 'asset_id' => $asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100', 'timeframe' => 'روزانه', 'body_sanitized' => 'مرحله هشت', 'status' => 'completed', 'version' => 2, 'created_by' => $owner->id, 'published_by' => $owner->id, 'published_at' => now()->subDay()]);
            SignalRevision::create(['signal_id' => $signal->id, 'version' => 1, 'snapshot_json' => ['formula_version' => 'pending-v1', 'signal' => ['direction' => 'buy', 'entry_low' => '100', 'entry_high' => null]], 'reason' => 'Legacy result', 'actor_id' => $owner->id, 'changed_at' => now(), 'announce_change' => false]);
            $result = SignalResult::create(['signal_id' => $signal->id, 'version' => 2, 'method' => 'manual', 'entry_execution_price' => '100', 'coverage_ratio' => '1', 'recorded_by' => $owner->id, 'idempotency_key' => (string) Str::uuid(), 'request_hash' => hash('sha256', Str::random(30))]);
            $result->exits()->create(['position' => 1, 'exit_price' => '110', 'exit_weight' => '1']);
            SignalAnnouncement::create(['signal_id' => $signal->id, 'signal_version' => 1, 'event_type' => 'published', 'safe_payload' => ['signal_id' => $signal->public_id], 'status' => 'pending', 'available_at' => now()]);
            $tables = ['accounts', 'members', 'subscriptions', 'subscription_renewals', 'markets', 'assets', 'signals', 'signal_revisions', 'signal_results', 'signal_exits', 'signal_announcements'];
            $before = [];
            foreach ($tables as $table) {
                $before[$table] = DB::table($table)->orderBy('id')->get()->toJson();
            }
            $this->assertSame(0, Artisan::call('migrate', ['--force' => true]));
            $this->assertTrue(Role::where('key', 'technical')->sole()->permissions()->where('key', 'backups.view')->exists());
            foreach ($before as $table => $bytes) {
                $this->assertSame($bytes, DB::table($table)->orderBy('id')->get()->toJson(), $table.' changed during upgrade');
            }
            $this->assertTrue($member->fresh()->eligible());
            $this->assertSame(0, Artisan::call('reports:calculate'));
            $calculation = app(CalculateSignalReturn::class)->persist($result);
            $this->assertSame('10.00000000', $calculation->final_return);
            $this->assertSame('pending-v1', $result->fresh()->formula_version);
            foreach (['signal_result_calculations', 'backup_runs', 'backup_restore_runs', 'operation_heartbeats'] as $table) {
                $this->assertTrue(Schema::hasTable($table));
            }
        } finally {
            DB::purge('upgrade_test');
            DB::setDefaultConnection($original);
            DB::statement('DROP DATABASE `'.$name.'`');
        }
    }
}
