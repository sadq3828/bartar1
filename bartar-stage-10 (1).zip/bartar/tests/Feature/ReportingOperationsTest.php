<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Permission;
use App\Modules\Authorization\Models\Role;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Reports\Actions\CalculateSignalReturn;
use App\Modules\Reports\Actions\PerformanceReport;
use App\Modules\Reports\Http\Controllers\PerformanceController;
use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\Signals\Models\Signal;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\Plan;
use App\Modules\SystemHealth\Actions\SystemHealth;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\Support\CapturingOtpSender;
use Tests\TestCase;

final class ReportingOperationsTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;

    private string $password;

    private Asset $asset;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'report_'.Str::lower(Str::random(8)), 'password_hash' => $this->password]);
        $this->owner->roles()->attach(Role::where('key', 'owner')->sole());
        $market = Market::create(['key' => 'r_'.Str::lower(Str::random(8)), 'title' => 'بازار گزارش', 'created_by' => $this->owner->id]);
        $this->asset = Asset::create(['market_id' => $market->id, 'symbol' => 'RPT', 'title' => 'دارایی گزارش', 'created_by' => $this->owner->id]);
    }

    private function data(array $extra = []): array
    {
        return $extra + ['current_password' => $this->password, 'reason' => 'Authorized report integration test'];
    }

    private function signal(string $title = 'گزارش واقعی'): Signal
    {
        $m = app(ManageSignals::class);
        $signal = $m->create($this->owner, $this->data(['title' => $title, 'market_id' => $this->asset->market_id, 'asset_id' => $this->asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100', 'entry_high' => '105', 'stop_loss' => '90', 'timeframe' => 'روزانه', 'body' => 'متن آزمون', 'targets' => [['price' => '110']]]));

        return $m->transition($this->owner, $signal, $this->data(['status' => 'published', 'idempotency_key' => (string) Str::uuid()]));
    }

    private function recordOutcome(Signal $signal, string $price = '110', string $weight = '1')
    {
        return app(ManageSignals::class)->recordResult($this->owner, $signal, $this->data(['method' => 'manual', 'entry_execution_price' => '100', 'coverage_ratio' => $weight, 'exits' => [['price' => $price, 'weight' => $weight]], 'idempotency_key' => (string) Str::uuid()]));
    }

    private function login(?Account $account = null): void
    {
        $account ??= $this->owner;
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $account->username, 'password' => $this->password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    public function test_result_corrections_preserve_calculations_and_use_latest_once(): void
    {
        $signal = $this->signal();
        $first = $this->recordOutcome($signal);
        $second = $this->recordOutcome($signal->fresh(), '90');
        $this->assertSame('10.00000000', app(CalculateSignalReturn::class)->persist($first)->final_return);
        $this->assertSame('-10.00000000', app(CalculateSignalReturn::class)->persist($second)->final_return);
        $this->assertDatabaseCount('signal_result_calculations', 2);
        $stats = app(PerformanceReport::class)->summary([]);
        $this->assertSame(1, $stats['n']);
        $this->assertSame(1, $stats['negative']);
        $this->assertSame('0.00', $stats['success_rate']);
        $this->expectException(QueryException::class);
        DB::table('signal_result_calculations')->where('signal_result_id', $first->id)->update(['final_return' => '999']);
    }

    public function test_denominator_includes_zero_and_excludes_partial_cancelled_expired(): void
    {
        $this->recordOutcome($this->signal(), '110');
        $this->recordOutcome($this->signal(), '100');
        $this->recordOutcome($this->signal(), '110', '0.5');
        foreach (['cancelled', 'expired'] as $status) {
            $s = $this->signal();
            app(ManageSignals::class)->transition($this->owner, $s, $this->data(['status' => $status, 'idempotency_key' => (string) Str::uuid()]));
        }
        $stats = app(PerformanceReport::class)->summary([]);
        $this->assertSame(5, $stats['total']);
        $this->assertSame(2, $stats['n']);
        $this->assertSame(1, $stats['zero']);
        $this->assertSame(1, $stats['incomplete']);
        $this->assertSame('50.00', $stats['success_rate']);
    }

    public function test_entry_range_without_execution_stays_unavailable_and_historical_direction_is_used(): void
    {
        $signal = $this->signal();
        $result = app(ManageSignals::class)->recordResult($this->owner, $signal, $this->data(['method' => 'manual', 'exits' => [['price' => '110', 'weight' => '1']], 'idempotency_key' => (string) Str::uuid()]));
        $this->assertSame('entry_execution_required', app(CalculateSignalReturn::class)->preview($result)['reason_code']);
        $result = $this->recordOutcome($signal->fresh());
        // Subsequent mutable signal values cannot rewrite immutable inputs.
        $signal->fresh()->update(['direction' => 'sell']);
        $this->assertSame('10.00000000', app(CalculateSignalReturn::class)->preview($result)['final_return']);
    }

    public function test_filters_use_tehran_date_and_empty_n_is_null(): void
    {
        $signal = $this->signal();
        $signal->update(['published_at' => '2026-10-19 20:45:00']);
        $r = app(PerformanceReport::class);
        $this->assertSame(1, $r->summary(['from' => '2026-10-20', 'to' => '2026-10-20'])['total']);
        $this->assertSame(0, $r->summary(['to' => '2026-10-19'])['total']);
        $this->assertNull($r->summary(['status' => 'completed'])['success_rate']);
        $this->login();
        $this->get('/admin/reports?to=2026-10-19')->assertOk()->assertSee('داده‌ای برای این بازه وجود ندارد');
    }

    public function test_report_html_csv_permissions_reauthentication_and_formula_injection(): void
    {
        $this->recordOutcome($this->signal('=HYPERLINK("https://invalid.test")'));
        $this->login();
        $this->get('/admin/reports')->assertOk()->assertSee('10.00000000')->assertSee('نتیجهٔ کامل');
        $this->post('/admin/reports/export', $this->data(['current_password' => 'wrong']))->assertSessionHasErrors('current_password');
        $response = $this->post('/admin/reports/export', $this->data());
        $response->assertOk();
        $csv = $response->streamedContent();
        $this->assertStringContainsString("'=HYPERLINK", $csv);
        $this->assertStringNotContainsString('phone', $csv);
        $this->assertStringNotContainsString('password', $csv);
        $this->assertSame("' \t+SUM(A1)", PerformanceController::csvCell(" \t+SUM(A1)"));
        $viewer = Account::create(['kind' => 'admin', 'username' => 'v_'.Str::lower(Str::random(8)), 'password_hash' => $this->password]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->sole());
        $this->login($viewer);
        $this->get('/admin/reports')->assertOk();
        $this->post('/admin/reports/export', $this->data())->assertForbidden();
        $this->get('/admin/health')->assertForbidden();
        $this->get('/admin/backups')->assertForbidden();
        $this->post('/admin/backups', $this->data())->assertForbidden();
    }

    public function test_health_marks_unknown_unconfigured_and_stale_explicitly_and_backup_is_queued(): void
    {
        config(['queue.default' => 'database', 'operations.backup.enabled' => false]);
        $health = app(SystemHealth::class);
        $result = $health->inspect();
        $this->assertSame('attention', $result['status']);
        $this->assertSame('unknown', $result['checks']['scheduler']);
        $this->assertSame('unknown', $result['checks']['queue_worker']);
        $this->assertSame('not_configured', $result['checks']['otp_sms']);
        $this->assertSame('not_configured', $result['checks']['backup']);
        $health->heartbeat('scheduler');
        $this->assertSame('healthy', $health->inspect()['checks']['scheduler']);
        DB::table('operation_heartbeats')->where('name', 'scheduler')->update(['seen_at' => now()->subMinutes(10)]);
        $this->assertSame('stale', $health->inspect()['checks']['scheduler']);
        $this->login();
        $this->get('/admin/health')->assertOk()->assertSee('پیکربندی نشده');
        $this->get('/admin/backups')->assertOk();
        $this->post('/admin/backups', $this->data())->assertRedirect();
        $this->assertDatabaseHas('backup_runs', ['status' => 'queued', 'requested_by' => $this->owner->id]);
        $this->post('/admin/backups', $this->data())->assertStatus(409);
        $this->owner->roles()->detach();
        $this->assertSame(1, Artisan::call('backups:work'));
        $this->assertDatabaseHas('backup_runs', ['status' => 'failed', 'error_code' => 'requester_permission_revoked']);
        $role = Role::create(['key' => 'backup_reader_'.Str::lower(Str::random(8)), 'title' => 'خواندن وضعیت بکاپ']);
        $role->permissions()->attach(Permission::where('key', 'backups.view')->sole());
        $reader = Account::create(['kind' => 'admin', 'username' => 'backup_reader_'.Str::lower(Str::random(8)), 'password_hash' => $this->password]);
        $reader->roles()->attach($role);
        $this->login($reader);
        $this->get('/admin/backups')->assertOk()->assertDontSee('درخواست بکاپ دستی');
        $this->post('/admin/backups', $this->data())->assertForbidden();
    }

    public function test_member_report_requires_current_membership_and_hides_unpublished_signals(): void
    {
        config(['membership.otp_key' => bin2hex(random_bytes(32))]);
        $sender = new CapturingOtpSender;
        app()->instance(OtpSender::class, $sender);
        $member = app(ManageMembers::class)->create($this->owner, $this->data(['phone' => '+989'.random_int(100000000, 999999999)]));
        app(ManageSubscriptions::class)->grant($this->owner, $member, $this->data(['operation' => 'activate', 'months' => 1, 'calendar' => 'persian', 'plan_id' => Plan::where('key', 'standard')->sole()->id, 'idempotency_key' => (string) Str::uuid()]));
        $this->recordOutcome($this->signal('نتیجه منتشرشده'));
        Signal::create(['title' => 'HIDDEN-DRAFT', 'market_id' => $this->asset->market_id, 'asset_id' => $this->asset->id, 'trade_type' => 'spot', 'direction' => 'buy', 'entry_low' => '100', 'timeframe' => 'روزانه', 'body_sanitized' => 'draft', 'status' => 'draft', 'version' => 1, 'created_by' => $this->owner->id]);
        $this->get('/app/performance')->assertRedirect('/login');
        Auth::forgetGuards();
        $this->post('/login', ['phone' => $member->phone_e164])->assertRedirect('/login/verify');
        $this->withCookie('bartar_member_session', session()->getId());
        $this->post('/login/verify', ['code' => $sender->code()])->assertRedirect('/app');
        $this->withCookie('bartar_member_session', session()->getId());
        $this->get('/app/performance')->assertOk()->assertSee('نتیجه منتشرشده')->assertDontSee('HIDDEN-DRAFT');
        $member->subscription()->update(['starts_at' => now()->subDay()->format('Y-m-d H:i:s.u'), 'ends_at' => now()->format('Y-m-d H:i:s.u')]);
        $this->get('/app/performance')->assertRedirect('/login');
    }
}
