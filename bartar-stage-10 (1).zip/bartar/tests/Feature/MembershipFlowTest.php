<?php

namespace Tests\Feature;

use App\Modules\Authentication\Jobs\SendMemberOtp;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Models\MemberSession;
use App\Modules\Authentication\Models\OtpChallenge;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\Authorization\Models\Role;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Members\Support\IranianPhone;
use App\Modules\SmsIntegration\Adapters\UnavailableOtpSender;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use App\Modules\Subscriptions\Actions\ManageManualPayments;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\ManualPayment;
use App\Modules\Subscriptions\Models\Plan;
use App\Modules\Subscriptions\Models\SubscriptionRenewal;
use Carbon\CarbonImmutable;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Tests\Support\CapturingOtpSender;
use Tests\TestCase;

class MembershipFlowTest extends TestCase
{
    use DatabaseTransactions;

    private Account $owner;

    private Member $member;

    private string $password;

    private CapturingOtpSender $sender;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->withCredentials();
        config(['membership.otp_key' => bin2hex(random_bytes(32))]);
        $this->sender = new CapturingOtpSender;
        app()->instance(OtpSender::class, $this->sender);
        $this->password = Str::random(32);
        $this->owner = Account::create(['kind' => 'admin', 'username' => 'owner_'.strtolower(Str::random(12)), 'password_hash' => $this->password])->fresh();
        $this->owner->roles()->attach(Role::where('key', 'owner')->firstOrFail());
        $this->member = $this->newMember();
    }

    private function newPhone(): string
    {
        return '+989'.random_int(100000000, 999999999);
    }

    private function sensitive(): array
    {
        return ['current_password' => $this->password, 'reason' => 'authorized integration test'];
    }

    private function newMember(): Member
    {
        return app(ManageMembers::class)->create($this->owner, $this->sensitive() + ['phone' => $this->newPhone(), 'display_name' => 'عضو آزمایش', 'internal_note' => 'یادداشت داخلی آزمایش']);
    }

    private function grant(?Member $member = null, array $extra = []): SubscriptionRenewal
    {
        return app(ManageSubscriptions::class)->grant($this->owner, $member ?? $this->member, array_merge($this->sensitive(), ['operation' => 'activate', 'months' => 1, 'calendar' => 'persian', 'plan_id' => Plan::where('key', 'standard')->sole()->id, 'idempotency_key' => (string) Str::uuid()], $extra));
    }

    private function adminLogin(): void
    {
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $this->owner->username, 'password' => $this->password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    private function requestOtp(?Member $member = null): void
    {
        Auth::forgetGuards();
        $this->post('/login', ['phone' => ($member ?? $this->member)->phone_e164])->assertRedirect('/login/verify');
        $this->withCookie('bartar_member_session', session()->getId());
    }

    private function memberLogin(?Member $member = null): void
    {
        $this->requestOtp($member);
        $this->post('/login/verify', ['code' => $this->sender->code()])->assertRedirect('/app');
        $this->withCookie('bartar_member_session', session()->getId());
    }

    public function test_member_creation_normalizes_encrypts_and_does_not_activate_subscription(): void
    {
        $phone = $this->member->phone_e164;
        $this->assertSame(IranianPhone::digest($phone), $this->member->phone_hash);
        $this->assertNotSame($phone, DB::table('members')->where('id', $this->member->id)->value('phone_e164'));
        $this->assertNull($this->member->account->password_hash);
        $this->assertSame('member', $this->member->account->kind);
        $this->assertFalse($this->member->eligible());
        $audit = json_encode(DB::table('audit_logs')->get());
        $this->assertStringNotContainsString($phone, $audit);
        $this->assertStringNotContainsString('یادداشت داخلی آزمایش', $audit);
        $this->adminLogin();
        $local = '0'.substr($phone, 3);
        $this->postJson('/admin/members', $this->sensitive() + ['phone' => $local])->assertUnprocessable()->assertJsonValidationErrors('phone');
        $search = $this->post('/admin/members/search', ['q' => $local, 'status' => 'all'])->assertRedirect();
        $this->assertStringNotContainsString($local, $search->headers->get('Location'));
        $this->get($search->headers->get('Location'))->assertOk()->assertSee($phone);
    }

    public function test_active_renewal_extends_from_end_and_idempotency_does_not_extend_twice(): void
    {
        $this->travelTo(CarbonImmutable::parse('2026-10-19T12:30:00Z'));
        $first = $this->grant();
        $oldEnd = $this->member->subscription()->firstOrFail()->ends_at;
        $data = $this->sensitive() + ['operation' => 'renew', 'months' => 3, 'calendar' => 'gregorian', 'plan_id' => Plan::sole()->id, 'idempotency_key' => (string) Str::uuid()];
        $manager = app(ManageSubscriptions::class);
        $renewal = $manager->grant($this->owner, $this->member, $data);
        $again = $manager->grant($this->owner, $this->member, $data);
        $this->assertTrue($renewal->base_at->equalTo($oldEnd));
        $this->assertSame($again->id, $renewal->id);
        $this->assertDatabaseCount('subscription_renewals', 2);
        $this->assertTrue($this->member->eligible());
        $this->adminLogin();
        $data['months'] = 6;
        $this->postJson('/admin/members/'.$this->member->public_id.'/subscription', $data)->assertConflict();
    }

    public function test_expired_renewal_begins_now_and_revokes_previous_sessions(): void
    {
        $this->grant();
        $this->memberLogin();
        $this->travelTo($this->member->subscription->ends_at->addSecond());
        $base = now()->toImmutable();
        $entry = $this->grant(null, ['operation' => 'renew', 'months' => 1]);
        $this->assertTrue($entry->base_at->equalTo($base));
        $this->assertSame(0, MemberSession::whereNull('revoked_at')->count());
        $this->get('/app')->assertRedirect('/login');
    }

    public function test_payment_record_and_confirmation_do_not_activate_member(): void
    {
        $this->adminLogin();
        $data = $this->sensitive() + ['amount' => '9007199254740993.25', 'unit' => 'IRT', 'paid_at' => '2026-10-19T15:30', 'method' => 'transfer', 'idempotency_key' => (string) Str::uuid()];
        $url = '/admin/members/'.$this->member->public_id.'/payments';
        $this->post($url, $data)->assertRedirect();
        $this->post($url, $data)->assertRedirect();
        $payment = ManualPayment::sole();
        $this->assertSame('9007199254740993.25', $payment->amount);
        $this->assertFalse($this->member->eligible());
        $this->assertDatabaseCount('manual_payments', 1);
        $this->post($url.'/'.$payment->public_id.'/confirm', $this->sensitive())->assertRedirect();
        $this->assertNotNull($payment->fresh()->confirmed_at);
        $this->assertFalse($this->member->eligible());
        foreach (['-1', '0.001', '1e8'] as $amount) {
            $this->postJson($url, array_merge($data, ['amount' => $amount, 'idempotency_key' => (string) Str::uuid()]))->assertUnprocessable();
        }
    }

    public function test_unknown_inactive_expired_blocked_and_revoked_members_receive_no_otp(): void
    {
        $expired = $this->newMember();
        $this->grant($expired);
        $expired->subscription()->update(['ends_at' => now()->subSecond(), 'starts_at' => now()->subMonth()]);
        $blocked = $this->newMember();
        $this->grant($blocked);
        app(ManageMembers::class)->block($this->owner, $blocked, $this->sensitive() + ['blocked' => true]);
        $revoked = $this->newMember();
        $this->grant($revoked);
        app(ManageSubscriptions::class)->revoke($this->owner, $revoked, $this->sensitive());
        foreach ([$this->newPhone(), $this->member->phone_e164, $expired->phone_e164, $blocked->phone_e164, $revoked->phone_e164] as $phone) {
            $this->postJson('/login', ['phone' => $phone])->assertStatus(202)->assertExactJson(['message' => 'اگر شماره مجاز و اشتراک معتبر باشد، کد ورود ارسال می‌شود.', 'next' => url('/login/verify')]);
        }
        $this->assertSame([], $this->sender->sent);
        $this->assertDatabaseCount('otp_challenges', 0);
    }

    public function test_valid_otp_is_hashed_bound_one_time_and_grants_member_only(): void
    {
        $this->grant();
        $before = session()->getId();
        $this->requestOtp();
        $code = $this->sender->code();
        $challenge = OtpChallenge::sole();
        $this->assertNotSame($code, $challenge->getRawOriginal('verifier_hmac'));
        $this->assertSame(64, strlen($challenge->getRawOriginal('verifier_hmac')));
        $pending = session('otp.pending');
        $this->post('/login/verify', ['code' => $code])->assertRedirect('/app');
        $this->withCookie('bartar_member_session', session()->getId());
        $this->assertNotSame($before, session()->getId());
        $this->get('/app')->assertOk()->assertSee('اشتراک فعال');
        $this->get('/api/member/status')->assertOk()->assertJsonPath('active', true);
        $this->get('/admin')->assertRedirect('/admin/login');
        $this->withSession(['otp.pending' => $pending]);
        $this->postJson('/login/verify', ['code' => $code])->assertUnprocessable();
        $this->assertDatabaseCount('member_sessions', 1);
        $this->assertNotNull($challenge->fresh()->consumed_at);
        $this->assertStringNotContainsString($code, json_encode(DB::table('audit_logs')->get()));
    }

    public function test_wrong_attempts_lock_challenge_without_storing_code_in_old_input(): void
    {
        $this->grant();
        $this->requestOtp();
        $correct = $this->sender->code();
        $wrong = $correct === '000000' ? '000001' : '000000';
        for ($i = 0; $i < 5; $i++) {
            $this->postJson('/login/verify', ['code' => $wrong])->assertUnprocessable();
        }
        $this->post('/login/verify', ['code' => $correct])->assertSessionHasErrors('code');
        $this->assertNull(session()->getOldInput('code'));
        $this->assertNotNull(OtpChallenge::sole()->invalidated_at);
        $this->assertDatabaseCount('member_sessions', 0);
    }

    public function test_expired_otp_and_different_browser_binding_are_rejected(): void
    {
        $this->grant();
        $this->requestOtp();
        $code = $this->sender->code();
        $challenge = OtpChallenge::sole();
        $challenge->update(['session_binding_hash' => AdminSession::digest(Str::random(40))]);
        $this->postJson('/login/verify', ['code' => $code])->assertUnprocessable();
        $challenge->update(['session_binding_hash' => AdminSession::digest(session()->getId()), 'expires_at' => now()]);
        $this->postJson('/login/verify', ['code' => $code])->assertUnprocessable();
        $this->assertDatabaseCount('member_sessions', 0);
    }

    public function test_resend_cooldown_invalidates_old_code_and_late_worker_never_sends_after_block(): void
    {
        $this->grant();
        $this->requestOtp();
        $old = OtpChallenge::sole();
        $this->postJson('/login/resend')->assertStatus(429)->assertHeader('Retry-After');
        $this->travel(61)->seconds();
        $this->post('/login/resend')->assertRedirect('/login/verify');
        $this->assertNotNull($old->fresh()->invalidated_at);
        $this->assertCount(2, $this->sender->sent);
        Queue::fake();
        $this->travel(61)->seconds();
        $this->post('/login/resend')->assertRedirect('/login/verify');
        $queued = OtpChallenge::latest('id')->firstOrFail();
        Queue::assertPushed(SendMemberOtp::class);
        app(ManageMembers::class)->block($this->owner, $this->member, $this->sensitive() + ['blocked' => true]);
        (new SendMemberOtp($queued->public_id))->handle($this->sender);
        $this->assertCount(2, $this->sender->sent);
    }

    public function test_block_unblock_revoke_and_expiry_cut_private_access_without_cron(): void
    {
        $this->grant();
        $this->memberLogin();
        app(ManageMembers::class)->block($this->owner, $this->member, $this->sensitive() + ['blocked' => true]);
        $this->getJson('/app/account')->assertUnauthorized();
        app(ManageMembers::class)->block($this->owner, $this->member, $this->sensitive() + ['blocked' => false]);
        $this->getJson('/api/member/status')->assertUnauthorized();
        $this->travel(61)->seconds();
        $this->memberLogin();
        app(ManageSubscriptions::class)->revoke($this->owner, $this->member, $this->sensitive());
        $this->get('/app/signals/archive')->assertRedirect('/login');
        $this->grant();
        $this->travel(61)->seconds();
        $this->memberLogin();
        $this->travelTo($this->member->subscription()->first()->ends_at);
        $this->getJson('/app')->assertUnauthorized();
        $this->getJson('/api/member/status')->assertUnauthorized();
    }

    public function test_phone_change_invalidates_sessions_and_codes_and_cannot_be_done_by_member_profile(): void
    {
        $this->grant();
        $this->memberLogin();
        $old = $this->member->phone_e164;
        $next = $this->newPhone();
        $this->put('/app/account', ['display_name' => 'نام تازه', 'phone' => $next, 'kind' => 'admin', 'account_id' => $this->owner->id])->assertRedirect('/app/account');
        $this->assertSame($old, $this->member->fresh()->phone_e164);
        $this->assertSame('member', $this->member->account->kind);
        app(ManageMembers::class)->update($this->owner, $this->member, $this->sensitive() + ['phone' => $next]);
        $this->getJson('/app')->assertUnauthorized();
        $this->assertSame($next, $this->member->fresh()->phone_e164);
    }

    public function test_unconfigured_sender_missing_key_and_production_fake_driver_fail_closed(): void
    {
        app()->bind(OtpSender::class, UnavailableOtpSender::class);
        app()->forgetInstance(OtpSender::class);
        $this->grant();
        $this->get('/login')->assertStatus(503);
        $this->post('/login', ['phone' => $this->member->phone_e164])->assertStatus(503);
        $this->assertDatabaseCount('otp_challenges', 0);
        app()->instance(OtpSender::class, $this->sender);
        config(['membership.otp_key' => '']);
        $this->assertFalse(OtpSecurity::ready());
        config(['membership.otp_key' => Str::random(64), 'sms.driver' => 'testing']);
        app()->instance('env', 'production');
        $this->assertFalse(OtpSecurity::ready());
    }

    public function test_delivery_failure_is_safe_and_no_code_can_log_in(): void
    {
        $this->grant();
        $this->sender->fail = true;
        $this->requestOtp();
        $challenge = OtpChallenge::sole();
        $this->assertNull($challenge->sent_at);
        $this->assertNotNull($challenge->invalidated_at);
        $this->assertSame([], $this->sender->sent);
        $this->postJson('/login/verify', ['code' => '000000'])->assertUnprocessable();
        $this->assertDatabaseCount('member_sessions', 0);
        $this->assertDatabaseHas('auth_events', ['outcome' => 'delivery_failed']);
    }

    public function test_renewal_history_is_immutable_in_mysql(): void
    {
        $this->grant();
        foreach (['update', 'delete'] as $op) {
            try {
                if ($op === 'update') {
                    DB::table('subscription_renewals')->update(['months' => 12]);
                } else {
                    DB::table('subscription_renewals')->delete();
                }$this->fail('History was changed');
            } catch (QueryException $e) {
                $this->assertSame('45000', $e->errorInfo[0]);
            }
        }
    }

    public function test_limited_admin_cannot_manage_members_and_payment_route_rejects_foreign_record(): void
    {
        $this->adminLogin();
        $foreign = $this->newMember();
        $payment = app(ManageManualPayments::class)->record($this->owner, $foreign, $this->sensitive() + ['amount' => '1.00', 'unit' => 'IRT', 'paid_at' => '2026-10-19T15:30', 'method' => 'cash', 'idempotency_key' => (string) Str::uuid()]);
        $this->postJson('/admin/members/'.$this->member->public_id.'/payments/'.$payment->public_id.'/confirm', $this->sensitive())->assertNotFound();
        $viewer = Account::create(['kind' => 'admin', 'username' => 'viewer_'.strtolower(Str::random(12)), 'password_hash' => $this->password]);
        $viewer->roles()->attach(Role::where('key', 'viewer')->firstOrFail());
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => $viewer->username, 'password' => $this->password]);
        $this->withCookie('bartar_admin_session', session()->getId());
        $this->get('/admin/members')->assertForbidden();
        $this->postJson('/admin/members/01INVALID/subscription', ['operation' => 'activate'])->assertForbidden();
        $this->postJson('/admin/members', [])->assertForbidden();
    }

    public function test_all_membership_pages_render_with_real_models_and_export_safe_review(): void
    {
        $this->grant();
        $this->adminLogin();
        $pages = [];
        foreach (['/admin/members', '/admin/members/create', '/admin/members/'.$this->member->public_id, '/admin/members/'.$this->member->public_id.'/edit', '/login'] as $path) {
            $response = $this->get($path)->assertOk();
            $pages[$path] = ['status' => 200, 'html' => $response->getContent()];
        }
        $this->memberLogin();
        foreach (['/app', '/app/account', '/app/subscription', '/app/signals', '/app/markets', '/app/performance', '/app/notifications'] as $path) {
            $response = $this->get($path)->assertOk()->assertDontSee('یادداشت داخلی آزمایش');
            $pages[$path] = ['status' => 200, 'html' => $response->getContent()];
        }
        if ($destination = getenv('BARTAR_MEMBERSHIP_REVIEW')) {
            foreach ($pages as &$page) {
                $page['html'] = preg_replace('/(name="_token" value=")[^"]*/', '$1', $page['html']);
                $page['html'] = str_replace($this->member->phone_e164, $this->member->maskedPhone(), $page['html']);
            }unset($page);
            file_put_contents($destination, json_encode($pages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        }
    }

    public function test_database_queue_payload_contains_only_reference_and_worker_sends_once(): void
    {
        $this->grant();
        config(['queue.default' => 'database']);
        $this->requestOtp();
        $this->assertSame([], $this->sender->sent);
        $challenge = OtpChallenge::sole();
        $this->assertNull($challenge->getRawOriginal('verifier_hmac'));
        $payload = DB::table('jobs')->sole()->payload;
        $this->assertStringNotContainsString($this->member->phone_e164, $payload);
        $this->assertStringNotContainsString('verifier_hmac', $payload);
        $this->assertStringContainsString($challenge->public_id, $payload);
        $job = Queue::connection('database')->pop();
        $this->assertNotNull($job);
        $job->fire();
        $this->assertCount(1, $this->sender->sent);
        (new SendMemberOtp($challenge->public_id))->handle($this->sender);
        $this->assertCount(1, $this->sender->sent);
        $this->assertNotNull($challenge->fresh()->sent_at);
    }

    public function test_pending_future_subscription_and_disabled_account_do_not_receive_codes(): void
    {
        $this->grant();
        $this->member->subscription()->update(['starts_at' => now()->addDay(), 'ends_at' => now()->addMonth()]);
        $this->requestOtp();
        $this->assertSame([], $this->sender->sent);
        $this->travel(61)->seconds();
        $this->member->subscription()->update(['starts_at' => now()->subMinute()]);
        $this->member->account()->update(['disabled_at' => now()]);
        $this->requestOtp();
        $this->assertSame([], $this->sender->sent);
    }

    public function test_member_logout_and_idle_timeout_invalidate_registry(): void
    {
        $this->grant();
        $this->memberLogin();
        $this->post('/app/logout')->assertRedirect('/login');
        $this->getJson('/app')->assertUnauthorized();
        $this->travel(61)->seconds();
        $this->memberLogin();
        $this->travel(121)->minutes();
        $this->getJson('/app')->assertUnauthorized();
        $this->assertSame(0, MemberSession::whereNull('revoked_at')->count());
    }

    public function test_confirmation_page_masks_phone_and_never_prefills_code(): void
    {
        $this->get('/login/verify')->assertRedirect('/login');
        $this->grant();
        $this->requestOtp();
        $response = $this->get('/login/verify')->assertOk()->assertSee($this->member->maskedPhone())->assertDontSee($this->member->phone_e164)->assertDontSee($this->sender->code());
        if ($destination = getenv('BARTAR_MEMBERSHIP_REVIEW')) {
            file_put_contents(dirname($destination).'/otp-pages.json', json_encode(['/login/verify' => ['status' => 200, 'html' => preg_replace('/(name="_token" value=")[^"]*/', '$1', $response->getContent())]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        }
    }
}
