<?php

namespace Tests\Feature;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authorization\Models\Role;
use App\Modules\Authorization\Support\PermissionCatalog;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Tests\TestCase;

class AdministrationSecurityTest extends TestCase
{
    use DatabaseTransactions;

    private string $password;

    private Account $owner;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->password = Str::random(32);
        $this->withCredentials();
        $this->owner = $this->account('owner');
    }

    private function account(string $role = 'viewer', string $kind = 'admin'): Account
    {
        $account = Account::create(['kind' => $kind, 'username' => 'manager_'.strtolower(Str::random(12)), 'password_hash' => $this->password]);
        $account->roles()->attach(Role::where('key', $role)->firstOrFail());

        return $account;
    }

    private function login(?Account $account = null): void
    {
        Auth::forgetGuards();
        $this->post('/admin/login', ['username' => ($account ?? $this->owner)->username, 'password' => $this->password])->assertRedirect('/admin');
        $this->withCookie('bartar_admin_session', session()->getId());
    }

    public function test_login_hashes_password_rotates_session_and_records_success_without_secrets(): void
    {
        $before = session()->getId();
        $this->login();
        $this->assertNotSame($before, session()->getId());
        $this->assertNotSame($this->password, $this->owner->password_hash);
        $this->assertTrue(Hash::check($this->password, $this->owner->password_hash));
        $this->assertDatabaseHas('auth_events', ['account_id' => $this->owner->id, 'outcome' => 'accepted']);
        $this->assertDatabaseHas('audit_logs', ['action' => 'auth.login', 'actor_id' => $this->owner->id]);
        $this->assertDatabaseCount('admin_sessions', 1);
        $this->get('/admin')->assertOk()->assertSee('داشبورد مدیریت');
        $this->get('/app')->assertRedirect('/login');
        $all = json_encode(DB::table('audit_logs')->get()).json_encode(DB::table('auth_events')->get()).json_encode(DB::table('admin_sessions')->get());
        $this->assertStringNotContainsString($this->password, $all);
        $this->assertStringNotContainsString(session()->getId(), $all);
    }

    public function test_wrong_unknown_disabled_and_member_accounts_have_generic_login_failure(): void
    {
        $disabled = $this->account();
        $disabled->update(['disabled_at' => now()]);
        $member = $this->account('owner', 'member');
        foreach ([[$this->owner->username, Str::random(31)], ['missing_manager', Str::random(31)], [$disabled->username, $this->password], [$member->username, $this->password]] as [$name,$password]) {
            Auth::forgetGuards();
            $this->postJson('/admin/login', ['username' => $name, 'password' => $password])->assertUnprocessable()->assertJsonPath('errors.username.0', 'نام کاربری یا رمز عبور معتبر نیست.');
        }
        $this->assertDatabaseCount('admin_sessions', 0);
        $this->assertDatabaseCount('auth_events', 4);
    }

    public function test_login_is_rate_limited_and_limit_recovers_after_expiry(): void
    {
        for ($i = 0; $i < 5; $i++) {
            $this->postJson('/admin/login', ['username' => $this->owner->username, 'password' => Str::random(30)])->assertUnprocessable();
        }
        $this->postJson('/admin/login', ['username' => $this->owner->username, 'password' => $this->password])->assertStatus(429)->assertHeader('Retry-After');
        $this->travel(61)->seconds();
        $this->login();
    }

    public function test_logout_and_session_revocation_remove_access(): void
    {
        $this->login();
        $this->post('/admin/logout')->assertRedirect('/admin/login');
        $this->get('/admin')->assertRedirect('/admin/login');
        $this->assertNotNull(AdminSession::first()->revoked_at);
        $this->login();
        AdminSession::whereNull('revoked_at')->update(['revoked_at' => now()]);
        $this->getJson('/admin')->assertUnauthorized();
    }

    public function test_disabling_account_or_changing_auth_version_invalidates_old_session(): void
    {
        $this->login();
        $this->owner->increment('auth_version');
        $this->getJson('/admin')->assertUnauthorized();
        $this->login();
        $this->owner->update(['disabled_at' => now()]);
        $this->getJson('/admin')->assertUnauthorized();
    }

    public function test_viewer_cannot_read_or_mutate_accounts_or_roles_directly(): void
    {
        $viewer = $this->account();
        $this->login($viewer);
        $this->get('/admin')->assertOk()->assertDontSee('نام کاربری', false);
        foreach (['/admin/accounts', '/admin/accounts/create', '/admin/roles', '/admin/audit'] as $path) {
            $this->get($path)->assertForbidden();
        }
        $this->putJson('/admin/accounts/'.$this->owner->public_id, ['role_ids' => [], 'current_password' => $this->password, 'reason' => 'unauthorized test'])->assertForbidden();
        $this->get('/admin/sessions')->assertOk()->assertSee($viewer->username)->assertDontSee($this->owner->username);
    }

    public function test_all_known_permissions_allow_owner_but_unknown_abilities_and_members_are_denied(): void
    {
        $member = $this->account('owner', 'member');
        foreach (array_keys(PermissionCatalog::permissions()) as $permission) {
            $this->assertTrue($this->owner->allows($permission));
            $this->assertFalse($member->allows($permission));
        }
        $this->assertFalse($this->owner->allows('unregistered.ability'));
        $this->assertFalse(Gate::forUser($this->owner)->allows('update', $member));
    }

    public function test_create_admin_requires_reauthentication_and_does_not_accept_extra_identity_fields(): void
    {
        $this->login();
        $viewer = Role::where('key', 'viewer')->firstOrFail();
        $new = Str::random(32);
        $payload = ['username' => 'new_manager', 'display_name' => 'مدیر جدید', 'password' => $new, 'password_confirmation' => $new, 'role_ids' => [$viewer->id], 'reason' => 'creating test administrator', 'current_password' => Str::random(32), 'kind' => 'member', 'auth_version' => 999];
        $this->postJson('/admin/accounts', $payload)->assertUnprocessable();
        $this->assertDatabaseMissing('accounts', ['username' => 'new_manager']);
        $payload['current_password'] = $this->password;
        $this->post('/admin/accounts', $payload)->assertRedirect();
        $created = Account::where('username', 'new_manager')->firstOrFail();
        $this->assertSame('admin', $created->kind);
        $this->assertSame(1, $created->auth_version);
        $this->assertTrue(Hash::check($new, $created->password_hash));
        $this->assertDatabaseHas('audit_logs', ['action' => 'admin.created', 'entity_id' => $created->public_id]);
    }

    public function test_last_owner_cannot_be_disabled_or_demoted_and_transaction_rolls_back(): void
    {
        $this->login();
        $viewer = Role::where('key', 'viewer')->firstOrFail();
        $owner = Role::where('key', 'owner')->firstOrFail();
        foreach ([['role_ids' => [$viewer->id]], ['role_ids' => [$owner->id], 'disabled' => true]] as $change) {
            $this->putJson('/admin/accounts/'.$this->owner->public_id, array_merge(['current_password' => $this->password, 'reason' => 'invariant test'], $change))->assertUnprocessable();
            $this->assertNull($this->owner->fresh()->disabled_at);
            $this->assertTrue($this->owner->fresh()->allows('all_modules'));
        }
        $this->assertDatabaseMissing('audit_logs', ['action' => 'admin.updated']);
    }

    public function test_role_permission_change_is_effective_on_next_request_and_preserves_owner_role(): void
    {
        $viewer = $this->account();
        $this->login($viewer);
        $this->get('/admin/accounts')->assertForbidden();
        $manager = app(ManageAdministrators::class);
        $role = Role::where('key', 'viewer')->firstOrFail();
        $manager->updateRole($this->owner, $role, ['title' => $role->title, 'permission_keys' => ['dashboard.view', 'admins.manage'], 'current_password' => $this->password, 'reason' => 'role regression test']);
        $this->get('/admin/accounts')->assertOk();
        $manager->updateRole($this->owner, $role, ['title' => $role->title, 'permission_keys' => ['dashboard.view'], 'current_password' => $this->password, 'reason' => 'revoke regression test']);
        $this->get('/admin/accounts')->assertForbidden();
        $this->login();
        $owner = Role::where('key', 'owner')->firstOrFail();
        $this->putJson('/admin/roles/'.$owner->id, ['title' => $owner->title, 'permission_keys' => ['dashboard.view'], 'current_password' => $this->password, 'reason' => 'protected role test'])->assertUnprocessable();
    }

    public function test_foreign_sessions_cannot_be_revoked_by_viewer_even_with_a_known_id(): void
    {
        $foreign = AdminSession::create(['account_id' => $this->owner->id, 'session_hash' => AdminSession::digest(Str::random(40)), 'auth_version' => 1, 'last_seen_at' => now()]);
        $viewer = $this->account();
        $this->login($viewer);
        $this->postJson('/admin/sessions/'.$foreign->public_id.'/revoke', ['current_password' => $this->password, 'reason' => 'idor test'])->assertForbidden();
        $this->assertNull($foreign->fresh()->revoked_at);
    }

    public function test_audit_is_append_only_at_database_level_and_redacts_nested_secret_fields(): void
    {
        $record = app(RecordAudit::class)->write($this->owner, 'test.redaction', 'test', null, [], ['password' => 'never-save', 'nested' => ['api_key' => 'never-save', 'safe' => 'visible']]);
        $this->assertSame(['nested' => ['safe' => 'visible']], $record->after_data);
        foreach (['update', 'delete'] as $operation) {
            try {
                if ($operation === 'update') {
                    DB::table('audit_logs')->where('id', $record->id)->update(['reason' => 'altered']);
                } else {
                    DB::table('audit_logs')->where('id', $record->id)->delete();
                }
                $this->fail('Database allowed immutable audit mutation.');
            } catch (QueryException $exception) {
                $this->assertSame('45000', $exception->errorInfo[0]);
            }
        }
        $this->assertDatabaseHas('audit_logs', ['id' => $record->id, 'action' => 'test.redaction']);
    }

    public function test_audit_scope_limits_technical_administrator(): void
    {
        $audit = app(RecordAudit::class);
        $audit->write($this->owner, 'technical.visible', 'test', null, [], [], null, 'technical');
        $audit->write($this->owner, 'security.hidden', 'test', null);
        $technical = $this->account('technical');
        $this->login($technical);
        $this->get('/admin/audit')->assertOk()->assertSee('technical.visible')->assertDontSee('security.hidden');
    }

    public function test_password_change_revokes_every_session_and_old_password_stops_working(): void
    {
        $this->login();
        $next = Str::random(32);
        $this->put('/admin/security/password', ['current_password' => $this->password, 'password' => $next, 'password_confirmation' => $next])->assertRedirect('/admin/login');
        $this->assertSame(0, AdminSession::whereNull('revoked_at')->count());
        Auth::forgetGuards();
        $this->postJson('/admin/login', ['username' => $this->owner->username, 'password' => $this->password])->assertUnprocessable();
        $this->assertTrue(Hash::check($next, $this->owner->fresh()->password_hash));
    }

    public function test_sensitive_forms_have_csrf_and_production_rejects_missing_csrf(): void
    {
        $this->login();
        $this->get('/admin/accounts/create')->assertOk()->assertSee('name="_token"', false)->assertSee('name="current_password"', false);
        app()->instance('env', 'production');
        $this->post('/admin/logout')->assertStatus(419);
    }

    public function test_console_recovery_requires_confirmation_revokes_sessions_and_logs_no_password(): void
    {
        $this->login();
        $new = Str::random(32);
        $this->artisan('bartar:admin-reset')->expectsQuestion('نام کاربری مدیر', $this->owner->username)->expectsQuestion('دلیل بازیابی؛ اطلاعات محرمانه وارد نکنید', 'authorized test recovery')->expectsQuestion('رمز جدید؛ حداقل ۱۲ نویسه', $new)->expectsQuestion('تکرار رمز جدید', $new)->expectsConfirmation('همه نشست‌های این مدیر لغو شوند؟', 'yes')->assertSuccessful();
        $this->assertTrue(Hash::check($new, $this->owner->fresh()->password_hash));
        $this->assertSame(0, AdminSession::whereNull('revoked_at')->count());
        $this->get('/admin')->assertRedirect('/admin/login');
        $this->assertDatabaseHas('audit_logs', ['action' => 'password.recovered', 'actor_kind' => 'console']);
        $this->assertStringNotContainsString($new, json_encode(DB::table('audit_logs')->get()));
    }

    public function test_all_real_management_pages_render_after_login(): void
    {
        $this->login();
        $role = Role::where('key', 'viewer')->firstOrFail();
        $pages = [];
        foreach (['/admin', '/admin/accounts', '/admin/accounts/create', '/admin/accounts/'.$this->owner->public_id.'/edit', '/admin/roles', ...Role::all()->map(fn ($item) => '/admin/roles/'.$item->id.'/edit')->all(), '/admin/sessions', '/admin/audit', '/admin/security'] as $path) {
            $response = $this->get($path)->assertOk()->assertHeader('Cache-Control', 'no-store, private');
            $html = preg_replace('/(name="_token" value=")[^"]*/', '$1', $response->getContent());
            $pages[$path] = ['status' => 200, 'html' => $html];
        }
        if ($destination = getenv('BARTAR_REVIEW_EXPORT')) {
            file_put_contents($destination, json_encode($pages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        }
    }

    public function test_authentication_and_permission_checks_precede_model_binding(): void
    {
        $this->putJson('/admin/accounts/01INVALID', ['reason' => 'test'])->assertUnauthorized();
        $viewer = $this->account();
        $this->login($viewer);
        $this->putJson('/admin/accounts/01INVALID', ['reason' => 'test'])->assertForbidden();
        $this->get('/admin/accounts/01INVALID/edit')->assertForbidden();
    }

    public function test_session_expires_and_cannot_be_revived_by_a_stale_cookie(): void
    {
        $this->login();
        $session = AdminSession::firstOrFail();
        $session->update(['last_seen_at' => now()->subMinutes((int) config('session.lifetime'))]);
        $this->getJson('/admin')->assertUnauthorized();
        $this->assertNotNull($session->fresh()->revoked_at);
        $this->getJson('/admin')->assertUnauthorized();
    }

    public function test_session_revocation_requires_password_then_removes_access(): void
    {
        $this->login();
        $session = AdminSession::firstOrFail();
        $url = '/admin/sessions/'.$session->public_id.'/revoke';
        $this->postJson($url, ['current_password' => Str::random(32), 'reason' => 'test'])->assertUnprocessable();
        $this->assertNull($session->fresh()->revoked_at);
        $this->post($url, ['current_password' => $this->password, 'reason' => 'test'])->assertRedirect('/admin/sessions');
        $this->getJson('/admin')->assertUnauthorized();
        $this->assertDatabaseHas('audit_logs', ['action' => 'session.revoked']);
    }

    public function test_limited_administrator_cannot_delegate_higher_permissions_or_modify_owner(): void
    {
        $role = Role::where('key', 'viewer')->firstOrFail();
        $manager = app(ManageAdministrators::class);
        $keys = array_merge(PermissionCatalog::roles()['viewer']['permissions'], ['admins.manage', 'manage_roles']);
        $manager->updateRole($this->owner, $role, ['title' => $role->title, 'permission_keys' => $keys, 'current_password' => $this->password, 'reason' => 'limited manager test']);
        $limited = $this->account();
        $this->login($limited);
        $ownerRole = Role::where('key', 'owner')->firstOrFail();
        $new = Str::random(32);
        $this->postJson('/admin/accounts', ['username' => 'escalation_test', 'password' => $new, 'password_confirmation' => $new, 'role_ids' => [$ownerRole->id], 'current_password' => $this->password, 'reason' => 'test'])->assertForbidden();
        $this->putJson('/admin/accounts/'.$this->owner->public_id, ['role_ids' => [$role->id], 'current_password' => $this->password, 'reason' => 'test'])->assertForbidden();
        $this->putJson('/admin/roles/'.$role->id, ['title' => $role->title, 'permission_keys' => array_merge($keys, ['all_modules']), 'current_password' => $this->password, 'reason' => 'test'])->assertForbidden();
        $this->assertDatabaseMissing('accounts', ['username' => 'escalation_test']);
        $this->assertTrue($this->owner->fresh()->allows('all_modules'));
        $this->assertFalse($limited->fresh()->allows('all_modules'));
    }

    public function test_authentication_history_is_append_only_in_mysql(): void
    {
        $this->postJson('/admin/login', ['username' => $this->owner->username, 'password' => Str::random(32)])->assertUnprocessable();
        foreach (['update', 'delete'] as $operation) {
            try {
                if ($operation === 'update') {
                    DB::table('auth_events')->update(['outcome' => 'accepted']);
                } else {
                    DB::table('auth_events')->delete();
                }
                $this->fail('Authentication history was mutable.');
            } catch (QueryException $exception) {
                $this->assertSame('45000', $exception->errorInfo[0]);
            }
        }
        $this->assertDatabaseHas('auth_events', ['outcome' => 'rejected']);
    }

    public function test_production_admin_cookie_is_secure_httponly_and_samesite(): void
    {
        app()->instance('env', 'production');
        $response = $this->get('/admin/login')->assertOk();
        $cookie = collect($response->headers->getCookies())->first(fn ($c) => $c->getName() === 'bartar_admin_session');
        $this->assertNotNull($cookie);
        $this->assertTrue($cookie->isSecure());
        $this->assertTrue($cookie->isHttpOnly());
        $this->assertSame('lax', $cookie->getSameSite());
    }

    public function test_cancelled_console_recovery_does_not_change_password_or_sessions(): void
    {
        $this->login();
        $before = $this->owner->password_hash;
        $new = Str::random(32);
        $this->artisan('bartar:admin-reset')->expectsQuestion('نام کاربری مدیر', $this->owner->username)->expectsQuestion('دلیل بازیابی؛ اطلاعات محرمانه وارد نکنید', 'cancelled test')->expectsQuestion('رمز جدید؛ حداقل ۱۲ نویسه', $new)->expectsQuestion('تکرار رمز جدید', $new)->expectsConfirmation('همه نشست‌های این مدیر لغو شوند؟', 'no')->assertFailed();
        $this->assertSame($before, $this->owner->fresh()->password_hash);
        $this->assertSame(1, AdminSession::whereNull('revoked_at')->count());
        $this->assertDatabaseMissing('audit_logs', ['action' => 'password.recovered']);
    }
}
