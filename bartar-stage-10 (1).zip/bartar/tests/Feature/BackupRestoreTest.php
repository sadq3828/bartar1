<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use App\Modules\BackupRestore\Actions\BackupManager;
use App\Modules\BackupRestore\Models\BackupRun;
use App\Modules\BackupRestore\Support\BackupFailure;
use App\Modules\BackupRestore\Support\EncryptedBackupFiles;
use App\Modules\Media\Models\MediaFile;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;

final class BackupRestoreTest extends TestCase
{
    private string $source;

    private string $target;

    private string $directory;

    private string $originalConnection;

    private Account $account;

    private string $png;

    protected function setUp(): void
    {
        parent::setUp();
        $this->assertSame('mysql', DB::connection()->getDriverName());
        $this->assertStringContainsString('test', DB::connection()->getDatabaseName());
        $this->originalConnection = config('database.default');
        $suffix = strtolower(Str::random(10));
        $this->source = 'bartar_backup_test_'.$suffix;
        $this->target = 'bartar_restore_test_'.$suffix;
        $this->directory = storage_path('framework/testing/backup-'.$suffix);
        DB::statement('CREATE DATABASE `'.$this->source.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        DB::statement('CREATE DATABASE `'.$this->target.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $source = config('database.connections.'.$this->originalConnection);
        $target = $source;
        $source['database'] = $this->source;
        $target['database'] = $this->target;
        config(['database.connections.backup_source' => $source, 'database.connections.backup_restore' => $target, 'operations.backup.enabled' => true, 'operations.backup.timeout' => 30, 'operations.backup.key' => base64_encode(random_bytes(32)), 'operations.backup.root' => $this->directory.'/backups', 'operations.backup.restore_enabled' => true, 'operations.backup.restore_media_root' => $this->directory.'/restored', 'filesystems.disks.signal-media.root' => $this->directory.'/media']);
        DB::setDefaultConnection('backup_source');
        Storage::forgetDisk('signal-media');
        Artisan::call('migrate', ['--force' => true]);
        Artisan::call('db:seed', ['--force' => true]);
        $this->account = Account::create(['kind' => 'admin', 'username' => 'restore_marker', 'password_hash' => Str::random(40)]);
        $this->png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aWQ0AAAAASUVORK5CYII=');
        Storage::disk('signal-media')->put('objects/aa/test-object', $this->png);
        MediaFile::create(['disk' => 'signal-media', 'object_key' => 'objects/aa/test-object', 'kind' => 'image', 'mime' => 'image/png', 'bytes' => strlen($this->png), 'sha256' => hash('sha256', $this->png), 'original_name' => 'synthetic.png', 'state' => 'ready', 'uploaded_by' => $this->account->id, 'verified_at' => now()]);
    }

    protected function tearDown(): void
    {
        DB::purge('backup_lock');
        DB::purge('backup_restore');
        DB::purge('backup_source');
        DB::setDefaultConnection($this->originalConnection);
        foreach ([$this->source, $this->target] as $name) {
            if (preg_match('/\Abartar_(?:backup|restore)_test_[a-z0-9]+\z/', $name)) {
                DB::statement('DROP DATABASE `'.$name.'`');
            }
        }
        File::deleteDirectory($this->directory);
        Storage::forgetDisk('signal-media');
        parent::tearDown();
    }

    private function backup(): BackupRun
    {
        $m = app(BackupManager::class);
        $run = $m->execute($m->enqueue(null, 'Isolated backup integration test'));
        $this->assertSame('completed', $run->status, $run->error_code ?? '');

        return $run;
    }

    public function test_real_mysql_dump_encrypted_media_and_isolated_restore_verify_counts_fks_and_triggers(): void
    {
        $run = $this->backup();
        $manager = app(BackupManager::class);
        $this->assertNull($run->restore_verified_at);
        $this->assertStringNotContainsString('restore_marker', file_get_contents($manager->artifact($run).'/database.enc'));
        $this->account->update(['username' => 'changed_after_backup']);
        $verification = $manager->drill($run, $this->target);
        $this->assertGreaterThan(40, $verification['tables']);
        $this->assertGreaterThan(10, $verification['triggers']);
        $this->assertSame(1, $verification['media_files']);
        $this->assertSame('verified', $verification['foreign_keys']);
        $this->assertNotNull($run->fresh()->restore_verified_at);
        $this->assertSame('restore_marker', DB::connection('backup_restore')->table('accounts')->value('username'));
        $this->assertSame('changed_after_backup', $this->account->fresh()->username);
        $files = File::allFiles($this->directory.'/restored');
        $this->assertCount(1, $files);
        $this->assertSame($this->png, file_get_contents($files[0]->getPathname()));
        $this->assertDatabaseHas('backup_restore_runs', ['status' => 'completed']);
    }

    public function test_wrong_key_and_truncation_fail_authentication_before_import(): void
    {
        $run = $this->backup();
        $key = config('operations.backup.key');
        $manager = app(BackupManager::class);
        config(['operations.backup.key' => base64_encode(random_bytes(32))]);
        try {
            $manager->drill($run, $this->target);
            $this->fail('Wrong key accepted');
        } catch (BackupFailure $e) {
            $this->assertSame('backup_authentication_failed', $e->safeCode);
        }
        $this->assertSame(0, DB::connection('backup_restore')->table('information_schema.TABLES')->where('TABLE_SCHEMA', $this->target)->count());
        config(['operations.backup.key' => $key]);
        $path = $manager->artifact($run).'/database.enc';
        $bytes = file_get_contents($path);
        file_put_contents($path, substr($bytes, 0, -7));
        try {
            $manager->drill($run, $this->target);
            $this->fail('Truncated backup accepted');
        } catch (BackupFailure $e) {
            $this->assertSame('backup_truncated', $e->safeCode);
        }
        $this->assertNull($run->fresh()->restore_verified_at);
        $this->assertDatabaseHas('backup_restore_runs', ['status' => 'failed']);
    }

    public function test_missing_media_and_unconfigured_key_fail_without_partial_success(): void
    {
        $good = $this->backup();
        $m = app(BackupManager::class);
        Storage::disk('signal-media')->delete('objects/aa/test-object');
        $bad = $m->execute($m->enqueue(null, 'Missing media test'));
        $this->assertSame('failed', $bad->status);
        $this->assertSame('media_missing', $bad->error_code);
        $this->assertDirectoryExists($m->artifact($good));
        $this->assertDirectoryDoesNotExist($m->artifact($bad).'.partial');
        config(['operations.backup.key' => null]);
        $bad = $m->execute($m->enqueue(null, 'Missing key test'));
        $this->assertSame('backup_unconfigured', $bad->error_code);
    }

    public function test_restore_requires_confirmation_and_empty_isolated_database(): void
    {
        $run = $this->backup();
        $m = app(BackupManager::class);
        try {
            $m->drill($run, 'production');
            $this->fail('Confirmation bypass');
        } catch (BackupFailure $e) {
            $this->assertSame('isolated_restore_required', $e->safeCode);
        }
        DB::connection('backup_restore')->statement('CREATE TABLE existing_marker (id INT PRIMARY KEY) ENGINE=InnoDB');
        try {
            $m->drill($run, $this->target);
            $this->fail('Nonempty target accepted');
        } catch (BackupFailure $e) {
            $this->assertSame('restore_target_not_empty', $e->safeCode);
        }
        $this->assertSame(1, DB::connection('backup_restore')->table('information_schema.TABLES')->where('TABLE_SCHEMA', $this->target)->count());
        config(['database.connections.backup_restore.database' => $this->source]);
        try {
            $m->drill($run, $this->source);
            $this->fail('Source restore accepted');
        } catch (BackupFailure $e) {
            $this->assertSame('isolated_restore_required', $e->safeCode);
        }
    }

    public function test_retention_keeps_latest_two_and_last_restore_verified_even_with_failed_attempt(): void
    {
        $m = app(BackupManager::class);
        config(['operations.backup.keep' => 2]);
        $first = $this->backup();
        $m->drill($first, $this->target);
        $second = $this->backup();
        $third = $this->backup();
        $fourth = $this->backup();
        $this->assertSame(1, $m->retain());
        $this->assertSame('deleted', $second->fresh()->status);
        foreach ([$first, $third, $fourth] as $run) {
            $this->assertDirectoryExists($m->artifact($run));
            $this->assertSame('completed', $run->fresh()->status);
        }
    }

    public function test_independent_connection_cannot_start_overlapping_backup(): void
    {
        config(['database.connections.competitor' => config('database.connections.backup_source')]);
        $other = DB::connection('competitor');
        $other->select("SELECT GET_LOCK('bartar:backup', 0)");
        $m = app(BackupManager::class);
        $run = $m->enqueue(null, 'Concurrent backup test');
        try {
            $m->execute($run);
            $this->fail('Overlapping backup started');
        } catch (BackupFailure $e) {
            $this->assertSame('backup_already_running', $e->safeCode);
            $this->assertSame('queued', $run->fresh()->status);
        } finally {
            $other->select("SELECT RELEASE_LOCK('bartar:backup')");
            DB::purge('competitor');
        }
    }

    public function test_streaming_encryption_authenticates_multiple_frames_and_rejects_extra_bytes(): void
    {
        File::ensureDirectoryExists($this->directory);
        $source = $this->directory.'/stream.bin';
        $cipher = $this->directory.'/stream.enc';
        $plain = $this->directory.'/stream-restored.bin';
        file_put_contents($source, random_bytes(2200000));
        $crypto = app(EncryptedBackupFiles::class);
        $expected = $crypto->encrypt($source, $cipher);
        $this->assertSame($expected, $crypto->decrypt($cipher, $plain));
        $this->assertSame(hash_file('sha256', $source), hash_file('sha256', $plain));
        file_put_contents($cipher, 'x', FILE_APPEND);
        $this->expectException(BackupFailure::class);
        $this->expectExceptionMessage('backup_trailing_data');
        $crypto->decrypt($cipher);
    }
}
