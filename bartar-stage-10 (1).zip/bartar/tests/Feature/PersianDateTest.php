<?php

namespace Tests\Feature;

use App\Modules\Foundation\Support\PersianDate;
use DateTimeImmutable;
use Tests\TestCase;

class PersianDateTest extends TestCase
{
    public function test_utc_storage_time_is_presented_in_tehran_persian_calendar(): void
    {
        $this->assertSame('۱۴۰۵/۰۷/۲۷', PersianDate::format(new DateTimeImmutable('2026-10-19T00:00:00+00:00'), 'yyyy/MM/dd'));
        $this->assertSame('۱۴۰۵/۰۷/۲۸', PersianDate::format(new DateTimeImmutable('2026-10-19T21:00:00+00:00'), 'yyyy/MM/dd'));
        $this->assertSame('UTC', config('app.timezone'));
    }
}
