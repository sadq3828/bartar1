<?php

namespace Tests\Feature;

use App\Modules\Authentication\Models\Account;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Tests\TestCase;

class InitialAdministratorTest extends TestCase
{
    use DatabaseTransactions;

    public function test_initial_admin_is_created_interactively_once_with_no_default_password(): void
    {
        $this->assertDatabaseCount('accounts', 0);
        $password = Str::random(32);
        $this->artisan('bartar:admin-create')->expectsQuestion('نام کاربری مدیر', 'initial_review_manager')->expectsQuestion('رمز جدید؛ حداقل ۱۲ نویسه', $password)->expectsQuestion('تکرار رمز جدید', $password)->assertSuccessful();
        $account = Account::sole();
        $this->assertSame('admin', $account->kind);
        $this->assertTrue($account->allows('all_modules'));
        $this->assertTrue(Hash::check($password, $account->password_hash));
        $this->assertDatabaseHas('audit_logs', ['action' => 'admin.initialized', 'actor_kind' => 'console']);
        $this->artisan('bartar:admin-create')->assertFailed();
        $this->assertDatabaseCount('accounts', 1);
    }

    public function test_short_or_mismatched_initial_password_does_not_create_an_account(): void
    {
        $this->artisan('bartar:admin-create')->expectsQuestion('نام کاربری مدیر', 'invalid_review_manager')->expectsQuestion('رمز جدید؛ حداقل ۱۲ نویسه', 'short')->expectsQuestion('تکرار رمز جدید', 'different')->assertFailed();
        $this->assertDatabaseCount('accounts', 0);
        $this->assertDatabaseCount('audit_logs',0);
    }
}
