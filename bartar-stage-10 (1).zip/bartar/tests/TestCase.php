<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        // Isolated, ephemeral encryption key for HTTP/session tests only.
        config(['app.key' => 'base64:'.base64_encode(random_bytes(32)), 'app.debug' => false]);
    }
}
