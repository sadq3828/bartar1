<?php

namespace Tests\Support;

use App\Modules\SmsIntegration\Contracts\OtpSender;

final class CapturingOtpSender implements OtpSender
{
    public array $sent = [];

    public bool $fail = false;

    public function available(): bool
    {
        return true;
    }

    public function send(string $phone, string $code): void
    {
        if ($this->fail) {
            throw new \RuntimeException('Simulated provider failure');
        }$this->sent[] = ['phone' => $phone, 'code' => $code];
    }

    public function code(): string
    {
        return $this->sent[array_key_last($this->sent)]['code'];
    }
}
