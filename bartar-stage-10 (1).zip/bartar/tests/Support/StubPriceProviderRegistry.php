<?php

namespace Tests\Support;

use App\Modules\MarketPrices\Contracts\MarketPriceProvider;
use App\Modules\MarketPrices\Contracts\PriceProviderRegistry;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\MarketPrices\Support\PriceProviderException;
use Illuminate\Support\Collection;

final class StubPriceProviderRegistry implements PriceProviderRegistry
{
    public array $payload = [];

    public ?string $error = null;

    public function for(PriceSource $source): MarketPriceProvider
    {
        return new class($this) implements MarketPriceProvider
        {
            public function __construct(private StubPriceProviderRegistry $registry) {}

            public function fetch(PriceSource $source, Collection $assets): iterable
            {
                if ($this->registry->error) {
                    throw new PriceProviderException($this->registry->error);
                }

                return $this->registry->payload;
            }
        };
    }
}
