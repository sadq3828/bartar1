<?php

namespace Tests\Unit;

use App\Modules\Reports\Actions\CalculateSignalReturn;
use PHPUnit\Framework\TestCase;

final class SignalReturnTest extends TestCase
{
    public function test_weighted_buy_and_sell_use_initial_position_weights(): void
    {
        $calculator = new CalculateSignalReturn;
        $exits = [['exit_price' => '110', 'exit_weight' => '0.4'], ['exit_price' => '90', 'exit_weight' => '0.6']];
        $buy = $calculator->calculate('buy', '100', $exits, '1');
        $sell = $calculator->calculate('sell', '100', $exits, '1');
        $this->assertSame('-2.00000000', $buy['final_return']);
        $this->assertSame('negative', $buy['outcome']);
        $this->assertSame('2.00000000', $sell['final_return']);
        $this->assertSame('positive', $sell['outcome']);
    }

    public function test_partial_return_is_not_renormalized_or_final(): void
    {
        $result = (new CalculateSignalReturn)->calculate('buy', '100', [['exit_price' => '110', 'exit_weight' => '0.4']]);
        $this->assertSame('4.00000000', $result['realised_return']);
        $this->assertNull($result['final_return']);
        $this->assertSame('0.400000', $result['coverage']);
        $this->assertSame('partial', $result['state']);
        $this->assertSame('unknown', $result['outcome']);
    }

    public function test_missing_entry_and_inconsistent_coverage_remain_unknown(): void
    {
        $c = new CalculateSignalReturn;
        $exits = [['exit_price' => '110', 'exit_weight' => '0.5']];
        $this->assertSame('entry_execution_required', $c->calculate('buy', null, $exits)['reason_code']);
        $this->assertSame('invalid_coverage', $c->calculate('buy', '100', $exits, '1')['reason_code']);
        $this->assertSame('missing_snapshot', $c->calculate(null, '100', $exits)['reason_code']);
        $this->assertNull($c->calculate('buy', '100', [], '0')['final_return']);
    }

    public function test_decimal_precision_rounding_and_zero_outcome(): void
    {
        $c = new CalculateSignalReturn;
        $tiny = $c->calculate('buy', '99999999999999999999.000000000001', [['exit_price' => '99999999999999999999.000000000002', 'exit_weight' => '1']]);
        $this->assertSame('0.00000000', $tiny['final_return']);
        $this->assertSame('positive', $tiny['outcome']); // classify before display rounding
        $zero = $c->calculate('buy', '100', [['exit_price' => '100', 'exit_weight' => '1']]);
        $this->assertSame('zero', $zero['outcome']);
        $this->assertSame('33.33333333', $c->calculate('buy', '3', [['exit_price' => '4', 'exit_weight' => '1']])['final_return']);
        $this->assertSame('-33.33333333', $c->calculate('sell', '3', [['exit_price' => '4', 'exit_weight' => '1']])['final_return']);
    }
}
