<?php

use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\MarketPrices\Actions\RefreshMarketPrices;
use App\Modules\Notifications\Actions\DispatchNotifications;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('signals:publish-due', function (ManageSignals $signals): void {
    $this->info($signals->publishDue().' scheduled signal(s) published.');
})->purpose('Publish due scheduled signals idempotently');

Schedule::command('signals:publish-due')->everyMinute()->withoutOverlapping();

Artisan::command('prices:refresh', function (RefreshMarketPrices $prices): void {
    foreach ($prices->due() as $source => $status) {
        $this->line($source.': '.$status);
    }
})->purpose('Refresh due market price sources without overlapping');

Schedule::command('prices:refresh')->everyMinute()->withoutOverlapping();

Artisan::command('notifications:dispatch', function (DispatchNotifications $notifications): void {
    foreach ($notifications->run() as $kind => $count) {
        $this->line($kind.': '.$count);
    }
})->purpose('Dispatch idempotent in-app notifications and configured SMS deliveries');

Schedule::command('notifications:dispatch')->everyMinute()->withoutOverlapping();

Artisan::command('reports:calculate', function (\App\Modules\Reports\Actions\CalculateSignalReturn $calculator): void {
    $count = 0;
    foreach (\App\Modules\Signals\Models\SignalResult::with('exits')->lazyById(200) as $result) {
        $calculator->persist($result); $count++;
    }
    $this->info($count.' result version(s) checked.');
})->purpose('Persist immutable calculations for legacy result versions');

Artisan::command('operations:heartbeat', function (\App\Modules\SystemHealth\Actions\SystemHealth $health): void {
    $health->heartbeat('scheduler'); $this->info('Scheduler heartbeat recorded.');
});
Schedule::command('operations:heartbeat')->everyMinute()->withoutOverlapping();

Artisan::command('operations:health', function (\App\Modules\SystemHealth\Actions\SystemHealth $health): int {
    $result = $health->inspect(); $this->line(json_encode($result, JSON_THROW_ON_ERROR));
    return $result['status'] === 'healthy' ? 0 : 1;
});

Artisan::command('backups:create', function (\App\Modules\BackupRestore\Actions\BackupManager $manager): int {
    if (! config('operations.backup.enabled')) { $this->error('backup_unconfigured'); return 1; }
    $run = $manager->enqueue(null, 'درخواست اپراتور یا زمان‌بندی'); $this->info($run->public_id);
    return 0;
});
Schedule::command('backups:create')->dailyAt(config('operations.backup.time'))->when(fn () => config('operations.backup.enabled'))->withoutOverlapping();

Artisan::command('backups:work', function (\App\Modules\BackupRestore\Actions\BackupManager $manager): int {
    try {
        $run = \App\Modules\BackupRestore\Models\BackupRun::where('status', 'queued')->oldest('id')->first();
        if (! $run) { $this->info('No queued backup.'); return 0; }
        // Recheck authorization after a queued request, including revocation.
        if ($run->requested_by && ! \App\Modules\Authentication\Models\Account::find($run->requested_by)?->allows('manage_backups')) {
            $run->update(['status' => 'failed', 'error_code' => 'requester_permission_revoked', 'completed_at' => now()]);
            app(\App\Modules\AuditLogs\Actions\RecordAudit::class)->write(null, 'backup.request.revoked', 'backup', $run->public_id, [], ['error_code' => 'requester_permission_revoked'], 'مجوز درخواست‌کننده پیش از اجرا لغو شده است', 'technical', 'system');
            $this->error('requester_permission_revoked'); return 1;
        }
        $run = $manager->execute($run); $this->line($run->public_id.': '.$run->status);
        if ($run->status !== 'completed') { $this->error($run->error_code); return 1; }
        $manager->retain(); return 0;
    } catch (\App\Modules\BackupRestore\Support\BackupFailure $e) { $this->error($e->safeCode); return 1; }
});
Schedule::command('backups:work')->everyMinute()->withoutOverlapping(120);

Artisan::command('deployment:check {--staging}', function (\App\Modules\SystemHealth\Actions\DeploymentReadiness $readiness): int {
    $result = $readiness->inspect((bool) $this->option('staging'));
    $this->line(json_encode($result, JSON_THROW_ON_ERROR));
    return $result['status'] === 'blocked' ? 1 : 0;
})->purpose('Read-only deployment gates; staging permits isolated test hosts only');

Artisan::command('backups:restore-drill {backup} {--confirm=}', function (\App\Modules\BackupRestore\Actions\BackupManager $manager): int {
    try {
        $run = \App\Modules\BackupRestore\Models\BackupRun::where('public_id', $this->argument('backup'))->firstOrFail();
        $result = $manager->drill($run, (string) $this->option('confirm'));
        $this->info(json_encode($result, JSON_THROW_ON_ERROR)); return 0;
    } catch (\Throwable $e) {
        $this->error($e instanceof \App\Modules\BackupRestore\Support\BackupFailure ? $e->safeCode : 'restore_failed'); return 1;
    }
})->purpose('Restore and verify into a configured empty isolated database only');
