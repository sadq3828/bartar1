<?php

use App\Modules\Administration\Http\Controllers\AdminController;
use App\Modules\Authentication\Http\Controllers\AdminAuthController;
use App\Modules\Authentication\Http\Controllers\MemberAuthController;
use App\Modules\Content\Http\Controllers\ManageContentController;
use App\Modules\Content\Http\Controllers\PublicContentMediaController;
use App\Modules\Foundation\Http\Controllers\PageController;
use App\Modules\Foundation\Http\Controllers\PreviewController;
use App\Modules\Members\Http\Controllers\ManageMembersController;
use App\Modules\Members\Http\Controllers\MemberController;
use App\Modules\Media\Http\Controllers\ManageSignalMediaController;
use App\Modules\Media\Http\Controllers\PrivateMediaController;
use App\Modules\Markets\Http\Controllers\ManageMarketsController;
use App\Modules\MarketPrices\Http\Controllers\ManageMarketPricesController;
use App\Modules\MarketPrices\Http\Controllers\MemberMarketController;
use App\Modules\Notifications\Http\Controllers\MemberNotificationController;
use App\Modules\Signals\Http\Controllers\ManageSignalsController;
use App\Modules\Signals\Http\Controllers\MemberSignalController;
use Illuminate\Support\Facades\Route;
use App\Modules\Reports\Http\Controllers\PerformanceController;
use App\Modules\SystemHealth\Http\Controllers\OperationsController;

Route::get('/', [PageController::class, 'home'])->name('home');
foreach (['about', 'subscription', 'guide', 'terms', 'privacy', 'contact'] as $page) {
    Route::get('/'.$page, [PageController::class, 'page'])->defaults('page', $page)->name($page);
}
Route::get('/announcements', [PageController::class, 'announcements'])->name('announcements');
Route::get('/content/media/{media}', [PublicContentMediaController::class, 'show'])->name('content.media');
Route::get('/login', [MemberAuthController::class, 'show'])->name('login');
Route::post('/login', [MemberAuthController::class, 'request'])->name('member.otp.request');
Route::get('/login/verify', [MemberAuthController::class, 'challenge'])->name('member.otp');
Route::post('/login/verify', [MemberAuthController::class, 'verify'])->name('member.otp.verify');
Route::post('/login/resend', [MemberAuthController::class, 'resend'])->name('member.otp.resend');
Route::get('/admin/login', [AdminAuthController::class, 'show'])->name('admin.login');
Route::post('/admin/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
Route::get('/admin/recovery', [AdminAuthController::class, 'recovery'])->name('admin.recovery');

Route::prefix('app')->name('member.')->middleware('active-membership')->group(function (): void {
    Route::get('/', [MemberController::class, 'page'])->name('home');
    Route::get('/signals', [MemberSignalController::class, 'index'])->name('signals');
    Route::get('/signals/{signal}', [MemberSignalController::class, 'show'])->name('signals.show');
    Route::get('/markets', [MemberMarketController::class, 'index'])->name('markets');
    Route::get('/notifications', [MemberNotificationController::class, 'index'])->name('notifications');
    Route::post('/notifications/read-all', [MemberNotificationController::class, 'readAll'])->name('notifications.read-all');
    Route::post('/notifications/{notification}/read', [MemberNotificationController::class, 'read'])->name('notifications.read');
    Route::get('/performance', [PerformanceController::class, 'index'])->name('performance');
    foreach (['account', 'subscription'] as $page) {
        Route::get('/'.$page, [MemberController::class, 'page'])->defaults('page', $page)->name($page);
    }
    Route::put('/account', [MemberController::class, 'profile'])->name('profile.update');
    Route::post('/logout', [MemberController::class, 'logout'])->name('logout');
    Route::get('/{path}', fn () => abort(404))->where('path', '.*');
});
Route::get('/api/member/status', [MemberController::class, 'status'])->middleware('active-membership')->name('member.status');
Route::get('/private/media/{media}', [PrivateMediaController::class, 'member'])->middleware('active-membership')->name('member.media.stream');
Route::prefix('admin')->name('admin.')->middleware('administrator')->group(function (): void {
    Route::get('/reports', [PerformanceController::class, 'index'])->middleware('admin-permission:reports.view')->name('reports');
    Route::post('/reports/export', [PerformanceController::class, 'export'])->middleware('admin-permission:reports.view', 'admin-permission:reports.export')->name('reports.export');
    Route::get('/health', [OperationsController::class, 'health'])->middleware('admin-permission:health.view')->name('health');
    Route::get('/backups', [OperationsController::class, 'backups'])->middleware('admin-permission:backups.view')->name('backups');
    Route::post('/backups', [OperationsController::class, 'create'])->middleware('admin-permission:manage_backups')->name('backups.create');
    Route::get('/', [AdminController::class, 'dashboard'])->middleware('admin-permission:dashboard.view')->name('dashboard');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');
    Route::get('/accounts', [AdminController::class, 'admins'])->middleware('admin-permission:admins.manage')->name('accounts.index');
    Route::get('/accounts/create', [AdminController::class, 'create'])->middleware('admin-permission:admins.manage')->name('accounts.create');
    Route::post('/accounts', [AdminController::class, 'store'])->middleware('admin-permission:admins.manage')->name('accounts.store');
    Route::get('/accounts/{account}/edit', [AdminController::class, 'edit'])->middleware('admin-permission:admins.manage')->name('accounts.edit');
    Route::put('/accounts/{account}', [AdminController::class, 'update'])->middleware('admin-permission:admins.manage')->name('accounts.update');
    Route::get('/roles', [AdminController::class, 'roles'])->middleware('admin-permission:manage_roles')->name('roles.index');
    Route::get('/roles/{role}/edit', [AdminController::class, 'editRole'])->middleware('admin-permission:manage_roles')->name('roles.edit');
    Route::put('/roles/{role}', [AdminController::class, 'updateRole'])->middleware('admin-permission:manage_roles')->name('roles.update');
    Route::get('/sessions', [AdminController::class, 'sessions'])->name('sessions');
    Route::post('/sessions/{adminSession}/revoke', [AdminController::class, 'revokeSession'])->name('sessions.revoke');
    Route::get('/audit', [AdminController::class, 'audit'])->name('audit');
    Route::get('/security', [AdminController::class, 'security'])->name('security');
    Route::put('/security/password', [AdminController::class, 'password'])->name('password.update');
    Route::get('/members', [ManageMembersController::class, 'index'])->middleware('admin-permission:members.view')->name('members.index');
    Route::post('/members/search', [ManageMembersController::class, 'search'])->middleware('admin-permission:members.view')->name('members.search');
    Route::get('/members/create', [ManageMembersController::class, 'create'])->middleware('admin-permission:members.create')->name('members.create');
    Route::post('/members', [ManageMembersController::class, 'store'])->middleware('admin-permission:members.create')->name('members.store');
    Route::get('/members/{member}', [ManageMembersController::class, 'show'])->middleware('admin-permission:members.view')->name('members.show');
    Route::get('/members/{member}/edit', [ManageMembersController::class, 'edit'])->middleware('admin-permission:members.update')->name('members.edit');
    Route::put('/members/{member}', [ManageMembersController::class, 'update'])->middleware('admin-permission:members.update')->name('members.update');
    Route::post('/members/{member}/block', [ManageMembersController::class, 'block'])->middleware('admin-permission:members.block')->name('members.block');
    Route::post('/members/{member}/subscription', [ManageMembersController::class, 'grant'])->middleware('admin-permission:subscriptions.activate,subscriptions.renew')->name('members.grant');
    Route::post('/members/{member}/revoke', [ManageMembersController::class, 'revoke'])->middleware('admin-permission:subscriptions.revoke')->name('members.revoke');
    Route::post('/members/{member}/payments', [ManageMembersController::class, 'payment'])->middleware('admin-permission:payments.create')->name('members.payment');
    Route::post('/members/{member}/payments/{payment}/confirm', [ManageMembersController::class, 'confirmPayment'])->middleware('admin-permission:payments.confirm')->name('members.payment.confirm');
    Route::get('/signals', [ManageSignalsController::class, 'index'])->middleware('admin-permission:signals.view')->name('signals.index');
    Route::get('/signals/create', [ManageSignalsController::class, 'create'])->middleware('admin-permission:signals.create')->name('signals.create');
    Route::post('/signals', [ManageSignalsController::class, 'store'])->middleware('admin-permission:signals.create')->name('signals.store');
    Route::get('/signals/{signal}', [ManageSignalsController::class, 'show'])->middleware('admin-permission:signals.view')->name('signals.show');
    Route::get('/signals/{signal}/edit', [ManageSignalsController::class, 'edit'])->middleware('admin-permission:signals.update')->name('signals.edit');
    Route::put('/signals/{signal}', [ManageSignalsController::class, 'update'])->middleware('admin-permission:signals.update')->name('signals.update');
    Route::post('/signals/{signal}/status', [ManageSignalsController::class, 'status'])->middleware('admin-permission:signals.publish')->name('signals.status');
    Route::post('/signals/{signal}/result', [ManageSignalsController::class, 'result'])->middleware('admin-permission:signals.result')->name('signals.result');
    Route::post('/signals/{signal}/media', [ManageSignalMediaController::class, 'store'])->middleware('admin-permission:media.upload')->name('signals.media.store');
    Route::put('/signals/{signal}/media-order', [ManageSignalMediaController::class, 'reorder'])->middleware('admin-permission:media.reorder')->name('signals.media.reorder');
    Route::delete('/signals/{signal}/media/{media}', [ManageSignalMediaController::class, 'destroy'])->middleware('admin-permission:media.delete')->name('signals.media.destroy');
    Route::get('/media/{media}', [PrivateMediaController::class, 'admin'])->middleware('admin-permission:media.view')->name('media.stream');
    Route::get('/markets', [ManageMarketsController::class, 'index'])->middleware('admin-permission:markets.view')->name('markets.index');
    Route::post('/markets', [ManageMarketsController::class, 'store'])->middleware('admin-permission:markets.create')->name('markets.store');
    Route::put('/markets/{market}', [ManageMarketsController::class, 'update'])->middleware('admin-permission:markets.update')->name('markets.update');
    Route::post('/markets/{market}/assets', [ManageMarketsController::class, 'asset'])->middleware('admin-permission:markets.create')->name('markets.assets.store');
    Route::put('/markets/{market}/assets/{asset}', [ManageMarketsController::class, 'updateAsset'])->middleware('admin-permission:markets.update')->name('markets.assets.update');
    Route::post('/assets/{asset}/prices/manual', [ManageMarketPricesController::class, 'manual'])->middleware('admin-permission:prices.manual')->name('prices.manual');
    Route::post('/assets/{asset}/overrides/{override}/revoke', [ManageMarketPricesController::class, 'revoke'])->middleware('admin-permission:prices.override')->name('prices.override.revoke');
    Route::post('/price-sources', [ManageMarketPricesController::class, 'source'])->middleware('admin-permission:manage_integrations')->name('price-sources.store');
    Route::get('/content/media/{media}', [PublicContentMediaController::class, 'admin'])->middleware('admin-permission:cms.view')->name('content.media');
    Route::get('/content', [ManageContentController::class, 'index'])->middleware('admin-permission:cms.view,notifications.view')->name('content.index');
    Route::get('/content/pages/create', [ManageContentController::class, 'createPage'])->middleware('admin-permission:cms.create')->name('content.pages.create');
    Route::post('/content/pages', [ManageContentController::class, 'storePage'])->middleware('admin-permission:cms.create')->name('content.pages.store');
    Route::get('/content/pages/{page}/edit', [ManageContentController::class, 'editPage'])->middleware('admin-permission:cms.update')->name('content.pages.edit');
    Route::put('/content/pages/{page}', [ManageContentController::class, 'updatePage'])->middleware('admin-permission:cms.update')->name('content.pages.update');
    Route::post('/content/pages/{page}/publish', [ManageContentController::class, 'publishPage'])->middleware('admin-permission:cms.publish')->name('content.pages.publish');
    Route::post('/content/pages/{page}/hero', [ManageContentController::class, 'uploadHero'])->middleware('admin-permission:cms.update')->name('content.pages.hero');
    Route::put('/content/settings', [ManageContentController::class, 'settings'])->middleware('admin-permission:settings.brand')->name('content.settings');
    Route::put('/content/menu', [ManageContentController::class, 'menu'])->middleware('admin-permission:cms.update')->name('content.menu');
    Route::post('/content/announcements', [ManageContentController::class, 'storeAnnouncement'])->middleware('admin-permission:notifications.create')->name('content.announcements.store');
    Route::get('/content/announcements/{announcement}/edit', [ManageContentController::class, 'editAnnouncement'])->middleware('admin-permission:notifications.create')->name('content.announcements.edit');
    Route::put('/content/announcements/{announcement}', [ManageContentController::class, 'updateAnnouncement'])->middleware('admin-permission:notifications.create')->name('content.announcements.update');
    Route::post('/content/announcements/{announcement}/publish', [ManageContentController::class, 'publishAnnouncement'])->middleware('admin-permission:notifications.publish')->name('content.announcements.publish');
    Route::post('/content/notifications/{notification}/read', [ManageContentController::class, 'readAdminNotification'])->middleware('admin-permission:notifications.view')->name('content.notifications.read');
    Route::get('/{path}', fn () => abort(404))->where('path', '.*');
});

// Empty layout review only: never authenticates or reads member data.
Route::prefix('dev')->middleware('development-preview')->name('preview.')->group(function (): void {
    Route::get('/', [PreviewController::class, 'index'])->name('index');
    Route::get('/member/{page?}', [PreviewController::class, 'member'])->name('member');
    Route::get('/admin/{page?}', [PreviewController::class, 'admin'])->name('admin');
    Route::get('/states', [PreviewController::class, 'states'])->name('states');
});
