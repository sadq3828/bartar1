// Progressive enhancement only; navigation and GET filters work without JavaScript.
document.querySelectorAll('form.filter-form').forEach((form) => {
    form.addEventListener('submit', () => {
        const button = form.querySelector('button[type="submit"]');
        if (button) button.setAttribute('aria-busy', 'true');
    });
});
window.addEventListener('pageshow', () => {
    document.querySelectorAll('[aria-busy="true"]').forEach((node) => node.removeAttribute('aria-busy'));
});

document.querySelectorAll('[data-repeater]').forEach((repeater) => {
    const rows = repeater.querySelector('[data-repeater-rows]');
    const template = repeater.querySelector('template');
    const group = repeater.dataset.repeater;
    const rename = () => rows.querySelectorAll('.repeater-row').forEach((row, index) => {
        row.querySelectorAll('[data-name]').forEach((input) => {
            input.name = `${group}[${index}][${input.dataset.name}]`;
        });
        row.querySelectorAll(`[name^="${group}["]`).forEach((input) => {
            const field = input.name.match(/\[([^\]]+)\]$/)?.[1];
            if (field) input.name = `${group}[${index}][${field}]`;
        });
    });
    repeater.querySelector('[data-add-row]')?.addEventListener('click', () => {
        if (rows.children.length >= 20) return;
        rows.append(template.content.cloneNode(true));
        rename();
    });
    repeater.addEventListener('click', (event) => {
        const button = event.target.closest('[data-remove-row]');
        if (!button || rows.children.length === 1) return;
        button.closest('.repeater-row')?.remove();
        rename();
    });
});
