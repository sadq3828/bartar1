# برنامه آزمون و پذیرش

فهرست زیر برنامه جامع ۷۷ سناریویی است. پوشش مرحله‌ای با تعداد ردیف‌های این طرح یکی نیست. مرحله ۸ suite را به ۱۰۶ تست و ۱۱۲۰ assertion رساند و ۸ تست/۷۲ assertion CMS و اعلان روی MySQL واقعی دارد. قرارداد adapterهای عمومی نوبیتکس/Binance از مرحله ۷ نیز سبز مانده است؛ smoke شبکه سرور مقصد، SMS واقعی، storage بیرونی، codec و seek مرورگر، بار/قطع upload، عملیات backup/deploy و UI مرورگر هنوز آزموده نشده‌اند.

## محیط و داده آزمون

Unit برای normalization، زمان و محاسبات؛ Feature برای HTTP/session/Policy؛ Integration روی MySQL واقعی هم‌نسخه تولید برای FK، قفل و transaction؛ آزمون مرورگر برای RTL، OTP و media. SQLite جایگزین تأیید رفتار MySQL نمی‌شود. زمان با clock تزریقی/frozen time قابل کنترل و تست concurrency با اتصال‌های مستقل است.

تمام داده‌های تست مصنوعی‌اند. شماره تست از تنظیم اختصاصی محیط تست خوانده می‌شود و ارسال واقعی فقط با گیرنده مورد تأیید انجام می‌شود. FakeSms و FakePrice تنها در محیط تست، با جلوگیری صریح load در production. هیچ اطلاعات واقعی عضو در fixture یا snapshot قرار نمی‌گیرد.

| شناسه | سطح / مرحله | سناریو و نتیجه مورد انتظار |
| --- | --- | --- |
| ENV01 | smoke / ۲،۱۰ | نسخه‌ها، extension، اتصال DB/HTTPS، worker و cron با exit/status واقعی ثبت شوند |
| BOOT01 | feature / ۲ | boot Laravel و صفحات پایه واقعی با پاسخ درست؛ asset محلی و خطای عمومی |
| UI01 | browser / ۲ | عرض ۳۶۰/۳۹۰/۷۶۸/۱۴۴۰؛ nav آخرین کارت را نپوشاند و RTL صحیح باشد |
| UI02 | browser / ۲ | keyboard، focus، label، zoom ۲۰۰٪ و contrast متن/کنترل |
| UI03 | unit/browser / ۲،۴ | نمایش شمسی/تهران، ارقام فارسی و isolation شماره/قیمت |
| UI04 | browser / ۲،۶ | loading/empty/error/success، retry و media بدون preload حجیم |
| UI05 | browser / ۲،۴ | paste OTP کامل، ارقام فارسی، تغییر شماره، resend و timer سروری |
| AUTH01 | feature / ۳ | login درست مدیر session را rotate کند؛ logout نشست را بی‌اعتبار کند |
| AUTH02 | feature / ۳ | رمز غلط، username ناموجود و lock/rate limit بدون افشا |
| AUTH03 | feature / ۳ | session cookie و guard مستقل؛ حساب عضو به admin دسترسی نگیرد |
| AUTH04 | feature / ۳ | reset token اشتباه/منقضی/مصرف‌شده رد؛ کانال ناموجود موفق جعلی ندهد |
| AUTH05 | integration / ۳ | revoke نشست از دستگاه دوم در درخواست بعدی مؤثر شود |
| RBAC01 | feature / ۳ | هر permission یک allow و deny مستقیم سمت سرور |
| RBAC02 | feature / ۳ | mass assignment نقش، publish بدون permission و export بدون مجوز رد |
| RBAC03 | feature / ۳،۵ | IDOR برای عضو/مدیر حوزه محدود، فایل، اعلان و گزارش رد |
| RBAC04 | integration / ۳ | حذف آخرین مدیر اصلی، race کاهش نقش و cache مجوز کنترل شوند |
| OTP01 | feature / ۴ | شماره مجاز+فعال+اشتراک معتبر دقیقاً یک request ارسال معتبر بسازد |
| OTP02 | feature / ۴ | نامجاز، blocked، منقضی و آینده: zero SMS و zero OTP معتبر؛ پاسخ عمومی یکنواخت |
| OTP03 | unit/integration / ۴ | 09/+98/0098 و ارقام فارسی به یک E.164 برسند؛ duplicate concurrent رد |
| OTP04 | feature / ۴ | resend، IP و phone limit مشترک؛ تغییر قالب شماره bypass نکند |
| OTP05 | feature / ۴ | OTP غلط، پس از ۳۰۰ثانیه، در مرز انقضا و با purpose/session غلط رد |
| OTP06 | integration / ۴ | دو verify هم‌زمان همان کد: دقیقاً یک موفقیت؛ attempts با race دور زده نشود |
| OTP07 | feature / ۴ | کد مصرف‌شده/چالش قبلی پس از resend و block بین request/verify رد |
| OTP08 | integration / ۴ | timeout/SMS failure نشست نسازد؛ کد خام در DB/log/job/exception نباشد |
| SUB01 | unit / ۴ | تمدید فعال از پایان قبلی، منقضی از now؛ future و revoked تعیین تکلیف شوند |
| SUB02 | unit / ۴ | ماه ۱/۳/۶/۱۲، آخرماه، کبیسه، ساعت تهران، تبدیل UTC و no-overflow |
| SUB03 | integration / ۴ | دوبارکلیک و retry با idempotency key فقط یک تمدید؛ درخواست‌های مستقل serial شوند |
| SUB04 | feature/media / ۴،۶ | درست در ends_at دسترسی پنل/API/آرشیو/media قطع؛ cron خاموش هم همین رفتار |
| SUB05 | feature / ۴ | block/unblock تاریخچه و actor داشته باشد؛ unblock اشتراک منقضی را تمدید نکند |
| SUB06 | feature / ۴ | ثبت پرداخت به‌تنهایی اشتراک را فعال نکند؛ تأیید/تمدید عملیات مجزا و ممیزی‌شده |
| PAY01 | feature / ۴ | مبلغ/واحد نامعتبر و فیلد حساس کارت رد؛ درگاه یا ثبت‌نام عمومی فعال نباشد |
| SIG01 | feature / ۵ | CRUD واقعی، FK بازار/دارایی، entry/target validation و ترتیب هدف |
| SIG02 | feature / ۵ | transition غیرمجاز، publish بدون فیلد لازم یا permission رد |
| SIG03 | integration / ۵ | ویرایش published نسخه قبلی اهداف/رسانه را حفظ؛ race نسخه گم‌شده نسازد |
| SIG04 | integration / ۵ | scheduler تکراری سیگنال/اعلان را دوبار منتشر نکند |
| SIG05 | feature / ۵ | اعلام اصلاح اختیاری؛ تاریخچه و اصلاح نتیجه در هر حال ثبت شوند |
| MEDIA01 | feature / ۶ | anonymous/expired/blocked/IDOR فایل خصوصی را با URL یا Range دریافت نکند |
| MEDIA02 | browser / ۶ | پخش MP4/صوت واقعی، seek با ۲۰۶، MIME و Content-Length مناسب |
| MEDIA03 | feature / ۶ | executable با پسوند jpg، XSS، SVG فعال و traversal رد؛ quarantine قابل پخش نباشد |
| MEDIA04 | integration / ۶ | Range صحیح/نامعتبر/خارج فایل و ۴۱۶؛ revoke وسط چند درخواست قطعه تست شود |
| MEDIA05 | integration/load / ۶ | سقف حجم، قطع upload، پرشدن دیسک، هم‌زمانی و عدم OOM با ویدیو حجیم |
| MEDIA06 | integration / ۶ | delete فایل referenced در revision/backup به purge غیرمجاز منجر نشود |
| PRICE01 | unit/feature / ۷ | price>0، unit/source معتبر؛ missing هرگز صفر یا قیمت زنده ساختگی نشود |
| PRICE02 | integration / ۷ | timeout/429/5xx/provider malformed، retry/backoff و scheduler overlap کنترل شوند |
| PRICE03 | unit / ۷ | observed_at قدیمی یا آینده، stale threshold و نمایش زمان درست |
| PRICE04 | integration / ۷ | manual override معتبر اولویت؛ پایان/ابطال به آخرین API معتبر برگردد |
| PRICE05 | feature / ۷ | ثبت/اصلاح دستی permission و actor/reason/history داشته باشد |
| CMS01 | feature / ۸ | ذخیره و انتشار واقعی صفحات/بنر/منو و ترتیب بلوک‌ها طبق permission |
| CMS02 | feature/browser / ۸ | script/event handler/javascript URL و iframe غیرمجاز اجرا نشوند |
| NOTICE01 | integration / ۸ | retry و اجرای هم‌زمان فقط یک اعلان داخلی بسازند |
| NOTICE02 | integration / ۸ | عضو پیش از job تمدید یا block شود؛ job وضعیت جدید را لحاظ کند |
| NOTICE03 | integration / ۸ | timeout مبهم SMS کورکورانه تکرار نشود؛ error و reconciliation معلوم باشد |
| PERF01 | unit / ۹ | entry=100،exit=110: خرید +10٪ و فروش −10٪؛ exit=90 برعکس؛ decimal دقیق |
| PERF02 | unit / ۹ | قیمت صفر/منفی رد؛ range بدون execution price بازده قطعی ندهد |
| PERF03 | unit / ۹ | وزن‌های ۰٫۵ در +۱۰ و −۱۰ → ۰؛ مجموع>۱ رد؛ پوشش<۱ نتیجه نهایی null |
| PERF04 | feature / ۹ | صفر/ناقص/cancelled/expired در گزارش مطابق تعریف نرخ موفقیت؛ N روشن |
| PERF05 | feature / ۹ | فیلتر زمانی/بازار، نسخه اصلاح نتیجه و CSV مطابق همان داده؛ سود شخصی ادعا نشود |
| AUDIT01 | integration / ۳–۹ | mutation حساس و audit در یک transaction؛ rollback هر دو را برگرداند |
| AUDIT02 | feature / ۳–۹ | actor/time/diff و درخواست خواندن audit مجاز؛ حذف بی‌ردپا رد |
| AUDIT03 | integration / ۳–۹ | رمز/OTP/key و body خام در log، audit، queue و export دیده نشود |
| SEC01 | feature / ۱۰ | payload SQLi و mass assignment بی‌اثر؛ validation سرور |
| SEC02 | feature / ۱۰ | CSRF، CORS، GET mutation، cookie و frame protection بررسی شوند |
| SEC03 | integration / ۱۰ | production debug خاموش، Fake driver غیرقابل فعال‌سازی و secret scan |
| SEC04 | feature / ۹،۱۰ | CSV با =,+,-,@,tab,CR در spreadsheet فرمان اجرا نکند |
| SEC05 | integration / ۱۰ | provider URL داخلی، metadata endpoint و redirect ناامن به SSRF نرسد |
| SEC06 | review / ۱۰ | وابستگی/permission/error/upload/session بازبینی و یافته‌ها رفع یا ثبت شوند |
| BACKUP01 | integration / ۹ | dump+media manifest+checksum و مقصد خصوصی واقعی تأیید شوند |
| BACKUP02 | integration / ۹ | restore در DB/storage ایزوله؛ شمارش، FK و checksum رسانه مطابق باشند |
| BACKUP03 | integration / ۹ | failure/فایل ناقص/کلید غلط/پرشدن مقصد و retention آخرین سالم را حفظ کنند |
| BACKUP04 | feature / ۹ | restore تولید بدون مجوز+reauth+تأیید صریح اجرا نشود |
| OPS01 | integration / ۹ | worker/cron قطع؛ heartbeat دیرکرد و قیمت stale آشکار؛ هشدار بی‌کانال موفق جعلی نباشد |
| OPS02 | integration/load / ۹ | صف کند، disk full و timeout provider بخش‌های نامرتبط را متوقف نکنند |
| OPS03 | feature / ۹ | health عمومی حداقلی، health فنی فقط مدیر مجاز و بدون secret |
| DEPLOY01 | staging / ۱۰ | فقط public قابل وب؛ env/log/git/backup/private media غیرعمومی |
| DEPLOY02 | staging / ۱۰ | HTTPS، DNS واقعی، cookie، lockfile و audit وابستگی ثبت شوند |
| DEPLOY03 | staging / ۱۰ | deploy/rollback آزمایشی با schema سازگار و گزارش نتیجه واقعی |
| DOC01 | review / هر مرحله | گزارش ۹‌بندی، وضعیت واقعی و تصمیم‌های باز به‌روز؛ تأیید مرحله بعد ثبت شود |

## دروازه پذیرش مرحله ۱

وجود نیازمندی‌ها، مرز ماژول‌ها، مدل داده/قیود، ماتریس مجوزها، نگاشت هر ۹ مرجع، ریسک و تصمیم‌های باز، برنامه تست و محدودیت محیط بررسی شود. traceability شناسه‌های R و آزمون‌ها، لینک‌های محلی و یکسانی prompt باید با بررسی ساختاری تأیید شوند. تأیید تجاری طراحی با کاربر است و هنوز صادر نشده است.

## دروازه مراحل بعد

هر مرحله تنها با اجرای معیار خودش و گزارش خطاها بسته می‌شود. برای مرحله ۸ runtime خصوصی PHP 8.4.1 و MySQL 8.4.11 فراهم و معیارها اجرا شدند؛ binaryهای توسعه داخل بسته سورس نیستند. هر اتصال بیرونی ابتدا با Fake تست قراردادی، سپس با حساب staging و درخواست واقعی مجاز بررسی می‌شود؛ این دو سطح جدا گزارش می‌شوند.

## اجرای مرحله ۴

suite فعلی ۷۷ تست/۸۵۵ assertion موفق دارد؛ این عدد همان پوشش ۷۷ سناریوی طرح کل نیست. عضویت، تمدید، پرداخت، OTP و registry، صف MySQL و upgrade به مجموعه افزوده شدند. نام caseها در phase-4-junit.xml و حدود دقیق در PHASE_4_REPORT.md آمده است. هیچ provider SMS یا پیام واقعی، شبکه هدف، browser، بار، تست نفوذ، رقابت چند اتصال مستقل، daemon/crash واقعی یا backup/deploy با این نتایج جایگزین نمی‌شود.

## پیاده‌سازی مرحله ۵

`SignalFlowTest` شش case تازه برای SIG01–SIG05 اضافه می‌کند: FK بازار/دارایی و decimal مرتب، رد حدضرر/هدف/وزن نامعتبر، revision محتوای منتشرشده و اعلان اختیاری، انتشار زمان‌بندی‌شده idempotent، نتیجه اصلاحی append-only، و deny درخواست مستقیم مشاهده‌گر. هر ۶ case با ۴۳ assertion روی MySQL 8.4.11 موفق‌اند؛ کل suite مرحله ۵ شامل ۸۳ تست/۸۹۸ assertion نیز موفق است. JUnitهای مستقل و کامل در evidence ثبت شده‌اند و دروازه DB مرحله ۵ سبز است.

## پیاده‌سازی مرحله ۶

`MediaFlowTest` پنج case برای MEDIA01 و MEDIA03 تا MEDIA06 دارد: upload تصویر با MIME واقعی/checksum و دیسک خصوصی؛ رد جعل پسوند و سقف حجم بدون residue؛ دسترسی عضو فعال، پاسخ کامل، Range ابتدا/پسوند و ۴۱۶ چندبخشی؛ قطع دسترسی پس از block و detach بدون purge زودهنگام؛ و reorder نسخه‌دار همراه deny نقش viewer. این مجموعه ۵ تست/۷۱ assertion و suite کامل ۸۸ تست/۹۷۰ assertion روی MySQL 8.4.11 موفق‌اند. MEDIA02 صوت/MP4 و seek مرورگر و بخش load/قطع upload از MEDIA05 هنوز باز و صریحاً جایگزین نشده‌اند.

## پیاده‌سازی مرحله ۷

`MarketPriceFlowTest` ده case برای PRICE01–PRICE05 دارد: decimal دقیق و مشاهده append-only؛ اولویت، overlap و لغو قیمت دستی؛ مرز fresh/stale و زمان آینده؛ atomicity payload؛ قرارداد endpoint/query و تبدیل دقیق نوبیتکس؛ قرارداد Binance بدون کلید؛ ثبت 429 و رعایت `next_retry_at` بدون observation؛ fail-closed؛ قفل مستقل MySQL؛ و deny مستقیم نقش viewer همراه رندر بدون صفر ساختگی. این مجموعه ۱۰ تست/۷۸ assertion و suite کامل ۹۸ تست/۱۰۴۸ assertion روی MySQL 8.4.11 موفق‌اند. smoke زنده از workspace به‌علت timeout پراکسی اجرا نشد و باید روی شبکه سرور مقصد تکرار شود.

## پیاده‌سازی مرحله ۸

`ContentNotificationFlowTest` هشت case برای CMS01–CMS02 و NOTICE01–NOTICE03 دارد: انتشار صفحه مدیریت‌شده و escape متن؛ revision و رد `javascript:`؛ تصویر واقعی و عدم دسترسی پیش از انتشار؛ اطلاعیه عمومی و inbox یکتا با رد IDOR؛ dispatch idempotent outbox سیگنال؛ هشدار نزدیک پایان عضو و انقضای ادمین؛ ثبت شکست امن provider SMS بدون موفقیت جعلی؛ و allow/deny مستقیم مدیر محتوا/مشاهده‌گر. این مجموعه ۸ تست/۷۲ assertion و suite کامل ۱۰۶ تست/۱۱۲۰ assertion روی MySQL 8.4.11 موفق‌اند. upgrade مرحله ۷→۸ نیز داده‌های قبلی و event سیگنال را حفظ کرد. رقابت چند process، timeout مبهم provider واقعی و QA مرورگر هنوز بازند.

## اجرای مرحله ۹

۱۹ تست تازه با ۱۹۲ assertion در SignalReturnTest، ReportingOperationsTest، BackupRestoreTest و StageNineUpgradeTest اضافه شد. کل suite شامل ۱۲۵ تست/۱۳۱۴ assertion با صفر failure/error/skip روی PHP 8.4.26 و MySQL 8.4.13 موفق است. PERF01–PERF05، BACKUP01–BACKUP04 و بخش سلامت OPS با بازده دقیق/ناقص/صفر، CSV/مجوز، تاریخ تهران، upgrade، رمزنگاری/کلید غلط/truncation، dump/restore واقعی و FK/checksum، retention و قفل اتصال مستقل پوشش دارند. scheduler و worker واقعی نیز smoke شدند. backend/MySQL واقعی است؛ runtime آزمون برای خطای rename workspace از shared InnoDB tablespace و native AIO خاموش استفاده کرد.

اجرای دیسک‌پر واقعی، crash/kill، بار/مرورگر و مقصد بیرونی انجام نشده است. عدد تست‌ها برابر شمارش سناریوهای طرح جامع نیست. شواهد نهایی phase-9-junit.xml و phase-9-summary.json هستند.

## اجرای مرحله ۱۰

ProductionHardeningTest شش case/۴۷ assertion و WebSessionUpgradeTest یک case/۹ assertion افزوده‌اند. کل suite واقعی: ۱۳۲ تست/۱۳۷۰ assertion، صفر failure/error/skip. چهار unittest Python برای release/zip نیز موفق‌اند. تست route با روش HTTP صحیح اجرا می‌شود و CSRF export/backup/settings/member read-all را پوشش می‌دهد. دروازه‌های Host/proxy/log/debug/cache/HSTS و ارتقای نشست بررسی شدند.

تمرین محلی واقعی Nginx/PHP-FPM/MySQL شامل TLS آزمایشی، DB role بدون DDL، مسیر خصوصی/پیش‌نمایش، CSRF، ورود مدیر، escape گزارش، secure cookie و prepare/switch/rollback با حفظ نشست بود. ۸۰ درخواست هم‌زمانی ۸ بدون خطا است و load ظرفیت نهایی نیست. مرورگر و axe **not_run** هستند؛ script qa-browser آماده است. semantic source check موفق، browser/accessibility pass نیست. smoke دو provider قیمت از workspace timeout داد. پذیرش نهایی میزبان/مرورگر/ویدیو/سرویس واقعی در FINAL_ACCEPTANCE.md باز است.
