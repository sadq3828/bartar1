# طراحی امنیت و تهدیدهای اصلی

وضعیت: کنترل‌های مدیریت، عضویت/OTP، سیگنال، رسانه، قیمت و CMS/اعلان تا مرحله ۸ روی MySQL واقعی آزموده شده‌اند. تست نفوذ مستقل، مرورگر، بار و SMS واقعی هنوز تأیید نشده‌اند. جزئیات مرحله جدید در `CONTENT_NOTIFICATIONS.md` و `PHASE_8_REPORT.md` است.

## مرز اعتماد

مرورگر عضو/مدیر ورودی غیرقابل اعتماد است؛ server تنها مرجع عضویت، نقش و مالکیت رکورد است. خروجی SMS/قیمت/storage نیز داده بیرونی و نیازمند validation است. فایل آپلودی تا تشخیص MIME و تأیید quarantine قابل پخش نیست. تولید با test و development از نظر کلید، DB، session و داده جداست.

| تهدید | کنترل برنامه‌ریزی‌شده | مدرک لازم قبل عرضه |
| --- | --- | --- |
| SQL Injection / Mass Assignment | query binding، FormRequest و فهرست صریح فیلدهای مجاز؛ تغییر role از فرم عضو ممنوع | SEC01، RBAC02 |
| XSS / rich text | escape Blade، sanitizer allowlist، حذف script/event handler/URL خطرناک؛ SVG آپلودی عمومی رد شود | CMS02، MEDIA03 |
| CSRF / CORS | session هم‌مبدأ، CSRF روی mutation، GET بدون اثر؛ CORS محدود | SEC02 |
| IDOR در سیگنال/فایل/اعلان/گزارش | Policy و query scope روی هر رکورد، مدیر نیز برحسب permission | RBAC03، MEDIA01 |
| brute force و کشف مشترک | محدودیت IP/شماره/چالش، خطای یکنواخت و زمان‌بندی نزدیک | OTP02، OTP04، AUTH02 |
| OTP replay / race | HMAC با کلید سرور جدا، TTL، سقف تلاش، مصرف با row lock و transaction | OTP05–OTP08 |
| session fixation / سرقت | session rotation، HttpOnly، Secure در HTTPS، SameSite، cookie guard جدا، revoke | AUTH01، AUTH03، SUB04 |
| رسانه عمومی / path traversal | object key تولیدشده، storage خصوصی، بدون symlink عمومی، Range policy و deny traversal | MEDIA01، MEDIA04 |
| SSRF / provider جعلی | driver allowlist، TLS verification، مقصدهای خروجی مجاز؛ IP داخلی/metadata مسدود | SEC05 |
| افشای اسرار و خطا | APP_DEBUG=false، redact URL/key/OTP، خطای عمومی، error_id | SEC03 |
| CSV formula injection | escape داده آغازشونده با =,+,-,@ و tab/CR؛ quote درست و مجوز export | SEC04 |
| دستکاری ممیزی | audit transaction، append-only app، DB privileges محدود و نسخه backup جدا | AUDIT01–AUDIT03 |
| زنجیره تأمین | lockfile، Composer/npm audit واقعی، حذف dependency بی‌نیاز و بازبینی مجوز asset | DEPLOY02 |
| فشار upload / صف | quota اندازه/زمان/هم‌زمانی، rate limit، job timeout و backoff محدود | MEDIA05، OPS02 |

## کنترل هویت و اسرار

رمز مدیر با ابزار استاندارد Laravel و الگوریتم امن پشتیبانی‌شده هش می‌شود؛ رمز اولیه ثابت یا حساب آزمایشی عمومی ساخته نمی‌شود. ساخت مدیر اولیه باید فرمان CLI تعاملی/مسیر نصب کنترل‌شده با ورودی محرمانه و ثبت audit باشد، نه secret در سورس یا آرگومان shell.

در مرحله ۳، بازیابی با CLI تعاملی و ورودی مخفی، تأیید صریح، دلیل تغییر و ممیزی انجام می‌شود؛ همه نشست‌ها لغو می‌شوند. دسترسی مجاز به کنسول سرور پیش‌نیاز است. بازیابی خودکار ایمیل/پیامک پیاده نشده؛ صفحه وب فقط این روش را توضیح می‌دهد. اگر کانال وب بعداً انتخاب شود، توکن هش‌شده یک‌بارمصرف با انقضای کوتاه لازم است.

APP_KEY، OTP_HMAC_KEY و کلید backup مستقل‌اند. `.env.example` صرفاً نام متغیر خالی دارد؛ production secret در مدیریت امن میزبان/فایل محدود خارج public تزریق می‌شود. کلید در لاگ، URL قابل مشاهده کاربر، manifest عمومی، JavaScript یا API response برنمی‌گردد. تعویض کلید و ابطال session/OTP در runbook مرحله ۱۰ ثبت و آزمایش می‌شود.

## عملیات حساس

تغییر نقش/مدیر، تنظیم سرویس، purge، revoke گسترده، ایجاد/دریافت backup و restore نیازمند مجوز دقیق، reauth و audit است. مقدارهای امنیتی از UI نمی‌توانند به OTP ثابت، تولید بدون OTP، debug تولید یا private storage عمومی تغییر یابند. مدیر اصلی همه اختیار تجاری تعریف‌شده را دارد؛ قواعد امنیتی و ثبت ردپا همچنان برقرارند.

هیچ IP ثابت برای ورود مدیر اجباری نیست. 2FA در نسخه اول اختیاریِ پیاده‌سازی‌نشده است؛ `account_factors` می‌تواند در آینده بدون تغییر هویت اصلی افزوده شود. نیازمندی امنیتی را با ادعای «آماده بودن 2FA» اجراشده اشتباه نکنیم.

## داده و ممیزی

لاگ‌ها request_id، code خطا و شناسه داخلی دارند، نه body خام ورود، OTP، password، API key و شماره کامل. IP و user-agent فقط به حد لازم، با retention مشخص و دسترسی فنی محدود نگهداری شوند. خروجی گزارش شخصی اعضا با نقش گزارش عادی باز نیست.

ممیزی شامل عامل، زمان UTC، حوزه، شناسه رکورد و diff پالایش‌شده است. برای actor حذف‌شده snapshot حداقلی باقی می‌ماند. app role نباید DELETE/UPDATE audit داشته باشد؛ migration/retention با حساب جدا و ثبت عملیات است. مالک کامل سرور/DB از نظر فنی قدرت بیشتری دارد؛ عدم امکان دستکاری مطلق ادعا نمی‌شود. backup خارج سرور و checksum/anchor بیرونی در صورت نیاز قابلیت کشف دستکاری را بهتر می‌کنند.

مدت retention اطلاعات تماس، OTP challenge، session، auth log، audit، رسانه و backup در D11 باز است. جلوگیری از ثبت اسرار مستقل از تصمیم retention است. بررسی الزامات عرضه تجاری در بازارهای هدف، در D12 ثبت شده؛ در این مرحله نظر حقوقی یا تأیید مجوز ارائه نشده است.

## مرز امنیتی مرحله ۴

Phone HMAC برای lookup و encrypted TEXT برای شماره/یادداشت، POST جست‌وجو و URL بدون شماره، dontFlash برای داده حساس، queue payload بدون secret و exception پالایش‌شده provider اجرا شدند. MemberPolicy و RequireActiveMembership روی هر route خصوصی اعمال می‌شوند. بازگشت دسترسی پس از reactivation به ورود تازه نیاز دارد؛ revoke/block/phone change کدها و نشست‌ها را هم باطل می‌کنند. رسانه مرحله ۶ روی دیسک غیرعمومی، key تولیدی، MIME واقعی، checksum، state ready و endpoint کنترل‌شده قرار دارد؛ object key/نام اصلی وارد snapshot یا audit نمی‌شود. Range چندگانه/نامعتبر ۴۱۶ است و stream فایل را یک‌باره داخل حافظه نمی‌خواند. signed URL در اجرای فعلی وجود ندارد.

## مرز امنیتی مرحله ۸

CMS فقط schemaهای از پیش تعریف‌شده را می‌پذیرد؛ صفحه، icon، نوع بخش، route منو و setting آزاد نیست. متن در خروجی Blade escape می‌شود، URL جاوااسکریپت و protocol ناامن رد می‌شود و تصویر SVG/محتوای جعل‌شده با تشخیص MIME پذیرفته نمی‌شود. فایل تصویر تا انتشار صفحه فقط برای مدیر مجاز قابل خواندن است. تغییر حساس نیازمند مجوز تازه از DB، reauth و reason ممیزی‌شده است. revision محتوای منتشرشده trigger append-only دارد.

اعلان inbox با recipient سمت سرور scope می‌شود و dedupe hash‌شده جلوی تکرار retry را می‌گیرد. dispatch پیش از هر ارسال eligibility فعلی را کنترل می‌کند. SMS اعلان پیش‌فرض خاموش است؛ adapter unavailable پاسخ موفق جعلی نمی‌دهد و فقط error code امن/تعداد تلاش را ثبت می‌کند. timeout مبهم provider و reconciliation واقعی تا انتخاب سرویس باز مانده است.

## مرز امنیتی مرحله ۹

گزارش و CSV با مجوز سمت سرور، scope سیگنال منتشرشده و بدون PII اعضا هستند؛ export POST با رمز فعلی/دلیل و خنثی‌سازی formula injection است. مشاهدهٔ بکاپ با backups.view از درخواست manage_backups جداست و مجوز درخواست صف‌شده دوباره کنترل می‌شود.

SQL، manifest و رسانه با کلید جدا و sodium secretstream احراز اصالت می‌شوند. credentials ابزار MySQL فایل 0600 موقت است و در argv/log نمی‌آید. key/DB_URL دلخواه از ورودی وب گرفته نمی‌شود. مقصد private و restore فقط ایزوله/خالی با confirmation است؛ هیچ endpoint تولید یا دانلود بکاپ عمومی وجود ندارد. شکست فقط safe code دارد. جزئیات crash residue، مدیریت کلید و نیاز به نسخهٔ offsite در BACKUP_RESTORE.md صریح‌اند.

## مرحله ۱۰

Host نامجاز در production رد، forwarded host نادیده و trusted proxy به literal IP/CIDR غیر /0 محدود شد. خطاها هم CSP/nosniff/frame deny/no-store دارند؛ HTTPS HSTS می‌گیرد. exception تولید فقط نوع خطا و UUID هم‌بستگی را ثبت می‌کند؛ SQL binding، متن provider و trace خام وارد log نمی‌شوند. session دیتابیسی با payload رمزنگاری‌شده و رجیستری حوزه‌ای آزموده شد.

قالب Nginx فقط index.php را به FPM می‌فرستد؛ dotfile، storage و پسوندهای حساس از public قابل دریافت نیستند. این قواعد با HTTP واقعی محلی آزموده شدند. archive release مسیر خارج root، symlink و env خصوصی را نمی‌پذیرد. log وب قالب حداقلی بدون query/بدنه/credential دارد. کاربر غیر root سیستم‌عامل، سرویس‌های واقعی، browser، تست نفوذ و ظرفیت سرور مقصد هنوز تأیید نشده‌اند؛ صفر advisory وابستگی، تضمین امنیت کامل نیست.
