# سلامت سامانه — مرحله ۹

`/admin/health` فقط برای مدیر دارای `health.view` است. `php artisan operations:health` برای اپراتور JSON با کلیدهای ثابت و کد خروج صفر فقط وقتی همهٔ checkها healthy باشند می‌دهد؛ وضعیت پیکربندی‌نشده/نامعلوم باعث exit 1 و attention است. پاسخ، رمز، شماره، مسیر خصوصی، exception خام یا credentials ندارد.

| بررسی | شواهد و معنای وضعیت |
| --- | --- |
| DB | اجرای SELECT 1؛ failure واقعاً ناموفق است |
| رسانه خصوصی | نوشتن/خواندن بایت تصادفی و پاک‌سازی probe |
| scheduler | heartbeat واقعی command زمان‌بندی‌شده، هر دقیقه؛ بیش از ۱۸۰ ثانیه stale |
| worker | heartbeat رویداد Queue::looping برای صف database؛ نبود شاهد unknown و sync پیکربندی‌نشده |
| failed jobs | وجود job شکست‌خورده نیازمند بررسی است |
| OTP/SMS | adapter غیرفعال پیکربندی‌نشده؛ adapter دیگر بدون شاهد end-to-end نامعلوم |
| تحویل اعلان | pending/failed به‌صورت degraded نمایش داده می‌شود |
| قیمت | source فعال، آخرین موفقیت، خطای ثبت‌شده و حد stale اختصاصی source |
| بکاپ | تنظیم کلید/فعال‌سازی، آخرین شکست، وجود فایل‌های اصلی و سن آخرین completed؛ بدون اجرا unknown |
| restore | آخرین تلاش جداگانه؛ شکست failed، نبود unknown و بیش از ۷ روز stale |
| فضا | کمتر از ۱GB یا ۱۰٪ دیسک degraded |

بررسی heartbeat تاریخ آیندهٔ غیرمعقول را نیز سالم نمی‌داند. نامعلوم با سالم جایگزین نمی‌شود. بکاپ موفقِ قدیمی یا درخواست صف‌شدهٔ بدون اجرا وضعیت آماده‌بودن ایجاد نمی‌کند. بررسی وجود فایل بکاپ در هر بازدید، جایگزین verify کامل یا drill دوره‌ای نیست.

راه‌اندازی روی میزبان نیازمند cron/scheduler و queue worker واقعی است:

```bash
php artisan schedule:work
php artisan queue:work --sleep=3 --tries=3
php artisan operations:health
```

به‌جای اجرای دائمی در shell اپراتور، در تولید supervisor و cron متناسب با هاست تنظیم شود. command مربوط به heartbeat را به‌عنوان جایگزین سلامت worker اجرا نکنید؛ برای worker تنها event پردازشگر شاهد است. heartbeat هنوز مانیتورینگ بیرونی، هشدار پیامکی/ایمیلی، HTTPS/DNS check یا SLA نیست. این موارد در مرحلهٔ استقرار تصمیم و آزمایش می‌شوند.
