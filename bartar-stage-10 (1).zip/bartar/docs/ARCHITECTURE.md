# معماری پیشنهادی

## تصمیم پایه

یک Laravel Modular Monolith، یک MySQL و یک چرخه انتشار. رابط Blade با کامپوننت‌های قابل استفاده مجدد، CSS محلی و JS سبک برای فیلتر، tabs و OTP. هسته کاربرد به SPA، سرویس خارجی رندر، WebSocket یا Redis وابسته اجباری نمی‌شود. صف و cache ابتدا database قابل انتخاب‌اند؛ Redis گزینه اختیاری پس از بررسی بار و میزبانی است.

## مرز ماژول‌ها

| ماژول | مالک داده و مسئولیت | وابستگی مجاز |
| --- | --- | --- |
| Authentication | ورود مدیر/عضو، OTP، نشست و بازیابی | Members، Subscriptions، SmsGateway |
| Administration | حساب مدیر و عملیات حساس | Authorization، Audit |
| Authorization | role، permission، Policy و Guard | حساب‌های مدیر |
| Members | شماره نرمال، وضعیت و پروفایل | Audit |
| Subscriptions | پلن، بازه اعتبار، تمدید و پرداخت دستی | Members، Audit، Outbox |
| Signals | سیگنال، هدف، وضعیت، revision و نتیجه | Markets، Authorization، Audit، Outbox |
| SignalMedia | فایل خصوصی و ترتیب اتصال | Signals، PrivateMediaStorage، Policy |
| Markets / Assets | بازار، نماد و واحد قیمت | Audit |
| MarketPrices | دریافت، دستی، اولویت و تازگی | Assets، MarketPriceProvider |
| PerformanceReports | خواندن نتایج و محاسبه نسخه‌دار | Signals؛ بدون دستکاری نتایج |
| CMS | صفحه، بخش، بنر، منو و برند محدود | Authorization، فایل عمومی تأییدشده |
| Notifications | اعلان و inbox، تحویل یکتا | Outbox، SmsGateway |
| SmsIntegration | Adapter، timeout و خطای پالایش‌شده | شبکه provider؛ بدون منطق عضویت |
| BackupRestore | manifest، DB/media، retention و restore | BackupDestination، Audit |
| AuditLogs | رویدادهای پالایش‌شده و دسترسی | مستقل از حذف تجاری |
| SystemHealth | heartbeat، health و هشدار | وضعیت خلاصه ماژول‌ها |

ساختار پیشنهادی `app/Modules/<Module>/{Actions,Models,Policies,Http,Jobs,Events}` است؛ زیرپوشه خالی یا لایه اضافی بی‌استفاده ساخته نمی‌شود. Controller فقط اعتبارسنجی، فراخوانی Action و پاسخ را هماهنگ می‌کند. Action مسئول transaction، invariant و audit است. Eloquent برای persistence کافی است؛ Repository صرفاً تزئینی اضافه نمی‌شود.

## قراردادهای بیرونی

| قرارداد | ورودی / خروجی | قاعده خطا |
| --- | --- | --- |
| SmsGateway.sendOtp | شماره مجاز، کد موقت، template → provider_reference/status | timeout محدود؛ شکست باعث ایجاد نشست نمی‌شود |
| SmsGateway.sendNotification | شماره، template، dedupe_key → نتیجه پالایش‌شده | retry محدود؛ timeout مبهم، ارسال مجدد کور ممنوع |
| MarketPriceProvider.fetch | asset و unit → decimal، observed_at، source | مقدار نامعتبر رد؛ داده قبلی stale باقی می‌ماند |
| PrivateMediaStorage | put/readRange/delete/metadata با کلید داخلی | هیچ public ACL یا URL دائمی خصوصی |
| BackupDestination | write/read/verify manifest و checksum | موفقیت انتقال از موفقیت restore جداست |

هیچ کلید واقعی در DB عمومی یا تنظیمات قابل خواندن کاربر قرار نمی‌گیرد. انتخاب Adapter از config و فهرست مجاز انجام می‌شود؛ URL دلخواه ورودی مدیر بدون کنترل SSRF قابل استفاده نیست.

## ورود عضو و OTP

۱. تبدیل ارقام فارسی/عربی، trim و normalize قالب‌های `09…`، `+98…` و `0098…` به E.164؛ سپس اعتبارسنجی طول/الگو. شماره کامل در log نمایش داده نمی‌شود.

۲. rate limit مشترک IP و HMAC شماره؛ بررسی شماره مجاز، عدم block و اشتراک معتبر. پاسخ request برای شماره‌های از نظر نحوی درست یکنواخت است. برای نامجاز، چالش صوری غیرقابل تأیید و زمان پاسخ هم‌تراز؛ OTP و SMS واقعی صفر است.

۳. برای مجاز، تولید با CSPRNG، HMAC شامل challenge+purpose+code با کلید مستقل و مقایسه constant-time. TTL پیش‌فرض ۳۰۰ ثانیه. پیشنهاد: ۶ رقم با ورودی قابل چسباندن، resend پس از ۱۲۰ ثانیه، حداکثر ۵ تلاش در هر چالش؛ مقدارهای ضدسوءاستفاده در config و ممیزی تغییر کنند.

۴. ارسال هم‌زمان با timeout محدود؛ کد فقط در حافظه درخواست تا تحویل به Adapter است. کد خام در DB، log، exception و payload صف پایدار ذخیره نمی‌شود. در failure چالش قابل استفاده نیست. متن خروجی provider و URL حاوی key در log پالایش می‌شود.

۵. verify داخل transaction و قفل رکورد؛ کنترل expiry، attempts، consumed_at، challenge/session binding و دوباره بررسی اشتراک؛ مصرف یکتا و ابطال چالش‌های قبلی، سپس session rotation. رقابت دو verify فقط یک موفقیت دارد.

## دسترسی خصوصی و قطع نشست

Guard عضو و مدیر مجزا، نام cookie مجزا و rotate session پس از login. ترتیب درخواست عضو: session معتبر → account kind → وضعیت عضو → اشتراک `[starts_at, ends_at)` → مجوز رکورد. اعتبار از DB خوانده می‌شود؛ cache بلندمدت اشتراک ممنوع است. تغییر block/انقضا `auth_version` را افزایش می‌دهد و نشست‌های عضو revoke می‌شوند؛ middleware علاوه بر revoke، در هر درخواست زمان پایان را مستقل کنترل می‌کند.

رسانه نیز همین مسیر را طی می‌کند. پیش‌فرض مرحله ۶، پخش از مسیر کنترل‌شده با HTTP Range و بررسی هر درخواست است. قطعه‌ای که پیش از ابطال به دستگاه رسیده پس گرفته نمی‌شود؛ برای stream باز، بازبینی دوره‌ای دسترسی/بازه قطعات و trade-off بار مستند و تست خواهد شد.

## transaction، رقابت و job

تمدید: قفل اشتراک، شناسه idempotency یکتا، محاسبه پایان، ثبت renewal و audit در یک transaction. انتشار/اصلاح: قفل سیگنال، snapshot revision، version increment، outbox و audit در همان commit. jobها فقط بعد از commit اجرا شوند.

Outbox با کلید یکتای `(event_id,recipient_id,channel)` و وضعیت pending/processing/sent/failed از دوباره‌سازی اعلان داخلی جلوگیری می‌کند. برای SMS تضمین exactly-once شبکه بدون پشتیبانی provider داده نمی‌شود؛ timeout مبهم به reconciliation نیاز دارد. Job قبل از ارسال یادآوری، وضعیت فعلی اشتراک را دوباره کنترل می‌کند.

Scheduler برای انتشار زمان‌بندی‌شده، قیمت، یادآوری، retention و heartbeat است. نبود scheduler حق دسترسی منقضی را باز نمی‌گذارد. اجرای تک‌نمونه و قفل/unique job از هم‌پوشانی دریافت قیمت و backup جلوگیری می‌کند.

در اجرای مرحله ۷، `prices:refresh` منابع موعدرسیده را هر دقیقه بررسی می‌کند و هر منبع named lock مستقل MySQL دارد. Provider فقط از registry مجاز resolve می‌شود؛ URL دلخواه مدیر ورودی دریافت نیست. payload ابتدا کامل validate و سپس در یک transaction به مشاهده‌های append-only تبدیل می‌شود، پس payload نیمه‌خراب قیمت جزئی ثبت نمی‌کند. resolver ابتدا override فعال و سپس آخرین API هم‌واحد را انتخاب و وضعیت fresh/stale/unavailable را تولید می‌کند.

در اجرای مرحله ۸، CMS یک page builder آزاد نیست: slug صفحه، نوع بخش، icon، route منو و کلید برند همگی allowlist دارند. صفحه منتشرشده پیش از ویرایش snapshot append-only می‌گیرد و تصویر با MIME واقعی روی storage خصوصی قرار می‌گیرد؛ endpoint عمومی فقط تصویر متصل به صفحه منتشرشده را پاسخ می‌دهد. متن در Blade escape می‌شود و لینک فقط مسیر داخلی یا HTTPS معتبر است. `CONTENT_DATABASE_ENABLED=false` صفحات عمومی را بدون اتصال DB روی متن fallback امن نگه می‌دارد.

`notifications:dispatch` هر دقیقه outbox سیگنال، یادآوری نزدیک پایان و انقضا را پردازش می‌کند. کلید hash‌شده dedupe روی inbox از دوباره‌سازی در retry جلوگیری می‌کند و eligibility عضو درست پیش از ایجاد اعلان یا ارسال SMS دوباره بررسی می‌شود. SMS اعلان پیش‌فرض خاموش و adapter تولیدی تا انتخاب provider عمداً unavailable است؛ خطا با code پالایش‌شده و retry محدود ثبت می‌شود، نه موفقیت جعلی.

## وضعیت سیگنال

| مبدأ | مقصد مجاز | شرط |
| --- | --- | --- |
| draft | scheduled، published، cancelled | اعتبار فیلدها و مجوز publish برای انتشار |
| scheduled | draft، published، cancelled | زمان و انتشار دقیقاً یک بار |
| published | completed، cancelled، expired | نتیجه تکمیل و دلیل تغییر ثبت شود |
| completed، cancelled، expired | همان وضعیت برای اصلاح نسخه‌دار | بازنشر مستقیم ممنوع؛ سیگنال جدید یا تصمیم تجاری جدا |

نتیجه بازده به هر revision نتیجه و نسخه فرمول متصل است؛ محاسبه نباید گذشته را بی‌ردپا عوض کند. پیشنهاد فرمول‌ها و نقاط باز در [DATABASE.md](DATABASE.md) ثبت شده‌اند.

## مسیرهای هدف

عمومی: `/`، `/about`، `/subscription`، `/guide`، `/terms`، `/privacy`، `/contact`، `/announcements`، `/login`.

عضو: `/app`، `/app/markets`، `/app/signals`، `/app/signals/{id}`، `/app/performance`، `/app/notifications`، `/app/account`، `/app/subscription` و `/private/media/{id}`. خروج با POST است. منقضی فقط صفحه محدود وضعیت/راهنمای تمدید و خروج را می‌بیند، به هیچ داده خصوصی دسترسی ندارد.

مدیر: `/admin/login` و زیرمسیرهای `/admin` طبق ماژول‌ها. endpoint ناشناخته، دسترسی غیرمجاز و خطا، داده خصوصی یا stacktrace برنمی‌گرداند. API نسخه اول هم‌مبدأ و session/CSRF است؛ public API با token بدون نیاز اضافه نمی‌شود.

## اجرای مرحله ۹

Reports محاسبات append-only را با فرمول weighted-gross-v1 به resultهای نسخه‌دار متصل می‌کند. ورودی از revision پیش از result می‌آید و GET گزارش mutation ندارد. آمار و CSV فقط آخرین result را می‌شمارند و coverage و N را روشن نمایش می‌دهند.

BackupRestore دارای صف درخواست مستقل DB، قفل named MySQL، dump واقعی، inventory رسانه در snapshot قفل‌شده، رمزنگاری streaming و manifest احراز اصالت‌شده است. مقصد فعلی local/private است. restore فقط به DB خالی با پیشوند bartar_restore_ و زیرپوشهٔ رسانهٔ جدید می‌رود؛ وارد تولید نمی‌شود. retention نسخهٔ آخر restoreشده و حداقل دو completed را نگه می‌دارد و پیش از حذف، نسخه‌های محافظت‌شده را verify می‌کند.

SystemHealth با heartbeat واقعی scheduler/worker و probeهای محدود داده/دیسک، healthy را از unknown/stale/not_configured/failed جدا می‌کند. این بخش جای مانیتور بیرونی یا تأیید سرویس SMS را نمی‌گیرد.

## آماده‌سازی production مرحله ۱۰

کنترل Host به APP_URL در production محدود است. middleware جایگزین proxy فقط IP/CIDR صریح را می‌پذیرد و forwarded host را اعتماد نمی‌کند. SecurityHeaders روی responseهای exception نیز اعمال می‌شود؛ log تولید پیام/trace خام ندارد و با request ID پیگیری می‌شود. debug HTTP در production خاموش می‌ماند و preflight تنظیم debug نامناسب را همچنان blocked می‌کند.

DeploymentReadiness چک‌های ثابت و سرویس‌ها را بدون اسرار گزارش می‌کند. release.py آرشیو را پیش از نوشتن بررسی و sourceها را زیر releases با env/storage مشترک آماده می‌کند؛ فعال‌سازی/بازگشت فقط هدف تأییدشده و schema سازگار را با symlink عوض می‌کند. migration/reload/DNS خودکار نیستند. جزئیات و محدودیت نسخهٔ قبل در RELEASE_RUNBOOK.md هستند.
