# منابع رسمی و حدود بررسی

تاریخ مراجعه: ۲۰۲۶-۱۰-۱۹. این‌ها منابع بیرونی طراحی‌اند؛ دسترسی به یک صفحه مستندات، آزمایش سرویس یا نصب فناوری نیست. قیمت/امکانات سرویس باید هنگام خرید و اتصال دوباره بررسی شود.

## فناوری

| منبع رسمی | یافته محدود مورد استفاده |
| --- | --- |
| [Laravel 13 Release Notes](https://laravel.com/framework/docs/13.x/releases) | Laravel 13 با PHP 8.3–8.5؛ تاریخ release هفدهم مارس ۲۰۲۶ و پایان اصلاح امنیتی هفدهم مارس ۲۰۲۸ در جدول رسمی ثبت است. قید `^13.0` مبنای پیشنهادی است. |
| [PHP Supported Versions](https://www.php.net/supported-versions.php) | شاخه 8.4 تا پایان ۲۰۲۶ حمایت فعال و تا پایان ۲۰۲۸ امنیتی؛ 8.5 نیز در جدول پشتیبانی موجود است. |
| [MySQL LTS and Innovation](https://dev.mysql.com/doc/refman/8.4/en/mysql-releases.html) | 8.4 مسیر LTS است؛ این شاخه برای مبنای پایدار پیشنهاد شده و ادعای جدیدترین بودن ندارد. |
| [Laravel Deployment](https://laravel.com/framework/docs/13.x/deployment) | حداقل PHP 8.3، افزونه‌ها، document root عمومی، دسترسی پوشه‌ها، worker و خاموشی debug تولید مبنای طرح استقرارند. |

در مرحله ۱ manifest و lockfile وجود نداشت. در مرحله ۲، Laravel framework 13.37.0، Composer و ۱۱۰ بسته از lock واقعی نصب شدند. تاریخ/نسخه دقیق dependency در composer.lock است؛ Composer validate، check-platform-reqs و audit اجرا شدند. تقویم نمایشی از IntlDateFormatter تقویم Persian و timezone تهران استفاده می‌کند؛ حساب‌کردن ماه اشتراک هنوز مرحله ۴ است.

## منابع پیاده‌سازی مرحله ۲

- [نصب رسمی Laravel](https://laravel.com/framework/docs/13.x/installation): اسکلت با Composer create-project و بدون اجرای migration/seed خودکار دریافت شد.
- [دریافت Composer](https://getcomposer.org/download/): SHA-256 فایل phar با مقدار منتشرشده در همان دامنه مطابقت داده شد.
- PHP توسعه از مسیر توزیعی معرفی‌شده در نصب رسمی Laravel یعنی php.new / Herd Lite، در workspace دریافت شد. نسخه فایل دریافت‌شده 8.4.1 است؛ فقط ابزار آزمون محلی است و در source ZIP قرار ندارد. این بررسی تأیید به‌روز بودن patch برای تولید نیست.
- [پروژه رسمی Vazirmatn](https://github.com/rastikerdar/vazirmatn): فونت Regular محلی و متن کامل OFL در public/assets/fonts موجودند؛ فایل‌ها از مخزن رسمی دریافت و hash شده‌اند.
- illustration انتزاعی بازار، favicon و آیکون‌ها SVG نوشته‌شده در همین پروژه هستند؛ نمودار یا قیمت واقعی بازار را نمایش نمی‌دهند.

## پیامک — بررسی مقدماتی گزینه‌ها

| گزینه | شواهد API/OTP | هزینه و محدودیت قابل بررسی | وضعیت واقعی |
| --- | --- | --- | --- |
| کاوه‌نگار | [REST رسمی](https://kavenegar.com/rest.html)، verify/lookup و template؛ خطاهای الگو/اعتبار/سطح سرویس مستند است | [تعرفه رسمی](https://kavenegar.com/pricing.html)؛ نوع پنل و فعال‌بودن خدمت اعتبارسنجی در هزینه/دسترسی مؤثر است | مستندات خوانده شد؛ حساب، کلید، template و ارسال واقعی نداریم |
| ملی‌پیامک | [مستندات رسمی API](https://www.melipayamak.com/api/) شامل OTP، پیامک پترن، delivery و دریافت تعرفه | تعرفه حساب/نوع ارسال و شرایط پترن باید با طرح منتخب و قرارداد بررسی شود؛ نرخ قطعی برای برتر معلوم نیست | مستندات خوانده شد؛ حساب و تست تحویل نداریم |
| SMS.ir | صفحه عمومی `https://sms.ir/api/` در مراجعه ابزار خطای داخلی داشت | بدون محتوای معتبر درباره تعرفه/سازگاری نتیجه قطعی داده نشد | نیازمند بررسی مجدد پیش از مقایسه نهایی |

مقایسه فنی اولیه: هر دو گزینه اول مسیر قالب‌دار و گزارش وضعیت را در مستندات دارند؛ کیفیت تحویل، دسترسی از سرور هدف، محدودیت خط خدماتی، whitelist/template، SLA و تعرفه واقعی پروژه باید روی حساب منتخب آزمایش/استعلام شوند. برتری قطعی یا تضمین پایداری هیچ‌یک ادعا نمی‌شود.

هزینه مقایسه نهایی شامل پنل، هزینه هر بخش پیامک، نوع ارسال OTP/خدماتی، مالیات و حجم مصرف است؛ اعداد نمونه API تعرفه روز محسوب نمی‌شوند. هیچ مبلغ از نمونه‌های قدیمی مستندات کپی نشده است. انتخاب خودکار، ساخت حساب یا ارسال پیام به کسی انجام نشده است.

## مراجع داخل گفتگو

[پرامپت اصلی](SOURCE_PROMPT.md) و جدول ۹ تصویر در [UI_SPEC.md](UI_SPEC.md). فایل‌های تصویر ورودی محفوظ‌اند؛ به‌دلیل شماره تلفن/اطلاعات صفحه مرجع، داخل بسته خروجی تکثیر نشده‌اند. از سایت نمایش‌داده‌شده در تصویر حسابی باز نشده و اطلاعاتی از آن خوانده نشده است.

## اجرای MySQL مرحله ۳

آرشیو رسمی MySQL Community 8.4.11 minimal از `https://cdn.mysql.com/Downloads/MySQL-8.4/mysql-8.4.11-linux-glibc2.28-x86_64-minimal.tar.xz` برای runtime خصوصی توسعه استفاده شد؛ libaio بسته Debian وابستگی سیستم آن بود. نسخه از SELECT VERSION واقعی تأیید شد. کد Laravel SessionGuard، Middleware configuration و Testing framework از vendor نصب‌شده برای بررسی رفتار کوکی، timebox و prompt تست خوانده شد؛ پیاده‌سازی امنیت متکی به API موجود همان lock است. هیچ binary DB/PHP یا credential به بسته سورس اضافه نشده است.

## منابع فنی مرحله ۹

- PHP sodium secretstream: https://www.php.net/manual/en/function.sodium-crypto-secretstream-xchacha20poly1305-init-push.php
- MySQL 8.4 mysqldump: https://dev.mysql.com/doc/refman/8.4/en/mysqldump.html
- MySQL 8.4 server options: https://dev.mysql.com/doc/refman/8.4/en/server-options.html

این منابع قرارداد ابزار را توضیح می‌دهند؛ شواهد اجرای خود پروژه در evidence/phase-9-junit.xml و گزارش مرحله ۹ است.

## منابع مرحله ۱۰ (بررسی در ۲۰۲۶-۱۰-۲۱ تهران)

- Laravel 13 deployment: https://laravel.com/framework/docs/13.x/deployment
- Laravel trusted proxies/hosts: https://laravel.com/framework/docs/13.x/requests
- Nginx core directives: https://nginx.org/en/docs/http/ngx_http_core_module.html
- PHP supported branches: https://www.php.net/supported-versions.php

قالب‌ها برای پروژه تنظیم شده‌اند. این منابع، نتیجهٔ آزمون خود پروژه یا patch امنیتی میزبان مقصد را تأیید نمی‌کنند. نسخه‌های ابزار و نتیجهٔ واقعی در evidence ثبت‌اند؛ هیچ قیمت سرویس یا تضمین ظرفیت از این منابع استنباط نشده است.
