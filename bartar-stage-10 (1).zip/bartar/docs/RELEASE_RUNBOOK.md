# راهنمای استقرار و بازگشت — مرحله ۱۰

این بسته روی سرور یا دامنهٔ واقعی منتشر نشده است. دستورهای زیر برای اپراتور دارای دسترسی مصوب‌اند. `deployment:check` آمادگی فنی را بررسی می‌کند؛ خروجی موفق آن، رسید ارسال پیامک، اعتبار گواهی عمومی، ظرفیت تولید یا مجوز انتشار نیست.

## آماده‌سازی میزبان

PHP 8.4 CLI و FPM با نسخه و افزونه‌های هماهنگ، MySQL 8.4، Nginx، Composer، Python 3 و cron/systemd لازم‌اند. Node فقط برای build و آزمون مرورگر استفاده می‌شود. پوشهٔ `/srv/bartar` در این سند یک مسیر نمونه است؛ پیش از اجرا مسیر و کاربر واقعی را تعیین کنید. پوشه‌ها متعلق به کاربر برنامه باشند؛ FPM با کاربر غیر root و فقط `storage` و `bootstrap/cache` قابل نوشتن باشند. مقادیر pool نمونه، ظرفیت تأییدشده نیستند.

فایل‌های `deploy/nginx.conf.example`، `php-fpm.conf.example`، `worker.service.example` و `scheduler.cron.example` را با مقادیر میزبان تکمیل کنید. هیچ token از نوع `@...@` نباید باقی بماند. HTTP server بیرونی فقط `current/public` را سرو کند. فایل پیکربندی Nginx داخل `http {}` بارگذاری می‌شود؛ مسیر `deploy/fastcgi_params` را نیز نصب کنید. مسیر private media، log و backup در document root قرار نگیرند و `public/storage` ایجاد نشود.

یک کاربر DB برای migration با CREATE/ALTER/TRIGGER/INDEX و یک کاربر جدا برای وب با DML موردنیاز آماده کنید. کاربر وب نباید root یا دارای DROP/ALTER/CREATE/TRIGGER باشد. نقش‌های مدیریتی برنامه، مجوز MySQL نیستند. triggerهای append-only حفظ شوند. backup/restore حساب عملیاتی جدا با دسترسی لازم خود دارند؛ رمزها در Git، argv، history یا سند نوشته نشوند.

## تهیهٔ release

۱. SHA256 بسته را با مقدار تحویل‌شده مقایسه کنید؛ آرشیو روی سیستم اپراتور بررسی شود. دستور prepare مسیرهای traversal، symlink، محیط خصوصی یا vendor داخل آرشیو را رد می‌کند و نسخهٔ موجود را بازنویسی نمی‌کند.

```bash
python3 scripts/release.py prepare --archive bartar-stage-10.zip --root /srv/bartar --release-id release_YYYYMMDD_01
```

۲. فایل `shared/.env` را از روی `deploy/env.production.example` با مقادیر واقعی در کانال امن بسازید و permission آن را 0600 کنید. هر release به همین فایل و storage مشترک symlink دارد. APP_KEY و OTP_HMAC_KEY قدیمی در ارتقا حفظ شوند؛ ساخت کلید تازه در ارتقای دادهٔ رمزنگاری‌شده مجاز نیست. نصب تازه کلید تصادفی مستقل می‌خواهد. scheduler/worker قدیمی پیش از migration متوقف یا drain شوند.

۳. در مسیر release و با همان PHP هدف اجرا کنید:

```bash
composer install --no-dev --prefer-dist --no-interaction --optimize-autoloader
composer check-platform-reqs --no-dev
```

assetها از قبل در بسته‌اند و manifest باید سالم باشد. در صورت ساخت دوباره، `npm ci` و `npm run build` با lock استفاده شود. dev dependencyها شامل Playwright/axe فقط برای آزمون‌اند و در وب اجرا نمی‌شوند.

۴. پیش از migration بکاپ واقعی و drill مستقل لازم است. اولین نصب به‌دلیل نبود schema قبل از migration، هنوز gate را نمی‌گذراند. با حساب migration فقط forward migration بازبینی‌شده را اجرا کنید، سپس مشخصات محیط را به کاربر محدود وب برگردانید:

```bash
php artisan migrate --force
php artisan db:seed --force
php artisan reports:calculate
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan deployment:check
```

seed فقط metadata/plan است و حساب نمونه نمی‌سازد. ایجاد اولین مدیر با `bartar:admin-create` تعاملی و مجاز است؛ حساب یا رمز پیش‌فرض وجود ندارد. خطای gate را با حذف check یا استفاده از `--staging` روی سرویس عمومی پنهان نکنید. پس از تغییر env، config cache دوباره ساخته شود.

## DNS، HTTPS و `.ir`

مالک دامنه/کنترل DNS باید مشخص باشد. در پنل سرویس DNS منتخب، A و در صورت وجود IPv6 واقعی AAAA دامنهٔ canonical را به IP میزبان بدهید؛ مقدار IP هنوز در این پروژه مشخص نیست. برای `.ir` نیز ابتدا DNSهای authoritative در پنل ثبت‌کنندهٔ مجاز مالک تنظیم شوند. رکورد مربوط به نام یا IP حدسی نسازید. propagation، پاسخ authoritative و دسترسی بیرونی از چند شبکه باید بررسی شوند.

گواهی معتبر برای همان نام و زنجیرهٔ کامل نصب شود؛ مسیر ACME در HTTP vhost برای صدور/تمدید در نظر گرفته شده است. پیش از فعال‌کردن HTTPS vhost، گواهی باید وجود داشته باشد. HTTP به نام canonical با 308 هدایت می‌شود. TLS 1.2/1.3، HSTS بدون preload و بدون تحمیل includeSubDomains تنظیم شده‌اند. تمدید گواهی و reload امن Nginx باید آزمایش شود. گواهی self-signed تمرین محلی، گواهی عمومی محسوب نمی‌شود.

APP_URL فقط یک میزبان HTTPS canonical است. alias مانند www باید vhost و گواهی معتبر خودش را داشته باشد و به canonical هدایت شود. برنامه در production میزبان دیگر را رد می‌کند. TRUSTED_PROXIES فقط IP/CIDR واقعی proxy است؛ `*`، `REMOTE_ADDR` و شبکهٔ /0 پذیرفته نمی‌شوند. پشت Nginx مستقیم با FPM، اغلب خالی‌ماندن این متغیر درست است. X-Forwarded-Host قابل اعتماد فرض نشده است.

## فعال‌سازی پس از پذیرش و تأیید مالک

SMS واقعی، صفر ارسال برای شمارهٔ نامجاز، منبع قیمت از شبکهٔ هدف، worker/scheduler، بکاپ و drill باید تأیید شوند. بررسی چشمی/مرورگر و ظرفیت میزبان نیز لازم‌اند. command فعال‌سازی هیچ‌کدام را جعل نمی‌کند.

```bash
python3 scripts/release.py activate --root /srv/bartar --release-id release_YYYYMMDD_01 --confirm release_YYYYMMDD_01 --schema-compatible
```

این فرمان preflight همان release را اجرا، `previous` را حفظ و `current` را تعویض می‌کند. migration، نصب dependency، حذف، تغییر DNS، restart سرویس یا فعال‌کردن maintenance به‌صورت پنهان انجام نمی‌دهد. پس از switch، PHP-FPM reload و worker restart شوند؛ realpath در FastCGI مانع نگه‌داشتن نام symlink به‌عنوان مسیر کد است. hookهای reload باید بر اساس سرویس واقعی میزبان اجرا و نتیجه ثبت شوند. cron فقط یک نسخه باشد. مسیر `/up` تنها boot را تأیید می‌کند؛ عملیات با `operations:health` بررسی شود.

## بازگشت و محدودیت schema

در این مرحله فقط جدول sessions افزوده شده و rollback عادی باید کد را برگرداند و schema افزایشی را حفظ کند. DB restore، `migrate:rollback` یا حذف جدول در بازگشت معمول اجرا نشود. سازگاری کد قبلی با schema جلوتر را پیشاپیش روی staging بررسی کنید.

```bash
python3 scripts/release.py rollback --root /srv/bartar --release-id release_PREVIOUS --confirm release_PREVIOUS --schema-compatible
```

فرمان فقط release آماده و دارای deployment:check را می‌پذیرد. بستهٔ قدیمی مرحله ۹ این command را ندارد؛ بازگشت خودکار به آن ادعا نشده و نیازمند آماده‌سازی/پذیرش جداست. تمرین این تحویل، دو release از بستهٔ مرحله ۱۰ با DB/storage مشترک و marker آزمایشی جدا بود؛ ورود و نشست پس از switch و rollback حفظ شدند. این شاهد، restore دادهٔ تولید یا انتشار عمومی نیست.

`--staging` تنها برای میزبان localhost/loopback یا `.test` و DB دارای test در نام است؛ سرویس‌های بیرونی در آن اجباری نیستند و خروجی `staging_ready` آمادگی تولید نیست. استفادهٔ روزمره از این flag برای دورزدن gate ممنوع عملیاتی است. مجوز صریح انتشار واقعی مستقل از همهٔ این دستورهاست.
