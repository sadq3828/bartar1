# محتوا و اعلان — مرحله ۸

## دامنه اجراشده

پنل «محتوا و اعلان» برای مدیر مجاز، صفحه‌های عمومی از پیش تعریف‌شده، ترتیب بخش‌ها، تصویر شاخص، برند، منوی عمومی و اطلاعیه را بدون تغییر کد مدیریت می‌کند. این قابلیت page builder آزاد نیست؛ فقط slug، icon، نوع بخش، route منو و settingهای تعریف‌شده در `ManageContent` پذیرفته می‌شوند.

صفحه‌های قابل مدیریت: خانه، درباره ما، عضویت، راهنما، قوانین، حریم خصوصی و تماس. بخش‌ها از نوع `text`، `banner` یا `cta` هستند. لینک CTA فقط مسیر داخلی با `/` یا HTTPS معتبر است. متن در Blade escape می‌شود و HTML خام اجرا نمی‌شود.

## انتشار و نسخه‌ها

- صفحه جدید draft است و تا انتشار، جای fallback امن config را نمی‌گیرد.
- انتشار حداقل یک بخش قابل نمایش می‌خواهد و `cms.publish`، رمز فعلی و دلیل را دوباره بررسی می‌کند.
- ویرایش صفحه منتشرشده snapshot نسخه قبلی را در `content_page_revisions` نگه می‌دارد و version را افزایش می‌دهد.
- revision با triggerهای MySQL append-only است؛ UPDATE/DELETE عادی رد می‌شود.
- `CONTENT_DATABASE_ENABLED=false` خواندن CMS را برای حالت اضطراری خاموش می‌کند و صفحات عمومی را بدون اتصال DB از config رندر می‌کند. مقدار تولید عادی باید true باشد.

## تصویر محتوا

تصویر JPEG، PNG یا WebP واقعی تا سقف ۵MB پذیرفته می‌شود. MIME از محتوای فایل تشخیص داده می‌شود؛ SVG، executable یا فایل جعل‌شده با پسوند تصویر رد می‌شود. فایل با object key تولیدی روی دیسک خصوصی `signal-media` قرار می‌گیرد. endpoint عمومی فقط وقتی پاسخ می‌دهد که تصویر به صفحه منتشرشده متصل باشد؛ مدیر دارای `cms.view` پیش از انتشار می‌تواند preview را ببیند.

## اطلاعیه و inbox

اطلاعیه می‌تواند برای `public`، `members` یا `all` باشد، زمان پایان اختیاری دارد و پس از انتشار به inbox اعضای واجد شرایط fan-out می‌شود. انتشار یا retry تکراری به‌دلیل `dedupe_key` یکتا اعلان دوم نمی‌سازد. صفحه عمومی فقط audience مناسب و بازه زمانی معتبر را نمایش می‌دهد.

عضو از `/app/notifications` فقط اعلان‌های خودش را می‌بیند و با POST یک اعلان یا همه را خوانده علامت می‌زند. شناسه اعلان عضو دیگر 404 است. رویدادهای زیر در inbox پشتیبانی می‌شوند:

- انتشار، تغییر مهم، تکمیل یا اصلاح نتیجه سیگنال؛
- اطلاعیه مدیر برای اعضا؛
- نزدیک‌شدن پایان اشتراک تا سه روز؛
- هشدار انقضای اخیر اشتراک برای مدیر دارای `notifications.view`.

## dispatch و SMS

Scheduler هر دقیقه `notifications:dispatch` را اجرا می‌کند. outbox سیگنال قفل می‌شود، تعداد تلاش و خطای امن ثبت و پس از fan-out به `dispatched` می‌رود. eligibility عضو درست پیش از ایجاد اعلان و دوباره پیش از SMS کنترل می‌شود. زمان انقضا مستقل از scheduler همچنان در middleware دسترسی enforce می‌شود.

SMS اعلان با `NOTIFICATION_SMS_ENABLED` کنترل می‌شود و پیش‌فرض خاموش است. فقط هشدارهای اشتراک/اداری delivery می‌سازند. adapter تولیدی فعلی `UnavailableNotificationSmsSender` است: موفقیت جعلی نمی‌دهد، `provider_unavailable` ثبت می‌کند و retry بعدی را ۱۵ دقیقه بعد تا سقف سه تلاش زمان‌بندی می‌کند. پیش از فعال‌سازی باید provider واقعی، template، حساب staging، timeout مبهم و reconciliation تصمیم و آزمون شوند.

## مجوز و ممیزی

`cms.view/create/update/publish`، `notifications.view/create/publish` و `settings.brand` جدا هستند. `content_manager` مجوز CMS، برند و اعلان را دارد؛ `viewer` با درخواست مستقیم رد می‌شود. همه mutationهای حساس در Action مجوز تازه از DB، reauthentication و reason را بررسی و audit حوزه `cms` ثبت می‌کنند.

## اجرای عملیاتی

```bash
php artisan migrate --force
php artisan notifications:dispatch
php artisan schedule:work
```

در production فقط یک scheduler فعال باشد. queue/cron، provider SMS و خطاهای delivery باید در مرحله عملیات مانیتور شوند. هیچ حساب، صفحه نمونه یا اطلاعیه نمایشی seed نمی‌شود.

## شواهد و حدود

`ContentNotificationFlowTest` شامل ۸ تست و ۷۲ assertion است. کل suite مرحله ۸ شامل ۱۰۶ تست و ۱۱۲۰ assertion روی MySQL Community 8.4.11 موفق شد. نصب تمیز و ارتقای واقعی مرحله ۷→۸ با حفظ داده‌های قبلی نیز موفق بود. race چند process، provider واقعی SMS، مرورگر/دسترس‌پذیری و بار هنوز اجرا نشده‌اند.
