# گزارش ۹‌بندی مرحله ۸

## ۱. دامنه

CMS محدود برای صفحه، بخش، تصویر، برند و منوی عمومی؛ اطلاعیه عمومی/اعضا؛ inbox عضو؛ fan-out رویداد سیگنال؛ هشدار پایان اشتراک؛ scheduler و adapter امن SMS ساخته شد. گزارش عملکرد، backup/restore، سلامت عملیاتی و استقرار خارج دامنه مرحله ۸ ماند.

## ۲. فایل‌ها

ماژول‌های `Content` و `Notifications` با Model، Action و Controller اضافه شدند؛ قرارداد/adapter اعلان در `SmsIntegration`، migration `000006`، routeهای عمومی/عضو/مدیر، command زمان‌بندی‌شده، viewهای CMS/inbox و CSS نسخه ۸ تکمیل شدند. `CONTENT_NOTIFICATIONS.md` راهنمای عملیاتی است.

## ۳. دیتابیس

۹ جدول `content_media`، `content_pages`، `content_sections`، `content_page_revisions`، `content_settings`، `content_menu_items`، `announcements`، `member_notifications` و `notification_deliveries` اضافه شدند. `signal_announcements` سه فیلد پردازش/تلاش/خطا گرفت. قیدهای status/audience/kind/channel، FKها، dedupe یکتا و triggerهای append-only revision اعمال شدند.

## ۴. امنیت و مجوز

slug/type/icon/route/setting allowlist است؛ متن Blade escape می‌شود؛ URL جاوااسکریپت رد و فقط مسیر داخلی/HTTPS پذیرفته می‌شود. تصویر با MIME واقعی و سقف ۵MB روی storage خصوصی است و پیش از انتشار عمومی نیست. mutationها RBAC سمت سرور، reauth، reason، transaction و audit دارند. inbox با recipient scope می‌شود و IDOR عضو دیگر 404 است.

## ۵. منطق اعلان

هر گیرنده/event کلید dedupe hash‌شده دارد. outbox سیگنال با lock و وضعیت پردازش می‌شود؛ retry اعلان دوم ایجاد نمی‌کند. وضعیت فعلی عضو/اشتراک پیش از fan-out و SMS دوباره بررسی می‌شود. نزدیک پایان برای عضو و انقضا برای مدیر مجاز اعلان می‌سازد. انقضای دسترسی مستقل از scheduler باقی است.

## ۶. UI

مدیر از پنل «محتوا و اعلان» صفحه/بخش/تصویر، برند، منو و اطلاعیه را مدیریت می‌کند. صفحه عمومی، اطلاعیه‌ها، header/footer/nav و تصویر منتشرشده از DB خوانده می‌شوند و fallback امن config دارند. عضو inbox واقعی با خواندن تکی/همه دارد. assetهای محلی با نسخه ۸ ساخته شدند.

## ۷. آزمون

PHP 8.4.1 و MySQL Community 8.4.11 واقعی استفاده شد. ۸ تست مرحله ۸ با ۷۲ assertion و کل suite شامل ۱۰۶ تست/۱۱۲۰ assertion موفق شدند. نصب تمیز و ارتقای مرحله ۷→۸ با حفظ ۲ حساب، ۱ عضو، اشتراک، بازار، دارایی، سیگنال، outbox و source قیمت موفق بود؛ ۹ جدول و ۳ ستون جدید و ۳ مجوز اعلان مدیر محتوا تأیید شدند. Composer validate/platform/audit بدون advisory، lint ۲۶۲ فایل PHP، build پنج asset و cache config/route/view موفق بود؛ ۱۰۲ route ثبت است.

## ۸. خطاها و حدود

در اجرای اولیه، regex لینک/نام فایل و مقایسه SQL زمان با precision میکروثانیه باعث شکست تست‌های هدف شد؛ regexها اصلاح و eligibility/بازه انقضا از castهای دامنه با یک زمان مرجع محاسبه شد. composer/asset checks موفق بودند؛ `optimize:clear` بدون env تولید به cache دیتابیسی دسترسی خواست، بنابراین پاک‌سازی نهایی با cache/session آرایه‌ای انجام شد و artifact cache تولیدی باقی نماند. provider SMS واقعی، timeout مبهم/reconciliation، رقابت چند process، مرورگر، دسترس‌پذیری و load تست نشده‌اند. PHP 8.4.1 محلی قدیمی است و binary در بسته نیست.

## ۹. وضعیت و ادامه

checkpoint فنی مرحله ۸ سبز است، اما کل محصول آماده عرضه اعلام نمی‌شود. قیمت عمومی رمزارز، CMS و اعلان داخلی واقعی‌اند؛ SMS بیرونی عمداً غیرفعال است تا provider انتخاب شود. دو مرحله ۹ و ۱۰ باقی‌اند. deploy، DNS، commit و push انجام نشده‌اند و ورود به مرحله ۹ به دستور مالک نیاز دارد.
