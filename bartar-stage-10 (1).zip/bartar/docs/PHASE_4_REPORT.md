# گزارش مرحله ۴ — شماره‌ها، اشتراک و OTP

شروع با دستور «ادامه بده» در ۲۰۲۶-۱۰-۲۰ به وقت تهران مجاز شد. checkpoint مرحله ۳ با SHA256 `81c97f5d6baba2de98ef0c1783494712642ffd7ab905af0cc730a7e1bc004874` محفوظ است. commit/push و استقرار انجام نشده‌اند. این گزارش فقط مرحله ۴ را پوشش می‌دهد.

## ۱. کارهای انجام‌شده

شماره مجاز با نرمال‌سازی رقم/قالب ایران و منع تکرار، نام نمایشی و یادداشت داخلی، جست‌وجو/فیلتر، مسدودی/رفع مسدودی، فعال‌سازی/تمدید ۱/۳/۶/۱۲ماهه، لغو اشتراک، تاریخچه عامل/زمان/دلیل، و پرداخت دستی ثبت/تأیید ساخته شدند. ثبت یا تأیید پرداخت، اشتراک را خودکار فعال نمی‌کند.

تقویم هر تمدید در فرم صریح و در دفترکل ذخیره است؛ شمسی/میلادی، آخر ماه و کبیسه، مبنای پایان فعال/اکنون منقضی و idempotency پیاده شدند. شماره و یادداشت داخلی در DB رمزگذاری و جست‌وجوی شماره با HMAC انجام می‌شود؛ فرم POST است تا شماره وارد URL نشود.

ورود OTP شش‌رقمی، HMAC مستقل، صف با ULID تنها، rate limit، resend، زمان انقضا، قفل مصرف، مرورگر متصل، guard/cookie جدا و registry عضو ساخته شدند. کد فقط در حافظه worker ساخته می‌شود؛ raw code در صف/DB/log/session نگهداری نمی‌شود. کنترل اشتراک هر درخواست خصوصی، انقضا/مسدودی/لغو و جلوگیری از زنده‌شدن نشست قدیمی پس از تمدید منقضی آزموده شدند.

قرارداد SMS و adapter غیرفعال واقعی fail-closed وجود دارند؛ provider واقعی انتخاب/متصل نشده است. در برنامه تولید OTP ثابت یا ورود نمایشی نیست. داشبورد عضو، پروفایل اختیاری، اشتراک و خروج واقعی‌اند؛ دیگر ماژول‌ها صریحاً غیرفعال‌اند.

## ۲. فایل‌های مهم

- migration `2026_10_20_000001_create_membership_tables.php` و PlanSeeder.
- ماژول Members: مدل، IranianPhone، MemberPolicy، ManageMembers و دو controller مدیریت/عضو.
- ماژول Subscriptions: Subscription/Plan/SubscriptionRenewal/ManualPayment، دو Action تراکنشی و SubscriptionCalendar.
- Authentication: IssueMemberOtp، VerifyMemberOtp، SendMemberOtp، OtpSecurity، MemberSession/OtpChallenge و MemberAuthController.
- SmsIntegration/Contracts/OtpSender و UnavailableOtpSender؛ Capture فقط در tests/Support است.
- RequireActiveMembership، permission middleware، route/config/provider، dontFlash و setup-local.
- Blade مدیریت اعضا/پرداخت/اشتراک، ورود/تأیید و صفحات عضو؛ nav و CSS.
- MembershipFlowTest و SubscriptionCalendarTest؛ FoundationTest با وضعیت فعلی تطبیق یافت.
- README، MEMBERSHIP، وضعیت و تصمیم‌ها/امنیت/DB/آزمون و evidence مرحله ۴. تغییرات فایل در phase-4-changes.json است.

## ۳. پایگاه داده

۷ جدول افزوده شد: members، plans، subscriptions، subscription_renewals، manual_payments، otp_challenges، member_sessions. FK/unique/index، CHECK بازه/مدت/واحد/مبلغ و دو trigger ضد تغییر/حذف renewal اجرا شدند؛ مجموع trigger امنیتی شش است. شماره/یادداشت encrypted، lookup HMAC، مبلغ DECIMAL(24,2) و تاریخ‌های جدید DATETIME(6) با قرارداد UTC هستند.

migrate/seed روی MySQL Community 8.4.11 واقعی توسعه/آزمون موفق بود. seed یک plan و metadata نقش‌هاست؛ حساب، مشترک یا OTP پیش‌فرض ندارد. پس از suite، هر دو DB صفر account/member/subscription/payment/OTP/session/audit/job داشتند و فقط metadata باقی ماند؛ فایل‌های phase-4-schema-local/testing.json مدرک‌اند.

ارتقای ساختار مرحله ۳ به۴ در DB ایزوله با یک مدیر قبلی آزموده شد: حساب و اختیارات قبلی حفظ، صفر عضو و یک plan باقی ماند. fixture فقط در DB آزمون ارتقا بود؛ به محیط محصول یا بسته داده منتقل نشد. شواهد phase-4-upgrade.json و phase-4-upgrade-verification.json هستند.

## ۴. آزمون و نتیجه واقعی

**۷۷ تست، ۸۵۵ assertion، همه موفق**؛ JUnit در phase-4-junit.xml و خروجی suite در phase-4-mysql-tests.json است. این تعداد برابر با تکمیل ۷۷ سناریوی برنامه کل محصول نیست؛ سیگنال/رسانه/قیمت و عملیات هنوز خارج اجرا هستند.

علاوه بر آزمون‌های مراحل قبل: encryption/normalize/duplicate، منع فعال‌شدن با ثبت شماره یا پرداخت، ده‌دهی بزرگ دقیق و ورودی نامعتبر، تمدید فعال/منقضی، retry/409، هر چهار مدت، کبیسه شمسی/میلادی و آخر ماه/تهران، immutable ledger، zero-send ناشناخته/بدون اشتراک/آینده/منقضی/مسدود/لغوشده/حساب غیرفعال، OTP غلط/مصرف‌شده/منقضی/مرورگر دیگر/سقف تلاش، resend و late job پس از block، شکست provider، production fail-closed، session/CSRF rotation، logout/timeout، قطع دسترسی بدون cron، تغییر شماره و mass assignment پروفایل، مجوز مدیر و IDOR پرداخت، ماسک صفحه تأیید و رندر صفحات بررسی شدند.

صف database واقعی MySQL با enqueue و pop/fire job اجرا شد؛ payload فقط مرجع داشت، قبل worker هیچ code/verifier ساخته نشده بود و اجرای دوباره job پیام اضافه نداد. ارسال‌ها در Capture حافظه‌ای تست ثبت شدند؛ **SMS واقعی ارسال نشده است**.

ساخت ۵ asset، JS syntax، Blade cache، route cache/list/clear (۶۲ route)، lint ۸۷ فایل PHP، Composer validate/platform/audit موفق بودند؛ audit advisory/abandoned نداشت، ولی audit خود PHP نیست. evidence/phase-4-verification.json و phase-4-composer-audit.json مدرک‌اند. ۵۶ ورودی preview آفلاین با داده موقت آزمون و شماره‌های ماسک‌شده ساخته شدند؛ tokenها خالی و POST غیرفعال‌اند.

یک کنترل اولیه fixture ارتقا، مدل پیش از refresh (فاقد فیلدهای default DB) را با ردیف کامل مقایسه و false گزارش کرد؛ مقایسه با snapshot کامل قبل/بعد اصلاح و ارتقا موفق شد. نتیجه اولیه در phase-4-upgrade-initial.json و phase-4-initial-verification.json حفظ شده است. تست application حذف، skip یا صوری سبز نشد؛ suite قبل از این کنترل نیز موفق بود.

## ۵. محدودیت‌ها

- اتصال/تحویل SMS واقعی و آزمون از شبکه هدف انجام نشده است؛ دریافت کلید به‌تنهایی کافی نیست و adapter سرویس انتخابی باید پیاده/تست شود.
- کنترل مرورگر محیط در دسترس نبود؛ mobile/tablet/desktop، zoom، screen reader و تطبیق بصری تأیید نشده‌اند. HTTP render و ۵۶snapshot جای آن را نمی‌گیرند.
- رقابت مستقل چند اتصال، load، timing آماری، تست نفوذ، queue worker به شکل daemon و crash واقعی، HTTPS/binlog/حقوق DB تولید آزموده نشده‌اند. pop/fire واقعی job با MySQL انجام شده است.
- PHP محلی 8.4.1 قدیمی و صرفاً runtime خصوصی بود؛ در بسته نیست. patch امن میزبان و بازآزمایی پیش از تولید لازم است.
- exactly-once تحویل SMS ادعا نمی‌شود؛ قطع پاسخ پس از تحویل provider ممکن است کد غیرقابل استفاده بسازد. resend کنترل‌شده پیش‌بینی شده است.
- تعریف روز لنگر مستقل نداریم؛ هر تمدید از پایان واقعی فعلی و clamp همان عملیات محاسبه می‌شود. جست‌وجوی فیلترشده فقط در نشست همان مدیر قابل بازکردن است.
- endpoint واقعی سیگنال، رسانه، بازار، گزارش و اعلان ساخته نشده و از UI عضو وضعیت غیرفعال دارند.

## ۶. سرویس‌های پیکربندی‌نشده

SMS/provider/template/حساب واقعی، قیمت، رسانه تولید، backup مقصد، هاست، دامنه و HTTPS. هیچ پیام واقعی، درخواست قیمت، پرداخت آنلاین یا استقرار انجام نشده است. MySQL فقط برای آزمون محلی است؛ زیرساخت تولید هنوز انتخاب نشده.

## ۷. تصمیم‌های موردنیاز مالک

نام سرویس پیامک، template تأییدشده و حساب مجاز باید انتخاب شوند؛ اسرار باید از مسیر خصوصی میزبان تزریق شوند. پس از آن، adapter و آزمون تحویل واقعی به شماره آزمایشی مجاز لازم است. سیاست پیش‌فرض تقویم قبل عرضه بررسی شود؛ اجرای فعلی انتخاب صریح در هر فعال‌سازی/تمدید با پیش‌فرض پیشنهادی شمسی دارد و هر دو تقویم تست شده‌اند. بودجه/هاست، حجم رسانه و provider قیمت در مراحل مربوط همچنان بازند.

## ۸. وضعیت معیارهای پذیرش

| قابلیت | وضعیت | حدود تأیید |
| --- | --- | --- |
| شماره، جست‌وجو، block/unblock و یادداشت | پیاده‌سازی‌شده و تست‌شده | MySQL و HTTP، شماره رمزگذاری‌شده و URL بدون شماره |
| اشتراک و تمدید تقویمی/idempotency/ledger | پیاده‌سازی‌شده و تست‌شده | چهار مدت و مرزهای زمانی؛ سیاست پیش‌فرض برای عرضه قابل بررسی |
| پرداخت دستی جدا از فعال‌سازی | پیاده‌سازی‌شده و تست‌شده | decimal دقیق، مجوز مستقل، بدون درگاه |
| OTP یک‌بارمصرف/صف/rate limit/guard | پیاده‌سازی‌شده و تست‌شده | adapter حافظه‌ای آزمون؛ تولید بدون provider بسته است |
| قطع دسترسی عضو و API | پیاده‌سازی‌شده و تست‌شده | هر درخواست، بدون cron؛ رسانه واقعی مرحله ۶ است |
| پنل عضو و مدیریت جدید | پیاده‌سازی‌شده و رندر تست‌شده | browser QA باقی است |
| ارسال و دریافت پیامک واقعی | وابسته به سرویس بیرونی | تأییدنشده؛ معیار تحویل OTP تولید باز است |
| تست بار/نفوذ/رقابت مستقل/daemon/زیرساخت | باقی‌مانده | ادعای اجرا نشده است |
| پذیرش بصری و نهایی مالک | دریافت نشده | بسته برای بررسی آماده است |

## ۹. مرحله بعد

مرحله ۵: CRUD واقعی سیگنال، اهداف، وضعیت، انتشار، revision، تاریخچه و فهرست/جزئیات/آرشیو عضو با کنترل اشتراک. اتصال SMS واقعی همچنان وابستگی باز مرحله ۴ است. طبق پرامپت پس از گزارش منتظر دستور مرحله بعد می‌مانیم.
