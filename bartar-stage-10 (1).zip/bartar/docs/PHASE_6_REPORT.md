# گزارش مرحله ۶ — رسانه خصوصی

شروع مرحله ۶ با دستور مستقیم کاربر در ۲۰۲۶-۱۰-۲۰ به وقت تهران مجاز شد. این بسته ادامه مستقیم مرحله ۵ است. commit/push، استقرار، تغییر دامنه و اتصال storage تولیدی انجام نشده‌اند.

## ۱. کارهای انجام‌شده

بارگذاری تصویر، صوت و ویدیو از صفحه سیگنال مدیر با مجوزهای مستقل، reauthentication و دلیل تغییر پیاده‌سازی شد. محتوا با `finfo` بررسی، SHA-256 و اندازه ثبت، ابتدا با key امن در quarantine ذخیره و فقط پس از move موفق ready می‌شود. فایل HTML/SVG/اجرایی یا محتوای ناسازگار با kind از روی محتوای واقعی رد می‌شود.

عضو فعال رسانه سیگنال منتشرشده را در همان صفحه می‌بیند. مدیر نیز فقط با `media.view` stream می‌گیرد. stream کامل و Single Range، پاسخ‌های ۲۰۰/۲۰۶/۴۱۶، `Content-Range`، `Accept-Ranges`، `no-store` و chunked read اجرا شده‌اند. ترتیب و detach رسانه منتشرشده revision قبلی را حفظ و version سیگنال را افزایش می‌دهد. detach فایل را purge نمی‌کند.

## ۲. فایل‌های مهم

- migration `2026_10_20_000003_create_private_media_tables.php`
- `config/media.php` و دیسک خصوصی `signal-media`
- قرارداد `PrivateMediaStorage` و adapter محلی Laravel
- `ManageSignalMedia` و `StreamPrivateMedia`
- مدل‌های `MediaFile` و `SignalMedia` و controllerهای مدیریت/پخش
- routeها و Bladeهای مدیر/عضو با preview داخلی تصویر/صوت/ویدیو
- snapshot رسانه بدون object key و نام اصلی
- `MediaFlowTest` و مستند `MEDIA_STORAGE.md`

## ۳. پایگاه داده

دو جدول `media_files` و `signal_media` افزوده شدند. هر دو public_id دارند؛ object key روی disk یکتا، media_file روی attachment یکتا و position در هر سیگنال یکتا است. دو CHECK برای kind/state/bytes و kind/position و سه FK واقعی تأیید شدند.

migration نصب تمیز و ارتقای واقعی مرحله ۵→۶ روی MySQL 8.4.11 موفق بود. در upgrade، حساب `existing-phase5-admin` با `auth_version=7` و سیگنال منتشرشده موجود با version=4 بدون تغییر ماندند. seed فایل یا رسانه تجاری ایجاد نمی‌کند.

## ۴. آزمون و نتیجه واقعی

`MediaFlowTest` با **۵ تست و ۷۱ assertion** موفق شد: upload معتبر خصوصی، جعل MIME/سقف حجم، stream کامل و Range، قطع دسترسی و detach، reorder/revision و deny نقش viewer. suite کامل با **۸۸ تست و ۹۷۰ assertion** روی MySQL واقعی موفق است.

Composer validate، platform requirements و audit بدون advisory، lint PHP، config/route/Blade cache، syntax JS و build asset همگی موفق بودند. شواهد ماشین‌خوان در `evidence/phase-6-media-junit.xml` و `evidence/phase-6-junit.xml` قرار دارند.

اجرای نخست سه نکته واقعی را آشکار کرد: شرط `published_at <= now` میکروثانیه را در binding حذف می‌کرد و سیگنال تازه‌منتشرشده را تا پایان همان ثانیه پنهان می‌کرد؛ شرط به رشته میکروثانیه‌دار اصلاح شد. نقش viewer عمداً `media.view` ندارد و تست مطابق deny پیش‌فرض تثبیت شد. مسیر خصوصی ناشناس، چه شناسه موجود و چه ناموجود، یکسان به login می‌رود تا امکان enumeration ندهد.

## ۵. محدودیت‌ها

- آزمون مرورگر واقعی برای codec صوت/MP4، seek، Safari/iOS، controls، layout، keyboard/zoom انجام نشده است.
- storage تولیدی/S3، Range backend بیرونی، CDN، reverse-proxy offload و دسترسی واقعی از ایران آزموده نشده‌اند.
- سقف ۱۰۰ MiB guardrail برنامه است؛ quota کل، محدودیت proxy/PHP، upload قطع‌شده، disk-full، load/OOM و رقابت چند اتصال آزموده نشده‌اند.
- فایل ready پس از detach برای retention نگهداری می‌شود؛ purge job و تصمیم retention/backup هنوز مرحله ۹ هستند.
- `controlsList=nodownload` مانع قطعی استخراج یا ضبط صفحه نیست؛ DRM/HLS/transcoding تعهد نشده است.
- antivirus/content scanning بیرونی و validation codec/container در این نسخه وجود ندارند؛ allowlist MIME جای آن‌ها را کامل نمی‌گیرد.

## ۶. سرویس‌های پیکربندی‌نشده

SMS واقعی، storage خصوصی تولیدی، provider قیمت، ارسال اعلان، backup/restore، هاست، دامنه و HTTPS پیکربندی نشده‌اند. اجرای فعلی local disk دارد و interface آماده به معنی اتصال آزموده‌شده S3 نیست.

## ۷. تصمیم‌های موردنیاز مالک

پیش از تولید باید سقف نهایی هر kind، ظرفیت/هزینه storage، retention و purge، نیاز antivirus، codecهای دقیق، مقصد backup و مدل delivery (PHP stream یا internal redirect) تصویب شوند. مرحله ۷ نیز به منبع قیمت، واحدها، freshness و fallback نیاز دارد.

## ۸. وضعیت معیارهای پذیرش

| قابلیت | وضعیت | حدود تأیید |
| --- | --- | --- |
| upload خصوصی و MIME واقعی | پیاده‌سازی و تست‌شده | جعل پسوند و oversize رد؛ residue ندارد |
| تصویر/صوت/ویدیو | پیاده‌سازی allowlist/UI | تصویر stream تست؛ codec صوت/ویدیو در مرورگر باز |
| کنترل عضو/مدیر | پیاده‌سازی و تست‌شده | active-membership، SignalPolicy و media.view |
| HTTP Range | پیاده‌سازی و تست‌شده | ۲۰۰، ۲۰۶ ابتدا/پسوند و ۴۱۶ چندگانه |
| reorder/detach/version | پیاده‌سازی و تست‌شده | snapshot نسخه قبل و عدم purge زودهنگام |
| migration تمیز/ارتقا | **سبز** | MySQL 8.4.11 و حفظ رکوردهای مرحله ۵ |
| suite کامل | **سبز** | ۸۸ تست، ۹۷۰ assertion |
| مرورگر/load/storage تولید | باز | نیازمند محیط staging و تصمیم مالک |

## ۹. مرحله بعد

checkpoint فنی مرحله ۶ سبز است. از ۱۰ مرحله، مراحل ۷ تا ۱۰ باقی مانده‌اند: بازار و قیمت، CMS/اعلان، گزارش/عملیات/backup و در پایان استقرار/پذیرش. شروع مرحله ۷، commit/push یا استقرار نیازمند دستور مالک است.
