# ماتریس مجوزها و وضعیت اجرا

نقش‌ها قالب آغاز هستند و مجوزهای جزئی از پنل مدیر اصلی قابل تغییرند. هویت عضو و مدیر جداست. deny پیش‌فرض؛ Policy سمت سرور روی route، Action و رکورد اعمال می‌شود. پنهان‌کردن UI کافی نیست.

| حوزه / مجوزها | مدیر اصلی | مدیر اشتراک | مدیر سیگنال | مدیر محتوا | مدیر گزارش | مشاهده‌گر | مدیر فنی |
| --- | --- | --- | --- | --- | --- | --- | --- |
| داشبورد `dashboard.view` | ✓ | ✓ محدود | ✓ محدود | ✓ محدود | ✓ محدود | ✓ محدود | ✓ سلامت |
| عضو `members.view/create/update/block` | همه | همه | — | — | — | فقط آمار تجمیعی | — |
| اشتراک `subscriptions.view/activate/renew/revoke` | همه | همه | — | — | — | — | — |
| پرداخت `payments.view/create/confirm` | همه | همه | — | — | فقط تجمیع مجاز | — | — |
| سیگنال `signals.view/create/update/publish/result` | همه | — | همه | — | view | view منتشرشده | — |
| رسانه `media.view/upload/reorder/delete` | همه | — | همه با حذف منطقی | فقط public_media | — | — | فقط وضعیت فضا |
| بازار `markets.view/create/update/deactivate` | همه | — | view | — | view | view | — |
| قیمت `prices.view/manual/override` | همه | — | view | — | view | view | فقط health |
| محتوا `cms.view/create/update/publish` | همه | — | — | همه | — | view منتشرشده | — |
| اعلان `notifications.view/create/publish` | همه | فقط یادآوری اشتراک | فقط تغییر سیگنال | اطلاعیه عمومی | — | — | فقط هشدار فنی |
| گزارش `reports.view/export` | همه | گزارش محدود اشتراک | نتیجه سیگنال خود حوزه | — | همه بدون PII اعضا | view تجمیعی | — |
| نقش و مدیر `manage_roles`, `admins.manage` | ✓ | — | — | — | — | — | — |
| حذف `delete_records` | ✓ | — | — | — | — | — | — |
| سرویس‌ها `manage_integrations` | ✓ | — | — | — | — | — | ✓ |
| نشست `revoke_sessions` | همه | فقط نشست اعضا پس از block/revoke | — | — | — | — | ✓ عملیات فنی مجاز |
| ممیزی `audit.view` | همه | حوزه اشتراک | حوزه سیگنال | حوزه CMS | — | — | حوزه فنی پالایش‌شده |
| بکاپ `backups.view`, `manage_backups` | ✓ | — | — | — | — | — | ✓ |
| سلامت `health.view` | ✓ | — | — | — | — | — | ✓ |
| تنظیمات `settings.brand/update`, `settings.security/update` | همه | — | — | فقط برند | — | — | فقط فنی/امنیت مجاز |

## محدودیت‌های سراسری

- `all_modules` دسترسی کسب‌وکار به همه حوزه‌هاست؛ CSRF، reauthentication عملیات حساس، invariant، redact اسرار و ممیزی را دور نمی‌زند.
- مدیر اصلی دارای `manage_roles`, `delete_records`, `manage_backups`, `revoke_sessions`, `manage_integrations` است. ممنوعیت IP ثابت وجود ندارد. 2FA اجباری نیست، ولی مدل factor آینده قابل افزودن است.
- `signals.update` به‌تنهایی publish یا ثبت/اصلاح نتیجه را مجاز نمی‌کند. export مستقل از view است.
- `media.delete` به معنی قطع اتصال/soft-delete مجاز است؛ purge دائمی نیازمند `delete_records`، سیاست retention و بررسی revision است.
- مدیر محتوا از public_media استفاده می‌کند؛ مجوز CMS امکان خواندن signal media خصوصی یا آپلود HTML اجرایی نمی‌دهد.
- `manage_integrations` اجازه تعویض driver/مرجع secret می‌دهد؛ secret ذخیره‌شده هرگز به کاربر پنل بازگردانده نمی‌شود. مقصد خروجی شبکه باید محدود باشد.
- حفظ حداقل یک مدیر اصلی فعال الزامی است؛ حذف/کاهش اختیار آخرین مدیر اصلی در transaction رد می‌شود. تغییر مجوز در درخواست بعدی اعمال می‌شود.
- `manage_backups` شامل restore عملیاتی می‌تواند باشد، اما restore تولید همچنان نیازمند تأیید صریح، reauth، ثبت درخواست و شواهد است.
- audit endpoint حذف ندارد. retention ممیزی از مسیر مجاز فنی ثبت‌شده و سیاست مصوب انجام می‌شود؛ مدیر اصلی از UI آن را بی‌ردپا حذف نمی‌کند.
- عضو فعال فقط داده شخصی خود و سیگنال‌های منتشرشده مجاز را می‌بیند. عضو منقضی/blocked به داده خصوصی، API و رسانه دسترسی ندارد. نام نمایشی تنها فیلد اختیاری پروفایل اولیه است؛ تغییر شماره احراز جدا می‌خواهد و خودکار مجاز نیست.

آزمون اجباری: برای هر permission یک مسیر allow، یک مسیر deny با درخواست مستقیم و یک مورد IDOR/رکورد خارج حوزه. اجتماع نقش‌ها فقط مجوزهای اعطاشده را جمع می‌کند؛ هیچ نقشی از عضویت عمومی استنتاج نمی‌شود.

## اجرای مرحله ۳

کاتالوگ دقیق و نقش‌های آغازین در `PermissionCatalog.php` منبع اجرایی‌اند. جدول بالا طرح کل محصول است؛ داشتن کلید permission به‌تنهایی route یا mutation تازه ایجاد نمی‌کند. کلیدهای مستقل `members.delete`، `signals.delete`، `markets.delete`، `cms.delete` و `notifications.delete` برای کنترل حذف آماده‌اند؛ `delete_records` به‌تنهایی endpoint حذف ایجاد نمی‌کند.

واگذاری نقش، تغییر حساب با مجوز بالاتر و تغییر role دارای مجوز بالاتر از اختیار عامل، در Action رد می‌شود؛ all_modules این مرز تجاری را برای مدیر اصلی پوشش می‌دهد. نقش protected مدیر اصلی باید all_modules را حفظ کند و حداقل یک مدیر اصلی فعال در transaction باقی بماند. همه مدیران فعال نشست‌های خود و تغییر رمز خود را دارند؛ sessions.view.all مشاهده همه نشست‌ها و revoke_sessions لغو نشست دیگران را مجاز می‌کند. هویت/مجوز پیش از model binding بررسی می‌شود.

## اجرای مرحله ۴

routeهای members.view/create/update/block، subscriptions.activate/renew/revoke، payments.create/confirm/view اکنون واقعی‌اند. view اشتراک و پرداخت در جزئیات به مجوز مستقل محدود است؛ فرم اشتراک با داشتن activate یا renew قابل دیدن و نوع انتخابی دوباره در Action بررسی می‌شود. عضو فقط پروفایل نام نمایشی خودش را تغییر می‌دهد؛ شماره/role/account_id از فرم عضو قابل تنظیم نیست. MemberPolicy دسترسی شخصی و نوع هویت را نیز بررسی می‌کند. staff اشتراک ممیزی subscriptions را دارد و security loginهای دیگران را نمی‌بیند.

## اجرای مرحله ۵

مسیرهای مدیریت سیگنال علاوه بر middleware مجوز، Policy رکورد و بررسی دوباره داخل Action تراکنشی دارند. `signals.update` انتشار یا نتیجه را مجاز نمی‌کند؛ `signals.publish` و `signals.result` مستقل‌اند. نوشتن بازار/دارایی پایه به `markets.create` نیاز دارد. مشاهده‌گر با درخواست مستقیم create/update/publish/result پاسخ 403 می‌گیرد. عضو از guard جدا، middleware اشتراک فعال و query محدود به `published_at <= now` عبور می‌کند؛ شناسه draft/scheduled با 404 پنهان می‌شود. این رفتار در `SignalFlowTest` روی MySQL 8.4.11 اجرا و موفق شد.

## اجرای مرحله ۶

routeهای `media.view/upload/reorder/delete` مستقل‌اند. viewer حتی با `signals.view` امکان خواندن endpoint فایل را ندارد. upload، reorder و detach علاوه بر middleware دوباره مجوز و رمز فعلی را داخل transaction بررسی می‌کنند. عضو فقط پس از active-membership، visible بودن سیگنال و SignalPolicy می‌تواند stream بگیرد؛ block/revoke/expiry درخواست بعدی را قطع می‌کند. URL موجود و ناموجود برای کاربر ناشناس به login می‌روند تا شناسه معتبر قابل تشخیص نباشد. این مرزها در `MediaFlowTest` با درخواست مستقیم آزموده شده‌اند.

## اجرای مرحله ۷

مشاهده قیمت با `prices.view`، ثبت دستی با `prices.manual` و فعال‌سازی اولویت با کنترل مضاعف `prices.override` انجام می‌شود. لغو override نیز `prices.override`، رمز فعلی و دلیل می‌خواهد. تعریف منبع فقط با `manage_integrations` مجاز است. ویرایش بازار/دارایی `markets.update` و غیرفعال‌سازی علاوه بر آن `markets.deactivate` می‌خواهد. همه mutationها در Action دوباره مجوز را از DB می‌خوانند و ممیزی actor/reason دارند؛ نقش viewer با درخواست مستقیم 403 گرفته است.

## اجرای مرحله ۸

فهرست/ایجاد/ویرایش/انتشار صفحه به‌ترتیب `cms.view/create/update/publish` را می‌خواهد. تغییر صفحه منتشرشده نیز `cms.publish`، رمز فعلی و دلیل دارد و revision قبلی را حفظ می‌کند. برند با `settings.brand` و منو با `cms.update` کنترل می‌شوند. اطلاعیه با `notifications.view/create/publish` تفکیک شده است. نقش `content_manager` این سه مجوز اعلان را در seed و migration ارتقا دریافت می‌کند؛ viewer در درخواست مستقیم 403 می‌گیرد. عضو فقط notificationهای `recipient_id` خودش را می‌بیند/می‌خواند و شناسه اعلان عضو دیگر 404 است.

## اجرای مرحله ۹

گزارش سیگنال منتشرشده با reports.view و POST خروجی با هر دو reports.view/export، reauth و reason ممیزی‌شده باز می‌شود. عضو گزارش همان سیگنال‌های منتشرشده را فقط با اشتراک معتبر می‌بیند؛ خروجی مدیریتی یا دادهٔ شخصی اعضا ندارد.

مشاهدهٔ وضعیت بکاپ با backups.view از درخواست اجرای بکاپ با manage_backups جداست. migration جدید view را به نقش‌های دارای manage_backups/all_modules اضافه می‌کند. queued پیش از اجرا مجوز درخواست‌کننده را دوباره بررسی می‌کند. health.view برای سلامت لازم است. restore فقط CLI اپراتور و هدف آزمایشی خالی/جدا با confirmation نام DB است؛ مسیر restore تولید وجود ندارد.
