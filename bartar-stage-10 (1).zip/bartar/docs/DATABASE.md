# مدل داده و وضعیت اجرا

این سند طرح منطقی کل محصول است. مراحل ۳ تا ۸ روی MySQL 8.4.11 اجرا و آزمون شدند. migration مرحله ۸ جداول محتوا و اعلان را اضافه کرد و هم با نصب تمیز و هم با ارتقای مرحله ۷→۸ و حفظ داده‌های قبلی تأیید شد. گزارش و عملیات همچنان مراحل بعدند. همه زمان‌ها با قرارداد UTC ذخیره می‌شوند.

## قراردادهای مشترک

- PK داخلی `BIGINT UNSIGNED`؛ شناسه عمومی غیرقابل حدس ULID در رکوردهای قابل آدرس‌دهی. ULID جای Policy را نمی‌گیرد.
- charset `utf8mb4`؛ کلیدهای ماشینی و شماره نرمال مقایسه باینری/دقیق داشته باشند. نام فارسی قابل جست‌وجو از کلید یکتای ماشینی جداست.
- زمان‌ها `DATETIME(6)` با قرارداد UTC، اتصال DB روی UTC؛ نمایش `Asia/Tehran` و شمسی. تاریخ شمسی به‌صورت رشته منبع حقیقت نیست.
- قیمت/مقدار `DECIMAL(30,12)`، وزن خروج `DECIMAL(12,9)`، مبلغ `DECIMAL(24,2)`، بازده `DECIMAL(20,8)`؛ محاسبه در PHP با decimal و رشته، نه float. گردکردن فقط در خروجی، براساس asset و unit.
- واحد قیمت و مبلغ صریح است. IRR و IRT دو unit جدا هستند؛ تومان/ریال از نام نماد استنباط نمی‌شود. ثبت مبلغ منفی و مخلوط‌کردن unit ممنوع است.
- created_at/updated_at برای رکورد mutable؛ دفترکل و audit الحاقی‌اند. soft-delete صرفاً برای داده تجاری مجاز، نه پنهان‌کردن ممیزی.
- FKهای مالی، audit و revision عموماً RESTRICT یا SET NULL با snapshot عامل‌اند؛ CASCADE فقط در pivot فنی فاقد نیاز تاریخی. حذف عضو نباید تاریخچه اشتراک/پرداخت را حذف کند.
- فیلد JSON برای snapshot/تنظیمات محدود و schemaدار است؛ رابطه‌های اصلی و فیلترپذیر در JSON دفن نمی‌شوند.

## هویت، اشتراک و امنیت

| جدول | فیلدهای اصلی | قید و index |
| --- | --- | --- |
| accounts | id، public_id، kind(member/admin)، username nullable، password_hash nullable، disabled_at، auth_version، last_login_at | unique public_id و username؛ CHECK سازگاری kind با username/password؛ حساب عضو رمز ورود ندارد |
| members | id، account_id، phone_e164، display_name nullable، status(active/blocked)، blocked_at، block_reason، created_by | unique account_id و phone_e164؛ FK accounts/admin actor؛ index status |
| roles | id، key، title، protected | unique key؛ حذف نقش اصلی بدون جایگزین مجاز نیست |
| permissions | id، key، title | unique key؛ کلیدها در PERMISSIONS.md |
| account_roles | admin_account_id، role_id | PK مرکب؛ cascade pivot پس از قواعد محافظتی |
| role_permissions | role_id، permission_id | PK مرکب |
| plans | id، key، title، active | unique key؛ نسخه اول یک پلن؛ مبلغ پیش‌فرض اجباری نیست |
| subscriptions | id، member_id، plan_id، starts_at، ends_at، revoked_at، version | unique member_id؛ CHECK end>start؛ index ends_at؛ status مؤثر از زمان و وضعیت عضو محاسبه شود |
| subscription_renewals | id، subscription_id، months، calendar، base_at، old_end، new_start، new_end، actor_id، reason، idempotency_key | unique idempotency_key؛ months IN(1,3,6,12)؛ index subscription_id,created_at |
| manual_payments | id، member_id، subscription_renewal_id nullable، amount، unit، paid_at، method، tracking_reference nullable، note، status، recorded_by، confirmed_by nullable، confirmed_at | مبلغ>=0؛ index member_id,paid_at؛ ثبت پرداخت اشتراک را تغییر نمی‌دهد |
| otp_challenges | id تصادفی، member_id، purpose، verifier_hmac، expires_at، consumed_at، invalidated_at، attempts، sent_at، session_binding_hash | index member_id,purpose,created_at و expires_at؛ بدون OTP خام؛ ساخت فقط برای عضو مجاز |
| sessions | id، account_id، guard، auth_version، encrypted_payload، last_activity، revoked_at | index account_id,guard؛ id نشست در UI/log خام نمایش داده نشود |
| admin_password_resets | id، account_id، token_hash، expires_at، used_at، channel | index expires_at؛ توکن یک‌بارمصرف؛ کانال بازیابی هنوز انتخاب نشده |
| auth_events | id، actor_id nullable، subject_hash، kind، outcome، reason_code، ip_digest، occurred_at | index occurred_at و actor_id؛ شماره کامل/OTP/رمز ممنوع |

کاربر انسانی می‌تواند دو account مستقل برای عضویت و مدیریت داشته باشد؛ Guard و cookie و permissions آن‌ها مشترک فرض نمی‌شوند. restriction به account kind در Policy و Service اجباری است؛ CHECK ساده تمام روابط بین‌جدولی را پوشش نمی‌دهد.

## بازار و قیمت

| جدول | فیلدهای اصلی | قید و index |
| --- | --- | --- |
| markets | id، key، title، trade_type، active، sort_order | unique key؛ spot/forex/gold/domestic |
| assets | id، market_id، symbol، title، price_unit، quantity_unit، price_scale، active | unique market_id,symbol؛ FK market؛ index active,market_id |
| price_sources | id، key، market_id، driver، enabled، refresh_seconds، stale_after_seconds | unique key؛ بدون API secret در config_json؛ محدودیت provider صریح |
| price_observations | id، asset_id، source_id nullable، source_kind(api/manual)، value، unit، observed_at، received_at، actor_id nullable، reason nullable | value>0؛ index asset_id,observed_at و source_id,received_at؛ واحد مطابق asset |
| manual_price_overrides | id، asset_id، observation_id، starts_at، ends_at، revoked_at، actor_id، reason | CHECK end>start؛ index asset_id,starts_at,ends_at؛ قفل asset هنگام افزودن برای جلوگیری از overlap |
| price_fetch_runs | id، source_id، started_at، finished_at، status، error_code، retry_count، next_retry_at | index source_id,started_at؛ خطا پالایش‌شده |

قیمت مؤثر: override معتبر و ابطال‌نشده اولویت دارد و «دستی» برچسب می‌خورد؛ در نبود آن آخرین observation معتبر API. تاریخ پایان override اجباری و قابل تعیین مدیر است. دریافت API در زمان override ادامه می‌یابد. stale بودن با زمان observed_at و آستانه منبع/دارایی تعیین می‌شود؛ received_at جای زمان واقعی قیمت را نمی‌گیرد. نبود قیمت معتبر، «ناموجود» است. مقدار صفر به‌عنوان placeholder ذخیره نمی‌شود.

## سیگنال و رسانه

| جدول | فیلدهای اصلی | قید و index |
| --- | --- | --- |
| signals | id، public_id، title، market_id، asset_id، trade_type، direction، entry_low، entry_high nullable، stop_loss nullable، timeframe، body_sanitized، risk_label nullable، status، scheduled_at، published_at، expires_at nullable، created_by، published_by nullable، version | unique public_id؛ entry_low>0 و high>=low؛ index status,published_at و market_id,asset_id,published_at |
| signal_targets | id، signal_id، position، price، proposed_exit_weight nullable | unique signal_id,position؛ price>0؛ FK signal RESTRICT پس از انتشار |
| signal_revisions | id، signal_id، version، snapshot_json، reason، actor_id، changed_at، announce_change | unique signal_id,version؛ immutable؛ snapshot شامل اهداف و metadata رسانه بدون object key/نام اصلی |
| signal_status_events | id، signal_id، from_status، to_status، reason، actor_id nullable، happened_at، idempotency_key | unique idempotency_key برای job؛ index signal_id,happened_at |
| signal_results | id، signal_id، version، method، entry_execution_price nullable، gross_return nullable، fee_input nullable، formula_version، computed_at nullable، coverage_ratio، note، recorded_by | unique signal_id,version؛ نتیجه ناقص null، نه صفر؛ immutable با نسخه جدید اصلاح شود |
| signal_exits | id، signal_result_id، position، exit_price، exit_weight، executed_at، target_id nullable | price>0؛ weight>0 و <=1؛ unique result,position؛ sum weights<=1 داخل transaction |
| media_files | id، public_id، disk، object_key، kind، mime، bytes، sha256، original_name، state(quarantined/ready/rejected/deleted)، uploaded_by، verified_at/deleted_at nullable | unique disk,object_key و public_id؛ CHECK kind/state/bytes؛ original filename فقط خصوصی و پالایش‌شده |
| signal_media | id، public_id، signal_id، media_file_id، kind(image/audio/video)، caption nullable، position | unique signal_id,position و media_file_id؛ CHECK kind/position؛ FKها RESTRICT |

asset باید متعلق به market انتخابی باشد؛ در migration با FK مرکب `(asset_id,market_id)` و unique متناظر assets یا validation+constraint قابل اتکا enforce شود. تغییر market دارایی دارای سیگنال تاریخی مستقیم مجاز نیست. پیشنهاد نهایی: FK مرکب برای این invariant.

در ویرایش سیگنال منتشرشده، داخل transaction و قفل signals، نسخه **پیشین** با اهداف و رسانه snapshot می‌شود، سپس نسخه فعلی افزایش می‌یابد. فایل اشاره‌شده در revision تا پایان retention مربوطه قابل purge نیست. ایجاد draft هم version اولیه دارد. تاریخچه فیلدهای حساس در audit پالایش و در revision تجاری قابل بررسی است.

## محتوا، اعلان و عملیات

| جدول | فیلدهای اصلی | قید و index |
| --- | --- | --- |
| content_media | id، public_id، media_file_id، alt_text، created_by | unique media_file_id/public_id؛ binary در storage خصوصی موجود و با MIME واقعی تأیید شده |
| content_pages | id، public_id، slug، eyebrow، title، intro، icon، hero_media_id، status، version، published_at، created_by، updated_by | unique slug/public_id؛ status draft/published؛ slug و icon از allowlist |
| content_sections | id، page_id، kind، position، title، body، action_label/url، visible | unique page_id,position؛ kind فقط text/banner/cta؛ لینک داخلی یا HTTPS |
| content_page_revisions | id، page_id، version، snapshot_json، reason، actor_id، created_at | unique page_id,version؛ triggerهای UPDATE/DELETE را رد می‌کنند |
| content_menu_items | id، route_name، title، icon، position، visible، updated_by | unique route_name؛ فقط routeهای عمومی و iconهای شناخته‌شده |
| content_settings | id، key، value، updated_by | unique key؛ فقط کلیدهای برند/پشتیبانی تعریف‌شده |
| announcements | id، public_id، title، body، audience، status، published_at، expires_at، version، created_by، updated_by | audience public/members/all و status محدود؛ index انتشار |
| member_notifications | id، public_id، recipient_id، kind، title، body، action_url، dedupe_key، read_at، created_at | unique dedupe_key؛ index recipient/read/time؛ خواندن فقط توسط گیرنده |
| notification_deliveries | id، notification_id، channel، status، attempts، provider_reference، error_code، next_retry_at، sent_at | unique notification/channel؛ SMS با retry محدود و پاسخ پالایش‌شده |
| signal_announcements افزوده | processed_at، attempts، last_error_code | outbox قبلی بدون حذف داده قابل پردازش و مشاهده شکست شد |
| audit_logs | id، actor_id nullable، actor_snapshot، action، entity_type، entity_id، safe_before_json، safe_after_json، request_id، happened_at، chain_hash nullable | index happened_at و entity_type,entity_id؛ append-only با مجوز DB محدود؛ بدون endpoint حذف |
| backup_runs | id، trigger، status، started_at، finished_at، manifest_key، checksum، destination، encryption_key_reference، created_by nullable، error_code | index started_at,status؛ reference کلید، نه خود کلید |
| restore_drills | id، backup_run_id، target_environment، started_at، finished_at، db_verified، media_verified، status، evidence_reference | production restore نیازمند اقدام/تأیید مجزا |
| service_heartbeats | id، service_key، checked_at، status، safe_summary_json | index service_key,checked_at؛ retention محدود |
| operational_alerts | id، service_key، severity، opened_at، resolved_at، dedupe_key | index service_key,resolved_at؛ dedupe فعال در service |
| jobs / failed_jobs / cache / cache_locks | ساختار استاندارد Laravel در صورت انتخاب درایور database | migration رسمی متناسب نسخه نصب‌شده؛ secrets در payload ممنوع |

## اشتراک و تقویم

اعتبار: `member.active AND not account.disabled AND not subscription.revoked AND starts_at <= now_utc < ends_at`.

تمدید فعال از ends_at فعلی؛ منقضی از اکنون. برنامه شروع آینده در UI اشتراک مؤثر نمی‌شود تا starts_at. هر تمدید یک ledger تغییرناپذیر دارد. کلیک یا retry تکراری با idempotency_key همان نتیجه اولیه را برمی‌گرداند.

در اجرای مرحله ۴ هر عملیات انتخاب صریح تقویم شمسی یا میلادی دارد؛ انتخاب پیش‌فرض فرم پیشنهادی شمسی است و سیاست پیش‌فرض قبل عرضه با مالک بررسی شود. هر دو no-overflow و حفظ ساعت تهران/ذخیره UTC را اجرا و تست می‌کنند. `calendar` روی هر renewal ذخیره می‌شود تا تغییر سیاست، سابقه را عوض نکند. در تقویم انتخابی اگر روز متناظر وجود نداشت، آخرین روز ماه مقصد انتخاب می‌شود؛ سال کبیسه، ۱/۳/۶/۱۲ ماه و مرز نیمه‌شب تست می‌شوند. به‌جای N×۳۰ روز از افزودن ماه تقویمی استفاده می‌شود.

## فرمول و تفسیر نتیجه

پیشنهاد برای بازده ناخالص جهت‌دار بدون اهرم: خرید `100×(exit-entry)/entry` و فروش `100×(entry-exit)/entry` با entry>0. این فرمول short، بازده جهت‌دار نسبت به قیمت ورود است؛ سود حساب یا مارجین را نشان نمی‌دهد. اهرم، کارمزد، لغزش و اندازه موقعیت بدون ورودی صریح فرض نمی‌شوند.

برای خروج‌های مشخص: جمع `weight_i × return_i`. وزن‌ها نسبت به موقعیت اولیه و مجموع حداکثر ۱ است. تنها پوشش کامل می‌تواند بازده نهایی باشد؛ کمتر از ۱، بازده تحقق‌یافته بخش بسته‌شده همراه با coverage نمایش داده می‌شود و بازده نهایی null می‌ماند. entry range بدون execution price مشخص، یک عدد بازده قطعی تولید نمی‌کند. قواعد بازار خاص/پیپ/اهرم و فرمول مرحله‌ای نیازمند تصمیم D06 هستند.

پیشنهاد نرخ موفقیت: تعداد completed با بازده ناخالص نهایی مثبت تقسیم بر completed با نتیجه کامل و معتبر؛ صفر جدا و در مخرج، cancelled/expired/ناقص خارج مخرج. همیشه N و تعریف معیار در گزارش نمایش داده شود. جمع بازده سیگنال‌ها به‌عنوان رشد سرمایه یا compound بازده حساب گزارش نمی‌شود.

## ترتیب migration برنامه‌ریزی‌شده

۱. هویت/نقش/مجوز و session؛ ۲. عضو/پلن/اشتراک/پرداخت/OTP؛ ۳. بازار/دارایی؛ ۴. سیگنال/هدف/revision/result؛ ۵. رسانه؛ ۶. قیمت؛ ۷. CMS/اعلان؛ ۸. audit/backup/health (جدول audit پایه از مرحله ۳). rollback عکس ترتیب FK، و حفظ داده تولید با forward migration امن است. تخریب داده به‌عنوان rollback عادی مجاز نیست.

## تفاوت طرح منطقی و اجرای فعلی

phone_e164 و internal_note به صورت encrypted TEXT و phone_hash کلید یکتای HMAC هستند. display_name روی account مشترک است و عضو/مدیر همان مقدار را می‌بینند. status از blocked_at و اعتبار زمانی به دست می‌آید. نشست عضو در member_sessions با HMAC ID است و payload وب در session driver رمزگذاری‌شده جدا قرار دارد. otp_challenges فقط برای login است؛ verifier تا اجرای worker nullable، سپس HMAC و sent_at ثبت می‌شود. جداول جدید DATETIME(6) و dateFormat با microsecond دارند. renewal به subscription واحد هر عضو وصل است و دو trigger immutable دارد. manual_payments مستقل است. رسانه CMS از همان `media_files` و storage خصوصی استفاده می‌کند اما `content_media` و endpoint انتشار جدا دارد. اعلان داخلی مستقیم با `dedupe_key` یکتا ذخیره می‌شود؛ outbox مستقل عمومیِ طرح اولیه ایجاد نشده و `signal_announcements` موجود نقش outbox سیگنال را دارد. seed فقط plan/مجوزهای آغازین را می‌افزاید. جزئیات واقعی columnها در migration مرجع‌اند.

## افزوده‌های مرحله ۹

`signal_result_calculations` خروجی دقیق و ورودی immutable را برای هر `(signal_result_id, formula_version)` نگه می‌دارد. coverage از نوع DECIMAL(7,6)، بازده‌ها DECIMAL(48,8)، state، outcome، inputs_json و computed_at دارد؛ دو trigger UPDATE/DELETE را رد می‌کنند. نتایج قدیمی بدون تغییر signal_results با command جدا محاسبه می‌شوند. ستون‌های reserved قدیمی result بازنویسی نمی‌شوند. فرمول در PERFORMANCE_REPORTS.md مستند است.

`backup_runs` درخواست/اجرای بکاپ، شناسهٔ ULID، actor، reason، status، bytes، error code امن و زمان آخرین restore تأییدشده را دارد. `backup_restore_runs` هر تلاش مستقل restore و تعداد جدول/رکورد/رسانه/trigger بررسی‌شده را ثبت می‌کند. `operation_heartbeats` فقط آخرین seen_at زمان‌بند/worker است. قید status در DB اعمال می‌شود. migration مجوز backups.view را اضافه و برای نقش‌هایی که قبلاً manage_backups/all_modules داشته‌اند فعال می‌کند. حساب یا دادهٔ نمایشی seed نمی‌شود.

## مرحله ۱۰: نشست وب

migration 2026_10_21_000001 جدول framework sessions را اضافه می‌کند تا SESSION_DRIVER=database واقعاً کار کند. ستون‌های ID، user_id nullable، ip_address/user_agent، payload و last_activity با index استاندارد هستند. SESSION_ENCRYPT=true payload را رمزنگاری می‌کند. رجیستری‌های HMAC حوزهٔ admin/member جدا باقی می‌مانند. upgrade accountهای قبلی را بازنویسی نمی‌کند. جدول افزایشی در rollback کد حفظ شود.
