# گزارش ۹‌بندی مرحله ۷

## ۱. دامنه

بازار/دارایی قابل ویرایش، مدل منبع و مشاهده قیمت، freshness، override دستی، scheduler دریافت، نمای عضو/مدیر و اتصال عمومی بدون کلید نوبیتکس/Binance ساخته شد. provider طلا/ارز داخلی، CMS، گزارش و عملیات production خارج دامنه ماند.

## ۲. فایل‌ها

ماژول `MarketPrices` شامل Contracts، Infrastructure، Models، Actions و Controllers اضافه شد؛ migrationهای `000004` و `000005`، adapterهای `NobitexPublicMarketPriceProvider` و `BinancePublicMarketPriceProvider`، routeها، command/schedule، دو view بازار و CSS نسخه ۷ تکمیل شدند.

## ۳. دیتابیس

چهار جدول `price_sources`، `price_observations`، `manual_price_overrides` و `price_fetch_runs` اضافه شدند. بازار نوع معامله و دارایی واحد/دقت قیمت گرفت. مشاهده‌ها append-only و مقدارها decimal(30,12) مثبت‌اند.

## ۴. امنیت و مجوز

mutationهای دستی، source و deactivate با permission سمت سرور، reauthentication، lock رکورد و audit انجام می‌شوند. provider فقط از registry/allowlist مجاز است؛ endpoint ثابت است و URL/secret دلخواه پنل پذیرفته نمی‌شود. TLS verification فعال و timeout محدود است.

## ۵. منطق قیمت

override فعال بر آخرین API هم‌واحد اولویت دارد. پایان یا لغو آن fallback را فعال می‌کند. stale صریح و unavailable برابر null است؛ مقدار ساختگی یا صفر تولید نمی‌شود.

## ۶. UI

عضو مقدار، واحد، منبع/نوع، زمان و برچسب تازه/قدیمی/دستی/ناموجود را می‌بیند. پنل مدیر منبع، بازار، دارایی، واحد، قیمت دستی زمان‌دار و لغو حفظ‌کننده تاریخچه را ارائه می‌دهد.

## ۷. آزمون

PHP 8.4.1 و MySQL Community 8.4.11 واقعی استفاده شد. migration تمیز، ارتقای مرحله ۶→۷ و سپس ارتقای `000005` با حفظ ۱ حساب/۱ بازار/۱ دارایی/۱ source موفق شد و constraint هر دو driver جدید را پذیرفت. ۱۰ تست قیمت/۷۸ assertion و کل suite شامل ۹۸ تست/۱۰۴۸ assertion موفق شدند. قراردادهای HTTP نوبیتکس/Binance، تبدیل دقیق ریال به تومان و 429/backoff آزموده شدند. Composer validate/platform/audit بدون advisory و lint ۲۳۶ فایل PHP موجود در workspace نیز موفق بود.

## ۸. خطاها و حدود

اجرای نخست suite پس از `config:cache` با SESSION/CACHE تولیدی ۵۰۰ داد؛ این خطای ترتیب harness بود و با پاک‌سازی cache قبل از PHPUnit رفع و اجرای تمیز سبز شد. اجرای مستقیم endpointهای بیرونی از workspace با `Proxy CONNECT aborted due to timeout` مسدود شد؛ بنابراین smoke زنده موفق ادعا نمی‌شود و باید روی سرور مقصد انجام شود. مرورگر/موبایل، بار و crash scheduler آزموده نشده‌اند. PHP 8.4.1 محلی قدیمی است و binary در بسته نیست.

## ۹. وضعیت و ادامه

checkpoint فنی مرحله ۷ سبز است، اما کل محصول آماده عرضه اعلام نمی‌شود. قیمت عمومی رمزارز متصل است؛ provider طلا/ارز، SMS واقعی و سه مرحلهٔ ۸ تا ۱۰ باقی‌اند. deploy، DNS، commit و push انجام نشده‌اند و مرحله ۸ به دستور بعدی مالک نیاز دارد.
