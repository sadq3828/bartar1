# بازار و قیمت — مرحله ۷

## قرارداد نمایش

- `fresh`: مشاهده API هنوز از حد `stale_after_seconds` نگذشته است.
- `stale`: آخرین مشاهده معتبر موجود ولی قدیمی است؛ هرگز «زنده» نامیده نمی‌شود.
- `manual`: override زمان‌دار مدیر فعال است و تا پایان یا لغو بر API اولویت دارد.
- `unavailable`: مشاهده معتبر هم‌واحد وجود ندارد؛ مقدار `null` و نمایش «—» است، نه صفر.

هر قیمت مقدار decimal دقیق، واحد، دارایی، نوع/نام منبع و زمان مشاهده/دریافت دارد. زمان در DB با UTC و در UI با تهران/شمسی نمایش داده می‌شود. تغییر و حذف مستقیم `price_observations` با trigger MySQL ممنوع است.

## دریافت و شکست

فرمان `php artisan prices:refresh` منابع فعال و موعدرسیده را اجرا می‌کند. scheduler آن را هر دقیقه با `withoutOverlapping` فرا می‌خواند و داخل Action برای هر منبع `GET_LOCK` مستقل وجود دارد. payload باید برای دارایی فعال، واحد دقیق، مقدار مثبت با حداکثر ۱۲ رقم اعشار و زمان نه بیش از پنج دقیقه آینده داشته باشد. کل payload پیش از transaction اعتبارسنجی می‌شود؛ خطای یک ردیف کل اجرای منبع را fail می‌کند.

کدهای خطا پالایش‌شده در source/run ذخیره می‌شوند و retry بعدی حداقل ۶۰ ثانیه است. زمان retry در scheduler رعایت می‌شود؛ 429/418، timeout، 5xx، پاسخ خراب و نماد ناموجود هیچ observation ساختگی نمی‌سازند.

دو driver تولیدی بدون API key موجود است:

| driver | endpoint ثابت | قرارداد دارایی | تبدیل |
| --- | --- | --- | --- |
| `nobitex_public` | `https://apiv2.nobitex.ir/market/stats` | نماد صرافی و `price_unit=IRT` | مقدار `latest` ریالی با bcmath دقیق بر ۱۰ تقسیم و تومان ذخیره می‌شود |
| `binance_public` | `https://data-api.binance.vision/api/v3/ticker/price` | نماد پایه و `price_unit=USDT` | جفت `{SYMBOL}USDT` بدون تغییر واحد ذخیره می‌شود |

URL از ورودی مدیر گرفته نمی‌شود، TLS verification خاموش نشده و timeout اتصال/کل درخواست به‌ترتیب ۳/۸ ثانیه است. این endpointها زمان مشاهده را در پاسخ مورد استفاده نمی‌دهند؛ بنابراین `observed_at` زمان دریافت پاسخ در سرور و UTC است. محدودیت نرخ و دسترسی شبکه سرور باید در محیط استقرار مانیتور شود. طلا، ارز و سکه تا اتصال منبع مجاز مخصوص خود روی `unavailable` می‌مانند.

## عملیات مدیر

ثبت دستی به `prices.manual` و `prices.override`، رمز فعلی و دلیل نیاز دارد. بازه‌های override فعال یک دارایی نمی‌توانند overlap کنند. لغو، تاریخچه و observation را حذف نمی‌کند. تعریف source به `manage_integrations` نیاز دارد و driver فقط از allowlist سه‌تایی نوبیتکس، Binance یا `unavailable` انتخاب می‌شود.

## شواهد

`MarketPriceFlowTest` ده تست و ۷۸ assertion برای decimal/واحد، append-only، تازگی، override، قرارداد نوبیتکس/Binance، تبدیل ریال به تومان، 429/backoff، payload خراب، قفل overlap و مجوز دارد. suite کامل ۹۸ تست/۱۰۴۸ assertion روی MySQL 8.4.11 موفق است. پاسخ‌های API در آزمون قراردادی با Laravel HTTP fake تزریق شده‌اند؛ تلاش smoke زنده از workspace با timeout پراکسی مسدود شد و موفق اعلام نمی‌شود. نتیجه JUnit در `evidence/phase-7-junit.xml` است.
