<?php

use App\Http\Middleware\AdministratorPermission;
use App\Http\Middleware\AuthenticatedAdministrator;
use App\Http\Middleware\DevelopmentPreview;
use App\Http\Middleware\PrivateAreaUnavailable;
use App\Http\Middleware\RequireActiveMembership;
use App\Http\Middleware\ScopeAdminSession;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->replace(\Illuminate\Http\Middleware\TrustProxies::class, \App\Http\Middleware\TrustConfiguredProxies::class);
        $middleware->prepend(ScopeAdminSession::class);
        $middleware->append(\App\Http\Middleware\EnforceApplicationHost::class);
        $middleware->prependToPriorityList(SubstituteBindings::class, AuthenticatedAdministrator::class);
        $middleware->prependToPriorityList(SubstituteBindings::class, AdministratorPermission::class);
        $middleware->prependToPriorityList(SubstituteBindings::class, RequireActiveMembership::class);
        $middleware->append(SecurityHeaders::class);
        $middleware->alias([
            'development-preview' => DevelopmentPreview::class,
            'private-unavailable' => PrivateAreaUnavailable::class,
            'administrator' => AuthenticatedAdministrator::class,
            'admin-permission' => AdministratorPermission::class,
            'active-membership' => RequireActiveMembership::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->report(fn (\Throwable $error) => (new \App\Modules\SystemHealth\Support\ReportProductionFailure)($error));
        $exceptions->respond(fn (\Symfony\Component\HttpFoundation\Response $response) => SecurityHeaders::apply($response, request()));
        $exceptions->dontFlash(['code', 'otp', 'phone', 'internal_note', 'q', 'password', 'password_confirmation', 'current_password']);
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
