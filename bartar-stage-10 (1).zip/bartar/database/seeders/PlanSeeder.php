<?php

namespace Database\Seeders;

use App\Modules\Subscriptions\Models\Plan;
use Illuminate\Database\Seeder;

class PlanSeeder extends Seeder
{
    public function run(): void
    {
        Plan::firstOrCreate(['key' => 'standard'], ['title' => 'اشتراک برتر', 'active' => true]);
    }
}
