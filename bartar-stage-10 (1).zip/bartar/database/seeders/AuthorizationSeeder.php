<?php

namespace Database\Seeders;

use App\Modules\Authorization\Models\Permission;
use App\Modules\Authorization\Models\Role;
use App\Modules\Authorization\Support\PermissionCatalog;
use Illuminate\Database\Seeder;

class AuthorizationSeeder extends Seeder
{
    public function run(): void
    {
        foreach (PermissionCatalog::permissions() as $key => $title) {
            Permission::firstOrCreate(['key' => $key], ['title' => $title]);
        }
        foreach (PermissionCatalog::roles() as $key => $definition) {
            $role = Role::firstOrCreate(['key' => $key], ['title' => $definition['title'], 'protected' => $key === 'owner']);
            if ($role->wasRecentlyCreated) {
                $role->permissions()->sync(Permission::whereIn('key', $definition['permissions'])->pluck('id'));
            }
        }
    }
}
