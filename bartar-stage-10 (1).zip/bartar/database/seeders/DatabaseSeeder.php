<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Only permission metadata; never create a default or demonstration account.
        $this->call(AuthorizationSeeder::class);
        $this->call(PlanSeeder::class);
    }
}
