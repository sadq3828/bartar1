<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('content_media', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('media_file_id')->unique()->constrained('media_files')->restrictOnDelete();
            $table->string('alt_text', 180);
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
        });

        Schema::create('content_pages', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->string('slug', 64)->unique();
            $table->string('eyebrow', 100)->nullable();
            $table->string('title', 180);
            $table->text('intro');
            $table->string('icon', 40)->default('document');
            $table->foreignId('hero_media_id')->nullable()->constrained('content_media')->nullOnDelete();
            $table->string('status', 16)->default('draft');
            $table->unsignedInteger('version')->default(1);
            $table->dateTime('published_at', 6)->nullable();
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->foreignId('updated_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
            $table->index(['status', 'published_at']);
        });
        DB::statement("ALTER TABLE content_pages ADD CONSTRAINT content_page_values CHECK (status IN ('draft','published'))");

        Schema::create('content_sections', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('page_id')->constrained('content_pages')->cascadeOnDelete();
            $table->string('kind', 16)->default('text');
            $table->unsignedSmallInteger('position');
            $table->string('title', 180);
            $table->text('body');
            $table->string('action_label', 100)->nullable();
            $table->string('action_url', 500)->nullable();
            $table->boolean('visible')->default(true);
            $table->timestamps(6);
            $table->unique(['page_id', 'position']);
        });
        DB::statement("ALTER TABLE content_sections ADD CONSTRAINT content_section_values CHECK (kind IN ('text','banner','cta') AND position > 0)");

        Schema::create('content_page_revisions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('page_id')->constrained('content_pages')->restrictOnDelete();
            $table->unsignedInteger('version');
            $table->json('snapshot_json');
            $table->string('reason', 500);
            $table->foreignId('actor_id')->constrained('accounts')->restrictOnDelete();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->unique(['page_id', 'version']);
        });

        Schema::create('content_settings', function (Blueprint $table): void {
            $table->id();
            $table->string('key', 64)->unique();
            $table->text('value')->nullable();
            $table->foreignId('updated_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
        });

        Schema::create('content_menu_items', function (Blueprint $table): void {
            $table->id();
            $table->string('route_name', 64)->unique();
            $table->string('title', 60);
            $table->string('icon', 40);
            $table->unsignedSmallInteger('position');
            $table->boolean('visible')->default(true);
            $table->foreignId('updated_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
            $table->index(['visible', 'position']);
        });

        Schema::create('announcements', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->string('title', 180);
            $table->text('body');
            $table->string('audience', 16)->default('all');
            $table->string('status', 16)->default('draft');
            $table->dateTime('published_at', 6)->nullable();
            $table->dateTime('expires_at', 6)->nullable();
            $table->unsignedInteger('version')->default(1);
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->foreignId('updated_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
            $table->index(['status', 'audience', 'published_at']);
        });
        DB::statement("ALTER TABLE announcements ADD CONSTRAINT announcement_values CHECK (audience IN ('public','members','all') AND status IN ('draft','published','archived') AND (expires_at IS NULL OR published_at IS NULL OR expires_at > published_at))");

        Schema::create('member_notifications', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('recipient_id')->constrained('accounts')->restrictOnDelete();
            $table->string('kind', 24);
            $table->string('title', 180);
            $table->text('body');
            $table->string('action_url', 500)->nullable();
            $table->char('dedupe_key', 64)->unique();
            $table->dateTime('read_at', 6)->nullable();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->index(['recipient_id', 'read_at', 'created_at']);
        });
        DB::statement("ALTER TABLE member_notifications ADD CONSTRAINT member_notification_values CHECK (kind IN ('signal','announcement','subscription','administrative'))");

        Schema::create('notification_deliveries', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('notification_id')->constrained('member_notifications')->restrictOnDelete();
            $table->string('channel', 16);
            $table->string('status', 16)->default('pending');
            $table->unsignedTinyInteger('attempts')->default(0);
            $table->string('provider_reference', 190)->nullable();
            $table->string('error_code', 64)->nullable();
            $table->dateTime('next_retry_at', 6)->nullable();
            $table->dateTime('sent_at', 6)->nullable();
            $table->timestamps(6);
            $table->unique(['notification_id', 'channel']);
            $table->index(['status', 'next_retry_at']);
        });
        DB::statement("ALTER TABLE notification_deliveries ADD CONSTRAINT notification_delivery_values CHECK (channel IN ('sms') AND status IN ('pending','sent','failed','skipped') AND attempts <= 5)");

        Schema::table('signal_announcements', function (Blueprint $table): void {
            $table->dateTime('processed_at', 6)->nullable()->after('available_at');
            $table->unsignedTinyInteger('attempts')->default(0)->after('processed_at');
            $table->string('last_error_code', 64)->nullable()->after('attempts');
        });

        foreach (['content_page_revisions' => 'Content revision history'] as $table => $message) {
            foreach (['UPDATE', 'DELETE'] as $operation) {
                DB::unprepared('CREATE TRIGGER '.$table.'_no_'.strtolower($operation)." BEFORE $operation ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '$message is append only'");
            }
        }

        $contentRoleId = DB::table('roles')->where('key', 'content_manager')->value('id');
        if ($contentRoleId) {
            $permissionIds = DB::table('permissions')->whereIn('key', ['notifications.view', 'notifications.create', 'notifications.publish'])->pluck('id');
            foreach ($permissionIds as $permissionId) {
                DB::table('role_permissions')->insertOrIgnore(['role_id' => $contentRoleId, 'permission_id' => $permissionId]);
            }
        }
    }

    public function down(): void
    {
        Schema::table('signal_announcements', function (Blueprint $table): void {
            $table->dropColumn(['processed_at', 'attempts', 'last_error_code']);
        });
        foreach (['notification_deliveries', 'member_notifications', 'announcements', 'content_menu_items', 'content_settings', 'content_page_revisions', 'content_sections', 'content_pages', 'content_media'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
