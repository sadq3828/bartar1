<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('markets', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->string('key', 64)->unique();
            $table->string('title', 100);
            $table->boolean('active')->default(true);
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
        });

        Schema::create('assets', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('market_id')->constrained()->restrictOnDelete();
            $table->string('symbol', 40);
            $table->string('title', 120);
            $table->boolean('active')->default(true);
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
            $table->unique(['market_id', 'symbol']);
            $table->unique(['id', 'market_id']);
        });

        Schema::create('signals', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->string('title', 160);
            $table->foreignId('market_id')->constrained()->restrictOnDelete();
            $table->unsignedBigInteger('asset_id');
            $table->string('trade_type', 32);
            $table->string('direction', 8);
            $table->decimal('entry_low', 32, 12);
            $table->decimal('entry_high', 32, 12)->nullable();
            $table->decimal('stop_loss', 32, 12)->nullable();
            $table->string('timeframe', 50);
            $table->text('body_sanitized');
            $table->string('risk_label', 50)->nullable();
            $table->string('status', 16)->default('draft');
            $table->dateTime('scheduled_at', 6)->nullable();
            $table->dateTime('published_at', 6)->nullable();
            $table->dateTime('expires_at', 6)->nullable();
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->foreignId('published_by')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->unsignedInteger('version')->default(1);
            $table->timestamps(6);
            $table->foreign(['asset_id', 'market_id'])->references(['id', 'market_id'])->on('assets')->restrictOnDelete();
            $table->index(['status', 'published_at']);
            $table->index(['market_id', 'asset_id', 'published_at']);
        });
        DB::statement("ALTER TABLE signals ADD CONSTRAINT signal_values CHECK (entry_low > 0 AND (entry_high IS NULL OR entry_high >= entry_low) AND (stop_loss IS NULL OR stop_loss > 0) AND direction IN ('buy','sell') AND status IN ('draft','scheduled','published','completed','cancelled','expired'))");

        Schema::create('signal_targets', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('position');
            $table->decimal('price', 32, 12);
            $table->decimal('proposed_exit_weight', 7, 6)->nullable();
            $table->unique(['signal_id', 'position']);
        });
        DB::statement('ALTER TABLE signal_targets ADD CONSTRAINT signal_target_values CHECK (price > 0 AND position > 0 AND (proposed_exit_weight IS NULL OR (proposed_exit_weight > 0 AND proposed_exit_weight <= 1)))');

        Schema::create('signal_revisions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_id')->constrained()->restrictOnDelete();
            $table->unsignedInteger('version');
            $table->json('snapshot_json');
            $table->string('reason', 500);
            $table->foreignId('actor_id')->constrained('accounts')->restrictOnDelete();
            $table->dateTime('changed_at', 6);
            $table->boolean('announce_change')->default(false);
            $table->unique(['signal_id', 'version']);
        });

        Schema::create('signal_status_events', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_id')->constrained()->restrictOnDelete();
            $table->string('from_status', 16)->nullable();
            $table->string('to_status', 16);
            $table->string('reason', 500);
            $table->foreignId('actor_id')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->dateTime('happened_at', 6);
            $table->char('idempotency_key', 64)->unique();
            $table->index(['signal_id', 'happened_at']);
        });

        Schema::create('signal_results', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_id')->constrained()->restrictOnDelete();
            $table->unsignedInteger('version');
            $table->string('method', 24);
            $table->decimal('entry_execution_price', 32, 12)->nullable();
            $table->decimal('gross_return', 20, 8)->nullable();
            $table->decimal('fee_input', 20, 8)->nullable();
            $table->string('formula_version', 32)->default('pending-v1');
            $table->dateTime('computed_at', 6)->nullable();
            $table->decimal('coverage_ratio', 7, 6)->nullable();
            $table->text('note')->nullable();
            $table->foreignId('recorded_by')->constrained('accounts')->restrictOnDelete();
            $table->uuid('idempotency_key')->unique();
            $table->char('request_hash', 64);
            $table->dateTime('created_at', 6)->useCurrent();
            $table->unique(['signal_id', 'version']);
        });
        DB::statement('ALTER TABLE signal_results ADD CONSTRAINT signal_result_values CHECK ((entry_execution_price IS NULL OR entry_execution_price > 0) AND (coverage_ratio IS NULL OR (coverage_ratio >= 0 AND coverage_ratio <= 1)))');

        Schema::create('signal_exits', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_result_id')->constrained()->restrictOnDelete();
            $table->unsignedSmallInteger('position');
            $table->decimal('exit_price', 32, 12);
            $table->decimal('exit_weight', 7, 6);
            $table->dateTime('executed_at', 6)->nullable();
            $table->foreignId('target_id')->nullable()->constrained('signal_targets')->nullOnDelete();
            $table->unique(['signal_result_id', 'position']);
        });
        DB::statement('ALTER TABLE signal_exits ADD CONSTRAINT signal_exit_values CHECK (exit_price > 0 AND exit_weight > 0 AND exit_weight <= 1 AND position > 0)');

        Schema::create('signal_announcements', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_id')->constrained()->restrictOnDelete();
            $table->unsignedInteger('signal_version');
            $table->string('event_type', 24);
            $table->json('safe_payload');
            $table->string('status', 16)->default('pending');
            $table->dateTime('available_at', 6);
            $table->dateTime('created_at', 6)->useCurrent();
            $table->unique(['signal_id', 'signal_version', 'event_type']);
            $table->index(['status', 'available_at']);
        });

        foreach (['signal_revisions' => 'Signal revision history', 'signal_status_events' => 'Signal status history', 'signal_results' => 'Signal result history', 'signal_exits' => 'Signal exit history'] as $table => $message) {
            foreach (['UPDATE', 'DELETE'] as $operation) {
                DB::unprepared('CREATE TRIGGER '.$table.'_no_'.strtolower($operation).' BEFORE '.$operation." ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '$message is append only'");
            }
        }
    }

    public function down(): void
    {
        foreach (['signal_announcements', 'signal_exits', 'signal_results', 'signal_status_events', 'signal_revisions', 'signal_targets', 'signals', 'assets', 'markets'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
