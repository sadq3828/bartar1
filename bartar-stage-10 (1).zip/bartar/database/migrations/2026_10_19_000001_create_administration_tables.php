<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->enum('kind', ['admin', 'member']);
            $table->string('username', 64)->nullable()->unique();
            $table->string('display_name', 100)->nullable();
            $table->string('password_hash')->nullable();
            $table->timestamp('disabled_at', 6)->nullable();
            $table->unsignedInteger('auth_version')->default(1);
            $table->timestamp('last_login_at', 6)->nullable();
            $table->timestamps(6);
            $table->index(['kind', 'disabled_at']);
        });
        DB::statement("ALTER TABLE accounts ADD CONSTRAINT accounts_admin_identity CHECK (kind <> 'admin' OR (username IS NOT NULL AND password_hash IS NOT NULL))");
        Schema::create('permissions', function (Blueprint $table): void {
            $table->id();
            $table->string('key', 100)->unique();
            $table->string('title', 150);
        });
        Schema::create('roles', function (Blueprint $table): void {
            $table->id();
            $table->string('key', 64)->unique();
            $table->string('title', 100);
            $table->boolean('protected')->default(false);
            $table->timestamps(6);
        });
        Schema::create('account_roles', function (Blueprint $table): void {
            $table->foreignId('account_id')->constrained()->restrictOnDelete();
            $table->foreignId('role_id')->constrained()->restrictOnDelete();
            $table->primary(['account_id', 'role_id']);
        });
        Schema::create('role_permissions', function (Blueprint $table): void {
            $table->foreignId('role_id')->constrained()->restrictOnDelete();
            $table->foreignId('permission_id')->constrained()->restrictOnDelete();
            $table->primary(['role_id', 'permission_id']);
        });
        Schema::create('security_locks', function (Blueprint $table): void {
            $table->unsignedTinyInteger('id')->primary();
        });
        DB::table('security_locks')->insert(['id' => 1]);
        Schema::create('admin_sessions', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('account_id')->constrained()->restrictOnDelete();
            $table->char('session_hash', 64)->unique();
            $table->unsignedInteger('auth_version');
            $table->char('ip_digest', 64)->nullable();
            $table->string('device', 80)->default('مرورگر');
            $table->timestamp('last_seen_at', 6);
            $table->timestamp('revoked_at', 6)->nullable();
            $table->timestamp('created_at', 6)->useCurrent();
            $table->index(['account_id', 'revoked_at']);
        });
        Schema::create('audit_logs', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('actor_id')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->string('actor_kind', 20);
            $table->string('action', 100);
            $table->string('scope', 32)->default('security');
            $table->string('entity_type', 50)->nullable();
            $table->string('entity_id', 40)->nullable();
            $table->json('before_data')->nullable();
            $table->json('after_data')->nullable();
            $table->string('reason', 500)->nullable();
            $table->timestamp('happened_at', 6);
            $table->index(['scope', 'happened_at']);
            $table->index(['entity_type', 'entity_id']);
        });
        Schema::create('auth_events', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('account_id')->nullable()->constrained()->restrictOnDelete();
            $table->char('subject_hash', 64);
            $table->char('ip_digest', 64);
            $table->string('outcome', 32);
            $table->timestamp('occurred_at', 6);
            $table->index(['occurred_at', 'outcome']);
        });
        foreach (['audit_logs', 'auth_events'] as $table) {
            foreach (['UPDATE', 'DELETE'] as $operation) {
                DB::unprepared("CREATE TRIGGER {$table}_no_".strtolower($operation)." BEFORE $operation ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Security records are append only'");
            }
        }
    }

    public function down(): void
    {
        // Used only in isolated tests or an explicitly approved rollback.
        foreach (['auth_events', 'audit_logs', 'admin_sessions', 'security_locks', 'role_permissions', 'account_roles', 'roles', 'permissions', 'accounts'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
