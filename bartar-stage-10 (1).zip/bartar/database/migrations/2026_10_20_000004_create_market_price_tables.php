<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('markets', function (Blueprint $table): void {
            $table->string('trade_type', 16)->nullable()->after('title');
        });
        Schema::table('assets', function (Blueprint $table): void {
            $table->string('price_unit', 16)->nullable()->after('title');
            $table->string('quantity_unit', 16)->nullable()->after('price_unit');
            $table->unsignedTinyInteger('price_scale')->default(8)->after('quantity_unit');
            $table->index(['active', 'market_id']);
        });
        DB::statement("ALTER TABLE markets ADD CONSTRAINT market_trade_type_values CHECK (trade_type IS NULL OR trade_type IN ('spot','forex','gold','domestic'))");
        DB::statement('ALTER TABLE assets ADD CONSTRAINT asset_price_scale_values CHECK (price_scale <= 12)');

        Schema::create('price_sources', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('market_id')->constrained()->restrictOnDelete();
            $table->string('key', 64)->unique();
            $table->string('title', 120);
            $table->string('driver', 40)->default('unavailable');
            $table->boolean('enabled')->default(false);
            $table->unsignedInteger('refresh_seconds')->default(60);
            $table->unsignedInteger('stale_after_seconds')->default(180);
            $table->dateTime('last_attempt_at', 6)->nullable();
            $table->dateTime('last_success_at', 6)->nullable();
            $table->dateTime('last_error_at', 6)->nullable();
            $table->string('last_error_code', 64)->nullable();
            $table->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $table->timestamps(6);
            $table->index(['enabled', 'last_attempt_at']);
        });
        DB::statement("ALTER TABLE price_sources ADD CONSTRAINT price_source_values CHECK (refresh_seconds >= 30 AND stale_after_seconds >= refresh_seconds AND driver IN ('unavailable'))");

        Schema::create('price_observations', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('asset_id')->constrained()->restrictOnDelete();
            $table->foreignId('source_id')->nullable()->constrained('price_sources')->restrictOnDelete();
            $table->string('source_kind', 12);
            $table->decimal('value', 30, 12);
            $table->string('unit', 16);
            $table->dateTime('observed_at', 6);
            $table->dateTime('received_at', 6);
            $table->foreignId('actor_id')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->string('reason', 500)->nullable();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->index(['asset_id', 'observed_at']);
            $table->index(['source_id', 'received_at']);
        });
        DB::statement("ALTER TABLE price_observations ADD CONSTRAINT price_observation_values CHECK (value > 0 AND source_kind IN ('api','manual') AND ((source_kind = 'api' AND source_id IS NOT NULL AND actor_id IS NULL) OR (source_kind = 'manual' AND source_id IS NULL AND actor_id IS NOT NULL)))");

        Schema::create('manual_price_overrides', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('asset_id')->constrained()->restrictOnDelete();
            $table->foreignId('observation_id')->unique()->constrained('price_observations')->restrictOnDelete();
            $table->dateTime('starts_at', 6);
            $table->dateTime('ends_at', 6);
            $table->dateTime('revoked_at', 6)->nullable();
            $table->foreignId('actor_id')->constrained('accounts')->restrictOnDelete();
            $table->foreignId('revoked_by')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->string('reason', 500);
            $table->string('revoke_reason', 500)->nullable();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->index(['asset_id', 'starts_at', 'ends_at']);
        });
        DB::statement('ALTER TABLE manual_price_overrides ADD CONSTRAINT manual_price_override_values CHECK (ends_at > starts_at AND ((revoked_at IS NULL AND revoked_by IS NULL AND revoke_reason IS NULL) OR (revoked_at IS NOT NULL AND revoked_by IS NOT NULL AND revoke_reason IS NOT NULL)))');

        Schema::create('price_fetch_runs', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('source_id')->constrained('price_sources')->restrictOnDelete();
            $table->dateTime('started_at', 6);
            $table->dateTime('finished_at', 6)->nullable();
            $table->string('status', 16);
            $table->string('error_code', 64)->nullable();
            $table->unsignedSmallInteger('retry_count')->default(0);
            $table->dateTime('next_retry_at', 6)->nullable();
            $table->unsignedInteger('observation_count')->default(0);
            $table->index(['source_id', 'started_at']);
            $table->index(['status', 'next_retry_at']);
        });
        DB::statement("ALTER TABLE price_fetch_runs ADD CONSTRAINT price_fetch_run_values CHECK (status IN ('running','succeeded','failed','skipped') AND observation_count >= 0)");

        foreach (['price_observations' => 'Price observations are append only'] as $table => $message) {
            foreach (['UPDATE', 'DELETE'] as $operation) {
                DB::unprepared('CREATE TRIGGER '.$table.'_no_'.strtolower($operation).' BEFORE '.$operation." ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '$message'");
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('price_fetch_runs');
        Schema::dropIfExists('manual_price_overrides');
        Schema::dropIfExists('price_observations');
        Schema::dropIfExists('price_sources');
        Schema::table('assets', function (Blueprint $table): void {
            $table->dropIndex(['active', 'market_id']);
            $table->dropColumn(['price_unit', 'quantity_unit', 'price_scale']);
        });
        Schema::table('markets', fn (Blueprint $table) => $table->dropColumn('trade_type'));
    }
};
