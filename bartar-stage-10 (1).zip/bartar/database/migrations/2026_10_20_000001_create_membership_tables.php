<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('members', function (Blueprint $t): void {
            $t->id();
            $t->ulid('public_id')->unique();
            $t->foreignId('account_id')->unique()->constrained()->restrictOnDelete();
            $t->text('phone_e164');
            $t->char('phone_hash', 64)->unique();
            $t->text('internal_note')->nullable();
            $t->dateTime('blocked_at', 6)->nullable();
            $t->string('block_reason', 500)->nullable();
            $t->foreignId('created_by')->constrained('accounts')->restrictOnDelete();
            $t->timestamps(6);
            $t->index('blocked_at');
        });
        Schema::create('plans', function (Blueprint $t): void {
            $t->id();
            $t->string('key', 64)->unique();
            $t->string('title', 100);
            $t->boolean('active')->default(true);
        });
        Schema::create('subscriptions', function (Blueprint $t): void {
            $t->id();
            $t->foreignId('member_id')->unique()->constrained()->restrictOnDelete();
            $t->foreignId('plan_id')->constrained()->restrictOnDelete();
            $t->dateTime('starts_at', 6);
            $t->dateTime('ends_at', 6);
            $t->dateTime('revoked_at', 6)->nullable();
            $t->unsignedInteger('version')->default(1);
            $t->timestamps(6);
            $t->index('ends_at');
        });
        DB::statement('ALTER TABLE subscriptions ADD CONSTRAINT subscription_window CHECK (ends_at > starts_at)');
        Schema::create('subscription_renewals', function (Blueprint $t): void {
            $t->id();
            $t->ulid('public_id')->unique();
            $t->foreignId('subscription_id')->constrained()->restrictOnDelete();
            $t->string('operation', 16);
            $t->unsignedTinyInteger('months');
            $t->string('calendar', 16);
            $t->dateTime('base_at', 6);
            $t->dateTime('old_end', 6)->nullable();
            $t->dateTime('new_start', 6);
            $t->dateTime('new_end', 6);
            $t->foreignId('actor_id')->constrained('accounts')->restrictOnDelete();
            $t->string('reason', 500);
            $t->uuid('idempotency_key')->unique();
            $t->char('request_hash', 64);
            $t->dateTime('created_at', 6)->useCurrent();
        });
        DB::statement("ALTER TABLE subscription_renewals ADD CONSTRAINT renewal_duration CHECK (months IN (1,3,6,12) AND calendar IN ('persian','gregorian'))");
        Schema::create('manual_payments', function (Blueprint $t): void {
            $t->id();
            $t->ulid('public_id')->unique();
            $t->foreignId('member_id')->constrained()->restrictOnDelete();
            $t->decimal('amount', 24, 2);
            $t->string('unit', 3);
            $t->dateTime('paid_at', 6);
            $t->string('method', 20);
            $t->string('tracking_reference', 100)->nullable();
            $t->string('note', 500)->nullable();
            $t->foreignId('recorded_by')->constrained('accounts')->restrictOnDelete();
            $t->foreignId('confirmed_by')->nullable()->constrained('accounts')->restrictOnDelete();
            $t->dateTime('confirmed_at', 6)->nullable();
            $t->uuid('idempotency_key')->unique();
            $t->char('request_hash', 64);
            $t->dateTime('created_at', 6)->useCurrent();
            $t->index(['member_id', 'paid_at']);
        });
        DB::statement("ALTER TABLE manual_payments ADD CONSTRAINT payment_amount CHECK (amount >= 0 AND unit IN ('IRT','IRR'))");
        Schema::create('otp_challenges', function (Blueprint $t): void {
            $t->id();
            $t->ulid('public_id')->unique();
            $t->foreignId('member_id')->constrained()->restrictOnDelete();
            $t->char('verifier_hmac', 64)->nullable();
            $t->char('session_binding_hash', 64);
            $t->char('ip_digest', 64);
            $t->dateTime('expires_at', 6);
            $t->dateTime('sent_at', 6)->nullable();
            $t->dateTime('consumed_at', 6)->nullable();
            $t->dateTime('invalidated_at', 6)->nullable();
            $t->unsignedTinyInteger('attempts')->default(0);
            $t->dateTime('created_at', 6)->useCurrent();
            $t->index(['member_id', 'created_at']);
            $t->index('expires_at');
        });
        Schema::create('member_sessions', function (Blueprint $t): void {
            $t->id();
            $t->ulid('public_id')->unique();
            $t->foreignId('account_id')->constrained()->restrictOnDelete();
            $t->char('session_hash', 64)->unique();
            $t->unsignedInteger('auth_version');
            $t->dateTime('last_seen_at', 6);
            $t->dateTime('revoked_at', 6)->nullable();
            $t->dateTime('created_at', 6)->useCurrent();
            $t->index(['account_id', 'revoked_at']);
        });
        foreach (['UPDATE', 'DELETE'] as $operation) {
            DB::unprepared('CREATE TRIGGER renewals_no_'.strtolower($operation)." BEFORE $operation ON subscription_renewals FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Subscription history is append only'");
        }
    }

    public function down(): void
    {
        foreach (['member_sessions', 'otp_challenges', 'manual_payments', 'subscription_renewals', 'subscriptions', 'plans', 'members'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
