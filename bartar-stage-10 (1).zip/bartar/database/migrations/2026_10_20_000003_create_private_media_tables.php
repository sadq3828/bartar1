<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('media_files', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->string('disk', 64);
            $table->string('object_key', 255);
            $table->string('kind', 16);
            $table->string('mime', 100);
            $table->unsignedBigInteger('bytes');
            $table->char('sha256', 64);
            $table->string('original_name', 255);
            $table->string('state', 16)->default('quarantined');
            $table->foreignId('uploaded_by')->constrained('accounts')->restrictOnDelete();
            $table->dateTime('verified_at', 6)->nullable();
            $table->dateTime('deleted_at', 6)->nullable();
            $table->timestamps(6);
            $table->unique(['disk', 'object_key']);
            $table->index(['state', 'created_at']);
        });
        DB::statement("ALTER TABLE media_files ADD CONSTRAINT media_file_values CHECK (kind IN ('image','audio','video') AND state IN ('quarantined','ready','rejected','deleted') AND bytes > 0)");

        Schema::create('signal_media', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('signal_id')->constrained()->restrictOnDelete();
            $table->foreignId('media_file_id')->unique()->constrained('media_files')->restrictOnDelete();
            $table->string('kind', 16);
            $table->string('caption', 500)->nullable();
            $table->unsignedSmallInteger('position');
            $table->timestamps(6);
            $table->unique(['signal_id', 'position']);
            $table->index(['signal_id', 'kind']);
        });
        DB::statement("ALTER TABLE signal_media ADD CONSTRAINT signal_media_values CHECK (kind IN ('image','audio','video') AND position > 0)");
    }

    public function down(): void
    {
        Schema::dropIfExists('signal_media');
        Schema::dropIfExists('media_files');
    }
};
