<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('signal_result_calculations', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('signal_result_id')->constrained()->restrictOnDelete();
            $table->string('formula_version', 32);
            $table->string('state', 20);
            $table->string('reason_code', 40)->nullable();
            $table->decimal('coverage', 7, 6);
            $table->decimal('realised_return', 48, 8)->nullable();
            $table->decimal('final_return', 48, 8)->nullable();
            $table->string('outcome', 12);
            $table->json('inputs_json');
            $table->dateTime('computed_at', 6);
            $table->unique(['signal_result_id', 'formula_version'], 'result_calculation_formula_unique');
        });
        DB::statement("ALTER TABLE signal_result_calculations ADD CONSTRAINT calculation_values CHECK (state IN ('complete','partial','unavailable') AND outcome IN ('positive','negative','zero','unknown') AND coverage >= 0 AND coverage <= 1 AND (state = 'complete' OR final_return IS NULL))");
        foreach (['UPDATE', 'DELETE'] as $operation) {
            DB::unprepared('CREATE TRIGGER signal_result_calculations_no_'.strtolower($operation).' BEFORE '.$operation." ON signal_result_calculations FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Result calculation history is append only'");
        }
        Schema::create('backup_runs', function (Blueprint $table): void {
            $table->id();
            $table->ulid('public_id')->unique();
            $table->foreignId('requested_by')->nullable()->constrained('accounts')->restrictOnDelete();
            $table->string('reason', 500);
            $table->string('status', 20)->default('queued');
            $table->string('error_code', 40)->nullable();
            $table->unsignedBigInteger('bytes')->nullable();
            $table->dateTime('started_at', 6)->nullable();
            $table->dateTime('completed_at', 6)->nullable();
            $table->dateTime('restore_verified_at', 6)->nullable();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->index(['status', 'created_at']);
        });
        Schema::create('backup_restore_runs', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('backup_run_id')->constrained()->restrictOnDelete();
            $table->string('status', 20);
            $table->string('error_code', 40)->nullable();
            $table->json('verification')->nullable();
            $table->dateTime('started_at', 6);
            $table->dateTime('completed_at', 6)->nullable();
        });
        DB::statement("ALTER TABLE backup_runs ADD CONSTRAINT backup_status CHECK (status IN ('queued','running','completed','failed','deleted'))");
        DB::statement("ALTER TABLE backup_restore_runs ADD CONSTRAINT restore_status CHECK (status IN ('running','completed','failed'))");
        Schema::create('operation_heartbeats', function (Blueprint $table): void {
            $table->string('name', 32)->primary();
            $table->dateTime('seen_at', 6);
        });
        $id = DB::table('permissions')->where('key', 'backups.view')->value('id');
        if (! $id) {
            $id = DB::table('permissions')->insertGetId(['key' => 'backups.view', 'title' => 'مشاهده وضعیت بکاپ']);
        }
        $roles = DB::table('role_permissions')->join('permissions', 'permissions.id', '=', 'role_permissions.permission_id')->whereIn('permissions.key', ['manage_backups', 'all_modules'])->distinct()->pluck('role_permissions.role_id');
        foreach ($roles as $role) {
            DB::table('role_permissions')->insertOrIgnore(['role_id' => $role, 'permission_id' => $id]);
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('operation_heartbeats');
        Schema::dropIfExists('backup_restore_runs');
        Schema::dropIfExists('backup_runs');
        Schema::dropIfExists('signal_result_calculations');
    }
};
