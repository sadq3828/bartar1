<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE price_sources DROP CHECK price_source_values');
        DB::statement("ALTER TABLE price_sources ADD CONSTRAINT price_source_values CHECK (refresh_seconds >= 30 AND stale_after_seconds >= refresh_seconds AND driver IN ('unavailable','nobitex_public','binance_public'))");
    }

    public function down(): void
    {
        DB::table('price_sources')->whereIn('driver', ['nobitex_public', 'binance_public'])->update(['driver' => 'unavailable', 'enabled' => false]);
        DB::statement('ALTER TABLE price_sources DROP CHECK price_source_values');
        DB::statement("ALTER TABLE price_sources ADD CONSTRAINT price_source_values CHECK (refresh_seconds >= 30 AND stale_after_seconds >= refresh_seconds AND driver IN ('unavailable'))");
    }
};
