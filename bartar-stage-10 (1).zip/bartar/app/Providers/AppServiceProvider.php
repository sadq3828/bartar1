<?php

namespace App\Providers;

use App\Modules\Administration\Policies\AccountPolicy;
use App\Modules\Authentication\Models\Account;
use App\Modules\Content\Models\ContentMenuItem;
use App\Modules\Content\Models\ContentSetting;
use App\Modules\Members\Models\Member;
use App\Modules\Members\Policies\MemberPolicy;
use App\Modules\Media\Contracts\PrivateMediaStorage;
use App\Modules\Media\Infrastructure\LaravelPrivateMediaStorage;
use App\Modules\MarketPrices\Contracts\PriceProviderRegistry;
use App\Modules\MarketPrices\Infrastructure\ConfiguredPriceProviderRegistry;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Policies\SignalPolicy;
use App\Modules\SmsIntegration\Adapters\UnavailableOtpSender;
use App\Modules\SmsIntegration\Adapters\UnavailableNotificationSmsSender;
use App\Modules\SmsIntegration\Contracts\NotificationSmsSender;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Throwable;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(OtpSender::class, UnavailableOtpSender::class);
        $this->app->bind(NotificationSmsSender::class, UnavailableNotificationSmsSender::class);
        $this->app->bind(PrivateMediaStorage::class, LaravelPrivateMediaStorage::class);
        $this->app->bind(PriceProviderRegistry::class, ConfiguredPriceProviderRegistry::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if ($this->app->environment('production')) {
            config(['security.configured_debug' => config('app.debug'), 'app.debug' => false]);
        }
        \Illuminate\Support\Facades\Queue::looping(function (): void {
            if (config('queue.default') === 'database') {
                app(\App\Modules\SystemHealth\Actions\SystemHealth::class)->heartbeat('worker');
            }
        });
        Gate::policy(Account::class, AccountPolicy::class);
        Gate::policy(Member::class, MemberPolicy::class);
        Gate::policy(Signal::class, SignalPolicy::class);
        View::composer('layouts.site', function ($view): void {
            $settings = [];
            $navigation = [];
            if (config('content.database_enabled') && ! app()->bound('content.database.unavailable')) {
                try {
                    $settings = Schema::hasTable('content_settings') ? ContentSetting::pluck('value', 'key')->all() : [];
                    $navigation = Schema::hasTable('content_menu_items') ? ContentMenuItem::where('visible', true)->orderBy('position')->get()->mapWithKeys(fn ($item) => [$item->route_name => ['title' => $item->title, 'icon' => $item->icon]])->all() : [];
                } catch (Throwable) {
                    DB::purge();
                    app()->instance('content.database.unavailable', true);
                }
            }
            $view->with(['brandSettings' => $settings, 'publicNavigation' => $navigation]);
        });
    }
}
