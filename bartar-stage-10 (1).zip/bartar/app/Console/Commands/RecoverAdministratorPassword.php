<?php

namespace App\Console\Commands;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class RecoverAdministratorPassword extends Command
{
    protected $signature = 'bartar:admin-reset';

    protected $description = 'Recover an administrator password from an authorized server console; revoke sessions';

    public function handle(ManageAdministrators $manager, RecordAudit $audit): int
    {
        $username = strtolower(trim((string) $this->ask('نام کاربری مدیر')));
        $reason = (string) $this->ask('دلیل بازیابی؛ اطلاعات محرمانه وارد نکنید');
        $password = (string) $this->secret('رمز جدید؛ حداقل ۱۲ نویسه');
        $confirmation = (string) $this->secret('تکرار رمز جدید');
        $v = Validator::make(['password' => $password, 'password_confirmation' => $confirmation, 'reason' => $reason], ['password' => ['required', 'string', 'min:12', 'max:128', 'confirmed'], 'reason' => ['required', 'string', 'max:500']]);
        if ($v->fails()) {
            $this->error('ورودی معتبر نیست یا تکرار رمز مطابقت ندارد.');

            return self::FAILURE;
        }
        if (! $this->confirm('همه نشست‌های این مدیر لغو شوند؟', false)) {
            return self::FAILURE;
        }
        $updated = DB::transaction(function () use ($manager, $audit, $username, $password, $reason): bool {
            $manager->lock();
            $account = Account::where('kind', 'admin')->where('username', $username)->lockForUpdate()->first();
            if (! $account) {
                return false;
            }
            $account->password_hash = $password;
            $account->auth_version++;
            $account->save();
            AdminSession::where('account_id', $account->id)->whereNull('revoked_at')->update(['revoked_at' => now()]);
            $audit->write(null, 'password.recovered', 'account', $account->public_id, [], [], $reason, 'security', 'console');

            return true;
        }, 3);
        if (! $updated) {
            $this->error('حساب مدیریتی پیدا نشد.');

            return self::FAILURE;
        }
        $this->info('رمز تغییر کرد و نشست‌ها لغو شدند.');

        return self::SUCCESS;
    }
}
