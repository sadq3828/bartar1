<?php

namespace App\Console\Commands;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authorization\Models\Role;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CreateInitialAdministrator extends Command
{
    protected $signature = 'bartar:admin-create';

    protected $description = 'Create the first administrator using hidden interactive password input';

    public function handle(ManageAdministrators $manager, RecordAudit $audit): int
    {
        if (Account::where('kind', 'admin')->exists()) {
            $this->error('مدیر اولیه قبلاً ایجاد شده است؛ از پنل مدیران استفاده کنید.');

            return self::FAILURE;
        }
        $username = strtolower(trim((string) $this->ask('نام کاربری مدیر')));
        $password = (string) $this->secret('رمز جدید؛ حداقل ۱۲ نویسه');
        $confirmation = (string) $this->secret('تکرار رمز جدید');
        $v = Validator::make(['username' => $username, 'password' => $password, 'password_confirmation' => $confirmation], ['username' => ['required', 'min:3', 'max:64', 'regex:/\A[a-z0-9][a-z0-9._-]*\z/'], 'password' => ['required', 'string', 'min:12', 'max:128', 'confirmed']]);
        if ($v->fails()) {
            $this->error('ورودی معتبر نیست یا تکرار رمز مطابقت ندارد.');

            return self::FAILURE;
        }
        DB::transaction(function () use ($manager, $audit, $username, $password): void {
            $manager->lock();
            if (Account::where('kind', 'admin')->exists()) {
                throw new \RuntimeException('Initial administrator already exists.');
            }
            $owner = Role::where('key', 'owner')->firstOrFail();
            $account = Account::create(['kind' => 'admin', 'username' => $username, 'password_hash' => $password]);
            $account->roles()->attach($owner->id);
            $audit->write(null, 'admin.initialized', 'account', $account->public_id, [], ['username' => $username], null, 'security', 'console');
        }, 3);
        $this->info('مدیر اولیه ایجاد شد. رمز در خروجی یا لاگ ثبت نشد.');

        return self::SUCCESS;
    }
}
