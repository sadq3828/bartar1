<?php

namespace App\Http\Middleware;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Models\MemberSession;
use App\Modules\Members\Models\Member;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;

final class RequireActiveMembership
{
    public function handle(Request $request, Closure $next): Response
    {
        $guard = Auth::guard('member');
        $user = $guard->user();
        $account = $user ? Account::find($user->getAuthIdentifier()) : null;
        $member = $account ? Member::where('account_id', $account->id)->first() : null;
        $registry = $account ? MemberSession::where('account_id', $account->id)->where('session_hash', AdminSession::digest($request->session()->getId()))->whereNull('revoked_at')->first() : null;
        $valid = $account && $member && $registry && $registry->auth_version === $account->auth_version && $registry->last_seen_at->gt(now()->subMinutes((int) config('membership.session_lifetime'))) && Gate::forUser($account)->allows('access', $member);
        if (! $valid) {
            if ($registry) {
                $registry->update(['revoked_at' => now()]);
            }
            if ($user) {
                $guard->logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
            }

            return $request->expectsJson() || $request->is('api/*') ? response()->json(['message' => 'ورود معتبر و اشتراک فعال لازم است.'], 401)->header('Cache-Control', 'private, no-store') : redirect()->route('login')->header('Cache-Control', 'private, no-store');
        }
        $guard->setUser($account);
        $request->setUserResolver(fn ($name = null) => $name === 'admin' ? Auth::guard('admin')->user() : $account);
        if ($registry->last_seen_at->lt(now()->subMinute())) {
            $registry->update(['last_seen_at' => now()]);
        }
        $request->attributes->set('member', $member);
        $request->attributes->set('member_session', $registry);
        $response = $next($request);
        $response->headers->set('Cache-Control', 'private, no-store');
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');

        return $response;
    }
}
