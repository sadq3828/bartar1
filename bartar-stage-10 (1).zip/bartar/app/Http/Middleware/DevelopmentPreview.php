<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class DevelopmentPreview
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless(app()->environment('local') && config('bartar.preview_enabled') === true, 404);
        $response = $next($request);
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow, noarchive');
        $response->headers->set('Cache-Control', 'private, no-store');
        return $response;
    }
}
