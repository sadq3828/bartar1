<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

final class TrustConfiguredProxies
{
    public static function valid(string $value): bool
    {
        $parts = explode('/', $value);
        if (count($parts) > 2 || ! filter_var($parts[0], FILTER_VALIDATE_IP)) {
            return false;
        }

        return count($parts) === 1 || (ctype_digit($parts[1]) && (int) $parts[1] > 0 && (int) $parts[1] <= (str_contains($parts[0], ':') ? 128 : 32));
    }

    public function handle(Request $request, Closure $next)
    {
        $proxies = array_values(array_filter(config('security.trusted_proxies', []), self::valid(...)));
        $request::setTrustedProxies($proxies, Request::HEADER_X_FORWARDED_FOR | Request::HEADER_X_FORWARDED_PROTO | Request::HEADER_X_FORWARDED_PORT);

        return $next($request);
    }
}
