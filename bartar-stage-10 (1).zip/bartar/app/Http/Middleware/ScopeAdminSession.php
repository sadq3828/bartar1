<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ScopeAdminSession
{
    public function handle(Request $request, Closure $next): Response
    {
        $cookie = $request->is('admin', 'admin/*') ? 'bartar_admin_session' : 'bartar_member_session';
        config(['session.cookie' => $cookie]);
        app('session')->driver()->setName($cookie);
        if (app()->environment('production')) {
            config(['session.secure' => true, 'session.http_only' => true, 'session.same_site' => 'lax', 'session.encrypt' => true]);
        }

        return $next($request);
    }
}
