<?php

namespace App\Http\Middleware;

use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AuthenticatedAdministrator
{
    public function handle(Request $request, Closure $next): Response
    {
        $guard = Auth::guard('admin');
        $user = $guard->user();
        $account = $user ? Account::find($user->getAuthIdentifier()) : null;
        $session = $account ? AdminSession::where('account_id', $account->id)->where('session_hash', AdminSession::digest($request->session()->getId()))->whereNull('revoked_at')->first() : null;
        $expired = $session && $session->last_seen_at->lte(now()->subMinutes((int) config('session.lifetime')));
        if (! $account || $account->kind !== 'admin' || $account->disabled_at || ! $session || $expired || $session->auth_version !== $account->auth_version) {
            if ($session) {
                $session->update(['revoked_at' => now()]);
            }
            if ($user) {
                $guard->logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
            }

            return $request->expectsJson() ? response()->json(['message' => 'احراز هویت لازم است.'], 401) : redirect()->route('admin.login');
        }
        $guard->setUser($account);
        $request->setUserResolver(fn ($name = null) => $name === 'member' ? Auth::guard('member')->user() : $account);
        if ($session->last_seen_at->lt(now()->subMinute())) {
            $session->update(['last_seen_at' => now()]);
        }
        $request->attributes->set('admin_session', $session);
        $response = $next($request);
        $response->headers->set('Cache-Control', 'private, no-store');
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');

        return $response;
    }
}
