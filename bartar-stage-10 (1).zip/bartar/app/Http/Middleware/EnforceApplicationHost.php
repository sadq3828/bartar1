<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class EnforceApplicationHost
{
    public function handle(Request $request, Closure $next)
    {
        $request->attributes->set('request_id', (string) Str::uuid());
        if (app()->environment('production')) {
            // HTTP error pages remain non-disclosing even under a bad env file.
            config(['app.debug' => false]);
            $host = parse_url((string) config('app.url'), PHP_URL_HOST);
            abort_unless(is_string($host) && $host !== '', 503);
            abort_unless(strcasecmp($request->getHost(), $host) === 0, 400);
        }

        return $next($request);
    }
}
