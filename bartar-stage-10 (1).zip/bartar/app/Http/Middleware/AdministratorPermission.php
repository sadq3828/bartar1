<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdministratorPermission
{
    public function handle(Request $request, Closure $next, string ...$permissions): Response
    {
        abort_unless(collect($permissions)->contains(fn ($permission) => $request->user('admin')?->allows($permission)), 403);

        return $next($request);
    }
}
