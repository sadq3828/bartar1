<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PrivateAreaUnavailable
{
    public function handle(Request $request, Closure $next, string $area = 'member'): Response
    {
        if ($request->expectsJson()) {
            return response()->json(['message' => 'احراز هویت لازم است.'], 401)
                ->header('Cache-Control', 'private, no-store');
        }
        return redirect()->route($area === 'admin' ? 'admin.login' : 'login')
            ->header('Cache-Control', 'private, no-store');
    }
}
