<?php

namespace App\Modules\SmsIntegration\Contracts;

interface OtpSender
{
    public function available(): bool;

    /** Send synchronously; never log or persist phone/code or provider response. */
    public function send(string $phone, string $code): void;
}
