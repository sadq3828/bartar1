<?php

namespace App\Modules\SmsIntegration\Contracts;

interface NotificationSmsSender
{
    public function send(string $phoneE164, string $template, array $variables, string $dedupeKey): ?string;
}
