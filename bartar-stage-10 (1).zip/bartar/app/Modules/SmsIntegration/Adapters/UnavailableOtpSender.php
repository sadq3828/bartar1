<?php

namespace App\Modules\SmsIntegration\Adapters;

use App\Modules\SmsIntegration\Contracts\OtpSender;

final class UnavailableOtpSender implements OtpSender
{
    public function available(): bool
    {
        return false;
    }

    public function send(string $phone, string $code): void
    {
        throw new \RuntimeException('SMS delivery is not configured.');
    }
}
