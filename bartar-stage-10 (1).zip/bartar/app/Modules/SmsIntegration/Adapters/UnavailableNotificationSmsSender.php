<?php

namespace App\Modules\SmsIntegration\Adapters;

use App\Modules\SmsIntegration\Contracts\NotificationSmsSender;
use App\Modules\SmsIntegration\Support\NotificationSmsException;

final class UnavailableNotificationSmsSender implements NotificationSmsSender
{
    public function send(string $phoneE164, string $template, array $variables, string $dedupeKey): ?string
    {
        throw new NotificationSmsException('provider_unavailable');
    }
}
