<?php

namespace App\Modules\SmsIntegration\Support;

use RuntimeException;

final class NotificationSmsException extends RuntimeException
{
    public function __construct(public readonly string $safeCode)
    {
        parent::__construct($safeCode);
    }
}
