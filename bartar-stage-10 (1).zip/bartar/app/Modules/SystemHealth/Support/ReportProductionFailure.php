<?php

namespace App\Modules\SystemHealth\Support;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

final class ReportProductionFailure
{
    public function __invoke(\Throwable $error): ?bool
    {
        if (! app()->environment('production')) {
            return null;
        }
        // Exception messages / SQL bindings / traces can contain personal data
        // or provider credentials. Keep a correlation ID and type only.
        $id = app()->bound('request') ? request()->attributes->get('request_id') : null;
        Log::error('application_failure', ['error_type' => class_basename($error), 'request_id' => $id ?: (string) Str::uuid()]);

        return false;
    }
}
