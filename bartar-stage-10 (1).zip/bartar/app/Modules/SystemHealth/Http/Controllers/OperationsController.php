<?php

namespace App\Modules\SystemHealth\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\BackupRestore\Actions\BackupManager;
use App\Modules\BackupRestore\Models\BackupRun;
use App\Modules\SystemHealth\Actions\SystemHealth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class OperationsController extends Controller
{
    public function health(Request $request, SystemHealth $health)
    {
        return view('operations.health', ['title' => 'سلامت سامانه', 'active' => 'health', 'area' => 'admin', 'preview' => false, 'adminUser' => $request->user('admin'), 'health' => $health->inspect()]);
    }

    public function backups(Request $request)
    {
        return view('operations.backups', ['title' => 'بکاپ و بازیابی', 'active' => 'backups', 'area' => 'admin', 'preview' => false, 'adminUser' => $request->user('admin'), 'runs' => BackupRun::latest('id')->paginate(20), 'restores' => DB::table('backup_restore_runs')->latest('id')->limit(10)->get()]);
    }

    public function create(Request $request, ManageAdministrators $security, BackupManager $manager, RecordAudit $audit)
    {
        $data = $request->validate(['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']]);
        DB::transaction(function () use ($request, $security, $manager, $audit, $data): void {
            $security->lock();
            $actor = $request->user('admin')->fresh();
            abort_unless($actor->allows('manage_backups'), 403);
            $security->confirmPassword($actor, $data['current_password']);
            abort_if(BackupRun::whereIn('status', ['queued', 'running'])->exists(), 409, 'یک بکاپ در انتظار یا در حال اجرا است.');
            $run = $manager->enqueue($actor->id, $data['reason']);
            $audit->write($actor, 'backup.requested', 'backup', $run->public_id, [], [], $data['reason'], 'technical');
        });

        return back()->with('status', 'درخواست بکاپ ثبت شد؛ نتیجهٔ اجرای واقعی در همین صفحه نمایش داده می‌شود.');
    }
}
