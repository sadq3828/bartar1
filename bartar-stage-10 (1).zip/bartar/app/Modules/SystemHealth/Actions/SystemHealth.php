<?php

namespace App\Modules\SystemHealth\Actions;

use App\Modules\BackupRestore\Actions\BackupManager;
use App\Modules\BackupRestore\Models\BackupRun;
use App\Modules\BackupRestore\Support\EncryptedBackupFiles;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\SmsIntegration\Adapters\UnavailableNotificationSmsSender;
use App\Modules\SmsIntegration\Adapters\UnavailableOtpSender;
use App\Modules\SmsIntegration\Contracts\NotificationSmsSender;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

final class SystemHealth
{
    public function heartbeat(string $name): void
    {
        if (! in_array($name, ['scheduler', 'worker'], true)) {
            throw new \InvalidArgumentException('Invalid heartbeat');
        }
        DB::table('operation_heartbeats')->upsert([['name' => $name, 'seen_at' => now()]], ['name'], ['seen_at']);
    }

    private function beat(string $name): string
    {
        $at = DB::table('operation_heartbeats')->where('name', $name)->value('seen_at');
        if (! $at) {
            return 'unknown';
        }
        $time = CarbonImmutable::parse($at, 'UTC');

        return $time->gt(now()->addSeconds(5)) || $time->lt(now()->subSeconds(config('operations.heartbeat_max_age_seconds'))) ? 'stale' : 'healthy';
    }

    public function inspect(): array
    {
        $checks = [];
        $check = static function (string $name, callable $probe) use (&$checks): void {
            try {
                $checks[$name] = $probe();
            } catch (\Throwable) {
                $checks[$name] = 'failed';
            }
        };
        $check('database', function () {
            DB::select('SELECT 1');

            return 'healthy';
        });
        $check('private_storage', function () {
            $disk = Storage::disk('signal-media');
            $key = '.health/'.bin2hex(random_bytes(12));
            $value = random_bytes(32);
            try {
                if (! $disk->put($key, $value) || ! hash_equals($value, $disk->get($key))) {
                    return 'failed';
                }

                return 'healthy';
            } finally {
                $disk->delete($key);
            }
        });
        $check('scheduler', fn () => $this->beat('scheduler'));
        $check('queue_worker', fn () => config('queue.default') === 'database' ? $this->beat('worker') : 'not_configured');
        $check('failed_jobs', fn () => DB::table('failed_jobs')->exists() ? 'failed' : 'healthy');
        $check('otp_sms', fn () => app(OtpSender::class) instanceof UnavailableOtpSender ? 'not_configured' : 'unknown');
        $check('notification_sms', fn () => ! config('notifications.sms_enabled') || app(NotificationSmsSender::class) instanceof UnavailableNotificationSmsSender ? 'not_configured' : 'unknown');
        $check('notification_deliveries', fn () => DB::table('notification_deliveries')->whereIn('status', ['failed', 'pending'])->exists() ? 'degraded' : 'healthy');
        $check('market_prices', function () {
            $sources = PriceSource::where('enabled', true)->get();
            if ($sources->isEmpty()) {
                return 'not_configured';
            }
            foreach ($sources as $source) {
                if ($source->last_error_code) {
                    return 'failed';
                }
                if (! $source->last_success_at) {
                    return 'unknown';
                }
                if ($source->last_success_at->lt(now()->subSeconds($source->stale_after_seconds))) {
                    return 'stale';
                }
            }

            return 'healthy';
        });
        $check('backup', function () {
            if (! config('operations.backup.enabled') || ! app(EncryptedBackupFiles::class)->configured()) {
                return 'not_configured';
            }
            $last = BackupRun::latest('id')->first();
            if (! $last) {
                return 'unknown';
            }
            if ($last->status === 'failed') {
                return 'failed';
            }
            if (in_array($last->status, ['queued', 'running'], true) && $last->created_at->lt(now()->subSeconds(config('operations.backup.timeout')))) {
                return 'stale';
            }
            $completed = BackupRun::where('status', 'completed')->latest('completed_at')->first();
            if (! $completed) {
                return 'unknown';
            }
            $artifact = app(BackupManager::class)->artifact($completed);
            if (! is_file($artifact.'/manifest.enc') || ! is_file($artifact.'/database.enc')) {
                return 'failed';
            }

            return $completed->completed_at->lt(now()->subHours(config('operations.backup.max_age_hours'))) ? 'stale' : 'healthy';
        });
        $check('restore_drill', function () {
            $last = DB::table('backup_restore_runs')->latest('id')->first();
            if (! $last) {
                return 'unknown';
            }

            return $last->status === 'completed' ? (CarbonImmutable::parse($last->completed_at, 'UTC')->lt(now()->subDays(7)) ? 'stale' : 'healthy') : ($last->status === 'failed' ? 'failed' : 'unknown');
        });
        $check('disk_space', function () {
            $free = disk_free_space(storage_path());
            $total = disk_total_space(storage_path());

            return $free === false || ! $total ? 'unknown' : ($free < max(1073741824, $total * 0.1) ? 'degraded' : 'healthy');
        });

        return ['status' => count(array_filter($checks, fn ($s) => $s !== 'healthy')) ? 'attention' : 'healthy', 'checked_at' => now()->utc()->toIso8601String(), 'checks' => $checks];
    }
}
