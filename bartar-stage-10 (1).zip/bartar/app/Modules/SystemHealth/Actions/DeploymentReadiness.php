<?php

namespace App\Modules\SystemHealth\Actions;

use App\Http\Middleware\TrustConfiguredProxies;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\BackupRestore\Support\EncryptedBackupFiles;
use Illuminate\Encryption\Encrypter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class DeploymentReadiness
{
    public function inspect(bool $staging = false): array
    {
        $checks = [];
        $add = static function (string $name, callable $probe) use (&$checks): void {
            try {
                $checks[$name] = $probe() ? 'passed' : 'blocked';
            } catch (\Throwable) {
                $checks[$name] = 'blocked';
            }
        };
        $add('environment', fn () => app()->environment('production'));
        $add('debug_disabled', fn () => (config('security.configured_debug') ?? config('app.debug')) === false);
        $add('preview_disabled', fn () => config('bartar.preview_enabled') === false);
        $url = parse_url((string) config('app.url'));
        $host = $url['host'] ?? '';
        $isolated = in_array($host, ['localhost', '127.0.0.1', '::1'], true) || str_ends_with($host, '.test');
        $add('https_canonical_url', fn () => ($url['scheme'] ?? '') === 'https' && $host !== '' && ! isset($url['user']) && ! isset($url['pass']) && ! isset($url['query']) && ! isset($url['fragment']) && in_array($url['path'] ?? '', ['', '/'], true) && ($staging ? $isolated : ! $isolated));
        $add('application_key', function () {
            $key = (string) config('app.key');
            $decoded = str_starts_with($key, 'base64:') ? base64_decode(substr($key, 7), true) : $key;

            return is_string($decoded) && Encrypter::supported($decoded, config('app.cipher'));
        });
        $add('otp_key', fn () => strlen((string) config('membership.otp_key')) >= 32 && config('membership.otp_key') !== config('app.key'));
        $add('persistent_cache', fn () => in_array(config('cache.default'), ['database', 'file', 'redis'], true));
        $add('persistent_session', fn () => in_array(config('session.driver'), ['database', 'file', 'redis'], true));
        $add('session_security', fn () => config('session.encrypt') === true && config('session.http_only') === true && config('session.secure') === true && in_array(config('session.same_site'), ['lax', 'strict'], true));
        $add('database_queue', fn () => config('queue.default') === 'database' && config('queue.connections.database.retry_after') > 15);
        $add('proxy_allowlist', fn () => count(array_filter(config('security.trusted_proxies'), TrustConfiguredProxies::valid(...))) === count(config('security.trusted_proxies')));
        $add('private_env_permissions', function () {
            $path = base_path('.env');

            return is_file($path) && (fileperms($path) & 0077) === 0;
        });
        $add('private_local_media', function () {
            if (config('filesystems.disks.signal-media.driver') !== 'local' || config('filesystems.disks.signal-media.serve') !== false || config('media.disk') !== 'signal-media') {
                return false;
            }
            $root = realpath(config('filesystems.disks.signal-media.root'));
            $public = realpath(public_path());

            return $root && $public && $root !== $public && ! str_starts_with($root, $public.'/') && is_writable($root) && ! is_link(public_path('storage'));
        });
        $add('assets_integrity', function () {
            $path = public_path('assets/manifest.json');
            $manifest = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            foreach (['site.css', 'site.js', 'fonts/Vazirmatn-Regular.woff2', 'market-scene.svg', 'favicon.svg'] as $name) {
                $file = public_path('assets/'.$name);
                if (! is_file($file) || ! hash_equals($manifest[$name]['sha256'] ?? '', hash_file('sha256', $file))) {
                    return false;
                }
            }

            return true;
        });
        $add('mysql_connection', function () use ($staging) {
            $db = DB::connection();

            return $db->getDriverName() === 'mysql' && (! $staging || str_contains($db->getDatabaseName(), 'test')) && (int) $db->selectOne('SELECT 1 AS n')->n === 1;
        });
        $add('non_root_web_database_user', fn () => ! in_array(strtolower((string) config('database.connections.'.config('database.default').'.username')), ['', 'root'], true));
        $add('migrations_applied', function () {
            if (! Schema::hasTable('migrations')) {
                return false;
            }
            $done = DB::table('migrations')->pluck('migration')->all();
            foreach (glob(database_path('migrations/*.php')) as $file) {
                if (! in_array(basename($file, '.php'), $done, true)) {
                    return false;
                }
            }

            return true;
        });
        $serviceChecks = [
            'otp_sms' => OtpSecurity::ready() ? 'configured_unverified' : 'not_configured',
            'backup' => config('operations.backup.enabled') && app(EncryptedBackupFiles::class)->configured() ? 'configured_unverified' : 'not_configured',
        ];
        if (! $staging) {
            $add('otp_adapter_configured', fn () => OtpSecurity::ready());
            $add('backup_configured', fn () => config('operations.backup.enabled') && app(EncryptedBackupFiles::class)->configured());
            $health = app(SystemHealth::class)->inspect();
            foreach (['scheduler', 'queue_worker', 'backup', 'restore_drill'] as $name) {
                $add('operational_'.$name, fn () => ($health['checks'][$name] ?? '') === 'healthy');
            }
        }

        return ['status' => in_array('blocked', $checks, true) ? 'blocked' : ($staging ? 'staging_ready' : 'technical_checks_passed'), 'checks' => $checks, 'services' => $serviceChecks, 'manual_acceptance' => ['real_sms_delivery_and_zero_send', 'destination_network_and_price_provider', 'offsite_and_rpo_rto', 'public_dns_tls_renewal', 'capacity_and_release_approval']];
    }
}
