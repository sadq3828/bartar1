<?php

namespace App\Modules\Media\Contracts;

interface PrivateMediaStorage
{
    public function put(string $disk, string $key, mixed $stream): void;

    public function move(string $disk, string $from, string $to): void;

    public function exists(string $disk, string $key): bool;

    public function readStream(string $disk, string $key): mixed;

    public function delete(string $disk, string $key): void;
}
