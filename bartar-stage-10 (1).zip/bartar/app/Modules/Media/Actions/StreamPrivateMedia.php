<?php

namespace App\Modules\Media\Actions;

use App\Modules\Media\Contracts\PrivateMediaStorage;
use App\Modules\Media\Models\MediaFile;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class StreamPrivateMedia
{
    public function __construct(private PrivateMediaStorage $storage) {}

    public function response(MediaFile $media, Request $request): Response
    {
        abort_unless($media->state === 'ready' && $media->verified_at && $this->storage->exists($media->disk, $media->object_key), 404);
        $size = $media->bytes;
        $rangeHeader = $request->header('Range');
        $range = $rangeHeader === null ? null : $this->range($rangeHeader, $size);
        if ($rangeHeader !== null && $range === false) {
            return response('', 416, ['Content-Range' => 'bytes */'.$size, 'Accept-Ranges' => 'bytes', 'Cache-Control' => 'private, no-store']);
        }

        [$start, $end] = $range ?: [0, $size - 1];
        $length = $end - $start + 1;
        $status = $range ? 206 : 200;
        $headers = [
            'Content-Type' => $media->mime,
            'Content-Length' => (string) $length,
            'Accept-Ranges' => 'bytes',
            'Content-Disposition' => 'inline; filename="'.$media->kind.$this->extension($media->mime).'"',
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ];
        if ($range) {
            $headers['Content-Range'] = "bytes $start-$end/$size";
        }

        return response()->stream(function () use ($media, $start, $length): void {
            $stream = $this->storage->readStream($media->disk, $media->object_key);
            try {
                if ($start > 0 && fseek($stream, $start) !== 0) {
                    $remainingSkip = $start;
                    while ($remainingSkip > 0 && ! feof($stream)) {
                        $chunk = fread($stream, min((int) config('media.stream_chunk_bytes'), $remainingSkip));
                        if ($chunk === false || $chunk === '') {
                            break;
                        }
                        $remainingSkip -= strlen($chunk);
                    }
                }
                $remaining = $length;
                while ($remaining > 0 && ! feof($stream)) {
                    $chunk = fread($stream, min((int) config('media.stream_chunk_bytes'), $remaining));
                    if ($chunk === false || $chunk === '') {
                        break;
                    }
                    echo $chunk;
                    $remaining -= strlen($chunk);
                    if (connection_aborted()) {
                        break;
                    }
                }
            } finally {
                fclose($stream);
            }
        }, $status, $headers);
    }

    private function range(string $header, int $size): array|false
    {
        if (str_contains($header, ',') || ! preg_match('/\Abytes=(\d*)-(\d*)\z/', trim($header), $matches) || ($matches[1] === '' && $matches[2] === '')) {
            return false;
        }
        if ($matches[1] === '') {
            $suffix = (int) $matches[2];
            if ($suffix < 1) {
                return false;
            }

            return [max(0, $size - $suffix), $size - 1];
        }
        $start = (int) $matches[1];
        if ($start >= $size) {
            return false;
        }
        $end = $matches[2] === '' ? $size - 1 : min((int) $matches[2], $size - 1);

        return $end < $start ? false : [$start, $end];
    }

    private function extension(string $mime): string
    {
        return match ($mime) {
            'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp',
            'audio/mpeg' => '.mp3', 'audio/aac' => '.aac', 'audio/mp4' => '.m4a',
            'video/mp4' => '.mp4', default => '.bin',
        };
    }
}
