<?php

namespace App\Modules\Media\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Media\Contracts\PrivateMediaStorage;
use App\Modules\Media\Models\MediaFile;
use App\Modules\Media\Models\SignalMedia;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\Signals\Models\SignalRevision;
use App\Modules\Signals\Support\SignalSnapshot;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class ManageSignalMedia
{
    public function __construct(
        private ManageAdministrators $security,
        private RecordAudit $audit,
        private SignalSnapshot $snapshots,
        private PrivateMediaStorage $storage,
    ) {}

    public function upload(Account $actor, Signal $signal, UploadedFile $file, array $data): SignalMedia
    {
        $metadata = $this->inspect($file, $data['kind']);
        $disk = (string) config('media.disk');
        $uuid = strtolower((string) Str::uuid());
        $quarantineKey = 'quarantine/'.$uuid;
        $finalKey = 'objects/'.substr($uuid, 0, 2).'/'.$uuid;
        $stored = [];

        try {
            return DB::transaction(function () use ($actor, $signal, $file, $data, $metadata, $disk, $quarantineKey, $finalKey, &$stored): SignalMedia {
                $actor = $this->authorize($actor, 'media.upload', $data['current_password']);
                $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
                abort_if($signal->mediaAttachments()->count() >= 20, 409, 'حداکثر ۲۰ رسانه برای هر سیگنال مجاز است.');

                $stream = fopen($file->getRealPath(), 'rb');
                if (! is_resource($stream)) {
                    throw ValidationException::withMessages(['media' => 'خواندن فایل بارگذاری‌شده ممکن نیست.']);
                }
                try {
                    $this->storage->put($disk, $quarantineKey, $stream);
                    $stored[] = $quarantineKey;
                } finally {
                    fclose($stream);
                }

                $media = MediaFile::create([
                    'disk' => $disk,
                    'object_key' => $quarantineKey,
                    'kind' => $data['kind'],
                    'mime' => $metadata['mime'],
                    'bytes' => $metadata['bytes'],
                    'sha256' => $metadata['sha256'],
                    'original_name' => $this->safeName($file->getClientOriginalName()),
                    'state' => 'quarantined',
                    'uploaded_by' => $actor->id,
                ]);

                $this->preservePublished($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
                $this->storage->move($disk, $quarantineKey, $finalKey);
                $stored = [$finalKey];
                $media->update(['object_key' => $finalKey, 'state' => 'ready', 'verified_at' => now()]);
                $attachment = SignalMedia::create([
                    'signal_id' => $signal->id,
                    'media_file_id' => $media->id,
                    'kind' => $data['kind'],
                    'caption' => $data['caption'] ?? null,
                    'position' => ((int) $signal->mediaAttachments()->max('position')) + 1,
                ]);
                $this->announceIfRequested($signal, (bool) ($data['announce_change'] ?? false));
                $this->audit->write($actor, 'signal.media.uploaded', 'signal', $signal->public_id, [], ['media_id' => $media->public_id, 'kind' => $media->kind, 'mime' => $media->mime, 'bytes' => $media->bytes, 'sha256' => $media->sha256, 'position' => $attachment->position, 'signal_version' => $signal->version], $data['reason'], 'signals');

                return $attachment->load('mediaFile');
            }, 3);
        } catch (\Throwable $error) {
            foreach ($stored as $key) {
                $this->storage->delete($disk, $key);
            }
            throw $error;
        }
    }

    public function reorder(Account $actor, Signal $signal, array $orderedIds, array $data): void
    {
        DB::transaction(function () use ($actor, $signal, $orderedIds, $data): void {
            $actor = $this->authorize($actor, 'media.reorder', $data['current_password']);
            $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
            $attachments = SignalMedia::where('signal_id', $signal->id)->orderBy('position')->lockForUpdate()->get();
            $current = $attachments->pluck('public_id')->all();
            if (count($orderedIds) !== count($current) || array_diff($orderedIds, $current) || array_diff($current, $orderedIds)) {
                throw ValidationException::withMessages(['media_order' => 'ترتیب باید دقیقاً شامل همه رسانه‌های همین سیگنال باشد.']);
            }
            if ($orderedIds === $current) {
                return;
            }

            $this->preservePublished($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
            foreach ($attachments as $attachment) {
                $attachment->update(['position' => $attachment->position + 1000]);
            }
            foreach (array_values($orderedIds) as $index => $publicId) {
                $attachments->firstWhere('public_id', $publicId)->update(['position' => $index + 1]);
            }
            $this->announceIfRequested($signal, (bool) ($data['announce_change'] ?? false));
            $this->audit->write($actor, 'signal.media.reordered', 'signal', $signal->public_id, ['order' => $current], ['order' => array_values($orderedIds), 'signal_version' => $signal->version], $data['reason'], 'signals');
        }, 3);
    }

    public function remove(Account $actor, Signal $signal, SignalMedia $attachment, array $data): void
    {
        DB::transaction(function () use ($actor, $signal, $attachment, $data): void {
            $actor = $this->authorize($actor, 'media.delete', $data['current_password']);
            $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
            $attachment = SignalMedia::whereKey($attachment->id)->where('signal_id', $signal->id)->lockForUpdate()->firstOrFail();
            $media = MediaFile::whereKey($attachment->media_file_id)->lockForUpdate()->firstOrFail();
            $this->preservePublished($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
            $before = ['media_id' => $media->public_id, 'kind' => $attachment->kind, 'position' => $attachment->position, 'sha256' => $media->sha256];
            $attachment->delete();
            $media->update(['state' => 'deleted', 'deleted_at' => now()]);
            $this->normalizePositions($signal);
            $this->announceIfRequested($signal, (bool) ($data['announce_change'] ?? false));
            $this->audit->write($actor, 'signal.media.detached', 'signal', $signal->public_id, $before, ['state' => 'deleted', 'signal_version' => $signal->version], $data['reason'], 'signals');
        }, 3);
    }

    private function inspect(UploadedFile $file, string $kind): array
    {
        if (! $file->isValid()) {
            throw ValidationException::withMessages(['media' => 'بارگذاری فایل کامل نشده است.']);
        }
        $bytes = (int) $file->getSize();
        if ($bytes < 1 || $bytes > (int) config('media.max_upload_bytes')) {
            throw ValidationException::withMessages(['media' => 'اندازه فایل خارج از سقف تنظیم‌شده است.']);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file->getRealPath()) ?: 'application/octet-stream';
        if (! in_array($mime, config("media.allowed_mimes.$kind", []), true)) {
            throw ValidationException::withMessages(['media' => 'محتوای واقعی فایل با نوع مجاز انتخاب‌شده سازگار نیست.']);
        }

        return ['bytes' => $bytes, 'mime' => $mime, 'sha256' => hash_file('sha256', $file->getRealPath())];
    }

    private function authorize(Account $actor, string $permission, string $password): Account
    {
        $this->security->lock();
        $actor = $actor->fresh();
        abort_unless($actor->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);

        return $actor;
    }

    private function preservePublished(Signal $signal, Account $actor, string $reason, bool $announce): void
    {
        if (! $signal->published_at) {
            return;
        }
        SignalRevision::create(['signal_id' => $signal->id, 'version' => $signal->version, 'snapshot_json' => $this->snapshots->make($signal), 'reason' => $reason, 'actor_id' => $actor->id, 'changed_at' => now(), 'announce_change' => $announce]);
        $signal->increment('version');
        $signal->refresh();
    }

    private function announceIfRequested(Signal $signal, bool $announce): void
    {
        if ($signal->published_at && $announce) {
            SignalAnnouncement::firstOrCreate(['signal_id' => $signal->id, 'signal_version' => $signal->version, 'event_type' => 'changed'], ['safe_payload' => ['signal_id' => $signal->public_id, 'version' => $signal->version, 'event' => 'changed'], 'status' => 'pending', 'available_at' => now()]);
        }
    }

    private function normalizePositions(Signal $signal): void
    {
        foreach ($signal->mediaAttachments()->orderBy('position')->get() as $index => $attachment) {
            if ($attachment->position !== $index + 1) {
                $attachment->update(['position' => $index + 1]);
            }
        }
    }

    private function safeName(string $name): string
    {
        $name = preg_replace('/[\\x00-\\x1F\\x7F\\/\\\\]+/u', '-', trim($name)) ?: 'media';

        return mb_substr($name, 0, 255);
    }
}
