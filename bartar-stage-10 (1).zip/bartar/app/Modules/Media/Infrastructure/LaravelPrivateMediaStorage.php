<?php

namespace App\Modules\Media\Infrastructure;

use App\Modules\Media\Contracts\PrivateMediaStorage;
use Illuminate\Support\Facades\Storage;
use RuntimeException;

final class LaravelPrivateMediaStorage implements PrivateMediaStorage
{
    public function put(string $disk, string $key, mixed $stream): void
    {
        $this->assertKey($key);
        if (! Storage::disk($disk)->put($key, $stream)) {
            throw new RuntimeException('Private media could not be stored.');
        }
    }

    public function move(string $disk, string $from, string $to): void
    {
        $this->assertKey($from);
        $this->assertKey($to);
        if (! Storage::disk($disk)->move($from, $to)) {
            throw new RuntimeException('Private media could not leave quarantine.');
        }
    }

    public function exists(string $disk, string $key): bool
    {
        $this->assertKey($key);

        return Storage::disk($disk)->exists($key);
    }

    public function readStream(string $disk, string $key): mixed
    {
        $this->assertKey($key);
        $stream = Storage::disk($disk)->readStream($key);
        if (! is_resource($stream)) {
            throw new RuntimeException('Private media stream is unavailable.');
        }

        return $stream;
    }

    public function delete(string $disk, string $key): void
    {
        $this->assertKey($key);
        Storage::disk($disk)->delete($key);
    }

    private function assertKey(string $key): void
    {
        if (! preg_match('#\A(?:quarantine|objects/[0-9a-f]{2})/[0-9a-f-]{36}\z#', $key)) {
            throw new RuntimeException('Invalid private media key.');
        }
    }
}
