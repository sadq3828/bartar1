<?php

namespace App\Modules\Media\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class MediaFile extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    protected $guarded = ['id'];

    protected $hidden = ['disk', 'object_key', 'original_name'];

    protected function casts(): array
    {
        return ['bytes' => 'integer', 'verified_at' => 'immutable_datetime', 'deleted_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $media): void {
            $media->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function attachment()
    {
        return $this->hasOne(SignalMedia::class);
    }
}
