<?php

namespace App\Modules\Media\Models;

use App\Modules\Signals\Models\Signal;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class SignalMedia extends Model
{
    protected $table = 'signal_media';

    protected $dateFormat = 'Y-m-d H:i:s.u';

    protected $guarded = ['id'];

    protected static function booted(): void
    {
        static::creating(function (self $attachment): void {
            $attachment->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function signal()
    {
        return $this->belongsTo(Signal::class);
    }

    public function mediaFile()
    {
        return $this->belongsTo(MediaFile::class);
    }
}
