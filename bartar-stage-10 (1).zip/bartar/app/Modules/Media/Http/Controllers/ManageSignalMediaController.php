<?php

namespace App\Modules\Media\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Media\Actions\ManageSignalMedia;
use App\Modules\Media\Models\SignalMedia;
use App\Modules\Signals\Models\Signal;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

final class ManageSignalMediaController extends Controller
{
    public function store(Request $request, Signal $signal, ManageSignalMedia $manager)
    {
        $maxKilobytes = (int) ceil(((int) config('media.max_upload_bytes')) / 1024);
        $data = $request->validate([
            'media' => ['required', 'file', 'max:'.$maxKilobytes],
            'kind' => ['required', Rule::in(array_keys(config('media.allowed_mimes')))],
            'caption' => ['nullable', 'string', 'max:500'],
            'announce_change' => ['nullable', 'boolean'],
        ] + $this->sensitive());
        $manager->upload($request->user('admin'), $signal, $request->file('media'), $data);

        return back()->with('status', 'رسانه پس از بررسی محتوای واقعی در فضای خصوصی ذخیره شد.');
    }

    public function reorder(Request $request, Signal $signal, ManageSignalMedia $manager)
    {
        $data = $request->validate([
            'media_order' => ['required', 'array', 'min:1', 'max:20'],
            'media_order.*' => ['required', 'integer', 'min:1', 'max:20', 'distinct'],
            'announce_change' => ['nullable', 'boolean'],
        ] + $this->sensitive());
        $order = collect($data['media_order'])->sort()->keys()->values()->all();
        $manager->reorder($request->user('admin'), $signal, $order, $data);

        return back()->with('status', 'ترتیب رسانه‌ها ذخیره شد.');
    }

    public function destroy(Request $request, Signal $signal, SignalMedia $media, ManageSignalMedia $manager)
    {
        $data = $request->validate(['announce_change' => ['nullable', 'boolean']] + $this->sensitive());
        $manager->remove($request->user('admin'), $signal, $media, $data);

        return back()->with('status', 'اتصال رسانه به‌صورت منطقی حذف شد؛ فایل تا سیاست retention نگهداری می‌شود.');
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }
}
