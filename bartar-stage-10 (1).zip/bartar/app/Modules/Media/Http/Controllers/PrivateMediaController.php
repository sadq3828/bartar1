<?php

namespace App\Modules\Media\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Media\Actions\StreamPrivateMedia;
use App\Modules\Media\Models\MediaFile;
use App\Modules\Media\Models\SignalMedia;
use App\Modules\Signals\Models\Signal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

final class PrivateMediaController extends Controller
{
    public function member(Request $request, MediaFile $media, StreamPrivateMedia $stream)
    {
        $attachment = SignalMedia::where('media_file_id', $media->id)->with('signal')->firstOrFail();
        abort_unless(Signal::memberVisible()->whereKey($attachment->signal_id)->exists(), 404);
        Gate::forUser($request->user('member'))->authorize('view', $attachment->signal);

        return $stream->response($media, $request);
    }

    public function admin(Request $request, MediaFile $media, StreamPrivateMedia $stream)
    {
        $attachment = SignalMedia::where('media_file_id', $media->id)->with('signal')->firstOrFail();
        Gate::forUser($request->user('admin'))->authorize('view', $attachment->signal);

        return $stream->response($media, $request);
    }
}
