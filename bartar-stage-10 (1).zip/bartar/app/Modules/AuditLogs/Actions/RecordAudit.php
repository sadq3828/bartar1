<?php

namespace App\Modules\AuditLogs\Actions;

use App\Modules\AuditLogs\Models\AuditLog;
use App\Modules\Authentication\Models\Account;
use Illuminate\Support\Str;

final class RecordAudit
{
    public function write(?Account $actor, string $action, string $entityType, ?string $entityId, array $before = [], array $after = [], ?string $reason = null, string $scope = 'security', string $actorKind = 'admin'): AuditLog
    {
        return AuditLog::create([
            'public_id' => (string) Str::ulid(), 'actor_id' => $actor?->id, 'actor_kind' => $actorKind,
            'action' => $action, 'scope' => $scope, 'entity_type' => $entityType, 'entity_id' => $entityId,
            'before_data' => $this->redact($before), 'after_data' => $this->redact($after),
            'reason' => $reason, 'happened_at' => now(),
        ]);
    }

    private function redact(array $data): array
    {
        $safe = [];
        foreach ($data as $key => $value) {
            if (preg_match('/password|secret|token|otp|credential|cookie|api.?key/i', (string) $key)) {
                continue;
            }
            $safe[$key] = is_array($value) ? $this->redact($value) : $value;
        }

        return $safe;
    }
}
