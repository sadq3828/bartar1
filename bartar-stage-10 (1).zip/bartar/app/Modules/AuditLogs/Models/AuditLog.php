<?php

namespace App\Modules\AuditLogs\Models;

use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['before_data' => 'array', 'after_data' => 'array', 'happened_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Audit records are append only.'));
        static::deleting(fn () => throw new \LogicException('Audit records are append only.'));
    }
}
