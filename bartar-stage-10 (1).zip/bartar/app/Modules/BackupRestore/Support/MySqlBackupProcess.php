<?php

namespace App\Modules\BackupRestore\Support;

use Symfony\Component\Process\Process;

final class MySqlBackupProcess
{
    public function run(string $mode, array $config, string $work, string $sql): void
    {
        $defaults = $work.'/client-'.bin2hex(random_bytes(6)).'.cnf';
        $quote = static fn ($value) => '"'.str_replace(['\\', '"', "\n", "\r"], ['\\\\', '\\"', '\\n', '\\r'], (string) $value).'"';
        $values = ['user' => $config['username'], 'password' => $config['password'], 'host' => $config['host'], 'port' => $config['port']];
        if ($config['unix_socket'] ?? null) {
            $values['socket'] = $config['unix_socket'];
        }
        foreach (['ssl-ca' => \PDO::MYSQL_ATTR_SSL_CA, 'ssl-cert' => \PDO::MYSQL_ATTR_SSL_CERT, 'ssl-key' => \PDO::MYSQL_ATTR_SSL_KEY] as $name => $option) {
            if (isset($config['options'][$option])) {
                $values[$name] = $config['options'][$option];
            }
        }
        $body = "[client]\n";
        foreach ($values as $name => $value) {
            $body .= $name.'='.$quote($value)."\n";
        }
        $old = umask(0077);
        try {
            if (file_put_contents($defaults, $body) === false) {
                throw new BackupFailure('private_work_unavailable');
            }
        } finally {
            umask($old);
        }
        $input = null;
        try {
            $arguments = [config('operations.backup.'.$mode), '--defaults-extra-file='.$defaults, '--default-character-set=utf8mb4'];
            if ($mode === 'mysqldump') {
                array_push($arguments, '--single-transaction', '--skip-lock-tables', '--no-tablespaces', '--set-gtid-purged=OFF', '--hex-blob', '--triggers', '--routines', '--events', '--result-file='.$sql, $config['database']);
            } else {
                array_push($arguments, '--binary-mode=1', $config['database']);
                $input = fopen($sql, 'rb');
            }
            $process = new Process($arguments, null, ['MYSQL_PWD' => false, 'MYSQL_TEST_LOGIN_FILE' => $work.'/no-login-file']);
            $process->setTimeout(max(30, (int) config('operations.backup.timeout')));
            $process->disableOutput();
            if ($input) {
                $process->setInput($input);
            }
            if ($process->run() !== 0) {
                throw new BackupFailure($mode === 'mysqldump' ? 'database_dump_failed' : 'database_restore_failed');
            }
        } finally {
            if ($input) {
                fclose($input);
            } if (is_file($defaults)) {
                unlink($defaults);
            }
        }
    }
}
