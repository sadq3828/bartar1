<?php

namespace App\Modules\BackupRestore\Support;

final class EncryptedBackupFiles
{
    private const CHUNK = 1048576;

    private const MAGIC = "BARTAR-BACKUP-1\n";

    private function key(): string
    {
        $key = base64_decode((string) config('operations.backup.key'), true);
        if (! function_exists('sodium_crypto_secretstream_xchacha20poly1305_init_push') || $key === false || strlen($key) !== 32) {
            throw new BackupFailure('backup_key_unconfigured');
        }

        return $key;
    }

    public function configured(): bool
    {
        try {
            $this->key();

            return true;
        } catch (BackupFailure) {
            return false;
        }
    }

    private function write($handle, string $bytes): void
    {
        while ($bytes !== '') {
            $n = fwrite($handle, $bytes);
            if ($n === false || $n === 0) {
                throw new BackupFailure('destination_write_failed');
            }
            $bytes = substr($bytes, $n);
        }
    }

    private function read($handle, int $length): string
    {
        $data = '';
        while (strlen($data) < $length && ! feof($handle)) {
            $part = fread($handle, $length - strlen($data));
            if ($part === false) {
                throw new BackupFailure('backup_read_failed');
            }
            $data .= $part;
        }
        if (strlen($data) !== $length) {
            throw new BackupFailure('backup_truncated');
        }

        return $data;
    }

    public function encrypt(string $source, string $destination): array
    {
        [$state, $header] = sodium_crypto_secretstream_xchacha20poly1305_init_push($this->key());
        $in = fopen($source, 'rb');
        $out = fopen($destination, 'xb');
        if (! $in || ! $out) {
            throw new BackupFailure('backup_file_unavailable');
        }
        chmod($destination, 0600);
        $hash = hash_init('sha256');
        $bytes = 0;
        try {
            $this->write($out, self::MAGIC.$header);
            while (! feof($in)) {
                $chunk = fread($in, self::CHUNK);
                if ($chunk === false) {
                    throw new BackupFailure('backup_read_failed');
                }
                if ($chunk === '') {
                    break;
                }
                hash_update($hash, $chunk);
                $bytes += strlen($chunk);
                $cipher = sodium_crypto_secretstream_xchacha20poly1305_push($state, $chunk);
                $this->write($out, pack('N', strlen($cipher)).$cipher);
            }
            $final = sodium_crypto_secretstream_xchacha20poly1305_push($state, '', '', SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL);
            $this->write($out, pack('N', strlen($final)).$final);
            if (! fflush($out)) {
                throw new BackupFailure('destination_write_failed');
            }
        } finally {
            fclose($in);
            fclose($out);
        }

        return ['sha256' => hash_final($hash), 'bytes' => $bytes];
    }

    // A null destination authenticates every frame without retaining plaintext.
    public function decrypt(string $source, ?string $destination = null): array
    {
        $key = $this->key();
        $in = fopen($source, 'rb');
        $out = $destination === null ? null : fopen($destination, 'xb');
        if (! $in || ($destination !== null && ! $out)) {
            throw new BackupFailure('backup_file_unavailable');
        }
        if ($out) {
            chmod($destination, 0600);
        }
        $hash = hash_init('sha256');
        $bytes = 0;
        $final = false;
        try {
            if ($this->read($in, strlen(self::MAGIC)) !== self::MAGIC) {
                throw new BackupFailure('backup_format_invalid');
            }
            $state = sodium_crypto_secretstream_xchacha20poly1305_init_pull($this->read($in, SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES), $key);
            while (! $final) {
                $length = unpack('Nlength', $this->read($in, 4))['length'];
                if ($length < 17 || $length > self::CHUNK + 17) {
                    throw new BackupFailure('backup_format_invalid');
                }
                $result = sodium_crypto_secretstream_xchacha20poly1305_pull($state, $this->read($in, $length));
                if ($result === false) {
                    throw new BackupFailure('backup_authentication_failed');
                }
                [$plain, $tag] = $result;
                hash_update($hash, $plain);
                $bytes += strlen($plain);
                if ($out) {
                    $this->write($out, $plain);
                }
                $final = $tag === SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL;
            }
            if (fread($in, 1) !== '') {
                throw new BackupFailure('backup_trailing_data');
            }
            if ($out && ! fflush($out)) {
                throw new BackupFailure('destination_write_failed');
            }
        } finally {
            fclose($in);
            if ($out) {
                fclose($out);
            }
        }

        return ['sha256' => hash_final($hash), 'bytes' => $bytes];
    }
}
