<?php

namespace App\Modules\BackupRestore\Support;

final class BackupFailure extends \RuntimeException
{
    public function __construct(public readonly string $safeCode)
    {
        parent::__construct($safeCode);
    }
}
