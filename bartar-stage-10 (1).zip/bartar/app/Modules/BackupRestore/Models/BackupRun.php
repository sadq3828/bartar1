<?php

namespace App\Modules\BackupRestore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class BackupRun extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected static function booted(): void
    {
        static::creating(fn (self $run) => $run->public_id ??= (string) Str::ulid());
    }

    protected function casts(): array
    {
        return ['started_at' => 'immutable_datetime', 'completed_at' => 'immutable_datetime', 'restore_verified_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }
}
