<?php

namespace App\Modules\BackupRestore\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\BackupRestore\Models\BackupRun;
use App\Modules\BackupRestore\Support\BackupFailure;
use App\Modules\BackupRestore\Support\EncryptedBackupFiles;
use App\Modules\BackupRestore\Support\MySqlBackupProcess;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

final class BackupManager
{
    public function __construct(private EncryptedBackupFiles $crypto, private MySqlBackupProcess $mysql, private RecordAudit $audit) {}

    public function privateDirectory(string $path): string
    {
        if (! str_starts_with($path, '/') || str_contains($path, '/../') || is_link($path)) {
            throw new BackupFailure('private_path_invalid');
        }
        if (! is_dir($path) && ! mkdir($path, 0700, true)) {
            throw new BackupFailure('private_work_unavailable');
        }
        $real = realpath($path);
        $public = realpath(public_path());
        if (! $real || $real === '/' || ($public && ($real === $public || str_starts_with($real, $public.'/')))) {
            throw new BackupFailure('private_path_invalid');
        }
        chmod($real, 0700);

        return $real;
    }

    private function root(): string
    {
        return $this->privateDirectory((string) config('operations.backup.root'));
    }

    public function artifact(BackupRun $run): string
    {
        if (! preg_match('/\A[0-9A-HJKMNP-TV-Z]{26}\z/', $run->public_id)) {
            throw new BackupFailure('backup_identifier_invalid');
        }

        return $this->root().'/'.$run->public_id;
    }

    private function work(): string
    {
        return $this->privateDirectory(storage_path('app/backup-work/'.bin2hex(random_bytes(12))));
    }

    public function enqueue(?int $actor, string $reason): BackupRun
    {
        return BackupRun::create(['requested_by' => $actor, 'reason' => $reason, 'status' => 'queued']);
    }

    public function execute(BackupRun $run): BackupRun
    {
        // MySQL named lock protects HTTP, cron and independent CLI processes.
        if ((int) DB::selectOne("SELECT GET_LOCK('bartar:backup', 0) AS acquired")->acquired !== 1) {
            throw new BackupFailure('backup_already_running');
        }
        $work = null;
        $partial = null;
        $lock = null;
        try {
            if ($run->fresh()->status !== 'queued') {
                return $run->fresh();
            }
            $run->update(['status' => 'running', 'started_at' => now()]);
            if (! config('operations.backup.enabled') || ! $this->crypto->configured()) {
                throw new BackupFailure('backup_unconfigured');
            }
            $work = $this->work();
            $partial = $this->artifact($run).'.partial';
            if (file_exists($partial) || file_exists($this->artifact($run))) {
                throw new BackupFailure('backup_destination_exists');
            }
            $this->privateDirectory($partial);
            $config = config('database.connections.'.config('database.default'));
            if (($config['driver'] ?? null) !== 'mysql' || ($config['url'] ?? null)) {
                throw new BackupFailure('database_config_unsupported');
            }
            // Database-scoped READ locks give dump, row counts and inventory the
            // same point in time. No global server lock or password in argv.
            config(['database.connections.backup_lock' => $config]);
            $lock = DB::connection('backup_lock');
            $tables = DB::select("SELECT TABLE_NAME AS name, ENGINE AS engine FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME");
            if (! $tables) {
                throw new BackupFailure('database_empty');
            }
            foreach ($tables as $table) {
                if ($table->engine !== 'InnoDB' || ! preg_match('/\A[a-zA-Z0-9_]+\z/', $table->name)) {
                    throw new BackupFailure('database_schema_unsupported');
                }
            }
            $lock->unprepared('LOCK TABLES '.implode(', ', array_map(fn ($t) => '`'.$t->name.'` READ', $tables)));
            try {
                $counts = [];
                foreach ($tables as $table) {
                    $counts[$table->name] = (int) $lock->table($table->name)->count();
                }
                $media = $lock->table('media_files')->orderBy('id')->get(['disk', 'object_key', 'bytes', 'sha256'])->map(fn ($row) => (array) $row)->all();
                $triggers = DB::table('information_schema.TRIGGERS')->where('TRIGGER_SCHEMA', DB::connection()->getDatabaseName())->count();
                $this->mysql->run('mysqldump', $config, $work, $work.'/database.sql');
            } finally {
                $lock->unprepared('UNLOCK TABLES');
                DB::purge('backup_lock');
                $lock = null;
            }
            $database = $this->crypto->encrypt($work.'/database.sql', $partial.'/database.enc');
            unlink($work.'/database.sql');
            $files = [];
            foreach ($media as $index => $item) {
                $this->validObject($item);
                $source = Storage::disk($item['disk'])->path($item['object_key']);
                if (! is_file($source) || is_link($source)) {
                    throw new BackupFailure('media_missing');
                }
                $file = 'media-'.$index.'.enc';
                $digest = $this->crypto->encrypt($source, $partial.'/'.$file);
                if ($digest['bytes'] !== (int) $item['bytes'] || ! hash_equals($item['sha256'], $digest['sha256'])) {
                    throw new BackupFailure('media_checksum_mismatch');
                }
                $files[] = $item + ['file' => $file];
            }
            $manifest = ['format' => 1, 'backup_id' => $run->public_id, 'created_at' => now()->utc()->toIso8601String(), 'database' => $database, 'table_counts' => $counts, 'triggers' => $triggers, 'media' => $files];
            file_put_contents($work.'/manifest.json', json_encode($manifest, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
            chmod($work.'/manifest.json', 0600);
            $this->crypto->encrypt($work.'/manifest.json', $partial.'/manifest.enc');
            $this->verify($partial, $run->public_id, $work.'/verified-manifest.json');
            if (! rename($partial, $this->artifact($run))) {
                throw new BackupFailure('destination_write_failed');
            }
            $partial = null;
            $bytes = array_sum(array_map(fn ($f) => $f->getSize(), File::files($this->artifact($run))));
            $run->update(['status' => 'completed', 'bytes' => $bytes, 'completed_at' => now(), 'error_code' => null]);
            $this->audit->write(null, 'backup.completed', 'backup', $run->public_id, [], ['bytes' => $bytes], 'بکاپ رمزنگاری‌شده و بررسی تمامیت', 'technical', 'system');
        } catch (\Throwable $e) {
            $run->update(['status' => 'failed', 'error_code' => $e instanceof BackupFailure ? $e->safeCode : 'backup_failed', 'completed_at' => now()]);
            $this->audit->write(null, 'backup.failed', 'backup', $run->public_id, [], ['error_code' => $run->error_code], 'شکست امن بکاپ؛ جزئیات محرمانه ثبت نشد', 'technical', 'system');
        } finally {
            if ($lock) {
                try {
                    $lock->unprepared('UNLOCK TABLES');
                } finally {
                    DB::purge('backup_lock');
                }
            }
            if ($work) {
                File::deleteDirectory($work);
            }
            if ($partial) {
                File::deleteDirectory($partial);
            }
            DB::select("SELECT RELEASE_LOCK('bartar:backup')");
        }

        return $run->fresh();
    }

    private function validObject(array $item): void
    {
        $key = (string) ($item['object_key'] ?? '');
        if (($item['disk'] ?? '') !== 'signal-media' || ! preg_match('~\A[a-zA-Z0-9][a-zA-Z0-9_./-]*\z~', $key) || str_contains($key, '..') || str_starts_with($key, '/') || config('filesystems.disks.signal-media.driver') !== 'local') {
            throw new BackupFailure('media_path_unsupported');
        }
        $root = realpath(config('filesystems.disks.signal-media.root'));
        $path = realpath(Storage::disk('signal-media')->path($key));
        if (! $root || ! $path || ! str_starts_with($path, $root.'/')) {
            throw new BackupFailure('media_missing');
        }
    }

    public function verify(string $directory, string $id, string $manifestPath): array
    {
        $this->crypto->decrypt($directory.'/manifest.enc', $manifestPath);
        $manifest = json_decode(file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);
        if (($manifest['format'] ?? null) !== 1 || ($manifest['backup_id'] ?? null) !== $id) {
            throw new BackupFailure('backup_format_invalid');
        }
        $digest = $this->crypto->decrypt($directory.'/database.enc');
        if ($digest !== $manifest['database']) {
            throw new BackupFailure('database_checksum_mismatch');
        }
        foreach ($manifest['media'] as $item) {
            if (! preg_match('/\Amedia-\d+\.enc\z/', $item['file'])) {
                throw new BackupFailure('backup_format_invalid');
            }
            $digest = $this->crypto->decrypt($directory.'/'.$item['file']);
            if ($digest['bytes'] !== (int) $item['bytes'] || ! hash_equals($item['sha256'], $digest['sha256'])) {
                throw new BackupFailure('media_checksum_mismatch');
            }
        }

        return $manifest;
    }

    public function drill(BackupRun $run, string $confirmation): array
    {
        $target = config('database.connections.backup_restore');
        $name = $target['database'] ?? '';
        if (! config('operations.backup.restore_enabled') || ! preg_match('/\Abartar_restore_[a-zA-Z0-9_]+\z/', $name) || ! hash_equals($name, $confirmation) || $name === DB::connection()->getDatabaseName() || ($target['url'] ?? null) || $run->status !== 'completed') {
            throw new BackupFailure('isolated_restore_required');
        }
        if ((int) DB::selectOne("SELECT GET_LOCK('bartar:backup', 0) AS acquired")->acquired !== 1) {
            throw new BackupFailure('backup_already_running');
        }
        $work = null;
        $record = null;
        try {
            $connection = DB::connection('backup_restore');
            $existing = $connection->select('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()');
            if ($existing) {
                throw new BackupFailure('restore_target_not_empty');
            }
            $record = DB::table('backup_restore_runs')->insertGetId(['backup_run_id' => $run->id, 'status' => 'running', 'started_at' => now()]);
            $work = $this->work();
            $directory = $this->artifact($run);
            $manifest = $this->verify($directory, $run->public_id, $work.'/manifest.json');
            $mediaRoot = $this->privateDirectory((string) config('operations.backup.restore_media_root'));
            $activeRoot = realpath(config('filesystems.disks.signal-media.root'));
            if ($activeRoot && ($mediaRoot === $activeRoot || str_starts_with($mediaRoot, $activeRoot.'/') || str_starts_with($activeRoot, $mediaRoot.'/'))) {
                throw new BackupFailure('isolated_restore_required');
            }
            $destination = $mediaRoot.'/'.$run->public_id.'-'.bin2hex(random_bytes(6));
            $this->privateDirectory($destination);
            $this->crypto->decrypt($directory.'/database.enc', $work.'/database.sql');
            $this->mysql->run('mysql', $target, $work, $work.'/database.sql');
            $tableNames = $connection->table('information_schema.TABLES')->where('TABLE_SCHEMA', $name)->where('TABLE_TYPE', 'BASE TABLE')->pluck('TABLE_NAME')->all();
            $expected = array_keys($manifest['table_counts']);
            sort($expected);
            sort($tableNames);
            if ($expected !== $tableNames) {
                throw new BackupFailure('restore_schema_mismatch');
            }
            foreach ($manifest['table_counts'] as $table => $count) {
                if (! preg_match('/\A[a-zA-Z0-9_]+\z/', $table) || $connection->table($table)->count() !== $count) {
                    throw new BackupFailure('restore_count_mismatch');
                }
            }
            if ($connection->table('information_schema.TRIGGERS')->where('TRIGGER_SCHEMA', $name)->count() !== $manifest['triggers']) {
                throw new BackupFailure('restore_trigger_mismatch');
            }
            $this->verifyForeignKeys($connection, $name);
            foreach ($manifest['media'] as $item) {
                // Manifest is authenticated, but paths are still bounded.
                $key = $item['object_key'];
                if (! preg_match('~\A[a-zA-Z0-9][a-zA-Z0-9_./-]*\z~', $key) || str_contains($key, '..') || str_starts_with($key, '/')) {
                    throw new BackupFailure('media_path_unsupported');
                }
                $path = $destination.'/'.$key;
                $this->privateDirectory(dirname($path));
                $digest = $this->crypto->decrypt($directory.'/'.$item['file'], $path);
                if ($digest['bytes'] !== (int) $item['bytes'] || ! hash_equals($item['sha256'], $digest['sha256'])) {
                    throw new BackupFailure('media_checksum_mismatch');
                }
            }
            $verification = ['tables' => count($expected), 'rows' => array_sum($manifest['table_counts']), 'media_files' => count($manifest['media']), 'triggers' => $manifest['triggers'], 'foreign_keys' => 'verified'];
            DB::table('backup_restore_runs')->where('id', $record)->update(['status' => 'completed', 'verification' => json_encode($verification, JSON_THROW_ON_ERROR), 'completed_at' => now()]);
            $run->update(['restore_verified_at' => now()]);
            $this->audit->write(null, 'backup.restore_drill.completed', 'backup', $run->public_id, [], $verification, 'بازیابی آزمایشی در مقصد ایزوله', 'technical', 'system');

            return $verification;
        } catch (\Throwable $e) {
            $code = $e instanceof BackupFailure ? $e->safeCode : 'restore_failed';
            if ($record) {
                DB::table('backup_restore_runs')->where('id', $record)->update(['status' => 'failed', 'error_code' => $code, 'completed_at' => now()]);
            }
            $this->audit->write(null, 'backup.restore_drill.failed', 'backup', $run->public_id, [], ['error_code' => $code], 'بازیابی ناموفق؛ مقصد ایزوله برای بررسی حفظ شد', 'technical', 'system');
            throw new BackupFailure($code);
        } finally {
            if ($work) {
                File::deleteDirectory($work);
            }
            DB::purge('backup_restore');
            DB::select("SELECT RELEASE_LOCK('bartar:backup')");
        }
    }

    private function verifyForeignKeys($connection, string $name): void
    {
        $keys = $connection->table('information_schema.KEY_COLUMN_USAGE')->where('TABLE_SCHEMA', $name)->whereNotNull('REFERENCED_TABLE_NAME')->orderBy('ORDINAL_POSITION')->get()->groupBy(fn ($r) => $r->TABLE_NAME.':'.$r->CONSTRAINT_NAME);
        foreach ($keys as $columns) {
            $first = $columns->first();
            $join = $columns->map(fn ($r) => 'c.`'.$r->COLUMN_NAME.'` = p.`'.$r->REFERENCED_COLUMN_NAME.'`')->implode(' AND ');
            $nonnull = $columns->map(fn ($r) => 'c.`'.$r->COLUMN_NAME.'` IS NOT NULL')->implode(' AND ');
            $sql = 'SELECT COUNT(*) AS n FROM `'.$first->TABLE_NAME.'` c LEFT JOIN `'.$first->REFERENCED_TABLE_NAME.'` p ON '.$join.' WHERE '.$nonnull.' AND p.`'.$first->REFERENCED_COLUMN_NAME.'` IS NULL';
            if ((int) $connection->selectOne($sql)->n !== 0) {
                throw new BackupFailure('restore_foreign_key_mismatch');
            }
        }
    }

    public function retain(): int
    {
        if ((int) DB::selectOne("SELECT GET_LOCK('bartar:backup', 0) AS acquired")->acquired !== 1) {
            throw new BackupFailure('backup_already_running');
        }
        $work = null;
        try {
            $keep = max(2, (int) config('operations.backup.keep'));
            $runs = BackupRun::where('status', 'completed')->latest('id')->get();
            $protected = $runs->take($keep)->pluck('id')->all();
            $lastVerified = $runs->whereNotNull('restore_verified_at')->sortByDesc('restore_verified_at')->first();
            if ($lastVerified) {
                $protected[] = $lastVerified->id;
            }
            // A corrupted newest copy must never justify deleting older ones.
            if ($runs->count() > $keep) {
                $work = $this->work();
                foreach ($runs->whereIn('id', $protected) as $candidate) {
                    $this->verify($this->artifact($candidate), $candidate->public_id, $work.'/'.$candidate->public_id.'.json');
                }
            }
            $removed = 0;
            foreach ($runs as $run) {
                if (in_array($run->id, $protected, true)) {
                    continue;
                }
                if (! File::deleteDirectory($this->artifact($run))) {
                    throw new BackupFailure('retention_delete_failed');
                }
                $run->update(['status' => 'deleted']);
                $removed++;
                $this->audit->write(null, 'backup.retention.deleted', 'backup', $run->public_id, [], [], 'سیاست نگه‌داری؛ آخرین نسخه‌های سالم و restoreشده حفظ شدند', 'technical', 'system');
            }

            return $removed;
        } finally {
            if ($work) {
                File::deleteDirectory($work);
            }
            DB::select("SELECT RELEASE_LOCK('bartar:backup')");
        }
    }
}
