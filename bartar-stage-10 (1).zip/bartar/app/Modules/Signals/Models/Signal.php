<?php

namespace App\Modules\Signals\Models;

use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Media\Models\SignalMedia;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Signal extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'scheduled_at' => 'immutable_datetime', 'published_at' => 'immutable_datetime',
            'expires_at' => 'immutable_datetime', 'version' => 'integer',
            'entry_low' => 'decimal:12', 'entry_high' => 'decimal:12', 'stop_loss' => 'decimal:12',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (self $signal): void {
            $signal->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function market()
    {
        return $this->belongsTo(Market::class);
    }

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }

    public function targets()
    {
        return $this->hasMany(SignalTarget::class)->orderBy('position');
    }

    public function revisions()
    {
        return $this->hasMany(SignalRevision::class)->latest('version');
    }

    public function statusEvents()
    {
        return $this->hasMany(SignalStatusEvent::class)->latest('happened_at');
    }

    public function results()
    {
        return $this->hasMany(SignalResult::class)->latest('version');
    }

    public function mediaAttachments()
    {
        return $this->hasMany(SignalMedia::class)->orderBy('position');
    }

    public function scopeMemberVisible($query)
    {
        return $query->whereNotNull('published_at')->where('published_at', '<=', now()->format('Y-m-d H:i:s.u'))->whereIn('status', ['published', 'completed', 'cancelled', 'expired']);
    }
}
