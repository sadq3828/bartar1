<?php

namespace App\Modules\Signals\Models;

use Illuminate\Database\Eloquent\Model;

class SignalResult extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['request_hash'];

    protected function casts(): array
    {
        return ['entry_execution_price' => 'decimal:12', 'gross_return' => 'decimal:8', 'fee_input' => 'decimal:8', 'coverage_ratio' => 'decimal:6', 'computed_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    public function exits()
    {
        return $this->hasMany(SignalExit::class)->orderBy('position');
    }

    public function calculations()
    {
        return $this->hasMany(\App\Modules\Reports\Models\SignalResultCalculation::class);
    }
}
