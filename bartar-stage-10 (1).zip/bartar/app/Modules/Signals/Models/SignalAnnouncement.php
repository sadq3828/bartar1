<?php

namespace App\Modules\Signals\Models;

use Illuminate\Database\Eloquent\Model;

class SignalAnnouncement extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['safe_payload' => 'array', 'available_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }
}
