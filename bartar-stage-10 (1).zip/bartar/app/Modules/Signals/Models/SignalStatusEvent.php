<?php

namespace App\Modules\Signals\Models;

use Illuminate\Database\Eloquent\Model;

class SignalStatusEvent extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['happened_at' => 'immutable_datetime'];
    }
}
