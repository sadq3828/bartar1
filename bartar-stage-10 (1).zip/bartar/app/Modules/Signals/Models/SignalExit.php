<?php

namespace App\Modules\Signals\Models;

use Illuminate\Database\Eloquent\Model;

class SignalExit extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['exit_price' => 'decimal:12', 'exit_weight' => 'decimal:6', 'executed_at' => 'immutable_datetime'];
    }
}
