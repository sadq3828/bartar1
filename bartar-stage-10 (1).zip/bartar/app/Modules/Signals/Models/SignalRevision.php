<?php

namespace App\Modules\Signals\Models;

use Illuminate\Database\Eloquent\Model;

class SignalRevision extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshot_json' => 'array', 'changed_at' => 'immutable_datetime', 'announce_change' => 'boolean', 'version' => 'integer'];
    }
}
