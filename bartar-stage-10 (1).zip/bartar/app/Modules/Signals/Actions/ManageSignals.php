<?php

namespace App\Modules\Signals\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Markets\Models\Asset;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\Signals\Models\SignalResult;
use App\Modules\Signals\Models\SignalRevision;
use App\Modules\Signals\Models\SignalStatusEvent;
use App\Modules\Signals\Support\SignalSnapshot;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManageSignals
{
    private const TRANSITIONS = [
        'draft' => ['scheduled', 'published', 'cancelled'],
        'scheduled' => ['draft', 'published', 'cancelled'],
        'published' => ['completed', 'cancelled', 'expired'],
        'completed' => [], 'cancelled' => [], 'expired' => [],
    ];

    public function __construct(private ManageAdministrators $security, private RecordAudit $audit, private SignalSnapshot $snapshots) {}

    private function authorize(Account $actor, string $permission, string $password): Account
    {
        $this->security->lock();
        $actor = $actor->fresh();
        abort_unless($actor->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);

        return $actor;
    }

    public function create(Account $actor, array $data): Signal
    {
        return DB::transaction(function () use ($actor, $data) {
            $actor = $this->authorize($actor, 'signals.create', $data['current_password']);
            $asset = $this->asset($data);
            $this->validateTradingValues($data);
            $signal = Signal::create($this->signalValues($data, $asset) + ['created_by' => $actor->id, 'status' => 'draft', 'version' => 1]);
            $this->replaceTargets($signal, $data['targets']);
            SignalStatusEvent::create(['signal_id' => $signal->id, 'from_status' => null, 'to_status' => 'draft', 'reason' => $data['reason'], 'actor_id' => $actor->id, 'happened_at' => now(), 'idempotency_key' => AdminSession::digest('signal-created:'.$signal->public_id)]);
            $this->audit->write($actor, 'signal.created', 'signal', $signal->public_id, [], $this->safeSummary($signal), $data['reason'], 'signals');

            return $signal->load(['market', 'asset', 'targets']);
        }, 3);
    }

    public function update(Account $actor, Signal $signal, array $data): Signal
    {
        return DB::transaction(function () use ($actor, $signal, $data) {
            $actor = $this->authorize($actor, 'signals.update', $data['current_password']);
            $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
            abort_if($signal->status === 'scheduled' && $signal->scheduled_at?->lte(now()), 409, 'سیگنال در آستانه انتشار است؛ ابتدا وضعیت آن را تغییر دهید.');
            $asset = $this->asset($data);
            $this->validateTradingValues($data);
            $before = $this->safeSummary($signal);
            if ($signal->published_at) {
                $this->preserveRevision($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
                $signal->version++;
            }
            $signal->fill($this->signalValues($data, $asset));
            $signal->save();
            $signal->targets()->delete();
            $this->replaceTargets($signal, $data['targets']);
            if ($signal->published_at && ($data['announce_change'] ?? false)) {
                $this->announcement($signal, 'changed');
            }
            $this->audit->write($actor, 'signal.updated', 'signal', $signal->public_id, $before, $this->safeSummary($signal), $data['reason'], 'signals');

            return $signal->load(['market', 'asset', 'targets']);
        }, 3);
    }

    public function transition(Account $actor, Signal $signal, array $data): Signal
    {
        return DB::transaction(function () use ($actor, $signal, $data) {
            $actor = $this->authorize($actor, 'signals.publish', $data['current_password']);
            $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
            $target = $data['status'];
            $fingerprint = AdminSession::digest('signal-transition:'.$signal->public_id.':'.$data['idempotency_key']);
            if ($existing = SignalStatusEvent::where('idempotency_key', $fingerprint)->first()) {
                abort_unless($existing->signal_id === $signal->id && $existing->to_status === $target, 409, 'شناسه درخواست قبلاً برای تغییر دیگری استفاده شده است.');

                return $signal->fresh();
            }
            if (! in_array($target, self::TRANSITIONS[$signal->status] ?? [], true)) {
                throw ValidationException::withMessages(['status' => 'این انتقال وضعیت مجاز نیست.']);
            }
            if (in_array($target, ['scheduled', 'published'], true)) {
                $this->validatePublishable($signal);
            }
            if ($target === 'scheduled') {
                $scheduledAt = $data['scheduled_at'] ?? null;
                if (! $scheduledAt || CarbonImmutable::parse($scheduledAt, 'Asia/Tehran')->utc()->lte(now())) {
                    throw ValidationException::withMessages(['scheduled_at' => 'زمان انتشار باید در آینده باشد.']);
                }
                $signal->scheduled_at = CarbonImmutable::parse($scheduledAt, 'Asia/Tehran')->utc();
                $signal->published_by = $actor->id;
            }
            if ($target === 'draft') {
                $signal->scheduled_at = null;
                $signal->published_by = null;
            }
            if ($signal->published_at) {
                $this->preserveRevision($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
                $signal->version++;
            }
            $from = $signal->status;
            $signal->status = $target;
            if ($target === 'published') {
                $signal->published_at ??= now();
                $signal->published_by = $actor->id;
                $signal->scheduled_at = null;
            }
            $signal->save();
            SignalStatusEvent::create(['signal_id' => $signal->id, 'from_status' => $from, 'to_status' => $target, 'reason' => $data['reason'], 'actor_id' => $actor->id, 'happened_at' => now(), 'idempotency_key' => $fingerprint]);
            if ($target === 'published') {
                $this->announcement($signal, 'published');
            } elseif ($signal->published_at && ($data['announce_change'] ?? false)) {
                $this->announcement($signal, 'changed');
            }
            $this->audit->write($actor, 'signal.status.changed', 'signal', $signal->public_id, ['status' => $from], ['status' => $target, 'version' => $signal->version], $data['reason'], 'signals');

            return $signal->fresh();
        }, 3);
    }

    public function publishDue(): int
    {
        $ids = Signal::where('status', 'scheduled')->whereNotNull('scheduled_at')->where('scheduled_at', '<=', now())->orderBy('id')->pluck('id');
        $published = 0;
        foreach ($ids as $id) {
            $published += DB::transaction(function () use ($id): int {
                $signal = Signal::whereKey($id)->lockForUpdate()->first();
                if (! $signal || $signal->status !== 'scheduled' || ! $signal->scheduled_at || $signal->scheduled_at->gt(now())) {
                    return 0;
                }
                $this->validatePublishable($signal);
                $key = AdminSession::digest('scheduled-publish:'.$signal->public_id.':'.$signal->scheduled_at->format('Y-m-d H:i:s.u'));
                if (SignalStatusEvent::where('idempotency_key', $key)->exists()) {
                    return 0;
                }
                $signal->update(['status' => 'published', 'published_at' => now(), 'scheduled_at' => null]);
                SignalStatusEvent::create(['signal_id' => $signal->id, 'from_status' => 'scheduled', 'to_status' => 'published', 'reason' => 'انتشار زمان‌بندی‌شده', 'actor_id' => null, 'happened_at' => now(), 'idempotency_key' => $key]);
                $this->announcement($signal, 'published');
                $this->audit->write(null, 'signal.published.scheduled', 'signal', $signal->public_id, ['status' => 'scheduled'], ['status' => 'published', 'version' => $signal->version], 'انتشار زمان‌بندی‌شده', 'signals', 'system');

                return 1;
            }, 3);
        }

        return $published;
    }

    public function recordResult(Account $actor, Signal $signal, array $data): SignalResult
    {
        return DB::transaction(function () use ($actor, $signal, $data) {
            $actor = $this->authorize($actor, 'signals.result', $data['current_password']);
            $signal = Signal::whereKey($signal->id)->lockForUpdate()->firstOrFail();
            abort_unless($signal->published_at && in_array($signal->status, ['published', 'completed'], true), 409, 'نتیجه فقط برای سیگنال منتشرشده ثبت می‌شود.');
            $requestHash = AdminSession::digest(json_encode([$signal->id, $actor->id, $data['method'], $data['entry_execution_price'] ?? null, $data['coverage_ratio'] ?? null, $data['note'] ?? null, $data['exits']], JSON_THROW_ON_ERROR));
            if ($existing = SignalResult::where('idempotency_key', $data['idempotency_key'])->first()) {
                abort_unless($existing->signal_id === $signal->id && hash_equals($existing->request_hash, $requestHash), 409, 'شناسه درخواست نتیجه قبلاً با اطلاعات دیگری استفاده شده است.');

                return $existing->load('exits');
            }
            $this->validateExits($data['exits']);
            $from = $signal->status;
            $this->preserveRevision($signal, $actor, $data['reason'], (bool) ($data['announce_change'] ?? false));
            $signal->version++;
            $signal->status = 'completed';
            $signal->save();
            $result = SignalResult::create(['signal_id' => $signal->id, 'version' => $signal->version, 'method' => $data['method'], 'entry_execution_price' => $data['entry_execution_price'] ?? null, 'coverage_ratio' => $data['coverage_ratio'] ?? null, 'note' => $data['note'] ?? null, 'recorded_by' => $actor->id, 'idempotency_key' => $data['idempotency_key'], 'request_hash' => $requestHash]);
            foreach (array_values($data['exits']) as $index => $exit) {
                $result->exits()->create(['position' => $index + 1, 'exit_price' => $exit['price'], 'exit_weight' => $exit['weight'], 'executed_at' => $exit['executed_at'] ?? null]);
            }
            app(\App\Modules\Reports\Actions\CalculateSignalReturn::class)->persist($result);
            if ($from !== 'completed') {
                SignalStatusEvent::create(['signal_id' => $signal->id, 'from_status' => $from, 'to_status' => 'completed', 'reason' => $data['reason'], 'actor_id' => $actor->id, 'happened_at' => now(), 'idempotency_key' => AdminSession::digest('signal-result-status:'.$signal->public_id.':'.$signal->version)]);
            }
            if ($data['announce_change'] ?? false) {
                $this->announcement($signal, $from === 'completed' ? 'result_corrected' : 'completed');
            }
            $this->audit->write($actor, $from === 'completed' ? 'signal.result.corrected' : 'signal.result.recorded', 'signal', $signal->public_id, ['status' => $from], ['status' => 'completed', 'version' => $signal->version, 'method' => $result->method, 'exit_count' => count($data['exits'])], $data['reason'], 'signals');

            return $result->load('exits');
        }, 3);
    }

    private function asset(array $data): Asset
    {
        return Asset::whereKey($data['asset_id'])->where('market_id', $data['market_id'])->where('active', true)->whereHas('market', fn ($query) => $query->where('active', true))->firstOrFail();
    }

    private function signalValues(array $data, Asset $asset): array
    {
        return ['title' => $data['title'], 'market_id' => $asset->market_id, 'asset_id' => $asset->id, 'trade_type' => $data['trade_type'], 'direction' => $data['direction'], 'entry_low' => $data['entry_low'], 'entry_high' => $data['entry_high'] ?? null, 'stop_loss' => $data['stop_loss'] ?? null, 'timeframe' => $data['timeframe'], 'body_sanitized' => $data['body'], 'risk_label' => $data['risk_label'] ?? null, 'expires_at' => $data['expires_at'] ?? null];
    }

    private function replaceTargets(Signal $signal, array $targets): void
    {
        foreach (array_values($targets) as $index => $target) {
            $signal->targets()->create(['position' => $index + 1, 'price' => $target['price'], 'proposed_exit_weight' => $target['weight'] ?? null]);
        }
    }

    private function validateTradingValues(array $data): void
    {
        $entryHigh = $data['entry_high'] ?? $data['entry_low'];
        if (bccomp((string) $entryHigh, (string) $data['entry_low'], 12) < 0) {
            throw ValidationException::withMessages(['entry_high' => 'سقف محدوده ورود نباید کمتر از کف باشد.']);
        }
        if (isset($data['stop_loss'])) {
            $valid = $data['direction'] === 'buy' ? bccomp((string) $data['stop_loss'], (string) $data['entry_low'], 12) < 0 : bccomp((string) $data['stop_loss'], (string) $entryHigh, 12) > 0;
            if (! $valid) {
                throw ValidationException::withMessages(['stop_loss' => 'حد ضرر با جهت و محدوده ورود سازگار نیست.']);
            }
        }
        $previous = null;
        foreach ($data['targets'] as $index => $target) {
            $price = (string) $target['price'];
            $validSide = $data['direction'] === 'buy' ? bccomp($price, (string) $entryHigh, 12) > 0 : bccomp($price, (string) $data['entry_low'], 12) < 0;
            $validOrder = $previous === null || ($data['direction'] === 'buy' ? bccomp($price, $previous, 12) > 0 : bccomp($price, $previous, 12) < 0);
            if (! $validSide || ! $validOrder) {
                throw ValidationException::withMessages(["targets.$index.price" => 'اهداف باید در سمت درست معامله و به‌ترتیب فاصله از ورود باشند.']);
            }
            $previous = $price;
        }
    }

    private function validateExits(array $exits): void
    {
        $sum = '0';
        foreach ($exits as $index => $exit) {
            $sum = bcadd($sum, (string) $exit['weight'], 6);
            if (bccomp($sum, '1', 6) > 0) {
                throw ValidationException::withMessages(["exits.$index.weight" => 'مجموع سهم خروج نمی‌تواند بیشتر از یک باشد.']);
            }
        }
    }

    private function validatePublishable(Signal $signal): void
    {
        $signal->loadMissing(['market', 'asset', 'targets']);
        if (! $signal->market?->active || ! $signal->asset?->active || $signal->targets->isEmpty()) {
            throw ValidationException::withMessages(['status' => 'برای انتشار، بازار و دارایی فعال و حداقل یک هدف لازم است.']);
        }
    }

    private function preserveRevision(Signal $signal, Account $actor, string $reason, bool $announce): void
    {
        SignalRevision::create(['signal_id' => $signal->id, 'version' => $signal->version, 'snapshot_json' => $this->snapshots->make($signal), 'reason' => $reason, 'actor_id' => $actor->id, 'changed_at' => now(), 'announce_change' => $announce]);
    }

    private function announcement(Signal $signal, string $event): void
    {
        SignalAnnouncement::firstOrCreate(['signal_id' => $signal->id, 'signal_version' => $signal->version, 'event_type' => $event], ['safe_payload' => ['signal_id' => $signal->public_id, 'version' => $signal->version, 'event' => $event], 'status' => 'pending', 'available_at' => now()]);
    }

    private function safeSummary(Signal $signal): array
    {
        return ['title' => $signal->title, 'market_id' => $signal->market_id, 'asset_id' => $signal->asset_id, 'direction' => $signal->direction, 'status' => $signal->status, 'version' => $signal->version];
    }
}
