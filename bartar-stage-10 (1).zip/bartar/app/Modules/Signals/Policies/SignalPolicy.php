<?php

namespace App\Modules\Signals\Policies;

use App\Modules\Authentication\Models\Account;
use App\Modules\Signals\Models\Signal;

final class SignalPolicy
{
    public function viewAny(Account $account): bool
    {
        return $account->allows('signals.view');
    }

    public function view(Account $account, Signal $signal): bool
    {
        if ($account->kind === 'member') {
            return $signal->published_at !== null && $signal->published_at->lte(now()) && in_array($signal->status, ['published', 'completed', 'cancelled', 'expired'], true);
        }

        return $account->allows('signals.view');
    }

    public function create(Account $account): bool
    {
        return $account->allows('signals.create');
    }

    public function update(Account $account, Signal $signal): bool
    {
        return $account->allows('signals.update');
    }

    public function publish(Account $account, Signal $signal): bool
    {
        return $account->allows('signals.publish');
    }

    public function result(Account $account, Signal $signal): bool
    {
        return $account->allows('signals.result');
    }
}
