<?php

namespace App\Modules\Signals\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Markets\Models\Market;
use App\Modules\Signals\Models\Signal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;

final class MemberSignalController extends Controller
{
    public function index(Request $request)
    {
        $filters = $request->validate(['q' => ['nullable', 'string', 'max:100'], 'market' => ['nullable', 'integer', 'exists:markets,id'], 'direction' => ['nullable', Rule::in(['all', 'buy', 'sell'])], 'archive' => ['nullable', 'boolean']]);
        $query = Signal::memberVisible()->with(['market', 'asset', 'targets'])->latest('published_at');
        if ($q = trim((string) ($filters['q'] ?? ''))) {
            $query->where(fn ($builder) => $builder->where('title', 'like', '%'.$q.'%')->orWhereHas('asset', fn ($asset) => $asset->where('symbol', 'like', '%'.$q.'%')));
        }
        if ($filters['market'] ?? null) {
            $query->where('market_id', $filters['market']);
        }
        if (($filters['direction'] ?? 'all') !== 'all') {
            $query->where('direction', $filters['direction']);
        }
        if ($filters['archive'] ?? false) {
            $query->whereIn('status', ['completed', 'cancelled', 'expired']);
        } else {
            $query->where('status', 'published');
        }

        return view('member.signals.index', ['title' => 'سیگنال‌ها', 'active' => 'signals', 'area' => 'member', 'preview' => false, 'signals' => $query->paginate(15)->withQueryString(), 'markets' => Market::whereHas('assets.signals', fn ($signals) => $signals->memberVisible())->orderBy('title')->get(), 'filters' => $filters]);
    }

    public function show(Request $request, Signal $signal)
    {
        abort_unless(Signal::memberVisible()->whereKey($signal->id)->exists(), 404);
        Gate::forUser($request->user('member'))->authorize('view', $signal);
        $signal->load(['market', 'asset', 'targets', 'mediaAttachments.mediaFile', 'revisions', 'statusEvents', 'results.exits']);

        return view('member.signals.show', ['title' => $signal->title, 'active' => 'signals', 'area' => 'member', 'preview' => false, 'signal' => $signal]);
    }
}
