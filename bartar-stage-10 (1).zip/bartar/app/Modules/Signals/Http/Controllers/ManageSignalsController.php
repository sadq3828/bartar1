<?php

namespace App\Modules\Signals\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Markets\Models\Market;
use App\Modules\Signals\Actions\ManageSignals;
use App\Modules\Signals\Models\Signal;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;

final class ManageSignalsController extends Controller
{
    private function data(Request $request, string $title, array $extra = []): array
    {
        return array_merge(['title' => $title, 'active' => 'signals', 'area' => 'admin', 'adminUser' => $request->user('admin'), 'preview' => false], $extra);
    }

    public function index(Request $request)
    {
        Gate::forUser($request->user('admin'))->authorize('viewAny', Signal::class);
        $filters = $request->validate(['q' => ['nullable', 'string', 'max:100'], 'status' => ['nullable', Rule::in(['all', 'draft', 'scheduled', 'published', 'completed', 'cancelled', 'expired'])], 'direction' => ['nullable', Rule::in(['all', 'buy', 'sell'])], 'market' => ['nullable', 'integer', 'exists:markets,id']]);
        $query = Signal::with(['market', 'asset'])->latest('id');
        if ($q = trim((string) ($filters['q'] ?? ''))) {
            $query->where(fn ($builder) => $builder->where('title', 'like', '%'.$q.'%')->orWhereHas('asset', fn ($asset) => $asset->where('symbol', 'like', '%'.$q.'%')));
        }
        if (($filters['status'] ?? 'all') !== 'all') {
            $query->where('status', $filters['status']);
        }
        if (($filters['direction'] ?? 'all') !== 'all') {
            $query->where('direction', $filters['direction']);
        }
        if ($filters['market'] ?? null) {
            $query->where('market_id', $filters['market']);
        }

        return view('admin.signals.index', $this->data($request, 'سیگنال‌ها', ['signals' => $query->paginate(20)->withQueryString(), 'markets' => Market::orderBy('title')->get(), 'filters' => $filters]));
    }

    public function create(Request $request)
    {
        Gate::forUser($request->user('admin'))->authorize('create', Signal::class);

        return view('admin.signals.form', $this->data($request, 'ایجاد سیگنال', ['signal' => null, 'markets' => Market::with(['assets' => fn ($query) => $query->where('active', true)])->where('active', true)->orderBy('title')->get()]));
    }

    public function store(Request $request, ManageSignals $manager)
    {
        Gate::forUser($request->user('admin'))->authorize('create', Signal::class);
        $signal = $manager->create($request->user('admin'), $this->fields($request));

        return redirect()->route('admin.signals.show', $signal)->with('status', 'پیش‌نویس سیگنال ثبت شد.');
    }

    public function show(Request $request, Signal $signal)
    {
        Gate::forUser($request->user('admin'))->authorize('view', $signal);
        $signal->load(['market', 'asset', 'targets', 'mediaAttachments.mediaFile', 'revisions', 'statusEvents', 'results.exits']);

        return view('admin.signals.show', $this->data($request, $signal->title, ['signal' => $signal]));
    }

    public function edit(Request $request, Signal $signal)
    {
        Gate::forUser($request->user('admin'))->authorize('update', $signal);
        $signal->load('targets');

        return view('admin.signals.form', $this->data($request, 'ویرایش سیگنال', ['signal' => $signal, 'markets' => Market::with(['assets' => fn ($query) => $query->where('active', true)])->where('active', true)->orderBy('title')->get()]));
    }

    public function update(Request $request, Signal $signal, ManageSignals $manager)
    {
        Gate::forUser($request->user('admin'))->authorize('update', $signal);
        $manager->update($request->user('admin'), $signal, $this->fields($request, true));

        return redirect()->route('admin.signals.show', $signal)->with('status', 'سیگنال ذخیره شد و در صورت انتشار، نسخهٔ پیشین حفظ شد.');
    }

    public function status(Request $request, Signal $signal, ManageSignals $manager)
    {
        Gate::forUser($request->user('admin'))->authorize('publish', $signal);
        $data = $request->validate(['status' => ['required', Rule::in(['draft', 'scheduled', 'published', 'completed', 'cancelled', 'expired'])], 'scheduled_at' => ['nullable', 'date_format:Y-m-d\TH:i'], 'idempotency_key' => ['required', 'uuid'], 'announce_change' => ['nullable', 'boolean']] + $this->sensitive());
        $manager->transition($request->user('admin'), $signal, $data);

        return back()->with('status', 'وضعیت سیگنال ثبت شد.');
    }

    public function result(Request $request, Signal $signal, ManageSignals $manager)
    {
        Gate::forUser($request->user('admin'))->authorize('result', $signal);
        $data = $request->validate(['method' => ['required', Rule::in(['manual', 'targets', 'partial'])], 'entry_execution_price' => $this->decimal(true), 'coverage_ratio' => ['nullable', 'string', 'regex:/\A(?:0(?:\.\d{1,6})?|1(?:\.0{1,6})?)\z/'], 'note' => ['nullable', 'string', 'max:2000'], 'exits' => ['required', 'array', 'min:1', 'max:20'], 'exits.*.price' => $this->decimal(), 'exits.*.weight' => ['required', 'string', 'regex:/\A(?:0\.\d{1,6}|1(?:\.0{1,6})?)\z/'], 'exits.*.executed_at' => ['nullable', 'date_format:Y-m-d\TH:i'], 'announce_change' => ['nullable', 'boolean'], 'idempotency_key' => ['nullable', 'uuid']] + $this->sensitive());
        $data['idempotency_key'] ??= (string) \Illuminate\Support\Str::uuid();
        foreach ($data['exits'] as &$exit) {
            if (! empty($exit['executed_at'])) {
                $exit['executed_at'] = CarbonImmutable::parse($exit['executed_at'], 'Asia/Tehran')->utc();
            }
        }
        unset($exit);
        $manager->recordResult($request->user('admin'), $signal, $data);

        return back()->with('status', 'نتیجه و محاسبهٔ نسخه‌دار ثبت شد؛ جزئیات در گزارش عملکرد قابل مشاهده است.');
    }

    private function fields(Request $request, bool $editing = false): array
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:160'], 'market_id' => ['required', 'integer', 'exists:markets,id'], 'asset_id' => ['required', 'integer', 'exists:assets,id'], 'trade_type' => ['required', Rule::in(['spot', 'futures', 'margin', 'other'])], 'direction' => ['required', Rule::in(['buy', 'sell'])], 'entry_low' => $this->decimal(), 'entry_high' => $this->decimal(true), 'stop_loss' => $this->decimal(true), 'timeframe' => ['required', 'string', 'max:50'], 'body' => ['required', 'string', 'max:10000'], 'risk_label' => ['nullable', 'string', 'max:50'], 'expires_at' => ['nullable', 'date_format:Y-m-d\TH:i'], 'targets' => ['required', 'array', 'min:1', 'max:20'], 'targets.*.price' => $this->decimal(), 'targets.*.weight' => ['nullable', 'string', 'regex:/\A(?:0\.\d{1,6}|1(?:\.0{1,6})?)\z/'], 'announce_change' => ['nullable', 'boolean']] + $this->sensitive());
        if (! empty($data['expires_at'])) {
            $data['expires_at'] = CarbonImmutable::parse($data['expires_at'], 'Asia/Tehran')->utc();
        }

        return $data;
    }

    private function decimal(bool $nullable = false): array
    {
        return array_values(array_filter([$nullable ? 'nullable' : 'required', 'string', 'regex:/\A(?:0|[1-9][0-9]{0,19})(?:\.\d{1,12})?\z/']));
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }
}
