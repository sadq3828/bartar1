<?php

namespace App\Modules\Signals\Support;

use App\Modules\Signals\Models\Signal;

final class SignalSnapshot
{
    public function make(Signal $signal): array
    {
        $signal->load(['market', 'asset', 'targets', 'mediaAttachments.mediaFile', 'results.exits']);

        return [
            'formula_version' => \App\Modules\Reports\Actions\CalculateSignalReturn::VERSION,
            'signal' => $signal->only(['public_id', 'title', 'trade_type', 'direction', 'entry_low', 'entry_high', 'stop_loss', 'timeframe', 'body_sanitized', 'risk_label', 'status', 'scheduled_at', 'published_at', 'expires_at', 'version']),
            'market' => $signal->market?->only(['public_id', 'key', 'title']),
            'asset' => $signal->asset?->only(['public_id', 'symbol', 'title']),
            'targets' => $signal->targets->map->only(['position', 'price', 'proposed_exit_weight'])->values()->all(),
            'media' => $signal->mediaAttachments->map(fn ($attachment) => [
                'public_id' => $attachment->public_id,
                'kind' => $attachment->kind,
                'caption' => $attachment->caption,
                'position' => $attachment->position,
                'file' => $attachment->mediaFile?->only(['public_id', 'mime', 'bytes', 'sha256']),
            ])->values()->all(),
            'results' => $signal->results->map(fn ($result) => [
                'version' => $result->version,
                'method' => $result->method,
                'entry_execution_price' => $result->entry_execution_price,
                'coverage_ratio' => $result->coverage_ratio,
                'note' => $result->note,
                'exits' => $result->exits->map->only(['position', 'exit_price', 'exit_weight', 'executed_at'])->values()->all(),
            ])->values()->all(),
        ];
    }
}
