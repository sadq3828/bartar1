<?php

namespace App\Modules\Content\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Content\Actions\ManageContent;
use App\Modules\Content\Actions\ManageContentMedia;
use App\Modules\Content\Models\Announcement;
use App\Modules\Content\Models\ContentMenuItem;
use App\Modules\Content\Models\ContentPage;
use App\Modules\Content\Models\ContentSetting;
use App\Modules\Notifications\Models\MemberNotification;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

final class ManageContentController extends Controller
{
    public function index(Request $request)
    {
        $menu = ContentMenuItem::orderBy('position')->get()->keyBy('route_name');

        return view('admin.content.index', $this->data($request, [
            'pages' => ContentPage::withCount('sections')->latest('updated_at')->get(),
            'announcements' => Announcement::latest('id')->paginate(15),
            'settings' => ContentSetting::pluck('value', 'key'),
            'menu' => $menu,
            'menuRoutes' => ManageContent::MENU_ROUTES,
            'adminNotifications' => MemberNotification::where('recipient_id', $request->user('admin')->id)->where('kind', 'administrative')->latest('id')->limit(20)->get(),
        ]));
    }

    public function createPage(Request $request)
    {
        return view('admin.content.page-form', $this->data($request, ['page' => null]));
    }

    public function editPage(Request $request, ContentPage $page)
    {
        return view('admin.content.page-form', $this->data($request, ['page' => $page->load(['sections', 'heroMedia', 'revisions'])]));
    }

    public function storePage(Request $request, ManageContent $manager)
    {
        $page = $manager->createPage($request->user('admin'), $this->pageData($request));

        return redirect()->route('admin.content.pages.edit', $page)->with('status', 'صفحه به‌صورت پیش‌نویس ساخته شد.');
    }

    public function updatePage(Request $request, ContentPage $page, ManageContent $manager)
    {
        $manager->updatePage($request->user('admin'), $page, $this->pageData($request, $page));

        return back()->with('status', 'محتوای صفحه ذخیره شد.');
    }

    public function publishPage(Request $request, ContentPage $page, ManageContent $manager)
    {
        $manager->publishPage($request->user('admin'), $page, $request->validate($this->sensitive()));

        return back()->with('status', 'صفحه منتشر شد.');
    }

    public function uploadHero(Request $request, ContentPage $page, ManageContentMedia $manager)
    {
        $maxKilobytes = (int) ceil(((int) config('content.max_image_bytes')) / 1024);
        $data = $request->validate(['image' => ['required', 'file', 'max:'.$maxKilobytes], 'alt_text' => ['required', 'string', 'max:180']] + $this->sensitive());
        $manager->uploadHero($request->user('admin'), $page, $request->file('image'), $data);

        return back()->with('status', 'تصویر واقعی بررسی و برای صفحه ذخیره شد.');
    }

    public function settings(Request $request, ManageContent $manager)
    {
        $data = $request->validate([
            'brand_name' => ['nullable', 'string', 'max:80'],
            'brand_tagline' => ['nullable', 'string', 'max:180'],
            'support_email' => ['nullable', 'email:rfc', 'max:190'],
            'support_phone' => ['nullable', 'string', 'max:40', 'regex:/\A[+0-9() -]+\z/'],
            'member_cta' => ['nullable', 'string', 'max:120'],
        ] + $this->sensitive());
        $manager->updateSettings($request->user('admin'), $data);

        return back()->with('status', 'تنظیمات برند ذخیره شد.');
    }

    public function menu(Request $request, ManageContent $manager)
    {
        $data = $request->validate([
            'items' => ['required', 'array', 'size:5'],
            'items.*.route_name' => ['required', 'string', 'distinct', Rule::in(ManageContent::MENU_ROUTES)],
            'items.*.title' => ['required', 'string', 'max:60'],
            'items.*.icon' => ['required', 'string', Rule::in(ManageContent::ICONS)],
            'items.*.position' => ['required', 'integer', 'min:1', 'max:5', 'distinct'],
            'items.*.visible' => ['nullable', 'boolean'],
        ] + $this->sensitive());
        $manager->updateMenu($request->user('admin'), $data);

        return back()->with('status', 'منوی عمومی ذخیره شد.');
    }

    public function storeAnnouncement(Request $request, ManageContent $manager)
    {
        $announcement = $manager->createAnnouncement($request->user('admin'), $this->announcementData($request));

        return redirect()->route('admin.content.announcements.edit', $announcement)->with('status', 'اطلاعیه به‌صورت پیش‌نویس ساخته شد.');
    }

    public function editAnnouncement(Request $request, Announcement $announcement)
    {
        return view('admin.content.announcement-form', $this->data($request, ['announcement' => $announcement]));
    }

    public function updateAnnouncement(Request $request, Announcement $announcement, ManageContent $manager)
    {
        $manager->updateAnnouncement($request->user('admin'), $announcement, $this->announcementData($request));

        return back()->with('status', 'اطلاعیه ذخیره شد.');
    }

    public function publishAnnouncement(Request $request, Announcement $announcement, ManageContent $manager)
    {
        $manager->publishAnnouncement($request->user('admin'), $announcement, $request->validate($this->sensitive()));

        return back()->with('status', 'اطلاعیه منتشر و اعلان اعضا بدون تکرار ایجاد شد.');
    }

    public function readAdminNotification(Request $request, MemberNotification $notification)
    {
        abort_unless($notification->recipient_id === $request->user('admin')->id && $notification->kind === 'administrative', 404);
        if (! $notification->read_at) {
            $notification->update(['read_at' => now()]);
        }

        return back()->with('status', 'اعلان مدیریتی خوانده شد.');
    }

    private function data(Request $request, array $extra): array
    {
        return ['title' => 'محتوا و اعلان', 'active' => 'content', 'area' => 'admin', 'adminUser' => $request->user('admin'), 'preview' => false] + $extra;
    }

    private function pageData(Request $request, ?ContentPage $page = null): array
    {
        return $request->validate([
            'slug' => ['required', 'string', Rule::in(ManageContent::PAGE_SLUGS), Rule::unique('content_pages', 'slug')->ignore($page?->id)],
            'eyebrow' => ['nullable', 'string', 'max:100'],
            'title' => ['required', 'string', 'max:180'],
            'intro' => ['required', 'string', 'max:3000'],
            'icon' => ['required', Rule::in(ManageContent::ICONS)],
            'sections' => ['required', 'array', 'min:1', 'max:12'],
            'sections.*.kind' => ['required', Rule::in(['text', 'banner', 'cta'])],
            'sections.*.title' => ['required', 'string', 'max:180'],
            'sections.*.body' => ['required', 'string', 'max:10000'],
            'sections.*.action_label' => ['nullable', 'string', 'max:100', 'required_with:sections.*.action_url'],
            'sections.*.action_url' => ['nullable', 'string', 'max:500'],
            'sections.*.visible' => ['nullable', 'boolean'],
        ] + $this->sensitive());
    }

    private function announcementData(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:180'],
            'body' => ['required', 'string', 'max:10000'],
            'audience' => ['required', Rule::in(['public', 'members', 'all'])],
            'expires_at' => ['nullable', 'date_format:Y-m-d\TH:i'],
        ] + $this->sensitive());
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }
}
