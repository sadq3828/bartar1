<?php

namespace App\Modules\Content\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Content\Models\ContentMedia;
use App\Modules\Content\Models\ContentPage;
use App\Modules\Media\Actions\StreamPrivateMedia;
use Illuminate\Http\Request;

final class PublicContentMediaController extends Controller
{
    public function show(Request $request, ContentMedia $media, StreamPrivateMedia $stream)
    {
        abort_unless(ContentPage::published()->where('hero_media_id', $media->id)->exists(), 404);

        return $stream->response($media->mediaFile()->firstOrFail(), $request);
    }

    public function admin(Request $request, ContentMedia $media, StreamPrivateMedia $stream)
    {
        abort_unless($request->user('admin')->allows('cms.view'), 403);

        return $stream->response($media->mediaFile()->firstOrFail(), $request);
    }
}
