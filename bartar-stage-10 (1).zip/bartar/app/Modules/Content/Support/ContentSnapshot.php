<?php

namespace App\Modules\Content\Support;

use App\Modules\Content\Models\ContentPage;

final class ContentSnapshot
{
    public function make(ContentPage $page): array
    {
        $page->loadMissing(['sections', 'heroMedia']);

        return [
            'page' => $page->only(['public_id', 'slug', 'eyebrow', 'title', 'intro', 'icon', 'status', 'version', 'published_at']),
            'hero_media_id' => $page->heroMedia?->public_id,
            'sections' => $page->sections->map(fn ($section) => $section->only(['kind', 'position', 'title', 'body', 'action_label', 'action_url', 'visible']))->values()->all(),
        ];
    }
}
