<?php

namespace App\Modules\Content\Models;

use Illuminate\Database\Eloquent\Model;

class ContentSetting extends Model
{
    protected $guarded = ['id'];
}
