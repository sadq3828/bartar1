<?php

namespace App\Modules\Content\Models;

use Illuminate\Database\Eloquent\Model;

class ContentPageRevision extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['snapshot_json' => 'array', 'created_at' => 'immutable_datetime', 'version' => 'integer'];
    }
}
