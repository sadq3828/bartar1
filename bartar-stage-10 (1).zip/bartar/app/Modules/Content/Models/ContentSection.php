<?php

namespace App\Modules\Content\Models;

use Illuminate\Database\Eloquent\Model;

class ContentSection extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['visible' => 'boolean', 'position' => 'integer'];
    }
}
