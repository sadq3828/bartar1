<?php

namespace App\Modules\Content\Models;

use App\Modules\Media\Models\MediaFile;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ContentMedia extends Model
{
    protected $guarded = ['id'];

    protected static function booted(): void
    {
        static::creating(function (self $media): void {
            $media->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function mediaFile()
    {
        return $this->belongsTo(MediaFile::class);
    }
}
