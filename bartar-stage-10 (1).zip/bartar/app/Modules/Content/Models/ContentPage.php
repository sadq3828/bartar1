<?php

namespace App\Modules\Content\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ContentPage extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['published_at' => 'immutable_datetime', 'version' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $page): void {
            $page->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function sections()
    {
        return $this->hasMany(ContentSection::class, 'page_id')->orderBy('position');
    }

    public function heroMedia()
    {
        return $this->belongsTo(ContentMedia::class, 'hero_media_id');
    }

    public function revisions()
    {
        return $this->hasMany(ContentPageRevision::class, 'page_id')->latest('version');
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published')->whereNotNull('published_at')->where('published_at', '<=', now());
    }
}
