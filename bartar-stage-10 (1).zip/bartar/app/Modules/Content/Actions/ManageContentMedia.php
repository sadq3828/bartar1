<?php

namespace App\Modules\Content\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Content\Models\ContentMedia;
use App\Modules\Content\Models\ContentPage;
use App\Modules\Content\Models\ContentPageRevision;
use App\Modules\Content\Support\ContentSnapshot;
use App\Modules\Media\Contracts\PrivateMediaStorage;
use App\Modules\Media\Models\MediaFile;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;

final class ManageContentMedia
{
    public function __construct(
        private ManageAdministrators $security,
        private RecordAudit $audit,
        private ContentSnapshot $snapshots,
        private PrivateMediaStorage $storage,
    ) {}

    public function uploadHero(Account $actor, ContentPage $page, UploadedFile $file, array $data): ContentMedia
    {
        $metadata = $this->inspect($file);
        $disk = (string) config('media.disk');
        $uuid = strtolower((string) Str::uuid());
        $quarantineKey = 'quarantine/'.$uuid;
        $finalKey = 'objects/'.substr($uuid, 0, 2).'/'.$uuid;
        $stored = [];

        try {
            return DB::transaction(function () use ($actor, $page, $file, $data, $metadata, $disk, $quarantineKey, $finalKey, &$stored): ContentMedia {
                $this->security->lock();
                $actor = $actor->fresh();
                abort_unless($actor->allows('cms.update'), 403);
                $this->security->confirmPassword($actor, $data['current_password']);
                $page = ContentPage::whereKey($page->id)->lockForUpdate()->firstOrFail();
                if ($page->status === 'published') {
                    abort_unless($actor->allows('cms.publish'), 403);
                    ContentPageRevision::create(['page_id' => $page->id, 'version' => $page->version, 'snapshot_json' => $this->snapshots->make($page), 'reason' => $data['reason'], 'actor_id' => $actor->id]);
                    $page->version++;
                }

                $stream = fopen($file->getRealPath(), 'rb');
                if (! is_resource($stream)) {
                    throw ValidationException::withMessages(['image' => 'خواندن تصویر ممکن نیست.']);
                }
                try {
                    $this->storage->put($disk, $quarantineKey, $stream);
                    $stored[] = $quarantineKey;
                } finally {
                    fclose($stream);
                }
                $mediaFile = MediaFile::create(['disk' => $disk, 'object_key' => $quarantineKey, 'kind' => 'image', 'mime' => $metadata['mime'], 'bytes' => $metadata['bytes'], 'sha256' => $metadata['sha256'], 'original_name' => $this->safeName($file->getClientOriginalName()), 'state' => 'quarantined', 'uploaded_by' => $actor->id]);
                $this->storage->move($disk, $quarantineKey, $finalKey);
                $stored = [$finalKey];
                $mediaFile->update(['object_key' => $finalKey, 'state' => 'ready', 'verified_at' => now()]);
                $contentMedia = ContentMedia::create(['media_file_id' => $mediaFile->id, 'alt_text' => $data['alt_text'], 'created_by' => $actor->id]);
                $page->update(['hero_media_id' => $contentMedia->id, 'updated_by' => $actor->id, 'version' => $page->version]);
                $this->audit->write($actor, 'content.media.uploaded', 'content_page', $page->public_id, [], ['media_id' => $contentMedia->public_id, 'mime' => $mediaFile->mime, 'bytes' => $mediaFile->bytes, 'sha256' => $mediaFile->sha256, 'version' => $page->version], $data['reason'], 'cms');

                return $contentMedia->load('mediaFile');
            }, 3);
        } catch (Throwable $error) {
            foreach ($stored as $key) {
                $this->storage->delete($disk, $key);
            }
            throw $error;
        }
    }

    private function inspect(UploadedFile $file): array
    {
        if (! $file->isValid()) {
            throw ValidationException::withMessages(['image' => 'بارگذاری تصویر کامل نشده است.']);
        }
        $bytes = (int) $file->getSize();
        if ($bytes < 1 || $bytes > (int) config('content.max_image_bytes')) {
            throw ValidationException::withMessages(['image' => 'اندازه تصویر خارج از سقف پنج مگابایت است.']);
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file->getRealPath()) ?: 'application/octet-stream';
        if (! in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
            throw ValidationException::withMessages(['image' => 'فقط تصویر واقعی JPEG، PNG یا WebP مجاز است.']);
        }

        return ['bytes' => $bytes, 'mime' => $mime, 'sha256' => hash_file('sha256', $file->getRealPath())];
    }

    private function safeName(string $name): string
    {
        $name = preg_replace('~[\x00-\x1F\x7F/\\\\]+~u', '-', trim($name)) ?: 'content-image';

        return mb_substr($name, 0, 255);
    }
}
