<?php

namespace App\Modules\Content\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Content\Models\Announcement;
use App\Modules\Content\Models\ContentMenuItem;
use App\Modules\Content\Models\ContentPage;
use App\Modules\Content\Models\ContentPageRevision;
use App\Modules\Content\Models\ContentSetting;
use App\Modules\Content\Support\ContentSnapshot;
use App\Modules\Notifications\Actions\DispatchNotifications;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManageContent
{
    public const PAGE_SLUGS = ['home', 'about', 'subscription', 'guide', 'terms', 'privacy', 'contact'];

    public const ICONS = ['home', 'compass', 'crown', 'book', 'document', 'shield', 'headphones', 'bell'];

    public const MENU_ROUTES = ['home', 'guide', 'subscription', 'announcements', 'about'];

    public const SETTINGS = ['brand_name', 'brand_tagline', 'support_email', 'support_phone', 'member_cta'];

    public function __construct(
        private ManageAdministrators $security,
        private RecordAudit $audit,
        private ContentSnapshot $snapshots,
        private DispatchNotifications $notifications,
    ) {}

    public function createPage(Account $actor, array $data): ContentPage
    {
        return DB::transaction(function () use ($actor, $data): ContentPage {
            $actor = $this->authorize($actor, 'cms.create', $data['current_password']);
            $this->assertPageData($data);
            $page = ContentPage::create($this->pageValues($data) + ['created_by' => $actor->id, 'updated_by' => $actor->id]);
            $this->replaceSections($page, $data['sections']);
            $this->audit->write($actor, 'content.page.created', 'content_page', $page->public_id, [], ['slug' => $page->slug, 'title' => $page->title, 'status' => 'draft'], $data['reason'], 'cms');

            return $page->load('sections');
        }, 3);
    }

    public function updatePage(Account $actor, ContentPage $page, array $data): ContentPage
    {
        return DB::transaction(function () use ($actor, $page, $data): ContentPage {
            $actor = $this->authorize($actor, 'cms.update', $data['current_password']);
            $page = ContentPage::whereKey($page->id)->lockForUpdate()->firstOrFail();
            if ($page->status === 'published') {
                abort_unless($actor->allows('cms.publish'), 403, 'ویرایش محتوای منتشرشده به مجوز انتشار نیاز دارد.');
                $this->preserve($page, $actor, $data['reason']);
                $page->version++;
            }
            $this->assertPageData($data);
            $before = ['title' => $page->title, 'version' => $page->version];
            $page->fill($this->pageValues($data) + ['updated_by' => $actor->id])->save();
            $page->sections()->delete();
            $this->replaceSections($page, $data['sections']);
            $this->audit->write($actor, 'content.page.updated', 'content_page', $page->public_id, $before, ['title' => $page->title, 'version' => $page->version, 'status' => $page->status], $data['reason'], 'cms');

            return $page->load('sections');
        }, 3);
    }

    public function publishPage(Account $actor, ContentPage $page, array $data): ContentPage
    {
        return DB::transaction(function () use ($actor, $page, $data): ContentPage {
            $actor = $this->authorize($actor, 'cms.publish', $data['current_password']);
            $page = ContentPage::whereKey($page->id)->with('sections')->lockForUpdate()->firstOrFail();
            if ($page->status === 'published') {
                return $page;
            }
            if ($page->sections->where('visible', true)->isEmpty()) {
                throw ValidationException::withMessages(['page' => 'حداقل یک بخش قابل نمایش برای انتشار لازم است.']);
            }
            $page->update(['status' => 'published', 'published_at' => now(), 'updated_by' => $actor->id]);
            $this->audit->write($actor, 'content.page.published', 'content_page', $page->public_id, ['status' => 'draft'], ['status' => 'published', 'version' => $page->version], $data['reason'], 'cms');

            return $page->fresh();
        }, 3);
    }

    public function updateSettings(Account $actor, array $data): void
    {
        DB::transaction(function () use ($actor, $data): void {
            $actor = $this->authorize($actor, 'settings.brand', $data['current_password']);
            $before = ContentSetting::whereIn('key', self::SETTINGS)->pluck('value', 'key')->all();
            foreach (self::SETTINGS as $key) {
                ContentSetting::updateOrCreate(['key' => $key], ['value' => $data[$key] ?? null, 'updated_by' => $actor->id]);
            }
            $this->audit->write($actor, 'content.settings.updated', 'content_settings', null, $before, collect($data)->only(self::SETTINGS)->all(), $data['reason'], 'cms');
        }, 3);
    }

    public function updateMenu(Account $actor, array $data): void
    {
        DB::transaction(function () use ($actor, $data): void {
            $actor = $this->authorize($actor, 'cms.update', $data['current_password']);
            $items = collect($data['items'])->keyBy('route_name');
            abort_unless($items->keys()->sort()->values()->all() === collect(self::MENU_ROUTES)->sort()->values()->all(), 422, 'منوی عمومی باید همه مسیرهای تعریف‌شده را دقیقاً یک‌بار داشته باشد.');
            foreach (self::MENU_ROUTES as $route) {
                $item = $items->get($route);
                ContentMenuItem::updateOrCreate(['route_name' => $route], ['title' => $item['title'], 'icon' => $item['icon'], 'position' => $item['position'], 'visible' => (bool) ($item['visible'] ?? false), 'updated_by' => $actor->id]);
            }
            $this->audit->write($actor, 'content.menu.updated', 'content_menu', null, [], ['routes' => self::MENU_ROUTES], $data['reason'], 'cms');
        }, 3);
    }

    public function createAnnouncement(Account $actor, array $data): Announcement
    {
        return DB::transaction(function () use ($actor, $data): Announcement {
            $actor = $this->authorize($actor, 'notifications.create', $data['current_password']);
            $announcement = Announcement::create($this->announcementValues($data) + ['status' => 'draft', 'created_by' => $actor->id, 'updated_by' => $actor->id]);
            $this->audit->write($actor, 'announcement.created', 'announcement', $announcement->public_id, [], ['title' => $announcement->title, 'audience' => $announcement->audience], $data['reason'], 'cms');

            return $announcement;
        }, 3);
    }

    public function updateAnnouncement(Account $actor, Announcement $announcement, array $data): Announcement
    {
        $updated = DB::transaction(function () use ($actor, $announcement, $data): Announcement {
            $actor = $this->authorize($actor, 'notifications.create', $data['current_password']);
            $announcement = Announcement::whereKey($announcement->id)->lockForUpdate()->firstOrFail();
            if ($announcement->status === 'published') {
                abort_unless($actor->allows('notifications.publish'), 403);
                $announcement->version++;
            }
            $before = ['title' => $announcement->title, 'audience' => $announcement->audience, 'version' => $announcement->version];
            $announcement->fill($this->announcementValues($data) + ['updated_by' => $actor->id])->save();
            $this->audit->write($actor, 'announcement.updated', 'announcement', $announcement->public_id, $before, ['title' => $announcement->title, 'audience' => $announcement->audience, 'version' => $announcement->version], $data['reason'], 'cms');

            return $announcement;
        }, 3);
        if ($updated->status === 'published') {
            $this->notifications->announcement($updated);
        }

        return $updated;
    }

    public function publishAnnouncement(Account $actor, Announcement $announcement, array $data): Announcement
    {
        $published = DB::transaction(function () use ($actor, $announcement, $data): Announcement {
            $actor = $this->authorize($actor, 'notifications.publish', $data['current_password']);
            $announcement = Announcement::whereKey($announcement->id)->lockForUpdate()->firstOrFail();
            if ($announcement->status !== 'published') {
                $announcement->update(['status' => 'published', 'published_at' => now(), 'updated_by' => $actor->id]);
                $this->audit->write($actor, 'announcement.published', 'announcement', $announcement->public_id, ['status' => 'draft'], ['status' => 'published', 'version' => $announcement->version], $data['reason'], 'cms');
            }

            return $announcement->fresh();
        }, 3);
        $this->notifications->announcement($published);

        return $published;
    }

    private function authorize(Account $actor, string $permission, string $password): Account
    {
        $this->security->lock();
        $actor = $actor->fresh();
        abort_unless($actor->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);

        return $actor;
    }

    private function assertPageData(array $data): void
    {
        abort_unless(in_array($data['slug'], self::PAGE_SLUGS, true) && in_array($data['icon'], self::ICONS, true), 422);
        foreach ($data['sections'] as $index => $section) {
            if (! empty($section['action_url']) && ! $this->safeUrl($section['action_url'])) {
                throw ValidationException::withMessages(["sections.$index.action_url" => 'لینک باید داخلی یا HTTPS معتبر باشد.']);
            }
        }
    }

    private function safeUrl(string $url): bool
    {
        if (preg_match('~\A/(?!/)[A-Za-z0-9/_?&=%#.-]*\z~', $url)) {
            return true;
        }
        $parts = parse_url($url);

        return is_array($parts) && ($parts['scheme'] ?? null) === 'https' && isset($parts['host']) && ! isset($parts['user']) && ! isset($parts['pass']);
    }

    private function pageValues(array $data): array
    {
        return collect($data)->only(['slug', 'eyebrow', 'title', 'intro', 'icon'])->all();
    }

    private function replaceSections(ContentPage $page, array $sections): void
    {
        foreach (array_values($sections) as $index => $section) {
            $page->sections()->create(['kind' => $section['kind'], 'position' => $index + 1, 'title' => $section['title'], 'body' => $section['body'], 'action_label' => $section['action_label'] ?? null, 'action_url' => $section['action_url'] ?? null, 'visible' => (bool) ($section['visible'] ?? false)]);
        }
    }

    private function preserve(ContentPage $page, Account $actor, string $reason): void
    {
        ContentPageRevision::create(['page_id' => $page->id, 'version' => $page->version, 'snapshot_json' => $this->snapshots->make($page), 'reason' => $reason, 'actor_id' => $actor->id]);
    }

    private function announcementValues(array $data): array
    {
        $expiresAt = empty($data['expires_at']) ? null : CarbonImmutable::parse($data['expires_at'], 'Asia/Tehran')->utc();
        if ($expiresAt?->lte(now())) {
            throw ValidationException::withMessages(['expires_at' => 'زمان پایان نمایش باید در آینده باشد.']);
        }

        return [
            'title' => $data['title'],
            'body' => $data['body'],
            'audience' => $data['audience'],
            'expires_at' => $expiresAt,
        ];
    }
}
