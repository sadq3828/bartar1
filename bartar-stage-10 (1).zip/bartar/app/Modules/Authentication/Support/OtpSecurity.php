<?php

namespace App\Modules\Authentication\Support;

use App\Modules\SmsIntegration\Contracts\OtpSender;
use Illuminate\Support\Facades\DB;

final class OtpSecurity
{
    public static function ready(): bool
    {
        $queue = config('queue.default');
        $safeQueue = in_array($queue, ['database', 'redis', 'sqs', 'beanstalkd'], true) || (app()->environment('testing') && $queue === 'sync');

        return strlen((string) config('membership.otp_key')) >= 32 && $safeQueue && app(OtpSender::class)->available();
    }

    public static function verifier(string $id, string $code): string
    {
        return hash_hmac('sha256', 'login:'.$id.':'.$code, (string) config('membership.otp_key'));
    }

    public static function event(string $subject, string $ip, string $outcome, ?int $accountId = null): void
    {
        DB::table('auth_events')->insert(['account_id' => $accountId, 'subject_hash' => $subject, 'ip_digest' => $ip, 'outcome' => $outcome, 'occurred_at' => now()]);
    }
}
