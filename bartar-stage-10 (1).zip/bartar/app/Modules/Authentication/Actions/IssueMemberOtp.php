<?php

namespace App\Modules\Authentication\Actions;

use App\Modules\Authentication\Jobs\SendMemberOtp;
use App\Modules\Authentication\Models\OtpChallenge;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\Members\Models\Member;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class IssueMemberOtp
{
    public function issue(string $phoneHash, string $binding, string $ip): string
    {
        $id = (string) Str::ulid();
        $created = DB::transaction(function () use ($id, $phoneHash, $binding, $ip): bool {
            $member = Member::where('phone_hash', $phoneHash)->lockForUpdate()->first();
            if (! $member || ! $member->eligible()) {
                return false;
            }
            if (OtpChallenge::where('member_id', $member->id)->where('created_at', '>', now()->subSeconds((int) config('membership.otp_resend')))->exists()) {
                return false;
            }
            OtpChallenge::where('member_id', $member->id)->whereNull('consumed_at')->whereNull('invalidated_at')->update(['invalidated_at' => now()]);
            OtpChallenge::create(['public_id' => $id, 'member_id' => $member->id, 'session_binding_hash' => $binding, 'ip_digest' => $ip, 'expires_at' => now()->addSeconds((int) config('membership.otp_ttl'))]);

            return true;
        });
        if ($created) {
            try {
                SendMemberOtp::dispatch($id);
            } catch (\Throwable) {
                OtpChallenge::where('public_id', $id)->update(['invalidated_at' => now()]);
                OtpSecurity::event($phoneHash, $ip, 'delivery_failed');
            }
        }

        return $id;
    }
}
