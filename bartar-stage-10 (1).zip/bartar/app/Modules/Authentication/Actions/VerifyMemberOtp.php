<?php

namespace App\Modules\Authentication\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Models\MemberSession;
use App\Modules\Authentication\Models\OtpChallenge;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\Members\Models\Member;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

final class VerifyMemberOtp
{
    public const ERROR = 'کد واردشده معتبر نیست یا امکان ورود وجود ندارد.';

    public function verify(Request $request, string $id, string $code, string $subject, string $ip): bool
    {
        $reference = OtpChallenge::where('public_id', $id)->first();
        if (! $reference) {
            OtpSecurity::event($subject, $ip, 'rejected');

            return false;
        }
        $guard = Auth::guard('member');
        try {
            return DB::transaction(function () use ($request, $reference, $code, $subject, $ip, $guard): bool {
                $member = Member::whereKey($reference->member_id)->lockForUpdate()->firstOrFail();
                $challenge = OtpChallenge::whereKey($reference->id)->lockForUpdate()->firstOrFail();
                $valid = $member->eligible() && ! $challenge->consumed_at && ! $challenge->invalidated_at && $challenge->sent_at && $challenge->expires_at->gt(now()) && $challenge->attempts < (int) config('membership.otp_attempts') && hash_equals($challenge->session_binding_hash, AdminSession::digest($request->session()->getId()));
                if (! $valid || ! hash_equals((string) $challenge->verifier_hmac, OtpSecurity::verifier($challenge->public_id, $code))) {
                    if (! $challenge->consumed_at && ! $challenge->invalidated_at) {
                        $challenge->attempts++;
                        if ($challenge->attempts >= (int) config('membership.otp_attempts')) {
                            $challenge->invalidated_at = now();
                        }$challenge->save();
                    }
                    OtpSecurity::event($subject, $ip, 'rejected');

                    return false;
                }
                $challenge->update(['consumed_at' => now()]);
                $account = $member->account()->firstOrFail();
                MemberSession::where('session_hash', AdminSession::digest($request->session()->getId()))->whereNull('revoked_at')->update(['revoked_at' => now()]);
                $guard->login($account, false);
                $request->session()->regenerate();
                $request->session()->regenerateToken();
                $request->session()->forget('otp.pending');
                MemberSession::create(['account_id' => $account->id, 'session_hash' => AdminSession::digest($request->session()->getId()), 'auth_version' => $account->auth_version, 'last_seen_at' => now()]);
                $account->update(['last_login_at' => now()]);
                OtpSecurity::event($subject, $ip, 'accepted', $account->id);
                app(RecordAudit::class)->write($account, 'member.login', 'member', $member->public_id, [], [], null, 'security', 'member');

                return true;
            });
        } catch (\Throwable $error) {
            $guard->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            throw $error;
        }
    }
}
