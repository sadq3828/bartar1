<?php

namespace App\Modules\Authentication\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class MemberSession extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['session_hash'];

    protected function casts(): array
    {
        return ['auth_version' => 'integer', 'last_seen_at' => 'immutable_datetime', 'revoked_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $s): void {
            $s->public_id ??= (string) Str::ulid();
        });
    }
}
