<?php

namespace App\Modules\Authentication\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class AdminSession extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['session_hash', 'ip_digest'];

    protected function casts(): array
    {
        return ['created_at' => 'immutable_datetime', 'last_seen_at' => 'immutable_datetime', 'revoked_at' => 'immutable_datetime', 'auth_version' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $session): void {
            $session->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class);
    }

    public static function digest(string $value): string
    {
        return hash_hmac('sha256', $value, (string) config('app.key'));
    }
}
