<?php

namespace App\Modules\Authentication\Models;

use Illuminate\Database\Eloquent\Model;

class OtpChallenge extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['verifier_hmac', 'session_binding_hash', 'ip_digest'];

    protected function casts(): array
    {
        return ['attempts' => 'integer', 'expires_at' => 'immutable_datetime', 'sent_at' => 'immutable_datetime', 'consumed_at' => 'immutable_datetime', 'invalidated_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }
}
