<?php

namespace App\Modules\Authentication\Models;

use App\Modules\Authorization\Models\Role;
use App\Modules\Authorization\Support\PermissionCatalog;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Str;

class Account extends Authenticatable
{
    protected $guarded = ['id'];

    protected $hidden = ['password_hash'];

    protected function casts(): array
    {
        return ['password_hash' => 'hashed', 'disabled_at' => 'immutable_datetime', 'last_login_at' => 'immutable_datetime', 'auth_version' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $account): void {
            $account->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function getAuthPasswordName(): string
    {
        return 'password_hash';
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'account_roles');
    }

    public function allows(string $permission): bool
    {
        if ($this->kind !== 'admin' || $this->disabled_at || ! array_key_exists($permission, PermissionCatalog::permissions())) {
            return false;
        }

        return $this->roles()->whereHas('permissions', fn ($q) => $q->whereIn('key', [$permission, 'all_modules']))->exists();
    }
}
