<?php

namespace App\Modules\Authentication\Models;

use Illuminate\Database\Eloquent\Model;

final class AuthenticationEvent extends Model
{
    protected $table = 'auth_events';

    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['subject_hash', 'ip_digest'];

    protected function casts(): array
    {
        return ['occurred_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        self::updating(fn () => throw new \LogicException('Authentication history is append only.'));
        self::deleting(fn () => throw new \LogicException('Authentication history is append only.'));
    }
}
