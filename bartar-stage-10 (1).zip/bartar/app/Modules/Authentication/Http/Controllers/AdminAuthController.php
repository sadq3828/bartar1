<?php

namespace App\Modules\Authentication\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\AdminSession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

class AdminAuthController extends Controller
{
    public function show()
    {
        return response()->view('admin.auth.login', ['title' => 'ورود مدیریت'])->header('Cache-Control', 'private, no-store');
    }

    public function login(Request $request, RecordAudit $audit)
    {
        $data = $request->validate(['username' => ['required', 'string', 'max:64'], 'password' => ['required', 'string', 'max:128']]);
        $username = strtolower(trim($data['username']));
        $subject = AdminSession::digest('username:'.$username);
        $ip = AdminSession::digest('ip:'.$request->ip());
        $keys = ['admin-login:'.$subject => 5, 'admin-login-ip:'.$ip => 30];
        foreach ($keys as $key => $limit) {
            if (RateLimiter::tooManyAttempts($key, $limit)) {
                DB::table('auth_events')->insert(['account_id' => null, 'subject_hash' => $subject, 'ip_digest' => $ip, 'outcome' => 'throttled', 'occurred_at' => now()]);

                return $request->expectsJson() ? response()->json(['message' => 'تلاش‌های زیادی انجام شده؛ کمی بعد دوباره تلاش کنید.'], 429)->header('Retry-After', (string) RateLimiter::availableIn($key)) : response()->view('errors.429', [], 429)->header('Retry-After', (string) RateLimiter::availableIn($key));
            }
        }
        foreach ($keys as $key => $limit) {
            RateLimiter::hit($key, 60);
        }
        $oldHash = AdminSession::digest($request->session()->getId());
        $guard = Auth::guard('admin');
        $valid = $guard->attempt(['username' => $username, 'kind' => 'admin', 'disabled_at' => null, 'password' => $data['password']], false);
        if (! $valid) {
            DB::table('auth_events')->insert(['account_id' => null, 'subject_hash' => $subject, 'ip_digest' => $ip, 'outcome' => 'rejected', 'occurred_at' => now()]);
            throw ValidationException::withMessages(['username' => 'نام کاربری یا رمز عبور معتبر نیست.']);
        }
        $request->session()->regenerate();
        $request->session()->regenerateToken();
        $account = $guard->user();
        try {
            DB::transaction(function () use ($request, $account, $subject, $ip, $oldHash, $audit): void {
                app(ManageAdministrators::class)->lock();
                $fresh = $account->fresh();
                if ($fresh->disabled_at || $fresh->auth_version !== $account->auth_version) {
                    throw ValidationException::withMessages(['username' => 'نام کاربری یا رمز عبور معتبر نیست.']);
                }
                AdminSession::where('session_hash', $oldHash)->whereNull('revoked_at')->update(['revoked_at' => now()]);
                AdminSession::create(['account_id' => $account->id, 'session_hash' => AdminSession::digest($request->session()->getId()), 'auth_version' => $account->auth_version, 'ip_digest' => $ip, 'device' => 'مرورگر', 'last_seen_at' => now()]);
                $account->update(['last_login_at' => now()]);
                DB::table('auth_events')->insert(['account_id' => $account->id, 'subject_hash' => $subject, 'ip_digest' => $ip, 'outcome' => 'accepted', 'occurred_at' => now()]);
                $audit->write($account, 'auth.login', 'account', $account->public_id);
            });
        } catch (\Throwable $error) {
            $guard->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            throw $error;
        }
        RateLimiter::clear('admin-login:'.$subject);

        return redirect()->route('admin.dashboard');
    }

    public function logout(Request $request, RecordAudit $audit)
    {
        $account = $request->user('admin');
        DB::transaction(function () use ($request, $account, $audit): void {
            $request->attributes->get('admin_session')->update(['revoked_at' => now()]);
            $audit->write($account, 'auth.logout', 'account', $account->public_id);
        });
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }

    public function recovery()
    {
        return view('admin.auth.recovery', ['title' => 'بازیابی دسترسی مدیریت']);
    }
}
