<?php

namespace App\Modules\Authentication\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Authentication\Actions\IssueMemberOtp;
use App\Modules\Authentication\Actions\VerifyMemberOtp;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\Members\Support\IranianPhone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

final class MemberAuthController extends Controller
{
    public function show()
    {
        return response()->view('member.auth.login', ['title' => 'ورود اعضا', 'ready' => OtpSecurity::ready()], OtpSecurity::ready() ? 200 : 503)->header('Cache-Control', 'private, no-store');
    }

    public function request(Request $request, IssueMemberOtp $issuer)
    {
        abort_unless(OtpSecurity::ready(), 503, 'ارسال پیامک هنوز پیکربندی نشده است.');
        $data = $request->validate(['phone' => ['required', 'string', 'max:40']]);
        $phone = IranianPhone::normalize($data['phone']);

        return $this->issue($request, $issuer, IranianPhone::digest($phone), IranianPhone::mask($phone));
    }

    public function resend(Request $request, IssueMemberOtp $issuer)
    {
        abort_unless(OtpSecurity::ready(), 503, 'ارسال پیامک هنوز پیکربندی نشده است.');
        $pending = $request->session()->get('otp.pending');
        if (! $pending) {
            return redirect()->route('login');
        }

        return $this->issue($request, $issuer, $pending['subject'], $pending['mask']);
    }

    private function issue(Request $request, IssueMemberOtp $issuer, string $subject, string $mask)
    {
        $ip = AdminSession::digest('member-ip:'.$request->ip());
        $this->limit(['member-request-ip:'.$ip => [10, 60], 'member-request-phone:'.$subject => [3, 900], 'member-resend:'.$subject => [1, (int) config('membership.otp_resend')]]);
        $id = $issuer->issue($subject, AdminSession::digest($request->session()->getId()), $ip);
        $request->session()->put('otp.pending', ['id' => $id, 'subject' => $subject, 'mask' => $mask]);
        $message = 'اگر شماره مجاز و اشتراک معتبر باشد، کد ورود ارسال می‌شود.';

        return $request->expectsJson() ? response()->json(['message' => $message, 'next' => route('member.otp')], 202) : redirect()->route('member.otp')->with('status', $message);
    }

    public function challenge(Request $request)
    {
        if (! $request->session()->has('otp.pending')) {
            return redirect()->route('login');
        }

        return response()->view('member.auth.verify', ['title' => 'تأیید ورود', 'mask' => $request->session()->get('otp.pending.mask'), 'ready' => OtpSecurity::ready(), 'resendSeconds' => (int) config('membership.otp_resend')])->header('Cache-Control', 'private, no-store');
    }

    public function verify(Request $request, VerifyMemberOtp $verifier)
    {
        abort_unless(OtpSecurity::ready(), 503, 'ارسال پیامک هنوز پیکربندی نشده است.');
        $ip = AdminSession::digest('member-ip:'.$request->ip());
        $binding = AdminSession::digest($request->session()->getId());
        $this->limit(['member-verify-ip:'.$ip => [20, 60], 'member-verify-session:'.$binding => [10, 300]]);
        $code = strtr((string) $request->input('code', ''), array_combine(preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY), str_split('01234567890123456789')));
        $pending = $request->session()->get('otp.pending');
        if (! preg_match('/\A[0-9]{6}\z/', $code) || ! $pending || ! $verifier->verify($request, $pending['id'], $code, $pending['subject'], $ip)) {
            throw ValidationException::withMessages(['code' => VerifyMemberOtp::ERROR]);
        }

        return redirect()->route('member.home');
    }

    private function limit(array $limits): void
    {
        foreach ($limits as $key => [$max,$seconds]) {
            if (RateLimiter::tooManyAttempts($key, $max)) {
                abort((request()->expectsJson() ? response()->json(['message' => 'تلاش‌های زیادی انجام شده؛ کمی بعد دوباره تلاش کنید.'], 429) : response()->view('errors.429', [], 429))->header('Retry-After', (string) RateLimiter::availableIn($key)));
            }
        }
        foreach ($limits as $key => [$max,$seconds]) {
            RateLimiter::hit($key, $seconds);
        }
    }
}
