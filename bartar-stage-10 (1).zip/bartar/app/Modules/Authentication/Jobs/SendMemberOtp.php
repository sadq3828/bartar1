<?php

namespace App\Modules\Authentication\Jobs;

use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Models\OtpChallenge;
use App\Modules\Authentication\Support\OtpSecurity;
use App\Modules\Members\Models\Member;
use App\Modules\SmsIntegration\Contracts\OtpSender;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\DB;

final class SendMemberOtp implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 15;

    public bool $failOnTimeout = true;

    // Only this opaque reference is serialized; no phone or OTP enters a queue payload.
    public function __construct(public string $challengeId) {}

    public function handle(OtpSender $sender): void
    {
        $reference = OtpChallenge::where('public_id', $this->challengeId)->first();
        if (! $reference) {
            return;
        }
        try {
            DB::transaction(function () use ($reference, $sender): void {
                $member = Member::whereKey($reference->member_id)->lockForUpdate()->firstOrFail();
                $challenge = OtpChallenge::whereKey($reference->id)->lockForUpdate()->firstOrFail();
                if ($challenge->sent_at || $challenge->consumed_at || $challenge->invalidated_at) {
                    return;
                }
                if (! OtpSecurity::ready() || ! $member->eligible() || $challenge->expires_at->lte(now())) {
                    $challenge->update(['invalidated_at' => now()]);

                    return;
                }
                $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                $challenge->update(['verifier_hmac' => OtpSecurity::verifier($challenge->public_id, $code)]);
                $sender->send($member->phone_e164, $code);
                $challenge->update(['sent_at' => now()]);
                unset($code);
            });
        } catch (\Throwable) {
            // Do not persist a provider exception: it can contain the OTP or destination.
            OtpChallenge::whereKey($reference->id)->whereNull('consumed_at')->update(['invalidated_at' => now()]);
            OtpSecurity::event(AdminSession::digest('member:'.$reference->member_id), $reference->ip_digest, 'delivery_failed');
        }
    }
}
