<?php

namespace App\Modules\MarketPrices\Actions;

use App\Modules\MarketPrices\Models\ManualPriceOverride;
use App\Modules\MarketPrices\Models\PriceObservation;
use App\Modules\Markets\Models\Asset;
use Carbon\CarbonImmutable;

final class ResolveEffectivePrice
{
    public function for(Asset $asset, ?CarbonImmutable $at = null): array
    {
        $asset = $asset->fresh();
        $at ??= now()->toImmutable();
        $stamp = $at->format('Y-m-d H:i:s.u');
        if (! $asset->active || ! $asset->price_unit) {
            return $this->unavailable($asset, 'asset_not_configured');
        }

        $override = ManualPriceOverride::where('asset_id', $asset->id)
            ->whereNull('revoked_at')->where('starts_at', '<=', $stamp)->where('ends_at', '>', $stamp)
            ->with('observation')->latest('starts_at')->first();
        if ($override && $override->observation?->unit === $asset->price_unit) {
            return $this->quote($asset, $override->observation, 'manual', 'manual', $override->ends_at, null);
        }

        $observation = PriceObservation::where('asset_id', $asset->id)->where('source_kind', 'api')
            ->where('unit', $asset->price_unit)->where('observed_at', '<=', $stamp)
            ->whereHas('source', fn ($query) => $query->where('enabled', true)->where('market_id', $asset->market_id))
            ->with('source')->latest('observed_at')->first();
        if (! $observation) {
            return $this->unavailable($asset, 'no_valid_observation');
        }
        $staleAt = $observation->observed_at->addSeconds($observation->source->stale_after_seconds);
        $status = $staleAt->lte($at) ? 'stale' : 'fresh';
        $source = $observation->source;
        $error = $source->last_error_at && (! $source->last_success_at || $source->last_error_at->gt($source->last_success_at))
            ? $source->last_error_code
            : null;

        return $this->quote($asset, $observation, $status, 'api', $staleAt, $error);
    }

    private function quote(Asset $asset, PriceObservation $observation, string $status, string $kind, $validUntil, ?string $error): array
    {
        return ['available' => true, 'asset_id' => $asset->public_id, 'value' => $observation->value, 'unit' => $observation->unit, 'status' => $status, 'source_kind' => $kind, 'source' => $observation->source?->title, 'observed_at' => $observation->observed_at, 'received_at' => $observation->received_at, 'valid_until' => $validUntil, 'error_code' => $error];
    }

    private function unavailable(Asset $asset, string $reason): array
    {
        return ['available' => false, 'asset_id' => $asset->public_id, 'value' => null, 'unit' => $asset->price_unit, 'status' => 'unavailable', 'source_kind' => null, 'source' => null, 'observed_at' => null, 'received_at' => null, 'valid_until' => null, 'error_code' => $reason];
    }
}
