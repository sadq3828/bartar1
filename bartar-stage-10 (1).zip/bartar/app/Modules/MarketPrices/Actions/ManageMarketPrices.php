<?php

namespace App\Modules\MarketPrices\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\MarketPrices\Models\ManualPriceOverride;
use App\Modules\MarketPrices\Models\PriceObservation;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\Markets\Models\Asset;
use Carbon\CarbonInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManageMarketPrices
{
    public function __construct(private ManageAdministrators $security, private RecordAudit $audit) {}

    public function createSource(Account $actor, array $data): PriceSource
    {
        return DB::transaction(function () use ($actor, $data): PriceSource {
            $actor = $this->authorize($actor, 'manage_integrations', $data['current_password']);
            $source = PriceSource::create([
                'market_id' => $data['market_id'], 'key' => $data['key'], 'title' => $data['title'],
                'driver' => $data['driver'], 'enabled' => (bool) ($data['enabled'] ?? false),
                'refresh_seconds' => $data['refresh_seconds'], 'stale_after_seconds' => $data['stale_after_seconds'],
                'created_by' => $actor->id,
            ]);
            $this->audit->write($actor, 'price.source.created', 'price_source', $source->public_id, [], $source->only(['key', 'title', 'driver', 'enabled', 'refresh_seconds', 'stale_after_seconds']), $data['reason'], 'technical');

            return $source;
        }, 3);
    }

    public function recordManualOverride(Account $actor, Asset $asset, array $data): ManualPriceOverride
    {
        return DB::transaction(function () use ($actor, $asset, $data): ManualPriceOverride {
            $actor = $this->authorize($actor, 'prices.manual', $data['current_password']);
            abort_unless($actor->allows('prices.override'), 403);
            $asset = Asset::whereKey($asset->id)->where('active', true)->lockForUpdate()->firstOrFail();
            if (! $asset->price_unit) {
                throw ValidationException::withMessages(['asset' => 'واحد قیمت این دارایی هنوز تنظیم نشده است.']);
            }
            $start = $data['starts_at'];
            $end = $data['ends_at'];
            $observedAt = $data['observed_at'];
            $value = (string) $data['value'];
            if (! $start instanceof CarbonInterface || ! $end instanceof CarbonInterface || ! $observedAt instanceof CarbonInterface || $end->lte($start)) {
                throw ValidationException::withMessages(['ends_at' => 'پایان بازه باید بعد از شروع آن باشد.']);
            }
            if ($observedAt->gt(now()->addMinutes(5))) {
                throw ValidationException::withMessages(['observed_at' => 'زمان مشاهده نمی‌تواند در آینده باشد.']);
            }
            if (! preg_match('/\A(?:0|[1-9][0-9]{0,17})(?:\.\d{1,12})?\z/', $value) || bccomp($value, '0', 12) <= 0) {
                throw ValidationException::withMessages(['value' => 'قیمت باید یک عدد اعشاری مثبت و معتبر باشد.']);
            }
            if (ManualPriceOverride::where('asset_id', $asset->id)->whereNull('revoked_at')->where('starts_at', '<', $end->format('Y-m-d H:i:s.u'))->where('ends_at', '>', $start->format('Y-m-d H:i:s.u'))->exists()) {
                throw ValidationException::withMessages(['starts_at' => 'بازه override با یک قیمت دستی فعال هم‌پوشانی دارد.']);
            }
            $observation = PriceObservation::create([
                'asset_id' => $asset->id, 'source_id' => null, 'source_kind' => 'manual', 'value' => $value,
                'unit' => $asset->price_unit, 'observed_at' => $observedAt, 'received_at' => now(),
                'actor_id' => $actor->id, 'reason' => $data['reason'],
            ]);
            $override = ManualPriceOverride::create([
                'asset_id' => $asset->id, 'observation_id' => $observation->id, 'starts_at' => $start, 'ends_at' => $end,
                'actor_id' => $actor->id, 'reason' => $data['reason'],
            ]);
            $this->audit->write($actor, 'price.manual.activated', 'asset', $asset->public_id, [], ['observation_id' => $observation->public_id, 'value' => $observation->value, 'unit' => $observation->unit, 'starts_at' => $start->toIso8601String(), 'ends_at' => $end->toIso8601String()], $data['reason'], 'signals');

            return $override->load('observation');
        }, 3);
    }

    public function revokeOverride(Account $actor, Asset $asset, ManualPriceOverride $override, array $data): void
    {
        DB::transaction(function () use ($actor, $asset, $override, $data): void {
            $actor = $this->authorize($actor, 'prices.override', $data['current_password']);
            $asset = Asset::whereKey($asset->id)->lockForUpdate()->firstOrFail();
            $override = ManualPriceOverride::whereKey($override->id)->where('asset_id', $asset->id)->whereNull('revoked_at')->lockForUpdate()->firstOrFail();
            $override->update(['revoked_at' => now(), 'revoked_by' => $actor->id, 'revoke_reason' => $data['reason']]);
            $this->audit->write($actor, 'price.manual.revoked', 'asset', $asset->public_id, ['override_id' => $override->public_id, 'active' => true], ['override_id' => $override->public_id, 'active' => false], $data['reason'], 'signals');
        }, 3);
    }

    private function authorize(Account $actor, string $permission, string $password): Account
    {
        $this->security->lock();
        $actor = $actor->fresh();
        abort_unless($actor->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);

        return $actor;
    }
}
