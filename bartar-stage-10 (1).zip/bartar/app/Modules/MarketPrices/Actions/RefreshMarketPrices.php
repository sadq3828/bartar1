<?php

namespace App\Modules\MarketPrices\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\MarketPrices\Contracts\PriceProviderRegistry;
use App\Modules\MarketPrices\Models\PriceFetchRun;
use App\Modules\MarketPrices\Models\PriceObservation;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\MarketPrices\Support\PriceProviderException;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

final class RefreshMarketPrices
{
    public function __construct(private PriceProviderRegistry $providers, private RecordAudit $audit) {}

    public function due(): array
    {
        $results = [];
        foreach (PriceSource::where('enabled', true)->orderBy('id')->get() as $source) {
            if ($source->last_attempt_at && $source->last_attempt_at->addSeconds($source->refresh_seconds)->gt(now())) {
                continue;
            }
            $lastRun = PriceFetchRun::where('source_id', $source->id)->latest('id')->first(['status', 'next_retry_at']);
            if ($lastRun?->status === 'failed' && $lastRun->next_retry_at?->gt(now())) {
                continue;
            }
            $results[$source->key] = $this->source($source);
        }

        return $results;
    }

    public function source(PriceSource $source): string
    {
        $lockName = 'bartar-price-'.substr(hash('sha256', (string) $source->id), 0, 40);
        $acquired = (int) (DB::selectOne('SELECT GET_LOCK(?, 0) AS acquired', [$lockName])->acquired ?? 0);
        if ($acquired !== 1) {
            PriceFetchRun::create(['source_id' => $source->id, 'started_at' => now(), 'finished_at' => now(), 'status' => 'skipped', 'error_code' => 'overlap']);

            return 'skipped';
        }

        try {
            $source = $source->fresh();
            if (! $source->enabled) {
                return 'disabled';
            }
            $source->update(['last_attempt_at' => now()]);
            $run = PriceFetchRun::create(['source_id' => $source->id, 'started_at' => now(), 'status' => 'running']);
            $assets = $source->market->assets()->where('active', true)->whereNotNull('price_unit')->orderBy('id')->get();
            try {
                $payload = $this->validated($this->providers->for($source)->fetch($source, $assets), $assets);
                DB::transaction(function () use ($payload, $source, $run): void {
                    foreach ($payload as $row) {
                        PriceObservation::create(['asset_id' => $row['asset_id'], 'source_id' => $source->id, 'source_kind' => 'api', 'value' => $row['value'], 'unit' => $row['unit'], 'observed_at' => $row['observed_at'], 'received_at' => now(), 'actor_id' => null]);
                    }
                    $source->update(['last_success_at' => now(), 'last_error_at' => null, 'last_error_code' => null]);
                    $run->update(['finished_at' => now(), 'status' => 'succeeded', 'observation_count' => count($payload)]);
                });

                return 'succeeded';
            } catch (PriceProviderException $error) {
                return $this->failed($source, $run, $error->safeCode);
            } catch (Throwable) {
                return $this->failed($source, $run, 'provider_error');
            }
        } finally {
            DB::selectOne('SELECT RELEASE_LOCK(?) AS released', [$lockName]);
        }
    }

    private function validated(iterable $payload, $assets): array
    {
        $byPublicId = $assets->keyBy('public_id');
        $seen = [];
        $valid = [];
        foreach ($payload as $row) {
            if (! is_array($row) || ! isset($row['asset_id'], $row['value'], $row['unit'], $row['observed_at'])) {
                throw new PriceProviderException('invalid_payload');
            }
            $asset = $byPublicId->get((string) $row['asset_id']);
            $value = (string) $row['value'];
            if (! $asset || isset($seen[$asset->id]) || $row['unit'] !== $asset->price_unit || ! preg_match('/\A(?:0|[1-9][0-9]{0,17})(?:\.\d{1,12})?\z/', $value) || bccomp($value, '0', 12) <= 0) {
                throw new PriceProviderException('invalid_payload');
            }
            try {
                $observedAt = CarbonImmutable::parse($row['observed_at'])->utc();
            } catch (Throwable) {
                throw new PriceProviderException('invalid_payload');
            }
            if ($observedAt->gt(now()->addMinutes(5))) {
                throw new PriceProviderException('future_observation');
            }
            $seen[$asset->id] = true;
            $valid[] = ['asset_id' => $asset->id, 'value' => $value, 'unit' => $asset->price_unit, 'observed_at' => $observedAt];
        }
        if ($assets->isNotEmpty() && count($valid) === 0) {
            throw new PriceProviderException('empty_payload');
        }

        return $valid;
    }

    private function failed(PriceSource $source, PriceFetchRun $run, string $code): string
    {
        $retry = min(3600, max(60, $source->refresh_seconds));
        DB::transaction(function () use ($source, $run, $code, $retry): void {
            $source->update(['last_error_at' => now(), 'last_error_code' => Str::limit($code, 64, '')]);
            $run->update(['finished_at' => now(), 'status' => 'failed', 'error_code' => Str::limit($code, 64, ''), 'next_retry_at' => now()->addSeconds($retry)]);
            $this->audit->write(null, 'price.fetch.failed', 'price_source', $source->public_id, [], ['error_code' => $code], 'دریافت قیمت ناموفق', 'technical', 'system');
        });

        return 'failed';
    }
}
