<?php

namespace App\Modules\MarketPrices\Contracts;

use App\Modules\MarketPrices\Models\PriceSource;
use Illuminate\Support\Collection;

interface MarketPriceProvider
{
    /**
     * @return iterable<array{asset_id:string,value:string,unit:string,observed_at:\DateTimeInterface|string}>
     */
    public function fetch(PriceSource $source, Collection $assets): iterable;
}
