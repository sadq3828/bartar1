<?php

namespace App\Modules\MarketPrices\Contracts;

use App\Modules\MarketPrices\Models\PriceSource;

interface PriceProviderRegistry
{
    public function for(PriceSource $source): MarketPriceProvider;
}
