<?php

namespace App\Modules\MarketPrices\Infrastructure;

use App\Modules\MarketPrices\Contracts\MarketPriceProvider;
use App\Modules\MarketPrices\Contracts\PriceProviderRegistry;
use App\Modules\MarketPrices\Models\PriceSource;

final class ConfiguredPriceProviderRegistry implements PriceProviderRegistry
{
    public function __construct(
        private UnavailableMarketPriceProvider $unavailable,
        private NobitexPublicMarketPriceProvider $nobitex,
        private BinancePublicMarketPriceProvider $binance,
    ) {}

    public function for(PriceSource $source): MarketPriceProvider
    {
        return match ($source->driver) {
            'nobitex_public' => $this->nobitex,
            'binance_public' => $this->binance,
            'unavailable' => $this->unavailable,
            default => $this->unavailable,
        };
    }
}
