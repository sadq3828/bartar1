<?php

namespace App\Modules\MarketPrices\Infrastructure;

use App\Modules\MarketPrices\Contracts\MarketPriceProvider;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\MarketPrices\Support\PriceProviderException;
use Illuminate\Support\Collection;

final class UnavailableMarketPriceProvider implements MarketPriceProvider
{
    public function fetch(PriceSource $source, Collection $assets): iterable
    {
        throw new PriceProviderException('provider_unavailable');
    }
}
