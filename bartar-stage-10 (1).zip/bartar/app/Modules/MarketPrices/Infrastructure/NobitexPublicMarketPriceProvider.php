<?php

namespace App\Modules\MarketPrices\Infrastructure;

use App\Modules\MarketPrices\Contracts\MarketPriceProvider;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\MarketPrices\Support\PriceProviderException;
use Carbon\CarbonImmutable;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;

final class NobitexPublicMarketPriceProvider implements MarketPriceProvider
{
    private const ENDPOINT = 'https://apiv2.nobitex.ir/market/stats';

    public function fetch(PriceSource $source, Collection $assets): iterable
    {
        if ($assets->isEmpty()) {
            return [];
        }

        $symbols = $assets->map(function ($asset): string {
            if ($asset->price_unit !== 'IRT' || ! preg_match('/\A[A-Z0-9_]{2,20}\z/', $asset->symbol)) {
                throw new PriceProviderException('provider_asset_unsupported');
            }

            return strtolower($asset->symbol);
        })->values();

        try {
            $response = Http::acceptJson()->withUserAgent('Bartar/1.0 market-data')->withoutRedirecting()
                ->connectTimeout(3)->timeout(8)
                ->get(self::ENDPOINT, ['srcCurrency' => $symbols->implode(','), 'dstCurrency' => 'rls']);
        } catch (ConnectionException) {
            throw new PriceProviderException('provider_timeout');
        }

        $this->assertSuccessful($response->status());
        $payload = $response->json();
        if (! is_array($payload) || ($payload['status'] ?? null) !== 'ok' || ! is_array($payload['stats'] ?? null)) {
            throw new PriceProviderException('invalid_payload');
        }

        $observedAt = CarbonImmutable::now('UTC');

        return $assets->map(function ($asset) use ($payload, $observedAt): array {
            $row = $payload['stats'][strtolower($asset->symbol).'-rls'] ?? null;
            $latest = is_array($row) ? ($row['latest'] ?? null) : null;
            if (! is_string($latest) && ! is_int($latest)) {
                throw new PriceProviderException('provider_symbol_missing');
            }

            return [
                'asset_id' => $asset->public_id,
                'value' => bcdiv((string) $latest, '10', 12),
                'unit' => 'IRT',
                'observed_at' => $observedAt,
            ];
        })->all();
    }

    private function assertSuccessful(int $status): void
    {
        if ($status === 429) {
            throw new PriceProviderException('provider_rate_limited');
        }
        if ($status >= 500) {
            throw new PriceProviderException('provider_unavailable');
        }
        if ($status < 200 || $status >= 300) {
            throw new PriceProviderException('provider_http_error');
        }
    }
}
