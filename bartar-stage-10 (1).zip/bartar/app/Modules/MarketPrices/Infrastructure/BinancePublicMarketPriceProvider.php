<?php

namespace App\Modules\MarketPrices\Infrastructure;

use App\Modules\MarketPrices\Contracts\MarketPriceProvider;
use App\Modules\MarketPrices\Models\PriceSource;
use App\Modules\MarketPrices\Support\PriceProviderException;
use Carbon\CarbonImmutable;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;

final class BinancePublicMarketPriceProvider implements MarketPriceProvider
{
    private const ENDPOINT = 'https://data-api.binance.vision/api/v3/ticker/price';

    public function fetch(PriceSource $source, Collection $assets): iterable
    {
        if ($assets->isEmpty()) {
            return [];
        }

        $symbols = $assets->map(function ($asset): string {
            if ($asset->price_unit !== 'USDT' || ! preg_match('/\A[A-Z0-9]{2,16}\z/', $asset->symbol) || $asset->symbol === 'USDT') {
                throw new PriceProviderException('provider_asset_unsupported');
            }

            return $asset->symbol.'USDT';
        })->values();

        try {
            $response = Http::acceptJson()->withUserAgent('Bartar/1.0 market-data')->withoutRedirecting()
                ->connectTimeout(3)->timeout(8)
                ->get(self::ENDPOINT, ['symbols' => json_encode($symbols->all(), JSON_THROW_ON_ERROR), 'symbolStatus' => 'TRADING']);
        } catch (ConnectionException) {
            throw new PriceProviderException('provider_timeout');
        }

        $this->assertSuccessful($response->status());
        $payload = $response->json();
        if (! is_array($payload) || ! array_is_list($payload)) {
            throw new PriceProviderException('invalid_payload');
        }
        $prices = collect($payload)->filter(fn ($row) => is_array($row) && is_string($row['symbol'] ?? null))->keyBy('symbol');
        $observedAt = CarbonImmutable::now('UTC');

        return $assets->map(function ($asset) use ($prices, $observedAt): array {
            $price = $prices->get($asset->symbol.'USDT')['price'] ?? null;
            if (! is_string($price) && ! is_int($price)) {
                throw new PriceProviderException('provider_symbol_missing');
            }

            return ['asset_id' => $asset->public_id, 'value' => (string) $price, 'unit' => 'USDT', 'observed_at' => $observedAt];
        })->all();
    }

    private function assertSuccessful(int $status): void
    {
        if ($status === 429 || $status === 418) {
            throw new PriceProviderException('provider_rate_limited');
        }
        if ($status >= 500) {
            throw new PriceProviderException('provider_unavailable');
        }
        if ($status < 200 || $status >= 300) {
            throw new PriceProviderException('provider_http_error');
        }
    }
}
