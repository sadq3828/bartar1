<?php

namespace App\Modules\MarketPrices\Support;

use RuntimeException;

final class PriceProviderException extends RuntimeException
{
    public function __construct(public readonly string $safeCode)
    {
        parent::__construct('Market price provider failed.');
    }
}
