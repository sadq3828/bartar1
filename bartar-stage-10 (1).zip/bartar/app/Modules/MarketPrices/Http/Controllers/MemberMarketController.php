<?php

namespace App\Modules\MarketPrices\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\MarketPrices\Actions\ResolveEffectivePrice;
use App\Modules\Markets\Models\Market;
use Illuminate\Http\Request;

final class MemberMarketController extends Controller
{
    public function index(Request $request, ResolveEffectivePrice $prices)
    {
        $filters = $request->validate(['q' => ['nullable', 'string', 'max:100'], 'market' => ['nullable', 'string', 'max:64']]);
        $query = Market::where('active', true)->with(['assets' => fn ($assets) => $assets->where('active', true)->orderBy('title')])->orderBy('title');
        if (($filters['market'] ?? 'all') !== 'all') {
            $query->where('key', $filters['market']);
        }
        if ($term = trim((string) ($filters['q'] ?? ''))) {
            $query->whereHas('assets', fn ($assets) => $assets->where('active', true)->where(fn ($match) => $match->where('title', 'like', '%'.$term.'%')->orWhere('symbol', 'like', '%'.$term.'%')));
        }
        $markets = $query->get();
        if ($term) {
            $markets->each(fn ($market) => $market->setRelation('assets', $market->assets->filter(fn ($asset) => str_contains(mb_strtolower($asset->title), mb_strtolower($term)) || str_contains(strtolower($asset->symbol), strtolower($term)))->values()));
        }
        $quotes = $markets->flatMap->assets->mapWithKeys(fn ($asset) => [$asset->id => $prices->for($asset)]);

        return view('member.markets', ['title' => 'نمای بازار', 'active' => 'markets', 'area' => 'member', 'preview' => false, 'markets' => $markets, 'marketTabs' => Market::where('active', true)->orderBy('title')->get(), 'quotes' => $quotes, 'query' => $filters]);
    }
}
