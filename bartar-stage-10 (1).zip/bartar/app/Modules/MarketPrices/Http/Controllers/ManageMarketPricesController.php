<?php

namespace App\Modules\MarketPrices\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\MarketPrices\Actions\ManageMarketPrices;
use App\Modules\MarketPrices\Models\ManualPriceOverride;
use App\Modules\Markets\Models\Asset;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

final class ManageMarketPricesController extends Controller
{
    public function manual(Request $request, Asset $asset, ManageMarketPrices $manager)
    {
        $data = $request->validate([
            'value' => ['required', 'string', 'regex:/\A(?:0|[1-9][0-9]{0,17})(?:\.\d{1,12})?\z/', 'not_in:0,0.0,0.00'],
            'observed_at' => ['required', 'date_format:Y-m-d\TH:i'], 'starts_at' => ['required', 'date_format:Y-m-d\TH:i'],
            'ends_at' => ['required', 'date_format:Y-m-d\TH:i', 'after:starts_at'],
        ] + $this->sensitive());
        foreach (['observed_at', 'starts_at', 'ends_at'] as $field) {
            $data[$field] = CarbonImmutable::parse($data[$field], 'Asia/Tehran')->utc();
        }
        if ($data['observed_at']->gt(now()->addMinutes(5))) {
            return back()->withErrors(['observed_at' => 'زمان مشاهده نمی‌تواند در آینده باشد.'])->withInput();
        }
        $manager->recordManualOverride($request->user('admin'), $asset, $data);

        return back()->with('status', 'قیمت دستی با بازه اولویت مشخص ثبت شد.');
    }

    public function revoke(Request $request, Asset $asset, ManualPriceOverride $override, ManageMarketPrices $manager)
    {
        $data = $request->validate($this->sensitive());
        $manager->revokeOverride($request->user('admin'), $asset, $override, $data);

        return back()->with('status', 'اولویت قیمت دستی لغو شد؛ تاریخچه قیمت حفظ می‌شود.');
    }

    public function source(Request $request, ManageMarketPrices $manager)
    {
        $data = $request->validate(['market_id' => ['required', 'integer', 'exists:markets,id'], 'key' => ['required', 'string', 'max:64', 'regex:/\A[a-z0-9][a-z0-9_-]*\z/', 'unique:price_sources,key'], 'title' => ['required', 'string', 'max:120'], 'driver' => ['required', Rule::in(['nobitex_public', 'binance_public', 'unavailable'])], 'enabled' => ['nullable', 'boolean'], 'refresh_seconds' => ['required', 'integer', 'min:30', 'max:86400'], 'stale_after_seconds' => ['required', 'integer', 'min:30', 'max:604800', 'gte:refresh_seconds']] + $this->sensitive());
        $manager->createSource($request->user('admin'), $data);

        return back()->with('status', 'منبع قیمت ذخیره شد؛ نتیجه دریافت در اجرای بعدی scheduler ثبت می‌شود.');
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }
}
