<?php

namespace App\Modules\MarketPrices\Models;

use App\Modules\Markets\Models\Market;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PriceSource extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['enabled' => 'boolean', 'refresh_seconds' => 'integer', 'stale_after_seconds' => 'integer', 'last_attempt_at' => 'immutable_datetime', 'last_success_at' => 'immutable_datetime', 'last_error_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $source) => $source->public_id ??= (string) Str::ulid());
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function market()
    {
        return $this->belongsTo(Market::class);
    }

    public function observations()
    {
        return $this->hasMany(PriceObservation::class, 'source_id');
    }
}
