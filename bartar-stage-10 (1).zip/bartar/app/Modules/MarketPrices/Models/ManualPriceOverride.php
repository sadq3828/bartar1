<?php

namespace App\Modules\MarketPrices\Models;

use App\Modules\Markets\Models\Asset;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ManualPriceOverride extends Model
{
    public $timestamps = false;
    protected $dateFormat = 'Y-m-d H:i:s.u';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['starts_at' => 'immutable_datetime', 'ends_at' => 'immutable_datetime', 'revoked_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $override) => $override->public_id ??= (string) Str::ulid());
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }

    public function observation()
    {
        return $this->belongsTo(PriceObservation::class, 'observation_id');
    }
}
