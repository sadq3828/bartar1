<?php

namespace App\Modules\MarketPrices\Models;

use App\Modules\Markets\Models\Asset;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PriceObservation extends Model
{
    public $timestamps = false;
    protected $dateFormat = 'Y-m-d H:i:s.u';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['value' => 'decimal:12', 'observed_at' => 'immutable_datetime', 'received_at' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $observation) => $observation->public_id ??= (string) Str::ulid());
    }

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }

    public function source()
    {
        return $this->belongsTo(PriceSource::class, 'source_id');
    }
}
