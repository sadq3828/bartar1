<?php

namespace App\Modules\MarketPrices\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class PriceFetchRun extends Model
{
    public $timestamps = false;
    protected $dateFormat = 'Y-m-d H:i:s.u';
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['started_at' => 'immutable_datetime', 'finished_at' => 'immutable_datetime', 'next_retry_at' => 'immutable_datetime', 'retry_count' => 'integer', 'observation_count' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(fn (self $run) => $run->public_id ??= (string) Str::ulid());
    }
}
