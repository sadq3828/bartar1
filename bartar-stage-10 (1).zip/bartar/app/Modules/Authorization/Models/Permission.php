<?php

namespace App\Modules\Authorization\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];
}
