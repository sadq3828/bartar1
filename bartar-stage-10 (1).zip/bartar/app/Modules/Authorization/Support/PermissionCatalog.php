<?php

namespace App\Modules\Authorization\Support;

final class PermissionCatalog
{
    public static function permissions(): array
    {
        return [
            'all_modules' => 'دسترسی کامل تجاری', 'dashboard.view' => 'مشاهده داشبورد',
            'members.delete' => 'حذف مجاز عضو', 'signals.delete' => 'حذف مجاز سیگنال', 'markets.delete' => 'حذف مجاز بازار', 'cms.delete' => 'حذف مجاز محتوا', 'notifications.delete' => 'حذف مجاز اعلان',
            'admins.manage' => 'مدیریت حساب مدیران', 'manage_roles' => 'مدیریت نقش و مجوز',
            'delete_records' => 'حذف مجاز رکوردهای تجاری', 'manage_backups' => 'مدیریت بکاپ',
            'revoke_sessions' => 'لغو نشست مدیران', 'manage_integrations' => 'مدیریت اتصال سرویس‌ها',
            'sessions.view.all' => 'مشاهده نشست مدیران', 'audit.view' => 'مشاهده همه ممیزی‌ها',
            'audit.subscriptions' => 'مشاهده ممیزی اشتراک', 'audit.signals' => 'مشاهده ممیزی سیگنال',
            'audit.cms' => 'مشاهده ممیزی محتوا', 'audit.technical' => 'مشاهده ممیزی فنی',
            'members.view' => 'مشاهده اعضا', 'members.create' => 'افزودن عضو', 'members.update' => 'ویرایش عضو', 'members.block' => 'مسدودسازی عضو',
            'subscriptions.view' => 'مشاهده اشتراک', 'subscriptions.activate' => 'فعال‌سازی اشتراک', 'subscriptions.renew' => 'تمدید اشتراک', 'subscriptions.revoke' => 'لغو اشتراک',
            'payments.view' => 'مشاهده پرداخت', 'payments.create' => 'ثبت پرداخت', 'payments.confirm' => 'تأیید پرداخت',
            'signals.view' => 'مشاهده سیگنال', 'signals.create' => 'ایجاد سیگنال', 'signals.update' => 'ویرایش سیگنال', 'signals.publish' => 'انتشار سیگنال', 'signals.result' => 'ثبت نتیجه سیگنال',
            'media.view' => 'مشاهده رسانه', 'media.upload' => 'بارگذاری رسانه', 'media.reorder' => 'ترتیب رسانه', 'media.delete' => 'حذف منطقی رسانه',
            'markets.view' => 'مشاهده بازار', 'markets.create' => 'ایجاد بازار', 'markets.update' => 'ویرایش بازار', 'markets.deactivate' => 'غیرفعال‌سازی بازار',
            'prices.view' => 'مشاهده قیمت', 'prices.manual' => 'ثبت دستی قیمت', 'prices.override' => 'اولویت دستی قیمت',
            'cms.view' => 'مشاهده محتوا', 'cms.create' => 'ایجاد محتوا', 'cms.update' => 'ویرایش محتوا', 'cms.publish' => 'انتشار محتوا',
            'notifications.view' => 'مشاهده اعلان', 'notifications.create' => 'ایجاد اعلان حوزه مجاز', 'notifications.publish' => 'انتشار اعلان حوزه مجاز',
            'reports.view' => 'مشاهده گزارش تجمیعی', 'reports.export' => 'خروجی گزارش مجاز',
            'backups.view' => 'مشاهده وضعیت بکاپ', 'health.view' => 'مشاهده سلامت', 'settings.brand' => 'تنظیمات برند', 'settings.security' => 'تنظیمات امنیتی',
        ];
    }

    public static function roles(): array
    {
        return [
            'owner' => ['title' => 'مدیر اصلی', 'permissions' => array_keys(self::permissions())],
            'subscription_manager' => ['title' => 'مدیر اشتراک', 'permissions' => ['dashboard.view', 'members.view', 'members.create', 'members.update', 'members.block', 'subscriptions.view', 'subscriptions.activate', 'subscriptions.renew', 'subscriptions.revoke', 'payments.view', 'payments.create', 'payments.confirm', 'audit.subscriptions']],
            'signal_manager' => ['title' => 'مدیر سیگنال', 'permissions' => ['dashboard.view', 'signals.view', 'signals.create', 'signals.update', 'signals.publish', 'signals.result', 'media.view', 'media.upload', 'media.reorder', 'media.delete', 'markets.view', 'prices.view', 'audit.signals']],
            'content_manager' => ['title' => 'مدیر محتوا', 'permissions' => ['dashboard.view', 'cms.view', 'cms.create', 'cms.update', 'cms.publish', 'notifications.view', 'notifications.create', 'notifications.publish', 'settings.brand', 'audit.cms']],
            'report_manager' => ['title' => 'مدیر گزارش', 'permissions' => ['dashboard.view', 'reports.view', 'reports.export', 'signals.view', 'markets.view', 'prices.view']],
            'viewer' => ['title' => 'مشاهده‌گر', 'permissions' => ['dashboard.view', 'reports.view', 'signals.view', 'markets.view', 'prices.view']],
            'technical' => ['title' => 'مدیر فنی', 'permissions' => ['dashboard.view', 'health.view', 'settings.security', 'manage_integrations', 'backups.view', 'manage_backups', 'revoke_sessions', 'sessions.view.all', 'audit.technical']],
        ];
    }
}
