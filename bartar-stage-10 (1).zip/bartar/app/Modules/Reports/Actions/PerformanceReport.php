<?php

namespace App\Modules\Reports\Actions;

use App\Modules\Signals\Models\Signal;
use Carbon\CarbonImmutable;

final class PerformanceReport
{
    public function query(array $filters)
    {
        $query = Signal::memberVisible()->with(['market', 'asset', 'results.exits', 'results.calculations']);
        foreach (['market' => 'market_id', 'asset' => 'asset_id', 'status' => 'status'] as $key => $column) {
            if ($filters[$key] ?? null) {
                $query->where($column, $filters[$key]);
            }
        }
        if ($filters['from'] ?? null) {
            $query->where('published_at', '>=', CarbonImmutable::parse($filters['from'], 'Asia/Tehran')->startOfDay()->utc());
        }
        if ($filters['to'] ?? null) {
            $query->where('published_at', '<', CarbonImmutable::parse($filters['to'], 'Asia/Tehran')->startOfDay()->addDay()->utc());
        }

        return $query;
    }

    public function calculation($result): ?array
    {
        if (! $result) {
            return null;
        }

        return $result->calculations->firstWhere('formula_version', CalculateSignalReturn::VERSION)?->toArray() ?? app(CalculateSignalReturn::class)->preview($result);
    }

    public function summary(array $filters): array
    {
        $stats = array_fill_keys(['total', 'published', 'completed', 'cancelled', 'expired', 'positive', 'negative', 'zero', 'incomplete', 'n'], 0);
        foreach ($this->query($filters)->lazyById(200) as $signal) {
            $stats['total']++;
            $stats[$signal->status]++;
            if ($signal->status !== 'completed') {
                continue;
            }
            $value = $this->calculation($signal->results->first());
            if (($value['state'] ?? null) !== 'complete') {
                $stats['incomplete']++;

                continue;
            }
            $stats['n']++;
            $stats[$value['outcome']]++;
        }
        $stats['success_rate'] = $stats['n'] ? bcdiv(bcmul((string) $stats['positive'], '100', 8), (string) $stats['n'], 2) : null;

        return $stats;
    }
}
