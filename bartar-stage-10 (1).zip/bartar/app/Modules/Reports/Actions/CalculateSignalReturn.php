<?php

namespace App\Modules\Reports\Actions;

use App\Modules\Reports\Models\SignalResultCalculation;
use App\Modules\Signals\Models\SignalResult;
use App\Modules\Signals\Models\SignalRevision;

final class CalculateSignalReturn
{
    public const VERSION = 'weighted-gross-v1';

    // All inputs are immutable: the revision immediately before this result,
    // its execution entry, and the append-only exits. Never use today's signal.
    public function preview(SignalResult $result): array
    {
        $revision = SignalRevision::where('signal_id', $result->signal_id)->where('version', $result->version - 1)->first();
        $signal = $revision?->snapshot_json['signal'] ?? [];
        $entry = $result->entry_execution_price;
        if ($entry === null && isset($signal['entry_low']) && (! isset($signal['entry_high']) || bccomp((string) $signal['entry_low'], (string) $signal['entry_high'], 12) === 0)) {
            $entry = (string) $signal['entry_low'];
        }

        return $this->calculate($signal['direction'] ?? null, $entry, $result->loadMissing('exits')->exits->map->only(['exit_price', 'exit_weight'])->all(), $result->coverage_ratio);
    }

    public function persist(SignalResult $result): SignalResultCalculation
    {
        return SignalResultCalculation::firstOrCreate(['signal_result_id' => $result->id, 'formula_version' => self::VERSION], $this->preview($result) + ['computed_at' => now()]);
    }

    public function calculate(?string $direction, ?string $entry, array $exits, ?string $declaredCoverage = null): array
    {
        $coverage = '0.000000';
        $weighted = '0';
        foreach ($exits as $exit) {
            $coverage = bcadd($coverage, (string) $exit['exit_weight'], 6);
            $weighted = bcadd($weighted, bcmul((string) $exit['exit_price'], (string) $exit['exit_weight'], 18), 18);
        }
        $base = ['formula_version' => self::VERSION, 'coverage' => $coverage, 'realised_return' => null, 'final_return' => null, 'state' => 'unavailable', 'reason_code' => null, 'outcome' => 'unknown', 'inputs_json' => ['direction' => $direction, 'entry' => $entry, 'declared_coverage' => $declaredCoverage, 'exits' => $exits]];
        if (bccomp($coverage, '1', 6) > 0 || bccomp($coverage, '0', 6) <= 0 || ($declaredCoverage !== null && bccomp($coverage, $declaredCoverage, 6) !== 0)) {
            return array_replace($base, ['coverage' => bccomp($coverage, '1', 6) > 0 ? '1.000000' : $coverage, 'reason_code' => 'invalid_coverage']);
        }
        if (! in_array($direction, ['buy', 'sell'], true)) {
            return array_replace($base, ['reason_code' => 'missing_snapshot']);
        }
        if ($entry === null || bccomp($entry, '0', 12) <= 0) {
            return array_replace($base, ['reason_code' => 'entry_execution_required']);
        }
        $difference = bcsub($weighted, bcmul($entry, $coverage, 18), 18);
        if ($direction === 'sell') {
            $difference = bcsub('0', $difference, 18);
        }
        $raw = bcdiv(bcmul('100', $difference, 20), $entry, 32);
        $rounded = bcadd($raw, bccomp($raw, '0', 32) < 0 ? '-0.000000005' : '0.000000005', 8);
        $complete = bccomp($coverage, '1', 6) === 0;
        $sign = bccomp($difference, '0', 18);

        return array_replace($base, ['realised_return' => $rounded, 'final_return' => $complete ? $rounded : null, 'state' => $complete ? 'complete' : 'partial', 'outcome' => $complete ? ($sign > 0 ? 'positive' : ($sign < 0 ? 'negative' : 'zero')) : 'unknown']);
    }
}
