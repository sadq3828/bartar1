<?php

namespace App\Modules\Reports\Models;

use Illuminate\Database\Eloquent\Model;

class SignalResultCalculation extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['inputs_json' => 'array', 'computed_at' => 'immutable_datetime', 'coverage' => 'decimal:6', 'realised_return' => 'decimal:8', 'final_return' => 'decimal:8'];
    }
}
