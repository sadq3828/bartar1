<?php

namespace App\Modules\Reports\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use App\Modules\Reports\Actions\PerformanceReport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

final class PerformanceController extends Controller
{
    private function filters(Request $request): array
    {
        return $request->validate([
            'market' => ['nullable', 'integer', 'exists:markets,id'], 'asset' => ['nullable', 'integer', 'exists:assets,id'],
            'status' => ['nullable', Rule::in(['published', 'completed', 'cancelled', 'expired'])],
            'from' => ['nullable', 'date_format:Y-m-d'], 'to' => ['nullable', 'date_format:Y-m-d', Rule::when((bool) $request->input('from'), ['after_or_equal:from'])],
        ]);
    }

    public function index(Request $request, PerformanceReport $reports)
    {
        $admin = $request->is('admin/*');
        $filters = $this->filters($request);

        return view('reports.performance', [
            'title' => 'گزارش عملکرد', 'active' => $admin ? 'reports' : 'performance', 'area' => $admin ? 'admin' : 'member', 'preview' => false,
            'adminUser' => $admin ? $request->user('admin') : null, 'filters' => $filters, 'stats' => $reports->summary($filters),
            'signals' => $reports->query($filters)->latest('published_at')->orderByDesc('id')->paginate(20)->withQueryString(), 'reports' => $reports,
            'markets' => Market::whereHas('assets.signals', fn ($q) => $q->memberVisible())->orderBy('title')->get(),
            'assets' => Asset::whereHas('signals', fn ($q) => $q->memberVisible())->when($filters['market'] ?? null, fn ($q, $id) => $q->where('market_id', $id))->orderBy('symbol')->get(),
        ]);
    }

    public static function csvCell(mixed $value): string
    {
        $text = (string) ($value ?? '');

        return preg_match('/\A[\s\x00-\x20]*[=+\-@]/u', $text) ? "'".$text : $text;
    }

    public function export(Request $request, PerformanceReport $reports, ManageAdministrators $security, RecordAudit $audit)
    {
        $filters = $this->filters($request);
        $data = $request->validate(['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']]);
        $actor = DB::transaction(function () use ($request, $security, $audit, $data, $filters) {
            $security->lock();
            $actor = $request->user('admin')->fresh();
            abort_unless($actor->allows('reports.view') && $actor->allows('reports.export'), 403);
            $security->confirmPassword($actor, $data['current_password']);
            $audit->write($actor, 'report.exported', 'performance_report', null, [], ['filters' => $filters], $data['reason'], 'signals');

            return $actor;
        });

        return response()->streamDownload(function () use ($actor, $filters, $reports): void {
            abort_unless($actor->fresh()->allows('reports.export'), 403);
            $out = fopen('php://output', 'wb');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['signal_id', 'title', 'market', 'asset', 'published_at_utc', 'status', 'result_version', 'formula_version', 'coverage', 'realised_gross_pct', 'final_gross_pct', 'state'], ',', '"', '');
            foreach ($reports->query($filters)->lazyById(200) as $signal) {
                $result = $signal->results->first();
                $value = $reports->calculation($result);
                $row = [$signal->public_id, $signal->title, $signal->market->title, $signal->asset->symbol, $signal->published_at->utc()->toIso8601String(), $signal->status, $result?->version, $value['formula_version'] ?? null, $value['coverage'] ?? null, $value['realised_return'] ?? null, $value['final_return'] ?? null, $value['state'] ?? 'unavailable'];
                fputcsv($out, array_map(self::csvCell(...), $row), ',', '"', '');
            }
            fclose($out);
        }, 'bartar-performance.csv', ['Content-Type' => 'text/csv; charset=UTF-8', 'Cache-Control' => 'private, no-store']);
    }
}
