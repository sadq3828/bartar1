<?php

namespace App\Modules\Administration\Policies;

use App\Modules\Authentication\Models\Account;

class AccountPolicy
{
    public function viewAny(Account $actor): bool
    {
        return $actor->allows('admins.manage');
    }

    public function create(Account $actor): bool
    {
        return $actor->allows('admins.manage');
    }

    public function update(Account $actor, Account $target): bool
    {
        return $target->kind === 'admin' && $actor->allows('admins.manage');
    }
}
