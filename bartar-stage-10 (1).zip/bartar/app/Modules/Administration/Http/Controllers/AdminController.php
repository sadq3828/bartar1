<?php

namespace App\Modules\Administration\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\AuditLogs\Models\AuditLog;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authentication\Models\AuthenticationEvent;
use App\Modules\Authorization\Models\Role;
use App\Modules\Authorization\Support\PermissionCatalog;
use App\Modules\Signals\Models\Signal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
    private function data(Request $request, string $title, string $active, array $extra = []): array
    {
        return array_merge(['title' => $title, 'active' => $active, 'area' => 'admin', 'adminUser' => $request->user('admin'), 'preview' => false], $extra);
    }

    public function dashboard(Request $request)
    {
        $user = $request->user('admin');
        $stats = [];
        if ($user->allows('admins.manage')) {
            $stats['مدیران فعال'] = Account::where('kind', 'admin')->whereNull('disabled_at')->count();
        }
        if ($user->allows('manage_roles')) {
            $stats['نقش‌های تعریف‌شده'] = Role::count();
        }
        if ($user->allows('signals.view')) {
            $stats['سیگنال‌های فعال'] = Signal::where('status', 'published')->count();
            $stats['انتشار زمان‌بندی‌شده'] = Signal::where('status', 'scheduled')->count();
        }
        $stats['نشست‌های فعال شما'] = AdminSession::where('account_id', $user->id)->whereNull('revoked_at')->where('auth_version', $user->auth_version)->where('last_seen_at', '>', now()->subMinutes((int) config('session.lifetime')))->count();

        return view('admin.dashboard', $this->data($request, 'داشبورد مدیریت', 'dashboard', ['stats' => $stats]));
    }

    public function admins(Request $request)
    {
        return view('admin.accounts.index', $this->data($request, 'مدیران سامانه', 'admins', ['accounts' => Account::where('kind', 'admin')->with('roles')->latest('id')->paginate(20)]));
    }

    public function create(Request $request)
    {
        return view('admin.accounts.form', $this->data($request, 'افزودن مدیر', 'admins', ['account' => null, 'roles' => Role::all()]));
    }

    public function edit(Request $request, Account $account)
    {
        Gate::forUser($request->user('admin'))->authorize('update', $account);
        abort_unless($account->kind === 'admin', 404);

        return view('admin.accounts.form', $this->data($request, 'ویرایش مدیر', 'admins', ['account' => $account, 'roles' => Role::all()]));
    }

    private function accountData(Request $request, bool $creating): array
    {
        if ($creating) {
            $request->merge(['username' => strtolower(trim((string) $request->input('username')))]);
        }
        $rules = ['display_name' => ['nullable', 'string', 'max:100'], 'role_ids' => ['required', 'array', 'min:1'], 'role_ids.*' => ['integer', 'distinct', 'exists:roles,id'], 'current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
        if ($creating) {
            $rules += ['username' => ['required', 'string', 'min:3', 'max:64', 'regex:/\A[a-z0-9][a-z0-9._-]*\z/', 'unique:accounts,username'], 'password' => ['required', 'string', 'min:12', 'max:128', 'confirmed']];
        } else {
            $rules['disabled'] = ['nullable', 'boolean'];
        }

        return $request->validate($rules);
    }

    public function store(Request $request, ManageAdministrators $manager)
    {
        $account = $manager->create($request->user('admin'), $this->accountData($request, true));

        return redirect()->route('admin.accounts.edit', $account)->with('status', 'مدیر جدید ثبت شد.');
    }

    public function update(Request $request, Account $account, ManageAdministrators $manager)
    {
        Gate::forUser($request->user('admin'))->authorize('update', $account);
        $manager->update($request->user('admin'), $account, $this->accountData($request, false));

        return redirect()->route('admin.accounts.index')->with('status', 'تغییرات مدیر ثبت شد.');
    }

    public function roles(Request $request)
    {
        return view('admin.roles.index', $this->data($request, 'نقش‌ها و مجوزها', 'roles', ['roles' => Role::withCount('permissions')->get()]));
    }

    public function editRole(Request $request, Role $role)
    {
        return view('admin.roles.form', $this->data($request, 'ویرایش نقش', 'roles', ['role' => $role, 'catalog' => PermissionCatalog::permissions()]));
    }

    public function updateRole(Request $request, Role $role, ManageAdministrators $manager)
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:100'], 'permission_keys' => ['nullable', 'array'], 'permission_keys.*' => ['string', 'distinct', Rule::in(array_keys(PermissionCatalog::permissions()))], 'current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']]);
        $manager->updateRole($request->user('admin'), $role, $data);

        return redirect()->route('admin.roles.index')->with('status', 'مجوزهای نقش ذخیره شدند.');
    }

    public function sessions(Request $request)
    {
        $query = AdminSession::with('account')->latest('id');
        if (! $request->user('admin')->allows('sessions.view.all')) {
            $query->where('account_id', $request->user('admin')->id);
        }

        return view('admin.sessions', $this->data($request, 'نشست‌ها', 'sessions', ['sessions' => $query->paginate(20), 'currentSession' => $request->attributes->get('admin_session')]));
    }

    public function revokeSession(Request $request, AdminSession $adminSession, ManageAdministrators $manager, RecordAudit $audit)
    {
        $user = $request->user('admin');
        abort_unless($adminSession->account_id === $user->id || $user->allows('revoke_sessions'), 403);
        $data = $request->validate(['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']]);
        DB::transaction(function () use ($manager, $audit, $user, $adminSession, $data): void {
            $manager->lock();
            abort_unless($adminSession->account_id === $user->id || $user->fresh()->allows('revoke_sessions'), 403);
            $manager->confirmPassword($user, $data['current_password']);
            $record = AdminSession::whereKey($adminSession->id)->lockForUpdate()->firstOrFail();
            if (! $record->revoked_at) {
                $record->update(['revoked_at' => now()]);
                $audit->write($user, 'session.revoked', 'admin_session', $record->public_id, [], [], $data['reason'], 'technical');
            }
        });

        return redirect()->route('admin.sessions')->with('status', 'نشست لغو شد.');
    }

    public function audit(Request $request)
    {
        $user = $request->user('admin');
        $query = AuditLog::latest('id');
        if (! $user->allows('audit.view')) {
            $scopes = [];
            foreach (['subscriptions', 'signals', 'cms', 'technical'] as $scope) {
                if ($user->allows('audit.'.$scope)) {
                    $scopes[] = $scope;
                }
            }
            abort_unless($scopes, 403);
            $query->whereIn('scope', $scopes);
        }

        return view('admin.audit', $this->data($request, 'ممیزی عملیات', 'audit', ['entries' => $query->paginate(30)]));
    }

    public function security(Request $request)
    {
        $events = AuthenticationEvent::where('subject_hash', AdminSession::digest('username:'.$request->user('admin')->username))->latest('id')->limit(30)->get();

        return view('admin.security', $this->data($request, 'امنیت حساب', 'security', ['events' => $events]));
    }

    public function password(Request $request, ManageAdministrators $manager, RecordAudit $audit)
    {
        $data = $request->validate(['current_password' => ['required', 'string', 'max:128'], 'password' => ['required', 'string', 'min:12', 'max:128', 'confirmed']]);
        DB::transaction(function () use ($request, $manager, $audit, $data): void {
            $manager->lock();
            $user = $request->user('admin')->fresh();
            $manager->confirmPassword($user, $data['current_password']);
            $user->password_hash = $data['password'];
            $user->auth_version++;
            $user->save();
            AdminSession::where('account_id', $user->id)->whereNull('revoked_at')->update(['revoked_at' => now()]);
            $audit->write($user,'password.changed','account',$user->public_id);
        });
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login')->with('status','رمز تغییر کرد؛ دوباره وارد شوید.');
    }
}
