<?php

namespace App\Modules\Administration\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Authorization\Models\Permission;
use App\Modules\Authorization\Models\Role;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

final class ManageAdministrators
{
    public function __construct(private RecordAudit $audit) {}

    public function confirmPassword(Account $actor, string $password): void
    {
        $fresh = Account::findOrFail($actor->id);
        if ($fresh->disabled_at || ! Hash::check($password, $fresh->password_hash)) {
            throw ValidationException::withMessages(['current_password' => 'رمز تأیید صحیح نیست.']);
        }
    }

    public function lock(): void
    {
        DB::table('security_locks')->where('id', 1)->lockForUpdate()->firstOrFail();
    }

    private function mayDelegate(Account $actor, array $keys): void
    {
        $actor = $actor->fresh();
        foreach ($keys as $key) {
            abort_unless($actor->allows($key), 403, 'امکان واگذاری یا تغییر مجوزی بالاتر از دسترسی خودتان وجود ندارد.');
        }
    }

    private function roleKeys(array $ids): array
    {
        return Role::whereIn('id', $ids)->with('permissions')->get()->flatMap(fn ($role) => $role->permissions->pluck('key'))->unique()->all();
    }

    public function create(Account $actor, array $data): Account
    {
        return DB::transaction(function () use ($actor, $data) {
            $this->lock();
            abort_unless($actor->fresh()->allows('admins.manage'), 403);
            $this->confirmPassword($actor, $data['current_password']);
            $this->mayDelegate($actor, $this->roleKeys($data['role_ids']));
            $account = Account::create(['kind' => 'admin', 'username' => $data['username'], 'display_name' => $data['display_name'] ?? null, 'password_hash' => $data['password']]);
            $account->roles()->sync($data['role_ids']);
            $this->audit->write($actor, 'admin.created', 'account', $account->public_id, [], ['username' => $account->username, 'roles' => $account->roles()->pluck('key')->all()], $data['reason']);

            return $account;
        }, 3);
    }

    public function update(Account $actor, Account $target, array $data): void
    {
        DB::transaction(function () use ($actor, $target, $data): void {
            $this->lock();
            abort_unless($actor->fresh()->allows('admins.manage'), 403);
            $this->confirmPassword($actor, $data['current_password']);
            $target = Account::whereKey($target->id)->lockForUpdate()->firstOrFail();
            abort_unless($target->kind === 'admin', 404);
            $before = ['display_name' => $target->display_name, 'disabled' => (bool) $target->disabled_at, 'roles' => $target->roles()->pluck('key')->all()];
            $oldRoleIds = $target->roles()->pluck('roles.id')->sort()->values()->all();
            $newRoleIds = collect($data['role_ids'])->map(fn ($id) => (int) $id)->unique()->sort()->values()->all();
            $this->mayDelegate($actor, $this->roleKeys(array_unique(array_merge($oldRoleIds, $newRoleIds))));
            $disable = (bool) ($data['disabled'] ?? false);
            $target->display_name = $data['display_name'] ?? null;
            $target->disabled_at = $disable ? ($target->disabled_at ?? now()) : null;
            if ($disable || $oldRoleIds !== $newRoleIds) {
                $target->auth_version++;
            }
            $target->save();
            $target->roles()->sync($newRoleIds);
            $this->ensureOwnerRemains();
            if ($disable || $oldRoleIds !== $newRoleIds) {
                AdminSession::where('account_id', $target->id)->whereNull('revoked_at')->update(['revoked_at' => now()]);
            }
            $this->audit->write($actor, 'admin.updated', 'account', $target->public_id, $before, ['display_name' => $target->display_name, 'disabled' => $disable, 'roles' => $target->roles()->pluck('key')->all()], $data['reason']);
        }, 3);
    }

    public function updateRole(Account $actor, Role $role, array $data): void
    {
        DB::transaction(function () use ($actor, $role, $data): void {
            $this->lock();
            abort_unless($actor->fresh()->allows('manage_roles'), 403);
            $this->confirmPassword($actor, $data['current_password']);
            $role = Role::whereKey($role->id)->lockForUpdate()->firstOrFail();
            $keys = $data['permission_keys'] ?? [];
            $this->mayDelegate($actor, array_unique(array_merge($keys, $role->permissions()->pluck('key')->all())));
            if ($role->protected && ! in_array('all_modules', $keys, true)) {
                throw ValidationException::withMessages(['permission_keys' => 'نقش مدیر اصلی باید دسترسی کامل داشته باشد.']);
            }
            $before = ['title' => $role->title, 'permissions' => $role->permissions()->pluck('key')->all()];
            $role->update(['title' => $data['title']]);
            $role->permissions()->sync(Permission::whereIn('key', $keys)->pluck('id'));
            $this->ensureOwnerRemains();
            $this->audit->write($actor, 'role.updated', 'role', (string) $role->id, $before, ['title' => $role->title, 'permissions' => $keys], $data['reason']);
        }, 3);
    }

    private function ensureOwnerRemains(): void
    {
        $exists = Account::where('kind', 'admin')->whereNull('disabled_at')->whereHas('roles.permissions', fn ($q) => $q->where('key','all_modules'))->exists();
        if (! $exists) {
            throw ValidationException::withMessages(['role_ids' => 'حداقل یک مدیر اصلی فعال باید باقی بماند.']);
        }
    }
}
