<?php

namespace App\Modules\Members\Models;

use App\Modules\Authentication\Models\Account;
use App\Modules\Members\Support\IranianPhone;
use App\Modules\Subscriptions\Models\Subscription;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Member extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    protected $guarded = ['id'];

    protected $hidden = ['phone_e164', 'phone_hash', 'internal_note'];

    protected function casts(): array
    {
        return ['phone_e164' => 'encrypted', 'internal_note' => 'encrypted', 'blocked_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $m): void {
            $m->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function account()
    {
        return $this->belongsTo(Account::class);
    }

    public function subscription()
    {
        return $this->hasOne(Subscription::class);
    }

    public function maskedPhone(): string
    {
        return IranianPhone::mask($this->phone_e164);
    }

    public function eligible(): bool
    {
        $account = $this->account()->first();
        $subscription = $this->subscription()->first();

        return ! $this->blocked_at && $account?->kind === 'member' && ! $account->disabled_at && $subscription && ! $subscription->revoked_at && $subscription->starts_at->lte(now()) && $subscription->ends_at->gt(now());
    }
}
