<?php

namespace App\Modules\Members\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Members\Models\Member;
use App\Modules\Signals\Models\Signal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

final class MemberController extends Controller
{
    public function page(Request $request, string $page = 'home')
    {
        abort_unless(in_array($page, ['home', 'account', 'subscription', 'signals', 'markets', 'performance', 'notifications'], true), 404);
        $member = $request->attributes->get('member');
        $title = ['home' => 'خانه', 'account' => 'حساب کاربری', 'subscription' => 'اشتراک من', 'signals' => 'سیگنال‌ها', 'markets' => 'نمای بازار', 'performance' => 'عملکرد سیگنال‌ها', 'notifications' => 'اعلان‌ها'][$page];

        return view('member.live.page', ['title' => $title, 'active' => $page, 'area' => 'member', 'preview' => false, 'page' => $page, 'member' => $member, 'subscription' => $member->subscription()->with('plan')->firstOrFail(), 'latestSignals' => $page === 'home' ? Signal::memberVisible()->where('status', 'published')->with(['market', 'asset'])->latest('published_at')->limit(3)->get() : collect()]);
    }

    public function profile(Request $request, RecordAudit $audit)
    {
        $data = $request->validate(['display_name' => ['nullable', 'string', 'max:100']]);
        $member = $request->attributes->get('member');
        DB::transaction(function () use ($member, $data, $audit): void {
            $member = Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            abort_unless($member->eligible(), 403);
            $account = $member->account()->firstOrFail();
            $before = $account->display_name;
            $account->update(['display_name' => $data['display_name'] ?? null]);
            $audit->write($account, 'member.profile.updated', 'member', $member->public_id, ['display_name' => $before], ['display_name' => $account->display_name], null, 'security', 'member');
        });

        return redirect()->route('member.account')->with('status', 'نام نمایشی ذخیره شد.');
    }

    public function logout(Request $request, RecordAudit $audit)
    {
        $member = $request->attributes->get('member');
        DB::transaction(function () use ($request, $member, $audit): void {
            $request->attributes->get('member_session')->update(['revoked_at' => now()]);
            $audit->write($request->user('member'), 'member.logout', 'member', $member->public_id, [], [], null, 'security', 'member');
        });
        Auth::guard('member')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    public function status(Request $request)
    {
        $member = $request->attributes->get('member');

        return response()->json(['active' => true, 'member_id' => $member->public_id, 'ends_at' => $member->subscription->ends_at->toIso8601String()]);
    }
}
