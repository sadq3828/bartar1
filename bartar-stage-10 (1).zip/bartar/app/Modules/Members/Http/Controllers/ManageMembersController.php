<?php

namespace App\Modules\Members\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Members\Support\IranianPhone;
use App\Modules\Subscriptions\Actions\ManageManualPayments;
use App\Modules\Subscriptions\Actions\ManageSubscriptions;
use App\Modules\Subscriptions\Models\ManualPayment;
use App\Modules\Subscriptions\Models\Plan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

final class ManageMembersController extends Controller
{
    private function data(Request $r, string $title, array $extra = []): array
    {
        return array_merge(['title' => $title, 'active' => 'members', 'area' => 'admin', 'preview' => false, 'adminUser' => $r->user('admin')], $extra);
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }

    private function fields(Request $r): array
    {
        return $r->validate(array_merge($this->sensitive(), ['phone' => ['required', 'string', 'max:40'], 'display_name' => ['nullable', 'string', 'max:100'], 'internal_note' => ['nullable', 'string', 'max:2000']]));
    }

    public function search(Request $r)
    {
        Gate::forUser($r->user('admin'))->authorize('viewAny', Member::class);
        $data = $r->validate(['q' => ['nullable', 'string', 'max:100'], 'status' => ['nullable', Rule::in(['all', 'active', 'expired', 'blocked', 'none', 'revoked'])]]);
        $q = trim($data['q'] ?? '');
        $phoneHash = null;
        $mask = null;
        try {
            if ($q !== '') {
                $phone = IranianPhone::normalize($q);
                $phoneHash = IranianPhone::digest($phone);
                $mask = IranianPhone::mask($phone);
                $q = '';
            }
        } catch (ValidationException) {
        }
        $token = (string) Str::uuid();
        $saved = $r->session()->get('member_searches', []);
        $saved[$token] = ['q' => $q, 'phone_hash' => $phoneHash, 'mask' => $mask, 'status' => $data['status'] ?? 'all'];
        $r->session()->put('member_searches', array_slice($saved, -5, null, true));

        return redirect()->route('admin.members.index', ['search' => $token]);
    }

    public function index(Request $r)
    {
        Gate::forUser($r->user('admin'))->authorize('viewAny', Member::class);
        $params = $r->validate(['search' => ['nullable', 'uuid']]);
        $filters = isset($params['search']) ? $r->session()->get('member_searches.'.$params['search']) : ['q' => '', 'status' => 'all'];
        abort_unless(is_array($filters), 404);
        $query = Member::with(['account', 'subscription']);
        if (! empty($filters['phone_hash'])) {
            $query->where('phone_hash', $filters['phone_hash']);
        } elseif (($filters['q'] ?? '') !== '') {
            $query->whereHas('account', fn ($a) => $a->where('display_name', 'like', '%'.addcslashes($filters['q'], '\\%_').'%'));
        }
        match ($filters['status'] ?? 'all') {
            'active' => $query->whereNull('blocked_at')->whereHas('account', fn ($a) => $a->whereNull('disabled_at'))->whereHas('subscription', fn ($s) => $s->whereNull('revoked_at')->where('starts_at', '<=', now())->where('ends_at', '>', now())),
            'expired' => $query->whereHas('subscription', fn ($s) => $s->whereNull('revoked_at')->where('ends_at', '<=', now())),
            'blocked' => $query->whereNotNull('blocked_at'),'none' => $query->whereDoesntHave('subscription'),'revoked' => $query->whereHas('subscription', fn ($s) => $s->whereNotNull('revoked_at')),default => null
        };

        return view('admin.members.index', $this->data($r, 'شماره‌ها و اشتراک', ['members' => $query->latest('id')->paginate(20)->withQueryString(), 'filters' => $filters]));
    }

    public function create(Request $r)
    {
        Gate::forUser($r->user('admin'))->authorize('create', Member::class);

        return view('admin.members.form', $this->data($r, 'افزودن شماره مجاز', ['member' => null]));
    }

    public function store(Request $r, ManageMembers $manager)
    {
        Gate::forUser($r->user('admin'))->authorize('create', Member::class);
        $member = $manager->create($r->user('admin'), $this->fields($r));

        return redirect()->route('admin.members.show', $member)->with('status', 'شماره ثبت شد؛ برای ورود عضو، اشتراک را جداگانه فعال کنید.');
    }

    public function show(Request $r, Member $member)
    {
        Gate::forUser($r->user('admin'))->authorize('view', $member);
        $member->load(['account', 'subscription.plan']);
        $subscription = $member->subscription;

        return view('admin.members.show', $this->data($r, 'جزئیات عضو', ['member' => $member, 'subscription' => $subscription, 'plans' => Plan::where('active', true)->get(), 'renewals' => $r->user('admin')->allows('subscriptions.view') && $subscription ? $subscription->renewals()->latest('id')->get() : collect(), 'payments' => $r->user('admin')->allows('payments.view') ? ManualPayment::where('member_id', $member->id)->latest('id')->paginate(15) : null]));
    }

    public function edit(Request $r, Member $member)
    {
        Gate::forUser($r->user('admin'))->authorize('update', $member);

        return view('admin.members.form', $this->data($r, 'ویرایش شماره', ['member' => $member->load('account')]));
    }

    public function update(Request $r, Member $member, ManageMembers $manager)
    {
        Gate::forUser($r->user('admin'))->authorize('update', $member);
        $manager->update($r->user('admin'), $member, $this->fields($r));

        return redirect()->route('admin.members.show', $member)->with('status', 'تغییرات عضو ذخیره شد.');
    }

    public function block(Request $r, Member $member, ManageMembers $manager)
    {
        Gate::forUser($r->user('admin'))->authorize('block', $member);
        $data = $r->validate($this->sensitive() + ['blocked' => ['required', 'boolean']]);
        $manager->block($r->user('admin'), $member, $data);

        return back()->with('status', 'وضعیت مسدودی ثبت و نشست‌های قبلی لغو شدند.');
    }

    public function grant(Request $r, Member $member, ManageSubscriptions $manager)
    {
        $data = $r->validate($this->sensitive() + ['operation' => ['required', Rule::in(['activate', 'renew'])], 'months' => ['required', 'integer', Rule::in([1, 3, 6, 12])], 'calendar' => ['required', Rule::in(['persian', 'gregorian'])], 'plan_id' => ['required', 'integer', 'exists:plans,id'], 'idempotency_key' => ['required', 'uuid']]);
        abort_unless($r->user('admin')->allows($data['operation'] === 'renew' ? 'subscriptions.renew' : 'subscriptions.activate'), 403);
        $manager->grant($r->user('admin'), $member, $data);

        return redirect()->route('admin.members.show', $member)->with('status', 'اشتراک ثبت شد. تکرار همان درخواست تمدید اضافه ایجاد نمی‌کند.');
    }

    public function revoke(Request $r, Member $member, ManageSubscriptions $manager)
    {
        $manager->revoke($r->user('admin'), $member, $r->validate($this->sensitive()));

        return back()->with('status', 'اشتراک و نشست‌ها لغو شدند.');
    }

    public function payment(Request $r, Member $member, ManageManualPayments $manager)
    {
        $data = $r->validate($this->sensitive() + ['amount' => ['required', 'string', 'regex:/\A[0-9]{1,22}(?:\.[0-9]{1,2})?\z/'], 'unit' => ['required', Rule::in(['IRT', 'IRR'])], 'paid_at' => ['required', 'date_format:Y-m-d\TH:i'], 'method' => ['required', Rule::in(['transfer', 'cash', 'other'])], 'tracking_reference' => ['nullable', 'string', 'max:100'], 'note' => ['nullable', 'string', 'max:500'], 'idempotency_key' => ['required', 'uuid']]);
        $manager->record($r->user('admin'), $member, $data);

        return back()->with('status', 'پرداخت ثبت شد؛ اشتراک تغییری نکرد.');
    }

    public function confirmPayment(Request $r, Member $member, ManualPayment $payment, ManageManualPayments $manager)
    {
        $manager->confirm($r->user('admin'), $member, $payment, $r->validate($this->sensitive()));

        return back()->with('status', 'پرداخت تأیید شد؛ فعال‌سازی اشتراک مستقل است.');
    }
}
