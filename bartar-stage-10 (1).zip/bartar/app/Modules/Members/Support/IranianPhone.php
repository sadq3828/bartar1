<?php

namespace App\Modules\Members\Support;

use Illuminate\Validation\ValidationException;

final class IranianPhone
{
    public static function normalize(string $input): string
    {
        $input = strtr($input, array_combine(preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY), str_split('01234567890123456789')));
        $input = preg_replace('/[\s()\-]+/u', '', trim($input));
        if (! preg_match('/\A(?:\+98|0098|98|0)?(9[0-9]{9})\z/', $input, $match)) {
            throw ValidationException::withMessages(['phone' => 'شماره موبایل ایران معتبر نیست.']);
        }

        return '+98'.$match[1];
    }

    public static function digest(string $phone): string
    {
        return hash_hmac('sha256', 'member-phone:'.$phone, (string) config('app.key'));
    }

    public static function mask(string $phone): string
    {
        return '۰۹•••••'.substr($phone, -4);
    }
}
