<?php

namespace App\Modules\Members\Policies;

use App\Modules\Authentication\Models\Account;
use App\Modules\Members\Models\Member;

final class MemberPolicy
{
    public function viewAny(Account $a): bool
    {
        return $a->allows('members.view');
    }

    public function view(Account $a, Member $m): bool
    {
        return $a->allows('members.view') && $m->account()->where('kind', 'member')->exists();
    }

    public function create(Account $a): bool
    {
        return $a->allows('members.create');
    }

    public function update(Account $a, Member $m): bool
    {
        return $a->allows('members.update') && $m->account()->where('kind', 'member')->exists();
    }

    public function block(Account $a, Member $m): bool
    {
        return $a->allows('members.block') && $m->account()->where('kind', 'member')->exists();
    }

    public function access(Account $a, Member $m): bool
    {
        return $a->kind === 'member' && $a->id === $m->account_id && $m->eligible();
    }
}
