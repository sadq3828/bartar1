<?php

namespace App\Modules\Members\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\MemberSession;
use App\Modules\Authentication\Models\OtpChallenge;
use App\Modules\Members\Models\Member;
use App\Modules\Members\Support\IranianPhone;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManageMembers
{
    public function __construct(private ManageAdministrators $security, private RecordAudit $audit) {}

    public function authorize(Account $actor, string $permission, string $password): void
    {
        $this->security->lock();
        abort_unless($actor->fresh()->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);
    }

    public function invalidate(Member $member): void
    {
        Account::whereKey($member->account_id)->increment('auth_version');
        MemberSession::where('account_id', $member->account_id)->whereNull('revoked_at')->update(['revoked_at' => now()]);
        OtpChallenge::where('member_id', $member->id)->whereNull('invalidated_at')->whereNull('consumed_at')->update(['invalidated_at' => now()]);
    }

    public function create(Account $actor, array $data): Member
    {
        return DB::transaction(function () use ($actor, $data) {
            $this->authorize($actor, 'members.create', $data['current_password']);
            $phone = IranianPhone::normalize($data['phone']);
            $hash = IranianPhone::digest($phone);
            if (Member::where('phone_hash', $hash)->exists()) {
                throw ValidationException::withMessages(['phone' => 'این شماره قبلاً ثبت شده است.']);
            }
            $account = Account::create(['kind' => 'member', 'display_name' => $data['display_name'] ?? null]);
            $member = Member::create(['account_id' => $account->id, 'phone_e164' => $phone, 'phone_hash' => $hash, 'internal_note' => $data['internal_note'] ?? null, 'created_by' => $actor->id]);
            $this->audit->write($actor, 'member.created', 'member', $member->public_id, [], ['phone' => $member->maskedPhone(), 'display_name' => $account->display_name], $data['reason'], 'subscriptions');

            return $member;
        }, 3);
    }

    public function update(Account $actor, Member $member, array $data): void
    {
        DB::transaction(function () use ($actor, $member, $data): void {
            $this->authorize($actor, 'members.update', $data['current_password']);
            $member = Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            abort_unless($member->account()->where('kind', 'member')->exists(), 403);
            $phone = IranianPhone::normalize($data['phone']);
            $hash = IranianPhone::digest($phone);
            if (Member::where('phone_hash', $hash)->whereKeyNot($member->id)->exists()) {
                throw ValidationException::withMessages(['phone' => 'این شماره قبلاً ثبت شده است.']);
            }
            $before = ['phone' => $member->maskedPhone(), 'display_name' => $member->account->display_name];
            if ($hash !== $member->phone_hash) {
                $this->invalidate($member);
            }
            $member->update(['phone_e164' => $phone, 'phone_hash' => $hash, 'internal_note' => $data['internal_note'] ?? null]);
            $member->account()->update(['display_name' => $data['display_name'] ?? null, 'updated_at' => now()]);
            $this->audit->write($actor, 'member.updated', 'member', $member->public_id, $before, ['phone' => $member->maskedPhone(), 'display_name' => $data['display_name'] ?? null, 'internal_note_changed' => true], $data['reason'], 'subscriptions');
        }, 3);
    }

    public function block(Account $actor, Member $member, array $data): void
    {
        DB::transaction(function () use ($actor, $member, $data): void {
            $this->authorize($actor, 'members.block', $data['current_password']);
            $member = Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            $blocked = (bool) $data['blocked'];
            $before = (bool) $member->blocked_at;
            $member->update(['blocked_at' => $blocked ? now() : null, 'block_reason' => $blocked ? $data['reason'] : null]);
            $this->invalidate($member);
            $this->audit->write($actor, $blocked ? 'member.blocked' : 'member.unblocked', 'member', $member->public_id, ['blocked' => $before], ['blocked' => $blocked], $data['reason'], 'subscriptions');
        }, 3);
    }
}
