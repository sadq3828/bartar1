<?php

namespace App\Modules\Markets\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Markets\Actions\ManageMarkets;
use App\Modules\Markets\Models\Market;
use App\Modules\Markets\Models\Asset;
use App\Modules\MarketPrices\Actions\ResolveEffectivePrice;
use App\Modules\MarketPrices\Models\PriceSource;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

final class ManageMarketsController extends Controller
{
    private function data(Request $request, array $extra = []): array
    {
        return array_merge(['title' => 'بازارها و دارایی‌ها', 'active' => 'markets', 'area' => 'admin', 'adminUser' => $request->user('admin'), 'preview' => false], $extra);
    }

    public function index(Request $request, ResolveEffectivePrice $prices)
    {
        $markets = Market::with(['assets.manualPriceOverrides' => fn ($query) => $query->whereNull('revoked_at')->with('observation')->latest('starts_at'), 'priceSources'])->orderBy('title')->get();
        $quotes = $markets->flatMap->assets->mapWithKeys(fn ($asset) => [$asset->id => $prices->for($asset)]);

        return view('admin.markets.index', $this->data($request, ['markets' => $markets, 'quotes' => $quotes, 'sources' => PriceSource::with('market')->latest('id')->get()]));
    }

    public function store(Request $request, ManageMarkets $manager)
    {
        $data = $request->validate(['key' => ['required', 'string', 'max:64', 'regex:/\A[a-z0-9][a-z0-9_-]*\z/', 'unique:markets,key'], 'title' => ['required', 'string', 'max:100'], 'trade_type' => ['required', Rule::in(['spot', 'forex', 'gold', 'domestic'])]] + $this->sensitive());
        $manager->createMarket($request->user('admin'), $data);

        return back()->with('status', 'بازار ثبت شد.');
    }

    public function asset(Request $request, Market $market, ManageMarkets $manager)
    {
        $data = $request->validate(['symbol' => ['required', 'string', 'max:40', 'regex:/\A[A-Za-z0-9._-]+\z/', 'unique:assets,symbol,NULL,id,market_id,'.$market->id], 'title' => ['required', 'string', 'max:120'], 'price_unit' => ['required', 'string', 'max:16', 'regex:/\A[A-Za-z0-9._-]+\z/'], 'quantity_unit' => ['nullable', 'string', 'max:16', 'regex:/\A[A-Za-z0-9._-]+\z/'], 'price_scale' => ['required', 'integer', 'min:0', 'max:12']] + $this->sensitive());
        $manager->createAsset($request->user('admin'), $market, $data);

        return back()->with('status', 'دارایی به بازار افزوده شد.');
    }

    public function update(Request $request, Market $market, ManageMarkets $manager)
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:100'], 'trade_type' => ['required', Rule::in(['spot', 'forex', 'gold', 'domestic'])], 'active' => ['nullable', 'boolean']] + $this->sensitive());
        $manager->updateMarket($request->user('admin'), $market, $data);

        return back()->with('status', 'بازار به‌روزرسانی شد.');
    }

    public function updateAsset(Request $request, Market $market, Asset $asset, ManageMarkets $manager)
    {
        $data = $request->validate(['title' => ['required', 'string', 'max:120'], 'price_unit' => ['required', 'string', 'max:16', 'regex:/\A[A-Za-z0-9._-]+\z/'], 'quantity_unit' => ['nullable', 'string', 'max:16', 'regex:/\A[A-Za-z0-9._-]+\z/'], 'price_scale' => ['required', 'integer', 'min:0', 'max:12'], 'active' => ['nullable', 'boolean']] + $this->sensitive());
        $manager->updateAsset($request->user('admin'), $market, $asset, $data);

        return back()->with('status', 'دارایی و واحد قیمت به‌روزرسانی شد.');
    }

    private function sensitive(): array
    {
        return ['current_password' => ['required', 'string', 'max:128'], 'reason' => ['required', 'string', 'max:500']];
    }
}
