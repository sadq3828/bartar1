<?php

namespace App\Modules\Markets\Actions;

use App\Modules\Administration\Actions\ManageAdministrators;
use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Markets\Models\Asset;
use App\Modules\Markets\Models\Market;
use Illuminate\Support\Facades\DB;

final class ManageMarkets
{
    public function __construct(private ManageAdministrators $security, private RecordAudit $audit) {}

    private function authorize(Account $actor, string $permission, string $password): void
    {
        $this->security->lock();
        abort_unless($actor->fresh()->allows($permission), 403);
        $this->security->confirmPassword($actor, $password);
    }

    public function createMarket(Account $actor, array $data): Market
    {
        return DB::transaction(function () use ($actor, $data) {
            $this->authorize($actor, 'markets.create', $data['current_password']);
            $market = Market::create(['key' => $data['key'], 'title' => $data['title'], 'trade_type' => $data['trade_type'] ?? null, 'created_by' => $actor->id]);
            $this->audit->write($actor, 'market.created', 'market', $market->public_id, [], $market->only(['key', 'title', 'trade_type']), $data['reason'], 'signals');

            return $market;
        }, 3);
    }

    public function createAsset(Account $actor, Market $market, array $data): Asset
    {
        return DB::transaction(function () use ($actor, $market, $data) {
            $this->authorize($actor, 'markets.create', $data['current_password']);
            $market = Market::whereKey($market->id)->where('active', true)->lockForUpdate()->firstOrFail();
            $asset = Asset::create(['market_id' => $market->id, 'symbol' => strtoupper($data['symbol']), 'title' => $data['title'], 'price_unit' => $data['price_unit'] ?? null, 'quantity_unit' => $data['quantity_unit'] ?? null, 'price_scale' => $data['price_scale'] ?? 8, 'created_by' => $actor->id]);
            $this->audit->write($actor, 'asset.created', 'asset', $asset->public_id, [], ['market' => $market->key] + $asset->only(['symbol', 'title', 'price_unit', 'quantity_unit', 'price_scale']), $data['reason'], 'signals');

            return $asset;
        }, 3);
    }

    public function updateMarket(Account $actor, Market $market, array $data): void
    {
        DB::transaction(function () use ($actor, $market, $data): void {
            $this->authorize($actor, 'markets.update', $data['current_password']);
            $market = Market::whereKey($market->id)->lockForUpdate()->firstOrFail();
            if ($market->active && ! (bool) ($data['active'] ?? false)) {
                abort_unless($actor->fresh()->allows('markets.deactivate'), 403);
            }
            $before = $market->only(['title', 'trade_type', 'active']);
            $market->update(['title' => $data['title'], 'trade_type' => $data['trade_type'], 'active' => (bool) ($data['active'] ?? false)]);
            $this->audit->write($actor, 'market.updated', 'market', $market->public_id, $before, $market->only(['title', 'trade_type', 'active']), $data['reason'], 'signals');
        }, 3);
    }

    public function updateAsset(Account $actor, Market $market, Asset $asset, array $data): void
    {
        DB::transaction(function () use ($actor, $market, $asset, $data): void {
            $this->authorize($actor, 'markets.update', $data['current_password']);
            $market = Market::whereKey($market->id)->lockForUpdate()->firstOrFail();
            $asset = Asset::whereKey($asset->id)->where('market_id', $market->id)->lockForUpdate()->firstOrFail();
            if ($asset->active && ! (bool) ($data['active'] ?? false)) {
                abort_unless($actor->fresh()->allows('markets.deactivate'), 403);
            }
            $before = $asset->only(['title', 'price_unit', 'quantity_unit', 'price_scale', 'active']);
            $asset->update(['title' => $data['title'], 'price_unit' => strtoupper($data['price_unit']), 'quantity_unit' => $data['quantity_unit'] ? strtoupper($data['quantity_unit']) : null, 'price_scale' => $data['price_scale'], 'active' => (bool) ($data['active'] ?? false)]);
            $this->audit->write($actor, 'asset.updated', 'asset', $asset->public_id, $before, $asset->only(['title', 'price_unit', 'quantity_unit', 'price_scale', 'active']), $data['reason'], 'signals');
        }, 3);
    }
}
