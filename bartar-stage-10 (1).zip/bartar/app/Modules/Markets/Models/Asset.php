<?php

namespace App\Modules\Markets\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Asset extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['active' => 'boolean', 'price_scale' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $asset): void {
            $asset->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function market()
    {
        return $this->belongsTo(Market::class);
    }

    public function signals()
    {
        return $this->hasMany(\App\Modules\Signals\Models\Signal::class);
    }

    public function priceObservations()
    {
        return $this->hasMany(\App\Modules\MarketPrices\Models\PriceObservation::class);
    }

    public function manualPriceOverrides()
    {
        return $this->hasMany(\App\Modules\MarketPrices\Models\ManualPriceOverride::class);
    }
}
