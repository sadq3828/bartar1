<?php

namespace App\Modules\Markets\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Market extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $market): void {
            $market->public_id ??= (string) Str::ulid();
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }

    public function assets()
    {
        return $this->hasMany(Asset::class);
    }

    public function priceSources()
    {
        return $this->hasMany(\App\Modules\MarketPrices\Models\PriceSource::class);
    }
}
