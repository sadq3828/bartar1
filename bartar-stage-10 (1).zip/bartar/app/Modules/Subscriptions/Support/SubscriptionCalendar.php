<?php

namespace App\Modules\Subscriptions\Support;

use Carbon\CarbonImmutable;
use DateTimeInterface;
use IntlCalendar;
use InvalidArgumentException;

final class SubscriptionCalendar
{
    public function add(DateTimeInterface $date, int $months, string $calendar): CarbonImmutable
    {
        if (! in_array($months, [1, 3, 6, 12], true) || ! in_array($calendar, ['persian', 'gregorian'], true)) {
            throw new InvalidArgumentException('Unsupported subscription duration/calendar');
        }
        $base = CarbonImmutable::instance($date)->setTimezone('Asia/Tehran');
        if ($calendar === 'gregorian') {
            return $base->addMonthsNoOverflow($months)->utc();
        }
        $cal = IntlCalendar::createInstance('Asia/Tehran', 'fa_IR@calendar=persian');
        $cal->setTime($base->getTimestamp() * 1000);
        $day = $cal->get(IntlCalendar::FIELD_DAY_OF_MONTH);
        $cal->set(IntlCalendar::FIELD_DAY_OF_MONTH, 1);
        $cal->add(IntlCalendar::FIELD_MONTH, $months);
        $cal->set(IntlCalendar::FIELD_DAY_OF_MONTH, min($day, $cal->getActualMaximum(IntlCalendar::FIELD_DAY_OF_MONTH)));

        return CarbonImmutable::createFromTimestampUTC((int) floor($cal->getTime() / 1000))->setMicrosecond($base->microsecond);
    }
}
