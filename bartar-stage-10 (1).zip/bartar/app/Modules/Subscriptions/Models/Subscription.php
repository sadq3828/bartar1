<?php

namespace App\Modules\Subscriptions\Models;

use App\Modules\Members\Models\Member;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['starts_at' => 'immutable_datetime', 'ends_at' => 'immutable_datetime', 'revoked_at' => 'immutable_datetime', 'version' => 'integer'];
    }

    public function renewals()
    {
        return $this->hasMany(SubscriptionRenewal::class);
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class);
    }

    public function member()
    {
        return $this->belongsTo(Member::class);
    }
}
