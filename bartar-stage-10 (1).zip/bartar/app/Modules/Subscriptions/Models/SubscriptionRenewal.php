<?php

namespace App\Modules\Subscriptions\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class SubscriptionRenewal extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.u';

    public $timestamps = false;

    protected $guarded = ['id'];

    protected $hidden = ['request_hash'];

    protected function casts(): array
    {
        return ['base_at' => 'immutable_datetime', 'old_end' => 'immutable_datetime', 'new_start' => 'immutable_datetime', 'new_end' => 'immutable_datetime', 'created_at' => 'immutable_datetime'];
    }

    protected static function booted(): void
    {
        static::creating(function (self $r): void {
            $r->public_id ??= (string) Str::ulid();
        });
        static::updating(fn () => throw new \LogicException('History is append only'));
        static::deleting(fn () => throw new \LogicException('History is append only'));
    }
}
