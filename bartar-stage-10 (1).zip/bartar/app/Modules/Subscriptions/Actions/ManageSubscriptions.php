<?php

namespace App\Modules\Subscriptions\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Subscriptions\Models\Plan;
use App\Modules\Subscriptions\Models\Subscription;
use App\Modules\Subscriptions\Models\SubscriptionRenewal;
use App\Modules\Subscriptions\Support\SubscriptionCalendar;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManageSubscriptions
{
    public function __construct(private ManageMembers $members, private RecordAudit $audit, private SubscriptionCalendar $calendar) {}

    public function grant(Account $actor, Member $member, array $data): SubscriptionRenewal
    {
        return DB::transaction(function () use ($actor, $member, $data) {
            $permission = $data['operation'] === 'renew' ? 'subscriptions.renew' : 'subscriptions.activate';
            $this->members->authorize($actor, $permission, $data['current_password']);
            $member = Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            $fingerprint = AdminSession::digest(json_encode([$member->id, $actor->id, $data['operation'], (int) $data['months'], $data['calendar'], (int) $data['plan_id'], $data['reason']], JSON_THROW_ON_ERROR));
            if ($existing = SubscriptionRenewal::where('idempotency_key', $data['idempotency_key'])->first()) {
                abort_unless(hash_equals($existing->request_hash, $fingerprint), 409, 'شناسه درخواست قبلاً با اطلاعات دیگری استفاده شده است.');

                return $existing;
            }
            $plan = Plan::whereKey($data['plan_id'])->where('active', true)->firstOrFail();
            $subscription = $member->subscription()->lockForUpdate()->first();
            $active = $subscription && ! $subscription->revoked_at && $subscription->starts_at->lte(now()) && $subscription->ends_at->gt(now());
            if ($data['operation'] === 'renew' && (! $subscription || $subscription->revoked_at)) {
                throw ValidationException::withMessages(['operation' => 'اشتراک فعلی وجود ندارد یا لغو شده است؛ فعال‌سازی را انتخاب کنید.']);
            }
            if ($data['operation'] === 'activate' && $active) {
                throw ValidationException::withMessages(['operation' => 'اشتراک فعال است؛ تمدید را انتخاب کنید.']);
            }
            $base = $active ? $subscription->ends_at : now()->toImmutable();
            $start = $active ? $subscription->starts_at : $base;
            $oldEnd = $subscription?->ends_at;
            $end = $this->calendar->add($base, (int) $data['months'], $data['calendar']);
            if (! $active) {
                $this->members->invalidate($member);
            }
            if (! $subscription) {
                $subscription = new Subscription(['member_id' => $member->id]);
            }
            $subscription->fill(['plan_id' => $plan->id, 'starts_at' => $start, 'ends_at' => $end, 'revoked_at' => null, 'version' => ($subscription->version ?? 0) + 1]);
            $subscription->save();
            $renewal = SubscriptionRenewal::create(['subscription_id' => $subscription->id, 'operation' => $data['operation'], 'months' => $data['months'], 'calendar' => $data['calendar'], 'base_at' => $base, 'old_end' => $oldEnd, 'new_start' => $start, 'new_end' => $end, 'actor_id' => $actor->id, 'reason' => $data['reason'], 'idempotency_key' => $data['idempotency_key'], 'request_hash' => $fingerprint]);
            $this->audit->write($actor, 'subscription.'.$data['operation'], 'member', $member->public_id, ['ends_at' => $oldEnd?->toIso8601String()], ['starts_at' => $start->toIso8601String(), 'ends_at' => $end->toIso8601String(), 'months' => (int) $data['months'], 'calendar' => $data['calendar']], $data['reason'], 'subscriptions');

            return $renewal;
        }, 3);
    }

    public function revoke(Account $actor, Member $member, array $data): void
    {
        DB::transaction(function () use ($actor, $member, $data): void {
            $this->members->authorize($actor, 'subscriptions.revoke', $data['current_password']);
            $member = Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            $subscription = $member->subscription()->lockForUpdate()->firstOrFail();
            if ($subscription->revoked_at) {
                return;
            }$subscription->revoked_at = now();
            $subscription->version++;
            $subscription->save();
            $this->members->invalidate($member);
            $this->audit->write($actor, 'subscription.revoked', 'member', $member->public_id, [], ['revoked' => true], $data['reason'], 'subscriptions');
        }, 3);
    }
}
