<?php

namespace App\Modules\Subscriptions\Actions;

use App\Modules\AuditLogs\Actions\RecordAudit;
use App\Modules\Authentication\Models\Account;
use App\Modules\Authentication\Models\AdminSession;
use App\Modules\Members\Actions\ManageMembers;
use App\Modules\Members\Models\Member;
use App\Modules\Subscriptions\Models\ManualPayment;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

final class ManageManualPayments
{
    public function __construct(private ManageMembers $members, private RecordAudit $audit) {}

    public function record(Account $actor, Member $member, array $data): ManualPayment
    {
        return DB::transaction(function () use ($actor, $member, $data) {
            $this->members->authorize($actor, 'payments.create', $data['current_password']);
            Member::whereKey($member->id)->lockForUpdate()->firstOrFail();
            $amount = bcadd($data['amount'], '0', 2);
            $hash = AdminSession::digest(json_encode([$actor->id, $member->id, $amount, $data['unit'], $data['paid_at'], $data['method'], $data['tracking_reference'] ?? null, $data['note'] ?? null, $data['reason']], JSON_THROW_ON_ERROR));
            if ($payment = ManualPayment::where('idempotency_key', $data['idempotency_key'])->first()) {
                abort_unless(hash_equals($payment->request_hash, $hash), 409);

                return $payment;
            }
            $payment = ManualPayment::create(['member_id' => $member->id, 'amount' => $amount, 'unit' => $data['unit'], 'paid_at' => CarbonImmutable::createFromFormat('!Y-m-d\TH:i', $data['paid_at'], 'Asia/Tehran')->utc(), 'method' => $data['method'], 'tracking_reference' => $data['tracking_reference'] ?? null, 'note' => $data['note'] ?? null, 'recorded_by' => $actor->id, 'idempotency_key' => $data['idempotency_key'], 'request_hash' => $hash]);
            $this->audit->write($actor, 'payment.recorded', 'payment', $payment->public_id, [], ['member' => $member->public_id, 'amount' => $amount, 'unit' => $data['unit']], $data['reason'], 'subscriptions');

            return $payment;
        }, 3);
    }

    public function confirm(Account $actor, Member $member, ManualPayment $payment, array $data): void
    {
        DB::transaction(function () use ($actor, $member, $payment, $data): void {
            $this->members->authorize($actor, 'payments.confirm', $data['current_password']);
            abort_unless($payment->member_id === $member->id, 404);
            $payment = ManualPayment::whereKey($payment->id)->lockForUpdate()->firstOrFail();
            if ($payment->confirmed_at) {
                return;
            }
            $payment->update(['confirmed_at' => now(), 'confirmed_by' => $actor->id]);
            $this->audit->write($actor, 'payment.confirmed', 'payment', $payment->public_id, [], ['confirmed' => true], $data['reason'], 'subscriptions');
        }, 3);
    }
}
