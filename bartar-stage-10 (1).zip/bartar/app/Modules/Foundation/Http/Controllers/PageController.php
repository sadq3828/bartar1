<?php

namespace App\Modules\Foundation\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Content\Models\Announcement;
use App\Modules\Content\Models\ContentPage;
use Illuminate\Http\Response;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;
use Throwable;

class PageController extends Controller
{
    public function home(): View
    {
        [$page, $announcements] = $this->fromContentDatabase(
            fn (): array => [
                ContentPage::published()->where('slug', 'home')->with(['sections', 'heroMedia'])->first(),
                Announcement::visible('public')->latest('published_at')->limit(3)->get(),
            ],
            [null, collect()],
        );

        return view('public.home', ['title' => $page?->title ?: 'برتر؛ نگاه روشن‌تر به بازار', 'active' => 'home', 'homeContent' => $page ? $this->content($page) : null, 'latestAnnouncements' => $announcements]);
    }
    public function page(string $page): View
    {
        $record = $this->fromContentDatabase(
            fn () => ContentPage::published()->where('slug', $page)->with(['sections', 'heroMedia'])->first(),
        );
        $content = $record ? $this->content($record) : config('content.'.$page);
        abort_unless(is_array($content), 404);
        return view('public.page', ['content' => $content, 'title' => $content['title'], 'active' => $page]);
    }
    public function announcements(): View
    {
        $empty = new LengthAwarePaginator([], 0, 15, 1, ['path' => request()->url()]);
        $announcements = $this->fromContentDatabase(
            fn () => Announcement::visible('public')->latest('published_at')->paginate(15),
            $empty,
        );

        return view('public.announcements', ['title' => 'اطلاعیه‌ها', 'active' => 'announcements', 'announcements' => $announcements]);
    }
    public function login(): Response
    {
        return response()->view('public.login', ['title' => 'ورود اعضا', 'admin' => false], 503)
            ->header('Cache-Control', 'private, no-store');
    }
    public function adminLogin(): Response
    {
        return response()->view('public.login', ['title' => 'ورود مدیریت', 'admin' => true], 503)
            ->header('Cache-Control', 'private, no-store');
    }

    private function content(ContentPage $page): array
    {
        return [
            'eyebrow' => $page->eyebrow,
            'title' => $page->title,
            'intro' => $page->intro,
            'icon' => $page->icon,
            'hero_media' => $page->heroMedia,
            'sections' => $page->sections->where('visible', true)->values()->map(fn ($section) => $section->only(['kind', 'title', 'body', 'action_label', 'action_url']))->all(),
        ];
    }

    private function fromContentDatabase(callable $callback, mixed $fallback = null): mixed
    {
        if (! config('content.database_enabled') || app()->bound('content.database.unavailable')) {
            return $fallback;
        }
        try {
            if (! Schema::hasTable('content_pages')) {
                return $fallback;
            }

            return $callback();
        } catch (Throwable) {
            DB::purge();
            app()->instance('content.database.unavailable', true);

            return $fallback;
        }
    }
}
