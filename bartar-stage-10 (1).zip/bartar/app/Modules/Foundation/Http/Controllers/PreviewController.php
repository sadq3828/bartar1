<?php

namespace App\Modules\Foundation\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PreviewController extends Controller
{
    public function index(): View
    {
        return view('preview.index', ['title' => 'بررسی رابط برتر', 'preview' => true]);
    }
    public function member(Request $request, string $page = 'home'): View
    {
        $pages = config('bartar.member_navigation') + [
            'notifications' => ['title' => 'اعلان‌ها', 'icon' => 'bell'],
            'subscription' => ['title' => 'وضعیت اشتراک', 'icon' => 'crown'],
        ];
        abort_unless(isset($pages[$page]), 404);
        $query = $request->validate([
            'q' => ['nullable', 'string', 'max:100'],
            'market' => ['nullable', 'in:all,crypto,forex,gold,domestic'],
            'direction' => ['nullable', 'in:all,buy,sell'],
            'active' => ['nullable', 'in:1'],
        ]);
        return view('member.'.$page, [
            'title' => $pages[$page]['title'], 'active' => $page,
            'area' => 'member', 'preview' => true, 'query' => $query,
        ]);
    }
    public function admin(string $page = 'dashboard'): View
    {
        $pages = config('bartar.admin_navigation');
        abort_unless(isset($pages[$page]), 404);
        return view('admin.shell', [
            'title' => $pages[$page]['title'], 'active' => $page,
            'area' => 'admin', 'preview' => true,
        ]);
    }
    public function states(): View
    {
        return view('preview.states', ['title' => 'حالت‌های رابط', 'preview' => true]);
    }
}
