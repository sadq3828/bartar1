<?php

namespace App\Modules\Foundation\Support;

use DateTimeInterface;
use IntlDateFormatter;

final class PersianDate
{
    public static function format(DateTimeInterface|string $date, string $pattern = 'd MMMM yyyy'): string
    {
        if (is_string($date)) { $date = \Carbon\CarbonImmutable::parse($date, 'UTC'); }
        $formatter = new IntlDateFormatter(
            'fa_IR@calendar=persian', IntlDateFormatter::NONE, IntlDateFormatter::NONE,
            config('bartar.display_timezone', 'Asia/Tehran'), IntlDateFormatter::TRADITIONAL, $pattern,
        );
        return $formatter->format($date) ?: '';
    }

    public static function number(string|int $value): string
    {
        return strtr((string) $value, ['0'=>'۰', '1'=>'۱', '2'=>'۲', '3'=>'۳', '4'=>'۴', '5'=>'۵', '6'=>'۶', '7'=>'۷', '8'=>'۸', '9'=>'۹']);
    }
}
