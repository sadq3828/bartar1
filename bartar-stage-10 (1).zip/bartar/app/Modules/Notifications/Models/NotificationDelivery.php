<?php

namespace App\Modules\Notifications\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationDelivery extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['attempts' => 'integer', 'next_retry_at' => 'immutable_datetime', 'sent_at' => 'immutable_datetime'];
    }

    public function notification()
    {
        return $this->belongsTo(MemberNotification::class, 'notification_id');
    }
}
