<?php

namespace App\Modules\Notifications\Actions;

use App\Modules\Authentication\Models\Account;
use App\Modules\Content\Models\Announcement;
use App\Modules\Members\Models\Member;
use App\Modules\Notifications\Models\MemberNotification;
use App\Modules\Notifications\Models\NotificationDelivery;
use App\Modules\Signals\Models\Signal;
use App\Modules\Signals\Models\SignalAnnouncement;
use App\Modules\SmsIntegration\Contracts\NotificationSmsSender;
use App\Modules\SmsIntegration\Support\NotificationSmsException;
use App\Modules\Subscriptions\Models\Subscription;
use Illuminate\Support\Facades\DB;
use Throwable;

final class DispatchNotifications
{
    public function __construct(private NotificationSmsSender $sms) {}

    public function run(): array
    {
        $result = ['signals' => $this->signals(), 'announcements' => 0, 'expiry' => $this->expiry(), 'sms' => 0];
        foreach (Announcement::visible('members')->orderBy('id')->get() as $announcement) {
            $result['announcements'] += $this->announcement($announcement);
        }
        $result['sms'] = $this->deliverSms();

        return $result;
    }

    public function announcement(Announcement $announcement): int
    {
        if ($announcement->status !== 'published' || $announcement->published_at?->isFuture() || $announcement->expires_at?->lte(now()) || ! in_array($announcement->audience, ['members', 'all'], true)) {
            return 0;
        }
        $created = 0;
        foreach ($this->eligibleMembers() as $member) {
            $notification = $this->store($member->account_id, 'announcement', $announcement->title, $announcement->body, '/announcements', 'announcement:'.$announcement->id.':'.$announcement->version.':'.$member->account_id);
            $created += $notification->wasRecentlyCreated ? 1 : 0;
        }

        return $created;
    }

    private function signals(): int
    {
        $created = 0;
        $events = SignalAnnouncement::where('status', 'pending')->where('available_at', '<=', now())->orderBy('id')->get();
        foreach ($events as $event) {
            try {
                $created += DB::transaction(function () use ($event): int {
                    $event = SignalAnnouncement::whereKey($event->id)->lockForUpdate()->first();
                    if (! $event || $event->status !== 'pending') {
                        return 0;
                    }
                    $event->increment('attempts');
                    $signal = Signal::memberVisible()->whereKey($event->signal_id)->firstOrFail();
                    $labels = [
                        'published' => ['سیگنال جدید منتشر شد', 'یک سیگنال تازه برای مشاهده شما منتشر شده است.'],
                        'changed' => ['سیگنال به‌روزرسانی شد', 'تغییر مهمی در سیگنال منتشرشده ثبت شد.'],
                        'completed' => ['نتیجه سیگنال ثبت شد', 'نتیجه سیگنال منتشرشده اکنون قابل مشاهده است.'],
                        'result_corrected' => ['نتیجه سیگنال اصلاح شد', 'یک نسخه اصلاحی برای نتیجه سیگنال ثبت شده است.'],
                    ];
                    [$title, $body] = $labels[$event->event_type] ?? ['تغییر سیگنال', 'یک تغییر قابل بررسی برای سیگنال ثبت شده است.'];
                    $count = 0;
                    foreach ($this->eligibleMembers() as $member) {
                        $notification = $this->store($member->account_id, 'signal', $title, $body, '/app/signals/'.$signal->public_id, 'signal:'.$event->id.':'.$member->account_id);
                        $count += $notification->wasRecentlyCreated ? 1 : 0;
                    }
                    $event->update(['status' => 'dispatched', 'processed_at' => now(), 'last_error_code' => null]);

                    return $count;
                }, 3);
            } catch (Throwable) {
                SignalAnnouncement::whereKey($event->id)->update(['last_error_code' => 'dispatch_failed']);
            }
        }

        return $created;
    }

    private function expiry(): int
    {
        $created = 0;
        $current = now();
        $ending = Subscription::whereNull('revoked_at')->with('member')->get()
            ->filter(fn (Subscription $subscription): bool => $subscription->starts_at->lte($current)
                && $subscription->ends_at->gt($current)
                && $subscription->ends_at->lte($current->copy()->addDays(3)));
        foreach ($ending as $subscription) {
            if (! $subscription->member || ! $subscription->member->eligible()) {
                continue;
            }
            $notification = $this->store($subscription->member->account_id, 'subscription', 'اشتراک شما رو به پایان است', 'کمتر از سه روز تا پایان اشتراک باقی مانده است. برای تمدید با پشتیبانی هماهنگ کنید.', '/app/subscription', 'subscription:ending:'.$subscription->id.':'.$subscription->version);
            $created += $notification->wasRecentlyCreated ? 1 : 0;
        }

        $expired = Subscription::whereNull('revoked_at')->with('member')->get()
            ->filter(fn (Subscription $subscription): bool => $subscription->ends_at->lte($current)
                && $subscription->ends_at->gt($current->copy()->subDay()));
        foreach ($expired as $subscription) {
            if (! $subscription->member) {
                continue;
            }
            foreach ($this->notificationAdmins() as $admin) {
                $notification = $this->store($admin->id, 'administrative', 'اشتراک یک عضو منقضی شد', 'اشتراک عضو موردنظر پایان یافته و دسترسی او متوقف شده است.', '/admin/members/'.$subscription->member->public_id, 'subscription:expired:'.$subscription->id.':'.$subscription->version.':'.$admin->id);
                $created += $notification->wasRecentlyCreated ? 1 : 0;
            }
        }

        return $created;
    }

    private function deliverSms(): int
    {
        if (! config('notifications.sms_enabled')) {
            return 0;
        }
        $sent = 0;
        $deliveries = NotificationDelivery::whereIn('status', ['pending', 'failed'])->where('attempts', '<', 3)
            ->where(fn ($query) => $query->whereNull('next_retry_at')->orWhere('next_retry_at', '<=', now()))
            ->with('notification')->orderBy('id')->limit(100)->get();
        foreach ($deliveries as $delivery) {
            $member = Member::where('account_id', $delivery->notification->recipient_id)->first();
            if (! $member || ! $member->eligible()) {
                $delivery->update(['status' => 'skipped', 'error_code' => 'recipient_ineligible']);
                continue;
            }
            try {
                $reference = $this->sms->send($member->phone_e164, 'notification', ['title' => $delivery->notification->title], $delivery->notification->dedupe_key);
                $delivery->update(['status' => 'sent', 'attempts' => $delivery->attempts + 1, 'provider_reference' => $reference, 'error_code' => null, 'next_retry_at' => null, 'sent_at' => now()]);
                $sent++;
            } catch (NotificationSmsException $error) {
                $delivery->update(['status' => 'failed', 'attempts' => $delivery->attempts + 1, 'error_code' => $error->safeCode, 'next_retry_at' => now()->addMinutes(15)]);
            } catch (Throwable) {
                $delivery->update(['status' => 'failed', 'attempts' => $delivery->attempts + 1, 'error_code' => 'provider_error', 'next_retry_at' => now()->addMinutes(15)]);
            }
        }

        return $sent;
    }

    private function eligibleMembers()
    {
        return Member::query()->whereNull('blocked_at')->orderBy('id')->get()
            ->filter(fn (Member $member): bool => $member->eligible())->values();
    }

    private function notificationAdmins()
    {
        return Account::where('kind', 'admin')->whereNull('disabled_at')->orderBy('id')->get()
            ->filter(fn (Account $account): bool => $account->allows('notifications.view'))->values();
    }

    private function store(int $recipientId, string $kind, string $title, string $body, ?string $url, string $dedupe): MemberNotification
    {
        $notification = MemberNotification::firstOrCreate(['dedupe_key' => hash('sha256', $dedupe)], ['recipient_id' => $recipientId, 'kind' => $kind, 'title' => $title, 'body' => $body, 'action_url' => $url]);
        if ($notification->wasRecentlyCreated && config('notifications.sms_enabled') && in_array($kind, ['subscription', 'administrative'], true)) {
            NotificationDelivery::firstOrCreate(['notification_id' => $notification->id, 'channel' => 'sms']);
        }

        return $notification;
    }
}
