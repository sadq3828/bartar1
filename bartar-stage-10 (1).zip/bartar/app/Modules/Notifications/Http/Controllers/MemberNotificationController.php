<?php

namespace App\Modules\Notifications\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Notifications\Models\MemberNotification;
use Illuminate\Http\Request;

final class MemberNotificationController extends Controller
{
    public function index(Request $request)
    {
        $notifications = MemberNotification::where('recipient_id', $request->user('member')->id)->latest('id')->paginate(20);

        return view('member.notifications', ['title' => 'اعلان‌ها', 'active' => 'notifications', 'area' => 'member', 'preview' => false, 'member' => $request->attributes->get('member'), 'notifications' => $notifications, 'unread' => MemberNotification::where('recipient_id', $request->user('member')->id)->whereNull('read_at')->count()]);
    }

    public function read(Request $request, MemberNotification $notification)
    {
        abort_unless($notification->recipient_id === $request->user('member')->id, 404);
        if (! $notification->read_at) {
            $notification->update(['read_at' => now()]);
        }

        return back()->with('status', 'اعلان خوانده شد.');
    }

    public function readAll(Request $request)
    {
        MemberNotification::where('recipient_id', $request->user('member')->id)->whereNull('read_at')->update(['read_at' => now()]);

        return back()->with('status', 'همه اعلان‌ها خوانده شدند.');
    }
}
