<?php

return [
    'string' => 'مقدار :attribute باید متن باشد.',
    'required' => 'واردکردن :attribute الزامی است.',
    'min' => ['string' => ':attribute باید حداقل :min نویسه باشد.', 'array' => 'حداقل :min مورد برای :attribute انتخاب کنید.'],
    'max' => ['string' => ':attribute نباید بیشتر از :max نویسه باشد.', 'array' => ':attribute نباید بیشتر از :max مورد باشد.'],
    'confirmed' => 'تکرار :attribute مطابقت ندارد.',
    'array' => 'ساختار :attribute معتبر نیست.',
    'integer' => ':attribute باید عدد صحیح باشد.',
    'boolean' => 'مقدار :attribute معتبر نیست.',
    'distinct' => ':attribute نباید تکراری باشد.',
    'exists' => ':attribute انتخاب‌شده وجود ندارد.',
    'unique' => ':attribute قبلاً استفاده شده است.',
    'regex' => 'قالب :attribute معتبر نیست.',
    'in' => 'مقدار انتخاب‌شده برای :attribute معتبر نیست.',
    'attributes' => ['q' => 'جست‌وجو', 'market' => 'بازار', 'direction' => 'جهت', 'active' => 'فیلتر فعال', 'username' => 'نام کاربری', 'password' => 'رمز عبور', 'current_password' => 'رمز فعلی', 'display_name' => 'نام نمایشی', 'role_ids' => 'نقش‌ها', 'role_ids.*' => 'نقش', 'permission_keys' => 'مجوزها', 'permission_keys.*' => 'مجوز', 'reason' => 'دلیل تغییر', 'title' => 'عنوان', 'disabled' => 'وضعیت غیرفعال'],
];
