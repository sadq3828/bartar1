<?php

return [
    'display_timezone' => 'Asia/Tehran',
    'preview_enabled' => (bool) env('BARTAR_PREVIEW_ENABLED', false),
    'support_email' => env('BARTAR_SUPPORT_EMAIL'),
    'member_navigation' => [
        'home' => ['title' => 'خانه', 'icon' => 'home'],
        'signals' => ['title' => 'سیگنال', 'icon' => 'signal'],
        'performance' => ['title' => 'عملکرد', 'icon' => 'pie'],
        'markets' => ['title' => 'نمای بازار', 'icon' => 'chart'],
        'account' => ['title' => 'حساب کاربری', 'icon' => 'user'],
    ],
    'admin_navigation' => [
        'dashboard' => ['title' => 'داشبورد', 'icon' => 'grid'],
        'members' => ['title' => 'شماره‌ها و اشتراک', 'icon' => 'users'],
        'signals' => ['title' => 'سیگنال‌ها', 'icon' => 'signal'],
        'markets' => ['title' => 'بازار و قیمت', 'icon' => 'chart'],
        'content' => ['title' => 'محتوا و اعلان', 'icon' => 'document'],
        'health' => ['title' => 'سلامت سامانه', 'icon' => 'pulse'],
        'settings' => ['title' => 'تنظیمات', 'icon' => 'settings'],
    ],
];
