<?php

return [
    // Literal IP/CIDR values only. Never trust arbitrary forwarded hosts.
    'trusted_proxies' => array_values(array_filter(array_map(trim(...), explode(',', (string) env('TRUSTED_PROXIES', ''))))),
    'hsts_max_age' => 31536000,
];
