<?php

use App\Modules\Authentication\Models\Account;

return [
    'defaults' => ['guard' => 'member', 'passwords' => 'admins'],
    'guards' => [
        'admin' => ['driver' => 'session', 'provider' => 'accounts'],
        'member' => ['driver' => 'session', 'provider' => 'accounts'],
    ],
    'providers' => ['accounts' => ['driver' => 'eloquent', 'model' => Account::class]],
    // Web password recovery stays disabled until a delivery channel is selected.
    'passwords' => [],
    'password_timeout' => 300,
];
