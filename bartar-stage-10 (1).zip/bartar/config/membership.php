<?php

return [
    'calendar' => env('SUBSCRIPTION_CALENDAR', 'persian'),
    'otp_key' => env('OTP_HMAC_KEY', ''),
    'otp_ttl' => max(60, min(600, (int) env('OTP_TTL_SECONDS', 300))),
    'otp_resend' => max(30, (int) env('OTP_RESEND_SECONDS', 60)),
    'otp_attempts' => 5,
    'session_lifetime' => 120,
];
