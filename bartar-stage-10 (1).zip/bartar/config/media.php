<?php

return [
    'disk' => env('PRIVATE_MEDIA_DISK') ?: 'signal-media',
    // Application guardrail only; hosting/proxy/storage limits must be set independently.
    'max_upload_bytes' => max(1_048_576, (int) (env('MEDIA_MAX_UPLOAD_BYTES') ?: 104_857_600)),
    'stream_chunk_bytes' => 65_536,
    'allowed_mimes' => [
        'image' => ['image/jpeg', 'image/png', 'image/webp'],
        'audio' => ['audio/mpeg', 'audio/aac', 'audio/mp4'],
        'video' => ['video/mp4'],
    ],
];
