<?php

return [
    'backup' => [
        'enabled' => (bool) env('BARTAR_BACKUP_ENABLED', false),
        'root' => env('BARTAR_BACKUP_ROOT') ?: storage_path('app/backups'),
        'key' => env('BARTAR_BACKUP_KEY'),
        'time' => env('BARTAR_BACKUP_TIME', '02:30'), // UTC
        'keep' => (int) env('BARTAR_BACKUP_KEEP', 7),
        'max_age_hours' => (int) env('BARTAR_BACKUP_MAX_AGE_HOURS', 30),
        'mysqldump' => env('BARTAR_MYSQLDUMP_BINARY', 'mysqldump'),
        'mysql' => env('BARTAR_MYSQL_BINARY', 'mysql'),
        'timeout' => (int) env('BARTAR_BACKUP_TIMEOUT', 3600),
        'restore_enabled' => (bool) env('BARTAR_RESTORE_DRILL_ENABLED', false),
        'restore_media_root' => env('BARTAR_RESTORE_MEDIA_ROOT') ?: storage_path('app/restore-drills'),
    ],
    'heartbeat_max_age_seconds' => 180,
];
