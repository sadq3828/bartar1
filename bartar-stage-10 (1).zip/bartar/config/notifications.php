<?php

return [
    'sms_enabled' => (bool) env('NOTIFICATION_SMS_ENABLED', false),
];
