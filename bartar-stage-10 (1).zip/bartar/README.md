# برتر — تحویل مرحله ۱۰

پروژهٔ فارسی و RTL با Laravel/PHP/MySQL؛ توسعهٔ ده‌مرحله‌ای و آماده‌سازی فنی تحویل شده است. **سایت هنوز روی دامنهٔ واقعی منتشر نشده و آمادهٔ عرضهٔ عمومی اعلام نمی‌شود.** اتصال SMS، بکاپ بیرونی/پذیرش عملیات و QA مرورگر/میزبان بازند.

## اجرا و ارتقا

PHP 8.4 CLI/FPM با intl/bcmath/pdo_mysql/sodium، MySQL 8.4، Composer و ابزارهای mysql/mysqldump لازم‌اند. Node ابزار build/QA است و backend PHP باقی است.

```bash
composer install
php scripts/setup-local.php
node scripts/build-assets.mjs
php artisan migrate --seed
php artisan reports:calculate
php artisan bartar:admin-create
php artisan serve --host=127.0.0.1 --port=8000
```

DB/کلیدها اختصاصی و خصوصی‌اند؛ هیچ حساب یا رمز پیش‌فرض ساخته نمی‌شود. APP_KEY و OTP_HMAC_KEY موجود را هنگام ارتقا عوض نکنید. migration جدید جدول sessions را برای SESSION_DRIVER=database می‌سازد. تمام مسیرهای خصوصی و رسانه همچنان مجوز/عضویت جاری را روی سرور بررسی می‌کنند. ثبت‌نام عمومی و پرداخت آنلاین فعال نیستند.

## استقرار

[راهنمای release/rollback](docs/RELEASE_RUNBOOK.md)، [پذیرش نهایی](docs/FINAL_ACCEPTANCE.md) و فایل‌های deploy را بخوانید. نمونهٔ محیط تولید در deploy/env.production.example است و secrets ندارد. فقط public باید document root باشد.

```bash
php artisan deployment:check
php artisan operations:health
```

gate با debug/preview، session/cache موقت، proxy نامعتبر، schema ناقص، SMS و backup ناموجود موفقیت جعلی نمی‌دهد. --staging فقط localhost/.test و DB آزمایشی را برای تمرین می‌پذیرد و اجازهٔ عرضه نیست. فعال‌سازی release نیازمند confirmation شناسه، بررسی سازگاری schema و تأیید مالک است؛ ابزار DNS، migration، حذف یا restore را پنهانی انجام نمی‌دهد.

در production Host فقط از APP_URL پذیرفته می‌شود؛ TRUSTED_PROXIES فهرست صریح IP/CIDR است. خطاها بدون متن خام credential/SQL و با request ID ثبت می‌شوند. پاسخ خصوصی/خطا no-store است و HTTPS هدر HSTS دارد. این‌ها جای بازبینی امنیت میزبان و تست نفوذ مستقل را نمی‌گیرند.

## آزمون

MySQL آزمایشی مستقل با نام دارای test، کلیدهای مجزا، پوشه‌های setup-local و cache/session آرایه‌ای برای suite لازم است. تست‌های backup/upgrade حساب آزمون با ساخت/حذف DBهای موقت می‌خواهند؛ حساب وب تولید نباید این اختیار را داشته باشد.

```bash
php artisan migrate --env=testing --seed
php vendor/bin/phpunit --log-junit evidence/phase-10-junit.xml
python3 -m unittest discover -s tests -p release_test.py
npm ci
npm audit
```

۱۳۲ تست/۱۳۷۰ assertion روی PHP 8.4.26 و MySQL 8.4.13 و چهار تست Python موفق‌اند. Composer/npm audit بدون advisory گزارش‌شده‌اند. Nginx/PHP-FPM/MySQL با TLS محلی، ورود واقعی مدیر و switch/rollback تمرین شد؛ ۸۰ درخواست سبک هم‌زمانی ۸ بدون خطا بود. این نتیجه ظرفیت تولید یا گواهی عمومی نیست.

مرورگر این sandbox با SIGTRAP بسته شد و آزمون بصری/axe اجرا نشده است. دستور قابل اجرای آن روی staging مناسب:

```bash
npx playwright install chromium
BARTAR_QA_URL=https://STAGING_HOST npm run qa:browser
```

شرح credential آزمایشی، محدودیت‌ها و caseها در FINAL_ACCEPTANCE.md است. هیچ SMS واقعی، انتشار عمومی، commit/push یا تغییر دامنه انجام نشده است. [گزارش ۹‌بندی مرحله ۱۰](docs/PHASE_10_REPORT.md) و JSON/JUnitهای evidence وضعیت واقعی را ثبت می‌کنند.

[گزارش عملکرد](docs/PERFORMANCE_REPORTS.md) · [بکاپ](docs/BACKUP_RESTORE.md) · [سلامت](docs/SYSTEM_HEALTH.md) · [وضعیت قابلیت‌ها](docs/IMPLEMENTATION_STATUS.md)
