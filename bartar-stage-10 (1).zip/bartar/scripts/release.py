#!/usr/bin/env python3
"""Prepare PHP releases; switch only explicitly confirmed, checked targets.

No downloads, secrets, database migrations, deletion, or service reloads happen
implicitly. Activation validates the prepared release with its own PHP config.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import uuid
import zipfile


def release_id(value):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", value):
        raise ValueError("invalid_release_id")
    return value


def inspect_archive(archive):
    files = {}
    total = 0
    with zipfile.ZipFile(archive) as source:
        for item in source.infolist():
            parts = Path(item.filename).parts
            if not parts or parts[0] != "bartar" or ".." in parts or item.filename.startswith("/") or "\\" in item.filename:
                raise ValueError("unsafe_archive_path")
            if stat.S_ISLNK(item.external_attr >> 16):
                raise ValueError("archive_symlink_rejected")
            if item.is_dir():
                continue
            name = "/".join(parts[1:])
            if name in files:
                raise ValueError("archive_duplicate_file")
            if any(part in {"vendor", "node_modules", ".git"} for part in parts[1:]):
                raise ValueError("archive_contains_runtime_or_repository")
            if Path(name).name.startswith(".env") and Path(name).name != ".env.example":
                raise ValueError("archive_contains_environment_secret")
            total += item.file_size
            if total > 200_000_000:
                raise ValueError("source_archive_too_large")
            files[name] = source.read(item)
    for required in ["artisan", "composer.json", "composer.lock", "public/index.php", "public/assets/manifest.json", "scripts/release.py"]:
        if required not in files:
            raise ValueError("archive_missing_source")
    return files


def prepare(args, root):
    target = root / "releases" / args.release_id
    if target.exists():
        raise ValueError("release_already_exists")
    files = inspect_archive(args.archive)
    shared = root / "shared"
    shared.mkdir(parents=True, exist_ok=True, mode=0o750)
    for folder in ["app/private", "app/signal-media", "framework/cache/data", "framework/cache/locks", "framework/sessions", "framework/views", "logs"]:
        (shared / "storage" / folder).mkdir(parents=True, exist_ok=True, mode=0o750)
    target.mkdir(parents=True, mode=0o750)
    for name, content in files.items():
        if name.startswith("storage/") or name.startswith("bootstrap/cache/"):
            continue
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
        path.write_bytes(content)
        path.chmod(0o640)
    (target / "bootstrap/cache").mkdir(parents=True, mode=0o750)
    (target / "storage").symlink_to(shared / "storage", target_is_directory=True)
    (target / ".env").symlink_to(shared / ".env")
    metadata = {"id": args.release_id, "source_sha256": hashlib.sha256(Path(args.archive).read_bytes()).hexdigest(), "files": len(files)}
    (target / "release.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return {"status": "prepared", "release_id": args.release_id, "files": len(files)}


def switch(args, root):
    if args.confirm != args.release_id or not args.schema_compatible:
        raise ValueError("confirmation_and_schema_review_required")
    target = (root / "releases" / args.release_id).resolve(strict=True)
    if target.parent != (root / "releases").resolve():
        raise ValueError("target_outside_releases")
    for name in ["vendor/autoload.php", "public/index.php", "release.json", ".env"]:
        if not (target / name).is_file():
            raise ValueError("release_not_installed")
    if (target / ".env").stat().st_mode & 0o077:
        raise ValueError("private_environment_permissions_required")
    command = [args.php, str(target / "artisan"), "deployment:check"]
    if args.staging:
        command.append("--staging")
    environment = dict(os.environ)
    environment["APP_ENV"] = "production"
    result = subprocess.run(command, cwd=target, env=environment, capture_output=True, text=True, timeout=120)
    try:
        report = json.loads(result.stdout.strip())
    except (ValueError, TypeError):
        raise ValueError("preflight_did_not_return_safe_report")
    if result.returncode != 0 or report.get("status") == "blocked":
        return {"status": "blocked", "release_id": args.release_id, "checks": report.get("checks", {})}
    current = root / "current"
    previous = root / "previous"
    old = current.resolve() if current.is_symlink() else None
    if current.exists() and not current.is_symlink():
        raise ValueError("current_must_be_a_symlink")
    if old and old != target:
        temp_previous = root / (".previous-" + uuid.uuid4().hex)
        temp_previous.symlink_to(old, target_is_directory=True)
        os.replace(temp_previous, previous)
    temporary = root / (".current-" + uuid.uuid4().hex)
    temporary.symlink_to(target, target_is_directory=True)
    os.replace(temporary, current)
    return {"status": "switched", "release_id": args.release_id, "staging": args.staging, "worker_restart_required": True, "php_reload_required": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["prepare", "activate", "rollback"])
    parser.add_argument("--root", required=True)
    parser.add_argument("--release-id", required=True, type=release_id)
    parser.add_argument("--archive")
    parser.add_argument("--confirm")
    parser.add_argument("--schema-compatible", action="store_true")
    parser.add_argument("--staging", action="store_true")
    parser.add_argument("--php", default="php")
    args = parser.parse_args()
    try:
        root = Path(args.root)
        if not root.is_absolute() or root == Path("/"):
            raise ValueError("absolute_deploy_root_required")
        root.mkdir(parents=True, exist_ok=True, mode=0o750)
        root = root.resolve()
        if root == Path("/"):
            raise ValueError("absolute_deploy_root_required")
        if args.operation == "prepare":
            if not args.archive:
                raise ValueError("archive_required")
            result = prepare(args, root)
        else:
            result = switch(args, root)
        print(json.dumps(result))
        return 1 if result["status"] == "blocked" else 0
    except (ValueError, OSError, zipfile.BadZipFile, KeyError, subprocess.TimeoutExpired):
        print(json.dumps({"status": "failed", "code": "release_operation_failed"}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
