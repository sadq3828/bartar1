import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const pages = JSON.parse(await readFile(path.join(root,'review/pages.json'),'utf8'));
for (const filename of ['admin-pages.json','membership-pages.json','otp-pages.json']) { try { Object.assign(pages,JSON.parse(await readFile(path.join(root,'review',filename),'utf8'))); } catch(error) {if(error.code!=='ENOENT')throw error;} }
let css = await readFile(path.join(root,'public/assets/site.css'),'utf8');
const font = await readFile(path.join(root,'public/assets/fonts/Vazirmatn-Regular.woff2'));
css = css.replace("'./fonts/Vazirmatn-Regular.woff2'",`'data:font/woff2;base64,${font.toString('base64')}'`);
const art = 'data:image/svg+xml;base64,'+(await readFile(path.join(root,'public/assets/market-scene.svg'))).toString('base64');
const bodies = {};
for (const [url,p] of Object.entries(pages)) {
    const body = p.html.match(/<body[^>]*>([\s\S]*)<\/body>/i)?.[1];
    if (!body) throw new Error('No body for '+url);
    bodies[url] = {
        body: body.replace(/(name="_token" value=")[^"]*/g,'$1')
            .replace(/http:\/\/localhost\/assets\/market-scene.svg/g, art)
            .replace(/http:\/\/localhost:8000\/assets\/market-scene.svg/g,art)
            .replace(/href="https?:\/\/localhost(?::8000)?([^"#]*)(#[^"]*)?"/g,(_,p,h)=>`href="#${p||'/'}${h?'~'+h.slice(1):''}"`)
            .replace(/action="https?:\/\/localhost(?::8000)?([^"]*)"/g,(_,p)=>`action="${p}" data-review-form`),
        title: p.html.match(/<title>([^<]*)<\/title>/)?.[1] || 'برتر',
        className: p.html.match(/<body class="([^"]*)"/)?.[1] || 'app-body',
        status: p.status,
    };
}
bodies['/dev/member'] = bodies['/dev/member/home'];
bodies['/dev/admin'] = bodies['/dev/admin/dashboard'];
const json = JSON.stringify(bodies).replace(/</g,'\\u003c');
const js = `
const pages=${json};
function showPage(){
  const raw=location.hash.slice(1)||'/admin/members'; const [url,anchor]=raw.split('~'); const path=url.split('?')[0];
  const current=pages[path]||pages['/dev'];document.title=current.title+' | پیش‌نمایش مرحله چهارم';
  document.body.className=current.className; document.body.innerHTML=current.body;
  const notice=document.createElement('div');notice.className='offline-review';
  notice.textContent='پیش‌نمایش آفلاین مرحلهٔ ۴ · صفحات اعضا و مدیریت با دادهٔ موقت آزمون رندر شده‌اند · فرم‌ها در این فایل اطلاعاتی ارسال نمی‌کنند';
  for(const [url,label] of [['/admin/members','اعضا و اشتراک'],['/app','پنل عضو'],['/login/verify','کد تأیید'],['/','خانه']]) { const a=document.createElement('a');a.href='#'+url;a.textContent=label;a.style.marginInlineStart='16px';notice.append(a); }
  document.body.prepend(notice);
  const query=new URLSearchParams(url.split('?')[1]||'');
  document.querySelectorAll('[name="q"]').forEach(n=>n.value=query.get('q')||'');
  document.querySelectorAll('[name="active"]').forEach(n=>n.checked=query.get('active')==='1');
  document.querySelectorAll('[name="direction"],[name="market"]').forEach(n=>{if(query.has(n.name))n.value=query.get(n.name)});
  document.querySelectorAll('.filter-tabs a,.market-tabs a').forEach(a=>{
    const target=a.getAttribute('href').slice(1);const next=new URLSearchParams(target.split('?')[1]||'');
    const key=path.includes('signals')?'direction':'market'; const value=next.get(key)||'all';
    const active=(query.get(key)||'all')===value;a.classList.toggle('is-active',active);if(active)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current');
    const merged=new URLSearchParams(query);merged.set(key,value);a.setAttribute('href','#'+path+'?'+merged.toString());
  });
  document.querySelectorAll('form[data-review-form]').forEach(form=>form.addEventListener('submit',e=>{
    e.preventDefault();if(form.method.toLowerCase()!=='get'){alert('این فایل فقط برای بررسی ظاهر است. برای ورود و ذخیرهٔ تغییرات، نسخهٔ Laravel را اجرا کنید.');return;}const q=new URLSearchParams(new FormData(form)); location.hash=form.getAttribute('action')+'?'+q.toString();
  }));
  document.querySelectorAll('a[href="#main"]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();document.getElementById('main')?.focus()}));
  requestAnimationFrame(()=>{if(anchor)document.getElementById(anchor)?.scrollIntoView();else scrollTo(0,0)});
}
window.addEventListener('hashchange',showPage);showPage();
`;
const html='<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>برتر | پیش‌نمایش مرحله چهارم</title><style>'+css+'\n.offline-review{padding:6px 16px;text-align:center;font:10px/1.8 Vazirmatn,Tahoma,sans-serif;background:#173947;color:#b8dce5;border-bottom:1px solid #35606c}</style></head><body><noscript>برای جابه‌جایی بین صفحات این پیش‌نمایش آفلاین، JavaScript لازم است. نسخهٔ اصلی Laravel بدون JavaScript نیز صفحات و فیلترها را ارائه می‌کند.</noscript><script>'+js+'</script></body></html>';
await mkdir(path.join(root,'review'),{recursive:true});
await writeFile(path.join(root,'review/bartar-stage-4-preview.html'),html);
console.log(JSON.stringify({pages:Object.keys(bodies).length,bytes:Buffer.byteLength(html),selfContained:true}));
