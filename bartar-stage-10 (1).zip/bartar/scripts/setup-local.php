<?php

declare(strict_types=1);

// Development bootstrap only: no database mutations, accounts or static secrets.
$root = dirname(__DIR__);
$required = ['bcmath', 'ctype', 'curl', 'dom', 'fileinfo', 'filter', 'hash', 'intl', 'mbstring', 'openssl', 'pdo_mysql', 'session', 'sodium', 'tokenizer', 'xml'];
$missing = array_values(array_filter($required, fn ($extension) => ! extension_loaded($extension)));
if (PHP_VERSION_ID < 80400 || $missing) {
    fwrite(STDERR, 'PHP >= 8.4 and required extensions are needed: '.implode(', ', $missing).PHP_EOL);
    exit(1);
}
foreach (['bootstrap/cache', 'storage/app/private', 'storage/framework/cache/data', 'storage/framework/sessions', 'storage/framework/views', 'storage/logs'] as $directory) {
    $path = $root.'/'.$directory;
    if (! is_dir($path) && ! mkdir($path, 0750, true) && ! is_dir($path)) {
        throw new RuntimeException('Could not prepare application directories.');
    }
}
if (! file_exists($root.'/.env')) {
    $config = [
        'APP_NAME' => '"برتر"', 'APP_ENV' => 'local', 'APP_KEY' => 'base64:'.base64_encode(random_bytes(32)),
        'OTP_HMAC_KEY' => bin2hex(random_bytes(32)), 'APP_DEBUG' => 'false', 'APP_URL' => 'http://localhost:8000', 'APP_LOCALE' => 'fa', 'APP_FALLBACK_LOCALE' => 'fa',
        'DB_CONNECTION' => 'mysql', 'DB_HOST' => '127.0.0.1', 'DB_PORT' => '3306', 'DB_DATABASE' => 'bartar',
        'DB_USERNAME' => '', 'DB_PASSWORD' => '', 'SESSION_DRIVER' => 'file', 'CACHE_STORE' => 'file',
        'QUEUE_CONNECTION' => 'database', 'BARTAR_PREVIEW_ENABLED' => 'true',
    ];
    $lines = [];
    foreach ($config as $name => $value) {
        $lines[] = $name.'='.$value;
    }
    if (file_put_contents($root.'/.env', implode(PHP_EOL, $lines).PHP_EOL, LOCK_EX) === false) {
        throw new RuntimeException('Could not write local configuration.');
    }
    chmod($root.'/.env', 0600);
    echo 'Local configuration created with a fresh private key.'.PHP_EOL;
} else {
    $existing = file_get_contents($root.'/.env');
    if (preg_match('/^APP_ENV=local$/m', $existing) && ! preg_match('/^OTP_HMAC_KEY=.{32,}$/m', $existing)) {
        $existing = preg_replace('/^OTP_HMAC_KEY=.*$/m', '', $existing);
        file_put_contents($root.'/.env', rtrim($existing).PHP_EOL.'OTP_HMAC_KEY='.bin2hex(random_bytes(32)).PHP_EOL, LOCK_EX);
        chmod($root.'/.env', 0600);
        echo 'A missing local OTP key was generated privately.'.PHP_EOL;
    }
    echo 'Existing application and database settings preserved.'.PHP_EOL;
}
echo 'No migration, seed, account creation or external request was performed.'.PHP_EOL;
