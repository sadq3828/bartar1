<?php

declare(strict_types=1);

use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

require dirname(__DIR__).'/vendor/autoload.php';
$app = require dirname(__DIR__).'/bootstrap/app.php';
$kernel = $app->make(Kernel::class);
$kernel->bootstrap();
if (! $app->environment('local') || config('bartar.preview_enabled') !== true) {
    fwrite(STDERR, 'Review export is available only in a local environment with preview enabled.'.PHP_EOL);
    exit(1);
}
$destination = $argv[1] ?? dirname(__DIR__).'/review';
if (! is_dir($destination)) mkdir($destination, 0750, true);
$paths = ['/', '/about', '/subscription', '/guide', '/terms', '/privacy', '/contact', '/announcements', '/login', '/admin/login', '/admin/recovery', '/dev', '/dev/states'];
foreach (array_keys(config('bartar.member_navigation')) as $page) $paths[] = '/dev/member/'.$page;
foreach (['notifications', 'subscription'] as $page) $paths[] = '/dev/member/'.$page;
foreach (array_keys(config('bartar.admin_navigation')) as $page) $paths[] = '/dev/admin/'.$page;
$pages = [];
foreach ($paths as $path) {
    $request = Request::create('http://localhost'.$path, 'GET');
    $response = $kernel->handle($request);
    if (! in_array($response->getStatusCode(), [200, 503], true)) {
        throw new RuntimeException('Unexpected export response for '.$path);
    }
    $pages[$path] = ['status' => $response->getStatusCode(), 'html' => $response->getContent()];
    $kernel->terminate($request, $response);
}
file_put_contents($destination.'/pages.json', json_encode($pages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
echo json_encode(['pages' => count($pages), 'destination' => $destination, 'private_data_read' => false], JSON_UNESCAPED_SLASHES).PHP_EOL;
