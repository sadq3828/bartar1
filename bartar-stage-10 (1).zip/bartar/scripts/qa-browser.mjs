// Run against an authorized test/staging host. No OTP or business mutation is sent.
import { chromium } from 'playwright';
import axe from 'axe-core';
import { writeFile } from 'node:fs/promises';

const base = process.env.BARTAR_QA_URL;
if (!base || !['https:', 'http:'].includes(new URL(base).protocol)) throw new Error('BARTAR_QA_URL is required');
const host = new URL(base).hostname;
const local = ['localhost', '127.0.0.1', '[::1]'].includes(host) || host.endsWith('.test');
if (process.env.BARTAR_QA_INSECURE_LOCAL_TLS === 'true' && !local) throw new Error('TLS relaxation is restricted to isolated hosts');
const result = { status: 'running', browser: 'chromium', public: [], admin: [], violations: [], errors: [], limits: ['Synthetic browser checks do not establish production capacity or real SMS delivery.'] };
let browser;
try {
  browser = await chromium.launch(process.env.BARTAR_QA_CHROME ? { executablePath: process.env.BARTAR_QA_CHROME } : {});
  const context = await browser.newContext({ ignoreHTTPSErrors: process.env.BARTAR_QA_INSECURE_LOCAL_TLS === 'true' && local });
  const page = await context.newPage();
  page.on('pageerror', () => result.errors.push('page_script_error'));
  async function check(path, width, area) {
    await page.setViewportSize({ width, height: 900 });
    const response = await page.goto(new URL(path, base).href, { waitUntil: 'networkidle' });
    const layout = await page.evaluate(() => ({ rtl: document.documentElement.dir === 'rtl', overflow: document.documentElement.scrollWidth > innerWidth + 1, h1: document.querySelectorAll('h1').length }));
    if (!response || response.status() >= 400 || !layout.rtl || layout.overflow || layout.h1 !== 1) throw new Error('layout_or_response_failed');
    await page.evaluate(axe.source);
    const audit = await page.evaluate(async () => await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa'] } }));
    result.violations.push(...audit.violations.map(v => ({ path, width, id: v.id, impact: v.impact, count: v.nodes.length })));
    result[area].push({ path, width, status: response.status(), rtl: true, horizontal_overflow: false });
  }
  for (const width of [360, 390, 768, 1440]) {
    for (const path of ['/', '/about', '/subscription', '/guide', '/terms', '/privacy', '/contact', '/announcements', '/admin/login']) await check(path, width, 'public');
  }
  await page.goto(new URL('/', base).href);
  await page.keyboard.press('Tab');
  if (!await page.locator('.skip-link').evaluate(el => el === document.activeElement)) throw new Error('skip_link_focus_failed');
  await page.keyboard.press('Enter');
  if (!await page.locator('#main').evaluate(el => el === document.activeElement)) throw new Error('skip_link_target_failed');
  if (process.env.BARTAR_QA_ADMIN_USERNAME && process.env.BARTAR_QA_ADMIN_PASSWORD) {
    await page.goto(new URL('/admin/login', base).href);
    await page.locator('#username').fill(process.env.BARTAR_QA_ADMIN_USERNAME);
    await page.locator('#password').fill(process.env.BARTAR_QA_ADMIN_PASSWORD);
    await Promise.all([page.waitForURL('**/admin'), page.locator('button[type=submit]').click()]);
    for (const width of [390, 1440]) for (const path of ['/admin', '/admin/reports', '/admin/backups', '/admin/health', '/admin/signals', '/admin/content']) await check(path, width, 'admin');
    const cookie = (await context.cookies()).find(c => c.name === 'bartar_admin_session');
    if (!cookie?.httpOnly || (new URL(base).protocol === 'https:' && !cookie.secure)) throw new Error('session_cookie_failed');
  } else result.limits.push('Authenticated admin pages were not run; no test credentials supplied.');
  result.status = result.errors.length || result.violations.length ? 'failed' : 'passed';
} catch (error) {
  // Do not include browser traces, credentials, page content or server internals.
  result.status = browser ? 'failed' : 'not_run';
  result.errors.push(browser ? 'browser_assertion_failed' : 'browser_runtime_unavailable');
} finally {
  if (browser) await browser.close();
}
await writeFile(process.env.BARTAR_QA_REPORT || 'browser-qa.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ status: result.status, public_cases: result.public.length, admin_cases: result.admin.length, violations: result.violations.length }));
process.exitCode = result.status === 'passed' ? 0 : 1;
