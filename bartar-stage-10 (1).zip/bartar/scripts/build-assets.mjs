import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root = fileURLToPath(new URL('../', import.meta.url));
const assets = path.join(root, 'public/assets');
await mkdir(assets, { recursive: true });
await copyFile(path.join(root, 'resources/css/app.css'), path.join(assets, 'site.css'));
await copyFile(path.join(root, 'resources/js/app.js'), path.join(assets, 'site.js'));
const manifest = {};
for (const name of ['site.css', 'site.js', 'fonts/Vazirmatn-Regular.woff2', 'market-scene.svg', 'favicon.svg']) {
    const bytes = await readFile(path.join(assets, name));
    manifest[name] = { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}
await writeFile(path.join(assets, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify({ status: 'built', assets: Object.keys(manifest).length, totalBytes: Object.values(manifest).reduce((n,v) => n + v.bytes, 0) }));
