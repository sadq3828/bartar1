@props(['icon' => 'document', 'title', 'description'])
<div {{ $attributes->merge(['class' => 'empty-state']) }}>
    <span class="empty-icon"><x-icon :name="$icon" /></span>
    <h2>{{ $title }}</h2><p>{{ $description }}</p>
    @if(trim($slot))<div class="empty-actions">{{ $slot }}</div>@endif
</div>
