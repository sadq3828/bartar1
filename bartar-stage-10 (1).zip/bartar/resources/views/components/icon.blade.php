@props(['name', 'class' => ''])
<svg {{ $attributes->merge(['class' => 'icon '.$class]) }} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
@switch($name)
@case('home')<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Z"/><path d="M9 21v-7h6v7"/>@break
@case('signal')<path d="M20 10V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h5"/><path d="m6 13 4-4 3 2 4-5m1 8 1.2 2.4 2.6.4-1.9 1.9.4 2.6-2.3-1.2-2.3 1.2.4-2.6-1.9-1.9 2.6-.4Z"/>@break
@case('pie')<path d="M21 13a9 9 0 1 1-10-10v10Z"/><path d="M15 2v7h7a8 8 0 0 0-7-7Z"/>@break
@case('chart')<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M7 16v-4m5 4V7m5 9v-6"/>@break
@case('user')<circle cx="12" cy="12" r="9"/><circle cx="12" cy="9" r="3"/><path d="M6 19a6 6 0 0 1 12 0"/>@break
@case('users')<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2m1-15a3 3 0 0 1 0 6m2 3a5 5 0 0 1 3 4v2"/>@break
@case('crown')<path d="m3 6 4 4 5-6 5 6 4-4-3 13H6Z"/><path d="M7 22h10"/>@break
@case('headphones')<path d="M4 13v-1a8 8 0 0 1 16 0v1m-2 7h-3"/><rect x="2" y="11" width="5" height="9" rx="2"/><rect x="17" y="11" width="5" height="9" rx="2"/>@break
@case('arrow-left')<path d="m14 6-6 6 6 6M8 12h13"/>@break
@case('arrow-up')<path d="m6 15 9-9m-7 0h7v7"/>@break
@case('shield')<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>@break
@case('book')<path d="M12 5v16M3 4h5a4 4 0 0 1 4 2 4 4 0 0 1 4-2h5v15h-5a4 4 0 0 0-4 2 4 4 0 0 0-4-2H3Z"/>@break
@case('document')<path d="M14 3H5v18h14V8Z"/><path d="M14 3v5h5M8 12h8m-8 4h6"/>@break
@case('bell')<path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 10h18c0-2-3-2-3-10M10 22h4"/>@break
@case('compass')<circle cx="12" cy="12" r="9"/><path d="m16 8-2 6-6 2 2-6Z"/>@break
@case('search')<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>@break
@case('calendar')<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18m-13 4h1m6 0h1"/>@break
@case('grid')<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>@break
@case('pulse')<path d="M2 12h5l3-8 4 16 3-8h5"/>@break
@case('settings')<path d="m9 3-1 3-3 1-2 5 2 5 3 1 1 3h6l1-3 3-1 2-5-2-5-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>@break
@case('lock')<rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>@break
@case('check')<path d="m5 12 4 4L20 5"/>@break
@case('info')<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>@break
@case('gold')<path d="m7 6-4 13h18L17 6Z"/><path d="M7 6h10l-2 7H5m10 0 6 6M9 16h2"/>@break
@case('coin')<circle cx="12" cy="12" r="9"/><path d="M9 5v14m0-12h4a3 3 0 0 1 0 6H9m0 0h4a3 3 0 0 1 0 6m3-14v2"/>@break
@case('currency')<path d="M12 2v20m5-16H9a4 4 0 0 0 0 8h6a4 4 0 0 1 0 8H6" transform="translate(0 -2) scale(1 .95)"/>@break
@case('globe')<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>@break
@default<circle cx="12" cy="12" r="9"/><path d="M8 12h8"/>
@endswitch
</svg>
