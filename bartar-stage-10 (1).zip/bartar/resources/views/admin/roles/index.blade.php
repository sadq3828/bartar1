@extends('layouts.site')
@section('content')
<div class="admin-page-heading"><div><p class="eyebrow">کنترل دسترسی</p><h1>نقش‌ها و مجوزها</h1></div><x-icon name="shield" /></div>@include('partials.form-messages')
<section class="panel-card"><div class="data-table"><table><thead><tr><th>نقش</th><th>تعداد مجوز</th><th>نوع</th><th>عملیات</th></tr></thead><tbody>@foreach($roles as $role)<tr><td>{{ $role->title }}</td><td>{{ $role->permissions_count }}</td><td>{{ $role->protected ? 'نقش اصلی حفاظت‌شده' : 'قابل تنظیم' }}</td><td><a class="text-link" href="{{ route('admin.roles.edit',$role) }}">ویرایش مجوزها <x-icon name="arrow-left" /></a></td></tr>@endforeach</tbody></table></div></section>
@endsection
