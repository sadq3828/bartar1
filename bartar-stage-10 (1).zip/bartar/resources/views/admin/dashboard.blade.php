@extends('layouts.site')
@section('content')
<div class="admin-page-heading"><div><p class="eyebrow">خوش آمدید، {{ $adminUser->display_name ?: $adminUser->username }}</p><h1>داشبورد مدیریت</h1></div><span class="admin-date"><x-icon name="calendar" />{{ \App\Modules\Foundation\Support\PersianDate::format(now()) }}</span></div>
@include('partials.form-messages')
<div class="admin-metrics">@foreach($stats as $label=>$value)<section class="metric-card"><span class="metric-icon"><x-icon name="shield" /></span><span>{{ $label }}</span><strong>{{ strtr((string)$value,['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']) }}</strong><small>بر اساس دادهٔ ثبت‌شده</small></section>@endforeach</div>
<section class="panel-card"><div class="section-heading"><h2>دسترسی‌های مدیریتی</h2><x-icon name="grid" /></div><p class="page-description">بخش‌های مجاز برای نقش شما در منوی مدیریت نمایش داده می‌شوند.</p><div class="admin-shortcuts"><a class="button button-outline" href="{{ route('admin.sessions') }}">نشست‌های حساب <x-icon name="user" /></a><a class="button button-outline" href="{{ route('admin.security') }}">امنیت و تغییر رمز <x-icon name="lock" /></a></div></section>
@endsection
