@extends('layouts.site')
@section('content')
@php($statusLabels=['draft'=>'پیش‌نویس','scheduled'=>'زمان‌بندی‌شده','published'=>'منتشرشده','completed'=>'تکمیل‌شده','cancelled'=>'لغوشده','expired'=>'منقضی'])
<div class="admin-page-heading"><div><p class="eyebrow">{{ $signal->market->title }} · <bdi dir="ltr">{{ $signal->asset->symbol }}</bdi></p><h1>{{ $signal->title }}</h1></div><div class="admin-shortcuts">@if($adminUser->allows('signals.update'))<a class="button button-outline" href="{{ route('admin.signals.edit',$signal) }}">ویرایش <x-icon name="edit" /></a>@endif<a class="button button-ghost" href="{{ route('admin.signals.index') }}">فهرست</a></div></div>
@include('partials.form-messages')
<div class="signal-admin-grid"><section class="panel-card"><div class="section-heading"><h2>مشخصات نسخه {{ $signal->version }}</h2><span class="badge signal-status-{{ $signal->status }}">{{ $statusLabels[$signal->status] }}</span></div><dl class="member-details"><div><dt>جهت / نوع</dt><dd>{{ $signal->direction==='buy'?'خرید':'فروش' }} · {{ $signal->trade_type }}</dd></div><div><dt>محدوده ورود</dt><dd dir="ltr">{{ $signal->entry_low }}{{ $signal->entry_high?' – '.$signal->entry_high:'' }}</dd></div><div><dt>حد ضرر</dt><dd dir="ltr">{{ $signal->stop_loss??'ثبت نشده' }}</dd></div><div><dt>تایم‌فریم</dt><dd>{{ $signal->timeframe }}</dd></div><div><dt>انتشار</dt><dd>{{ $signal->published_at?\App\Modules\Foundation\Support\PersianDate::format($signal->published_at,'yyyy/MM/dd HH:mm'):'منتشر نشده' }}</dd></div></dl><p class="preserve-lines signal-body">{{ $signal->body_sanitized }}</p><h3>اهداف</h3><ol class="target-list">@foreach($signal->targets as $target)<li><bdi dir="ltr">{{ $target->price }}</bdi>@if($target->proposed_exit_weight)<small>سهم پیشنهادی {{ $target->proposed_exit_weight }}</small>@endif</li>@endforeach</ol></section>
@if($adminUser->allows('signals.publish'))<section class="panel-card"><h2>تغییر وضعیت</h2><form class="admin-form" method="post" action="{{ route('admin.signals.status',$signal) }}">@csrf<input type="hidden" name="idempotency_key" value="{{ (string)\Illuminate\Support\Str::uuid() }}"><label>وضعیت بعدی<select name="status">@foreach(['draft'=>'پیش‌نویس','scheduled'=>'زمان‌بندی‌شده','published'=>'انتشار اکنون','completed'=>'تکمیل‌شده','cancelled'=>'لغوشده','expired'=>'منقضی'] as $key=>$label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></label><label>زمان انتشار؛ فقط برای زمان‌بندی، وقت تهران<input type="datetime-local" name="scheduled_at"></label><label class="checkbox-option"><input type="checkbox" name="announce_change" value="1">درخواست اعلان تغییر</label>@include('partials.sensitive-confirm',['prefix'=>'status'])<button class="button button-primary" type="submit">ثبت وضعیت</button></form></section>@endif</div>
@if($adminUser->allows('signals.result')&&in_array($signal->status,['published','completed']))<section class="panel-card"><h2>{{ $signal->status==='completed'?'اصلاح نسخه‌دار نتیجه':'ثبت نتیجه' }}</h2><p class="page-description">وزن خروج نسبت به موقعیت اولیه است. بازده ناخالص و پوشش خروج در گزارش عملکرد نمایش داده می‌شود؛ برای بازهٔ ورود، قیمت اجرای ورود را ثبت کنید.</p><form class="admin-form" method="post" action="{{ route('admin.signals.result',$signal) }}">@csrf<div class="form-grid"><label>روش ثبت<select name="method"><option value="manual">دستی</option><option value="targets">بر اساس اهداف ثبت‌شده</option><option value="partial">خروج مرحله‌ای ناقص</option></select></label><label>قیمت اجرای ورود؛ اختیاری<input name="entry_execution_price" inputmode="decimal" dir="ltr"></label><label>نسبت پوشش؛ اختیاری<input name="coverage_ratio" inputmode="decimal" dir="ltr" placeholder="1.0"></label></div><label>یادداشت نتیجه<textarea name="note" maxlength="2000"></textarea></label><fieldset class="repeater" data-repeater="exits"><legend>خروج‌ها</legend><div data-repeater-rows><div class="repeater-row"><label>قیمت خروج<input name="exits[0][price]" inputmode="decimal" dir="ltr" required></label><label>سهم خروج<input name="exits[0][weight]" inputmode="decimal" dir="ltr" required value="1.0"></label><label>زمان؛ اختیاری<input type="datetime-local" name="exits[0][executed_at]"></label><button class="button button-ghost" type="button" data-remove-row>حذف</button></div></div><button class="button button-outline" type="button" data-add-row>افزودن خروج</button><template><div class="repeater-row"><label>قیمت خروج<input data-name="price" inputmode="decimal" dir="ltr" required></label><label>سهم خروج<input data-name="weight" inputmode="decimal" dir="ltr" required></label><label>زمان؛ اختیاری<input type="datetime-local" data-name="executed_at"></label><button class="button button-ghost" type="button" data-remove-row>حذف</button></div></template></fieldset><label class="checkbox-option"><input type="checkbox" name="announce_change" value="1">درخواست اعلان نتیجه/اصلاح</label>@include('partials.sensitive-confirm',['prefix'=>'result'])<button class="button button-primary" type="submit">ثبت نتیجه نسخه‌دار</button></form></section>@endif
<section class="panel-card signal-media-section">
    <div class="section-heading"><h2>رسانه‌های خصوصی</h2><span class="badge badge-outline">{{ $signal->mediaAttachments->count() }} از ۲۰</span></div>
    <p class="page-description">تصویر، صوت و ویدیوی تأییدشده فقط پس از کنترل عضویت یا دسترسی مدیریتی پخش می‌شوند.</p>
    @if($adminUser->allows('media.view')&&$signal->mediaAttachments->isNotEmpty())
        <div class="media-gallery">
            @foreach($signal->mediaAttachments as $attachment)
                @php($file=$attachment->mediaFile)
                <article class="media-card">
                    <div class="media-frame">
                        @if($attachment->kind==='image')
                            <img src="{{ route('admin.media.stream',$file) }}" alt="{{ $attachment->caption?:'تصویر پیوست سیگنال' }}" loading="lazy">
                        @elseif($attachment->kind==='audio')
                            <audio controls controlslist="nodownload noremoteplayback" preload="metadata" src="{{ route('admin.media.stream',$file) }}"></audio>
                        @else
                            <video controls controlslist="nodownload noremoteplayback" disablepictureinpicture preload="metadata" src="{{ route('admin.media.stream',$file) }}"></video>
                        @endif
                    </div>
                    <p>{{ $attachment->caption?:'بدون توضیح' }}</p>
                    <small>{{ number_format($file->bytes/1024,1) }} کیلوبایت · {{ $file->mime }}</small>
                    @if($adminUser->allows('media.delete'))
                        <form class="media-delete-form" method="post" action="{{ route('admin.signals.media.destroy',[$signal,$attachment]) }}">
                            @csrf @method('DELETE')
                            @include('partials.sensitive-confirm',['prefix'=>'delete-media-'.$attachment->public_id])
                            <label class="checkbox-option"><input type="checkbox" name="announce_change" value="1">اعلان تغییر</label>
                            <button class="button button-outline button-small" type="submit">حذف اتصال رسانه</button>
                        </form>
                    @endif
                </article>
            @endforeach
        </div>
    @elseif($signal->mediaAttachments->isEmpty())
        <p class="compact-empty">هنوز رسانه‌ای به این سیگنال متصل نشده است.</p>
    @else
        <p class="compact-empty">مجوز مشاهده رسانه‌های خصوصی برای این نقش فعال نیست.</p>
    @endif
    @if($adminUser->allows('media.reorder')&&$signal->mediaAttachments->count()>1)
        <form class="admin-form media-order-form" method="post" action="{{ route('admin.signals.media.reorder',$signal) }}">
            @csrf @method('PUT')
            <h3>ترتیب نمایش</h3>
            <div class="media-order-grid">@foreach($signal->mediaAttachments as $attachment)<label>{{ $attachment->caption?:'رسانه '.$loop->iteration }}<input type="number" name="media_order[{{ $attachment->public_id }}]" min="1" max="{{ $signal->mediaAttachments->count() }}" value="{{ $attachment->position }}" required></label>@endforeach</div>
            <label class="checkbox-option"><input type="checkbox" name="announce_change" value="1">درخواست اعلان تغییر</label>
            @include('partials.sensitive-confirm',['prefix'=>'reorder-media'])
            <button class="button button-outline" type="submit">ذخیره ترتیب</button>
        </form>
    @endif
    @if($adminUser->allows('media.upload')&&$signal->mediaAttachments->count()<20)
        <form class="admin-form media-upload-form" method="post" enctype="multipart/form-data" action="{{ route('admin.signals.media.store',$signal) }}">
            @csrf
            <h3>افزودن رسانه</h3>
            <div class="form-grid"><label>نوع<select name="kind" required><option value="image">تصویر JPEG/PNG/WebP</option><option value="audio">صوت MP3/AAC/M4A</option><option value="video">ویدیوی MP4</option></select></label><label>فایل<input type="file" name="media" accept="image/jpeg,image/png,image/webp,audio/mpeg,audio/aac,audio/mp4,video/mp4" required></label></div>
            <label>توضیح کوتاه<input name="caption" maxlength="500" value="{{ old('caption') }}"></label>
            <p class="field-help">سقف برنامه: {{ number_format(config('media.max_upload_bytes')/1048576) }} مگابایت. پسوند کافی نیست و نوع واقعی فایل بررسی می‌شود.</p>
            <label class="checkbox-option"><input type="checkbox" name="announce_change" value="1">درخواست اعلان تغییر</label>
            @include('partials.sensitive-confirm',['prefix'=>'upload-media'])
            <button class="button button-primary" type="submit">بارگذاری خصوصی</button>
        </form>
    @endif
</section>
<div class="signal-history-grid"><section class="panel-card"><h2>تاریخچه وضعیت</h2>@forelse($signal->statusEvents as $event)<div class="history-entry"><strong>{{ $event->from_status?$statusLabels[$event->from_status].' ← ':'' }}{{ $statusLabels[$event->to_status] }}</strong><small>{{ \App\Modules\Foundation\Support\PersianDate::format($event->happened_at,'yyyy/MM/dd HH:mm') }} · {{ $event->reason }}</small></div>@empty<p class="page-description">رویدادی ثبت نشده است.</p>@endforelse</section><section class="panel-card"><h2>نسخه‌های پیشین</h2>@forelse($signal->revisions as $revision)<details class="history-entry"><summary>نسخه {{ $revision->version }} · {{ \App\Modules\Foundation\Support\PersianDate::format($revision->changed_at,'yyyy/MM/dd HH:mm') }}</summary><p class="page-description">{{ $revision->reason }} · اعلان: {{ $revision->announce_change?'درخواست شده':'خیر' }}</p><pre>{{ json_encode($revision->snapshot_json,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) }}</pre></details>@empty<p class="page-description">تا زمانی که محتوای منتشرشده تغییر نکند، نسخهٔ پیشین ساخته نمی‌شود.</p>@endforelse</section></div>
@if($signal->results->isNotEmpty())<section class="panel-card"><h2>نسخه‌های نتیجه</h2>@foreach($signal->results as $result)<details class="history-entry"><summary>نتیجه نسخه {{ $result->version }} · {{ $result->method }}</summary><p class="preserve-lines">{{ $result->note?:'بدون یادداشت' }}</p><ol class="target-list">@foreach($result->exits as $exit)<li><bdi dir="ltr">{{ $exit->exit_price }}</bdi><small>سهم {{ $exit->exit_weight }}</small></li>@endforeach</ol></details>@endforeach</section>@endif
@endsection
