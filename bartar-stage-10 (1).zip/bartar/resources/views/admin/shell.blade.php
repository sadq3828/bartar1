@extends('layouts.site')
@section('content')
<div class="admin-page-heading"><div><p class="eyebrow">مدیریت برتر</p><h1>{{ $title }}</h1></div><span class="admin-date"><x-icon name="calendar" />{{ \App\Modules\Foundation\Support\PersianDate::format(now()) }}</span></div>
@if($active === 'dashboard')
<div class="admin-metrics">@foreach([['users','اعضای دارای اشتراک'],['signal','سیگنال‌های فعال'],['chart','آخرین دریافت قیمت'],['shield','آخرین بکاپ']] as [$icon,$label])<section class="metric-card"><span class="metric-icon"><x-icon :name="$icon" /></span><span>{{ $label }}</span><strong>—</strong><small>هنوز داده‌ای متصل نشده</small></section>@endforeach</div>
<div class="admin-panels"><section class="panel-card"><div class="section-heading"><h2>آخرین فعالیت‌ها</h2><x-icon name="pulse" /></div><x-empty-state icon="document" title="فعالیتی ثبت نشده" description="پس از فعال‌شدن ماژول‌ها، رویدادهای مجاز در این بخش دیده می‌شوند." /></section><section class="panel-card"><div class="section-heading"><h2>وضعیت سرویس‌ها</h2><x-icon name="settings" /></div>@foreach(['پایگاه داده','پیامک','منبع قیمت','فضای رسانه'] as $service)<div class="service-row"><span>{{ $service }}</span><span class="badge badge-muted">بررسی نشده</span></div>@endforeach<p class="subtle-note">وضعیت سلامت بدون اجرای بررسی واقعی، موفق اعلام نمی‌شود.</p></section></div>
@else
<section class="panel-card"><div class="section-heading"><h2>{{ $title }}</h2><span class="badge badge-outline">قالب پایه</span></div><x-empty-state :icon="config('bartar.admin_navigation.'.$active.'.icon')" title="داده‌ای برای نمایش وجود ندارد" description="این صفحه ساختار پایهٔ فضای مدیریت است. عملیات این بخش پس از تکمیل ماژول مربوط در دسترس قرار می‌گیرد." /></section>
@endif
@endsection
