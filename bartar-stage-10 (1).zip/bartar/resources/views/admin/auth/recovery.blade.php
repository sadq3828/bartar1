@extends('layouts.site')
@section('content')
<div class="page-intro"><span class="page-icon"><x-icon name="lock" /></span><p class="eyebrow">دسترسی مدیریت</p><h1>بازیابی امن رمز</h1><p>بازیابی رمز مدیریت در این نسخه توسط مسئول مجاز سرور انجام می‌شود. هیچ رمز یا کد بازیابی را از راه‌های غیررسمی ارسال نکنید.</p></div>
<section class="text-card"><x-icon name="shield" /><div><h2>پس از تغییر رمز</h2><p>همه نشست‌های قبلی آن حساب لغو می‌شوند و ورود دوباره با رمز جدید لازم است.</p></div></section><a class="button button-outline full-width" href="{{ route('admin.login') }}">بازگشت به ورود مدیریت</a>
@endsection
