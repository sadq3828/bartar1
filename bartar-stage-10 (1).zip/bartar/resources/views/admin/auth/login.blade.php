@extends('layouts.site')
@section('content')
<section class="auth-card real-login"><span class="auth-icon"><x-icon name="shield" /></span><span class="badge badge-outline">فضای مدیریت برتر</span><h1>ورود مدیریت</h1><p>با نام کاربری و رمز عبور خود وارد شوید.</p>
@include('partials.form-messages')
<form method="post" action="{{ route('admin.login.submit') }}" class="admin-form">@csrf
<label for="username">نام کاربری</label><input id="username" name="username" value="{{ old('username') }}" required maxlength="64" dir="ltr" autocomplete="username" autocapitalize="none" spellcheck="false">
<label for="password">رمز عبور</label><input id="password" name="password" type="password" required maxlength="128" dir="ltr" autocomplete="current-password">
<button class="button button-primary full-width" type="submit">ورود به مدیریت <x-icon name="arrow-left" /></button></form>
<a class="text-link" href="{{ route('admin.recovery') }}">بازیابی دسترسی</a><p class="auth-note"><x-icon name="lock" /> دسترسی مدیریت با حساب اعضا متفاوت است.</p></section>
@endsection
