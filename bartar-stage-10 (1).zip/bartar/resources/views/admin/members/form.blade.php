@extends('layouts.site')
@section('content')
<div class="admin-page-heading"><div><p class="eyebrow">شماره مجاز</p><h1>{{ $member?'ویرایش عضو':'افزودن عضو' }}</h1></div><a class="button button-outline" href="{{ route('admin.members.index') }}">فهرست اعضا</a></div>@include('partials.form-messages')
<section class="panel-card"><form class="admin-form" method="post" action="{{ $member?route('admin.members.update',$member):route('admin.members.store') }}">@csrf @if($member)@method('PUT')@endif
<label for="allowed-phone">شماره موبایل ایران</label><input id="allowed-phone" name="phone" type="tel" inputmode="tel" autocomplete="off" dir="ltr" value="{{ $member?->phone_e164 }}" required maxlength="40"><label for="display-name">نام نمایشی؛ اختیاری</label><input id="display-name" name="display_name" value="{{ old('display_name',$member?->account->display_name) }}" maxlength="100"><label for="internal-note">یادداشت داخلی؛ فقط مدیران مجاز</label><textarea id="internal-note" name="internal_note" maxlength="2000">{{ $member?->internal_note }}</textarea>
<p class="page-description">ثبت شماره به‌تنهایی اجازه ورود ایجاد نمی‌کند. تغییر شماره، نشست‌ها و کدهای ورود قبلی را باطل می‌کند.</p>@include('partials.sensitive-confirm',['prefix'=>'member'])<button type="submit" class="button button-primary">ذخیره عضو</button></form></section>
@endsection
