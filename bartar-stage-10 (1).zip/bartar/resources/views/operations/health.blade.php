@extends('layouts.site')
@section('content')
@php($labels=['database'=>'پایگاه داده','private_storage'=>'رسانهٔ خصوصی؛ خواندن و نوشتن','scheduler'=>'زمان‌بند','queue_worker'=>'پردازشگر صف','failed_jobs'=>'کارهای شکست‌خوردهٔ صف','otp_sms'=>'پیامک ورود','notification_sms'=>'پیامک اعلان','notification_deliveries'=>'تحویل اعلان','market_prices'=>'تازگی منابع قیمت','backup'=>'بکاپ','restore_drill'=>'بازیابی آزمایشی','disk_space'=>'فضای دیسک'])
@php($states=['healthy'=>'سالم','unknown'=>'نامعلوم','not_configured'=>'پیکربندی نشده','failed'=>'ناموفق','stale'=>'قدیمی','degraded'=>'نیازمند بررسی'])
<div class="page-title-row"><h1>سلامت سامانه</h1><span class="badge {{ $health['status']==='healthy'?'price-status-fresh':'badge-warning' }}">{{ $health['status']==='healthy'?'سالم':'نیازمند بررسی' }}</span></div>
<p class="page-description">وضعیت پیکربندی‌نشده و نامعلوم نیازمند بررسی است. سلامت اتصال، تضمین آماده‌بودن کل محصول نیست.</p>
<div class="panel-card service-list">@foreach($health['checks'] as $key=>$state)<div class="service-row"><strong>{{ $labels[$key] }}</strong><span class="badge {{ $state==='healthy'?'price-status-fresh':'badge-warning' }}">{{ $states[$state] }}</span></div>@endforeach</div>
<p class="subtle-note">آخرین بررسی: {{ \App\Modules\Foundation\Support\PersianDate::format($health['checked_at'],'yyyy/MM/dd HH:mm:ss') }} تهران</p>
@endsection
