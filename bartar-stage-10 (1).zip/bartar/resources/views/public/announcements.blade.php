@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>اطلاعیه‌ها</h1><span class="page-icon small"><x-icon name="bell" /></span></div>
<p class="page-description">خبرها و اطلاع‌رسانی‌های رسمی برتر در این بخش منتشر می‌شوند.</p>
@forelse($announcements as $announcement)<article class="panel-card announcement-card"><div class="section-heading"><h2>{{ $announcement->title }}</h2><span class="badge badge-muted">رسمی</span></div><p class="preserve-lines">{{ $announcement->body }}</p><small>{{ \App\Modules\Foundation\Support\PersianDate::format($announcement->published_at,'yyyy/MM/dd HH:mm') }}</small></article>@empty<x-empty-state icon="bell" title="هنوز اطلاعیه‌ای منتشر نشده" description="اطلاعیه‌های جدید پس از انتشار در این صفحه قرار می‌گیرند."><a class="button button-outline" href="{{ route('home') }}">بازگشت به خانه</a></x-empty-state>@endforelse
{{ $announcements->links('partials.pagination') }}
@endsection
