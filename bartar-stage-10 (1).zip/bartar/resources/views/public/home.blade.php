@extends('layouts.site')
@section('content')
<section class="hero">
    <div class="eyebrow"><span class="tiny-line"></span>{{ $homeContent['eyebrow'] ?? 'همراه مسیر آگاهانهٔ شما' }}</div>
    <h1>{{ $homeContent['title'] ?? 'نگاه روشن‌تر، تصمیم آگاهانه‌تر.' }}</h1>
    <p>{{ $homeContent['intro'] ?? 'تحلیل‌ها، سیگنال‌ها و گزارش عملکرد را در یک فضای منظم دنبال کنید.' }}</p>
    <div class="hero-actions"><a class="button button-primary" href="{{ route('login') }}">{{ $brandSettings['member_cta'] ?? 'ورود اعضا' }} <x-icon name="arrow-left" /></a><a class="button button-ghost" href="{{ route('about') }}">آشنایی با برتر</a></div>
    <div class="hero-footnote"><x-icon name="shield" /> دسترسی با شمارهٔ مجاز و اشتراک فعال</div>
</section>
<div class="market-banner">
    <div class="banner-content"><span>دیدی منظم به بازار</span><h2>از تحلیل<br>تا پیگیری نتیجه</h2><a href="{{ route('guide') }}">راهنمای استفاده <x-icon name="arrow-left" /></a></div>
    @if($homeContent['hero_media'] ?? null)<img class="market-illustration" src="{{ route('content.media',$homeContent['hero_media']) }}" alt="{{ $homeContent['hero_media']->alt_text }}" width="260" height="220" decoding="async">@else<img class="market-illustration" src="{{ asset('assets/market-scene.svg') }}" alt="" width="260" height="220" decoding="async">@endif
</div>
<section class="section-block" aria-labelledby="features-title">
    <div class="section-heading"><h2 id="features-title">یک مسیر، چند نگاه</h2><span class="section-note">بخش‌های برتر</span></div>
    <div class="feature-grid">
        <a class="feature-card" href="{{ route('guide') }}#signals"><span class="feature-icon"><x-icon name="signal" /></span><h3>پیگیری سیگنال</h3><p>مشخصات، اهداف و اصلاحات</p><x-icon class="feature-arrow" name="arrow-left" /></a>
        <a class="feature-card" href="{{ route('guide') }}#performance"><span class="feature-icon"><x-icon name="pie" /></span><h3>گزارش عملکرد</h3><p>نتیجهٔ ثبت‌شده و قابل بررسی</p><x-icon class="feature-arrow" name="arrow-left" /></a>
    </div>
</section>
<section class="section-block" aria-labelledby="markets-title">
    <div class="section-heading"><h2 id="markets-title">بازارهای مورد توجه</h2><x-icon name="globe" /></div>
    <div class="market-categories"><span><x-icon name="coin" /> ارز دیجیتال</span><span><x-icon name="currency" /> فارکس</span><span><x-icon name="gold" /> طلا</span><span><x-icon name="chart" /> بازار داخلی</span></div>
    <p class="subtle-note">قیمت رمزارز از منبع عمومی فعال و همراه زمان و وضعیت تازگی نمایش داده می‌شود؛ بازار بدون منبع، ناموجود می‌ماند.</p>
</section>
<section class="join-card"><span class="join-symbol"><x-icon name="crown" /></span><div><h2>برای همراهی با برتر</h2><p>با مسیر دریافت و فعال‌سازی اشتراک آشنا شوید.</p></div><a href="{{ route('subscription') }}" class="text-link">راهنمای عضویت <x-icon name="arrow-left" /></a></section>
@if($homeContent && count($homeContent['sections']))<section class="content-sections">@foreach($homeContent['sections'] as $section)<article class="text-card"><div><h2>{{ $section['title'] }}</h2><p>{{ $section['body'] }}</p>@if($section['action_url'] ?? null)<a class="text-link" href="{{ $section['action_url'] }}">{{ $section['action_label'] }} <x-icon name="arrow-left" /></a>@endif</div></article>@endforeach</section>@endif
<section class="section-block"><div class="section-heading"><h2>آخرین اطلاعیه‌ها</h2><a class="text-link" href="{{ route('announcements') }}">همه <x-icon name="arrow-left" /></a></div>@forelse($latestAnnouncements as $announcement)<article class="history-entry"><strong>{{ $announcement->title }}</strong><p class="preserve-lines">{{ $announcement->body }}</p><small>{{ \App\Modules\Foundation\Support\PersianDate::format($announcement->published_at,'yyyy/MM/dd HH:mm') }}</small></article>@empty<div class="compact-empty"><x-icon name="bell" /><span>هنوز اطلاعیه‌ای منتشر نشده است.</span></div>@endforelse</section>
@endsection
