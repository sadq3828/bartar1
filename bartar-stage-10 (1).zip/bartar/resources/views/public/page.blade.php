@extends('layouts.site')
@section('content')
<div class="page-intro"><span class="page-icon"><x-icon :name="$content['icon']" /></span><p class="eyebrow">{{ $content['eyebrow'] }}</p><h1>{{ $content['title'] }}</h1><p>{{ $content['intro'] }}</p></div>
@if($content['hero_media'] ?? null)<img class="content-hero-image" src="{{ route('content.media',$content['hero_media']) }}" alt="{{ $content['hero_media']->alt_text }}" decoding="async">@endif
@if(($active ?? '') === 'subscription')
<div class="term-list" aria-label="مدت‌های اشتراک"><span>۱ ماهه</span><span>۳ ماهه</span><span>۶ ماهه</span><span>۱۲ ماهه</span></div>
@endif
<div class="content-sections">
@foreach($content['sections'] as $section)
<section class="text-card" @if(($active ?? '') === 'guide' && $loop->index < 4) id="{{ ['login', 'signals', 'markets', 'subscription'][$loop->index] }}" @endif><span class="text-card-index">{{ strtr((string) ($loop->index + 1), array_combine(range(0,9), preg_split('//u', '۰۱۲۳۴۵۶۷۸۹', -1, PREG_SPLIT_NO_EMPTY))) }}</span><div><h2>{{ $section['title'] }}</h2><p>{{ $section['body'] }}</p>@if($section['action_url'] ?? null)<a class="text-link" href="{{ $section['action_url'] }}">{{ $section['action_label'] }} <x-icon name="arrow-left" /></a>@endif</div></section>
@endforeach
</div>
@if(($active ?? '') === 'guide')<section id="performance" class="note-card"><x-icon name="pie" /><p>گزارش عملکرد، نتیجهٔ سیگنال‌های ثبت‌شده را نشان می‌دهد؛ سود واقعی حساب شخصی اعضا از آن استنباط نمی‌شود.</p></section>@endif
@if(($active ?? '') === 'contact' && (($brandSettings['support_email'] ?? null) || config('bartar.support_email')))<a class="button button-primary full-width" href="mailto:{{ $brandSettings['support_email'] ?? config('bartar.support_email') }}">ارسال ایمیل به پشتیبانی <x-icon name="arrow-left" /></a>@endif
@if(($active ?? '') === 'contact' && ($brandSettings['support_phone'] ?? null))<p class="note-card"><x-icon name="headphones" /><bdi dir="ltr">{{ $brandSettings['support_phone'] }}</bdi></p>@endif
<div class="page-end-links"><a class="text-link" href="{{ route('home') }}">بازگشت به خانه</a>@if(($active ?? '') !== 'subscription')<a class="text-link" href="{{ route('subscription') }}">راهنمای اشتراک <x-icon name="arrow-left" /></a>@else<a class="text-link" href="{{ route('contact') }}">ارتباط با ما <x-icon name="arrow-left" /></a>@endif</div>
@endsection
