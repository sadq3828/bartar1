@extends('layouts.site')
@section('content')
<section class="auth-card"><span class="auth-icon"><x-icon :name="$admin ? 'shield' : 'lock'" /></span><span class="badge badge-warning">هنوز فعال نشده</span><h1>{{ $admin ? 'ورود مدیریت' : 'ورود به برتر' }}</h1><p>{{ $admin ? 'دسترسی مدیریت پس از آماده‌شدن سامانه ورود فعال خواهد شد.' : 'ورود پیامکی اعضا هنوز در دسترس نیست. برای آشنایی با شرایط عضویت، راهنمای اشتراک را ببینید.' }}</p><div class="auth-divider"></div><a class="button button-primary full-width" href="{{ route('subscription') }}">راهنمای دریافت اشتراک <x-icon name="arrow-left" /></a><a class="button button-outline full-width" href="{{ route('home') }}">بازگشت به خانه</a><p class="auth-note"><x-icon name="shield" /> ثبت‌نام عمومی در برتر وجود ندارد.</p></section>
@endsection
