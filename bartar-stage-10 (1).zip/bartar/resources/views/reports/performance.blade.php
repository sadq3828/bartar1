@extends('layouts.site')
@section('content')
@php($isAdmin=$area==='admin')
@php($statusLabels=['published'=>'فعال','completed'=>'تکمیل‌شده','cancelled'=>'لغوشده','expired'=>'منقضی'])
<div class="page-title-row"><div><p class="eyebrow">نتایج ثبت‌شدهٔ سیگنال‌ها</p><h1>گزارش عملکرد</h1></div><span class="badge badge-outline">بازده ناخالص · بدون اهرم</span></div>
@include('partials.form-messages')
<div class="note-card"><x-icon name="info" /><p>این گزارش عملکرد سیگنال‌های منتشرشده است. سود حساب شخصی، کارمزد و لغزش را محاسبه نمی‌کند. نرخ موفقیت = نتایج کاملِ مثبت ÷ تمام نتایج کاملِ تکمیل‌شده؛ نتیجهٔ صفر در مخرج است. لغوشده، منقضی و ناقص وارد نرخ نمی‌شوند.</p></div>
<form class="panel-card admin-form report-filters" method="get" action="{{ $isAdmin?route('admin.reports'):route('member.performance') }}">
<label>بازار<select name="market"><option value="">همه</option>@foreach($markets as $market)<option value="{{ $market->id }}" @selected(($filters['market']??'')==$market->id)>{{ $market->title }}</option>@endforeach</select></label>
<label>دارایی<select name="asset"><option value="">همه</option>@foreach($assets as $asset)<option value="{{ $asset->id }}" @selected(($filters['asset']??'')==$asset->id)>{{ $asset->symbol }}</option>@endforeach</select></label>
<label>وضعیت<select name="status"><option value="">همه</option>@foreach($statusLabels as $key=>$label)<option value="{{ $key }}" @selected(($filters['status']??'')===$key)>{{ $label }}</option>@endforeach</select></label>
<label>از تاریخ انتشار؛ میلادی، تهران<input type="date" name="from" value="{{ $filters['from']??'' }}"></label><label>تا تاریخ انتشار؛ میلادی، تهران<input type="date" name="to" value="{{ $filters['to']??'' }}"></label><button class="button button-primary" type="submit">اعمال فیلتر</button>
</form>
<div class="report-stats">@foreach(['total'=>'کل منتشرشده','published'=>'فعال','completed'=>'تکمیل‌شده','cancelled'=>'لغوشده','expired'=>'منقضی','positive'=>'مثبت','negative'=>'منفی','zero'=>'صفر','incomplete'=>'نتیجهٔ ناقص'] as $key=>$label)<div class="panel-card"><small>{{ $label }}</small><strong>{{ \App\Modules\Foundation\Support\PersianDate::number($stats[$key]) }}</strong></div>@endforeach</div>
<section class="panel-card report-rate"><h2>نرخ موفقیت <bdi dir="ltr">{{ $stats['success_rate']===null?'—':$stats['success_rate'].'%' }}</bdi></h2><p>تعداد نتایج معتبر در مخرج (N): {{ \App\Modules\Foundation\Support\PersianDate::number($stats['n']) }} · بدون نتیجهٔ معتبر، نرخ ناموجود است.</p></section>
<div class="report-rows">@forelse($signals as $signal)
@php($result=$signal->results->first()) @php($value=$reports->calculation($result))
<article class="panel-card report-row"><div class="section-heading"><div><h2>{{ $signal->title }}</h2><small>{{ $signal->market->title }} · <bdi dir="ltr">{{ $signal->asset->symbol }}</bdi> · {{ \App\Modules\Foundation\Support\PersianDate::format($signal->published_at,'yyyy/MM/dd HH:mm') }}</small></div><span class="badge badge-muted">{{ $statusLabels[$signal->status] }}</span></div>
@if($value)<dl class="report-values"><div><dt>پوشش خروج</dt><dd><bdi dir="ltr">{{ bcmul($value['coverage'],'100',2) }}%</bdi></dd></div><div><dt>بازده بخش بسته‌شده</dt><dd><bdi dir="ltr">{{ $value['realised_return']===null?'—':$value['realised_return'].'%' }}</bdi></dd></div><div><dt>بازده نهایی</dt><dd><bdi dir="ltr">{{ $value['final_return']===null?'—':$value['final_return'].'%' }}</bdi></dd></div></dl>
<p class="subtle-note">نسخهٔ نتیجه {{ $result->version }} · <bdi dir="ltr">{{ $value['formula_version'] }}</bdi> · {{ ['complete'=>'نتیجهٔ کامل','partial'=>'خروج جزئی؛ بازده نهایی ناموجود','unavailable'=>'ورودی کافی یا سازگار برای محاسبه وجود ندارد'][$value['state']] }}</p>
@if($signal->results->count()>1)<details class="history-entry"><summary>تاریخچهٔ اصلاح نتایج</summary>@foreach($signal->results->skip(1) as $old) @php($oldValue=$reports->calculation($old))<p>نسخه {{ $old->version }} · پوشش <bdi dir="ltr">{{ $oldValue['coverage'] }}</bdi> · بازده نهایی <bdi dir="ltr">{{ $oldValue['final_return']??'—' }}</bdi> · {{ \App\Modules\Foundation\Support\PersianDate::format($old->created_at,'yyyy/MM/dd HH:mm') }}</p>@endforeach</details>@endif
@else<p class="subtle-note">نتیجه‌ای ثبت نشده است.</p>@endif
</article>@empty<x-empty-state icon="pie" title="داده‌ای برای این بازه وجود ندارد" description="با ثبت سیگنال و نتیجهٔ واقعی، عملکرد اینجا نمایش داده می‌شود." />@endforelse</div>
{{ $signals->links('partials.pagination') }}
@if($isAdmin&&$adminUser->allows('reports.export'))<details class="panel-card"><summary>دریافت CSV همین فیلترها</summary><form class="admin-form" method="post" action="{{ route('admin.reports.export') }}">@csrf @foreach($filters as $key=>$filter)<input type="hidden" name="{{ $key }}" value="{{ $filter }}">@endforeach @include('partials.sensitive-confirm',['prefix'=>'export'])<button class="button button-outline" type="submit">دریافت CSV</button></form></details>@endif
<p class="subtle-note">فرمول هر خروج: ۱۰۰ × (قیمت خروج − ورود) ÷ ورود؛ برای فروش جهت معکوس است. جمع وزن‌دار خروج‌ها نسبت به موقعیت اولیه محاسبه می‌شود. بازهٔ ورود بدون قیمت اجرای مشخص، بازده قطعی ندارد. جمع بازده‌ها رشد سرمایه محسوب نمی‌شود.</p>
@endsection
