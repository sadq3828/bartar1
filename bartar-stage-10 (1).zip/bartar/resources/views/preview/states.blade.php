@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>حالت‌های رابط</h1><x-icon name="pulse" /></div>
<p class="page-description">نمونهٔ کامپوننت‌ها برای بررسی طراحی؛ این پیام‌ها نتیجهٔ عملیات واقعی نیستند.</p>
<section class="state-demo"><h2>در حال بارگیری</h2><div class="loading-placeholder" role="status"><span class="sr-only">در حال بارگیری اطلاعات</span><i></i><i></i><i></i></div></section>
<section class="state-demo"><h2>خطا و تلاش مجدد</h2><div class="message message-error" role="alert"><x-icon name="info" /><div><strong>دریافت اطلاعات ممکن نشد</strong><p>اتصال را بررسی کنید و دوباره تلاش کنید.</p></div></div><a class="button button-outline" href="{{ route('preview.states') }}">بارگذاری دوبارهٔ صفحه</a></section>
<section class="state-demo"><h2>موفقیت</h2><div class="message message-success" role="status"><x-icon name="check" /><div><strong>پیام موفقیت</strong><p>نمونهٔ طراحی برای نمایش نتیجهٔ موفق عملیات.</p></div></div></section>
<section class="state-demo"><h2>دادهٔ خالی</h2><x-empty-state title="هنوز رکوردی وجود ندارد" description="پس از ثبت اطلاعات، رکوردها در این بخش نمایش داده می‌شوند." /></section>
@endsection
