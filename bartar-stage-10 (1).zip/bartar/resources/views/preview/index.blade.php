@extends('layouts.site')
@section('content')
<div class="page-intro"><p class="eyebrow">بررسی مرحلهٔ دوم</p><h1>صفحات پایهٔ برتر</h1><p>این مسیر فقط در محیط توسعه فعال است. صفحات پنل، اسکلت خالی دارند و ورود به حساب واقعی انجام نمی‌دهند.</p></div>
<div class="review-links"><a href="{{ route('home') }}"><x-icon name="home" /><span><strong>صفحات عمومی</strong><small>خانه، معرفی، راهنما و عضویت</small></span><x-icon name="arrow-left" /></a><a href="{{ route('preview.member') }}"><x-icon name="user" /><span><strong>قالب پنل اعضا</strong><small>خانه، بازار، سیگنال و عملکرد</small></span><x-icon name="arrow-left" /></a><a href="{{ route('preview.admin') }}"><x-icon name="grid" /><span><strong>قالب مدیریت</strong><small>چیدمان واکنش‌گرا و ماژول‌ها</small></span><x-icon name="arrow-left" /></a><a href="{{ route('preview.states') }}"><x-icon name="pulse" /><span><strong>حالت‌های رابط</strong><small>خالی، خطا، بارگیری و موفقیت</small></span><x-icon name="arrow-left" /></a></div>
@endsection
