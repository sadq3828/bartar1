<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#122544">
    <meta name="description" content="برتر؛ پیگیری منظم تحلیل بازار، سیگنال و گزارش عملکرد برای اعضا.">
    @if($preview ?? false)<meta name="robots" content="noindex,nofollow,noarchive">@endif
    <title>{{ $title ?? ($brandSettings['brand_name'] ?? 'برتر') }} | {{ $brandSettings['brand_name'] ?? 'برتر' }}</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('assets/favicon.svg') }}">
    <link rel="stylesheet" href="{{ asset('assets/site.css') }}?v=10">
    <script src="{{ asset('assets/site.js') }}?v=10" defer></script>
</head>
<body class="{{ ($area ?? 'public') === 'admin' ? 'admin-body' : 'app-body' }}">
<a class="skip-link" href="#main">رفتن به محتوای اصلی</a>
@if($preview ?? false)
    <div class="dev-notice"><span class="status-dot"></span>پیش‌نمایش توسعه؛ بدون دادهٔ اعضا <a href="{{ route('preview.index') }}">فهرست صفحات <x-icon name="arrow-left" /></a></div>
@endif
@if(($area ?? 'public') === 'admin')
    <div class="admin-layout">
        @include('partials.admin-sidebar')
        <div class="admin-workspace">
            @include('partials.header')
            <main id="main" class="admin-main" tabindex="-1">@yield('content')</main>
            <footer class="admin-footer">برتر · فضای مدیریت</footer>
        </div>
    </div>
@else
    <div class="app-shell">
        @include('partials.header')
        <main id="main" class="main-content" tabindex="-1">@yield('content')</main>
        @if(($area ?? 'public') === 'public')
            <footer class="public-footer"><a href="{{ route('terms') }}">قوانین استفاده</a><span>·</span><a href="{{ route('privacy') }}">حریم خصوصی</a><p>{{ $brandSettings['brand_tagline'] ?? 'برتر؛ همراه مسیر آگاهانهٔ شما' }}</p></footer>
        @endif
    </div>
    @include('partials.bottom-nav')
@endif
</body>
</html>
