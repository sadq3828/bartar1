@extends('errors.page', ['title' => 'دسترسی مجاز نیست', 'errorCode' => '۴۰۳', 'errorTitle' => 'دسترسی مجاز نیست', 'errorMessage' => 'برای دسترسی به این بخش، مجوز معتبر لازم است.'])
