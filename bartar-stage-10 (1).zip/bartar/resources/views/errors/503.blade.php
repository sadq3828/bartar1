@extends('errors.page', ['title' => 'سرویس در دسترس نیست', 'errorCode' => '۵۰۳', 'errorTitle' => 'این بخش موقتاً در دسترس نیست', 'errorMessage' => 'لطفاً کمی بعد دوباره به این بخش سر بزنید.'])
