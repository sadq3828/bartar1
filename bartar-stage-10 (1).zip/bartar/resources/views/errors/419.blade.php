@extends('errors.page', ['title' => 'درخواست منقضی شده', 'errorCode' => '۴۱۹', 'errorTitle' => 'درخواست منقضی شده', 'errorMessage' => 'صفحه را دوباره باز کنید و درخواست خود را تکرار کنید.'])
