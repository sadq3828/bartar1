@extends('errors.page', ['title' => 'کمی صبر کنید', 'errorCode' => '۴۲۹', 'errorTitle' => 'درخواست‌های زیادی فرستاده شده', 'errorMessage' => 'کمی صبر کنید و سپس دوباره تلاش کنید.'])
