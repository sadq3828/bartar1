@extends('layouts.site')
@section('content')
<section class="error-page"><div class="error-number" aria-hidden="true">{{ $errorCode }}</div><h1>{{ $errorTitle }}</h1><p>{{ $errorMessage }}</p><a class="button button-primary" href="{{ route('home') }}">بازگشت به خانه <x-icon name="arrow-left" /></a><a class="button button-ghost" href="{{ route('guide') }}">راهنمای استفاده</a></section>
@endsection
