@extends('layouts.site')
@section('content')
<div class="welcome-row"><div><p class="eyebrow">همراه شما در بازار</p><h1>به برتر خوش آمدید.</h1></div><span class="welcome-mark"><x-icon name="compass" /></span></div>
<section class="subscription-summary"><div><span>وضعیت اشتراک</span><strong>اطلاعات اشتراک موجود نیست</strong></div><a href="{{ route('preview.member', ['page' => 'subscription']) }}" aria-label="مشاهده وضعیت اشتراک"><x-icon name="arrow-left" /></a></section>
<div class="quick-actions">
    @foreach([['signals','signal','سیگنال‌ها'],['performance','pie','عملکرد'],['notifications','bell','اعلان‌ها'],['markets','chart','نمای بازار']] as [$page,$icon,$label])<a href="{{ route('preview.member', ['page' => $page]) }}"><span><x-icon :name="$icon" /></span>{{ $label }}</a>@endforeach
</div>
<div class="market-banner compact"><div class="banner-content"><span>با نگاهی منظم‌تر</span><h2>تحلیل، پیگیری<br>و بررسی نتیجه</h2><a href="{{ route('guide') }}">راهنمای استفاده <x-icon name="arrow-left" /></a></div><img class="market-illustration" src="{{ asset('assets/market-scene.svg') }}" alt="" width="260" height="220"></div>
<section class="section-block"><div class="section-heading"><h2>آخرین سیگنال‌ها</h2><a class="text-link" href="{{ route('preview.member', ['page' => 'signals']) }}">همه <x-icon name="arrow-left" /></a></div><div class="compact-empty"><x-icon name="signal" /><span>سیگنالی برای نمایش موجود نیست.</span></div></section>
<section class="section-block"><div class="section-heading"><h2>نمای بازار</h2><a class="text-link" href="{{ route('preview.member', ['page' => 'markets']) }}">مشاهده همه <x-icon name="arrow-left" /></a></div><div class="price-waiting"><span class="coin-icon"><x-icon name="coin" /></span><div><strong>قیمت‌های بازار</strong><small>در انتظار اتصال منبع قیمت</small></div><span class="unavailable-value">—</span></div><p class="subtle-note">قیمت یا درصد تغییر ساختگی نمایش داده نمی‌شود.</p></section>
@endsection
