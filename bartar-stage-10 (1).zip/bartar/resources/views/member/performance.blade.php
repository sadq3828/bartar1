@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>گزارش عملکرد</h1><x-icon name="pie" /></div><p class="page-description">مرور نتایج ثبت‌شدهٔ سیگنال‌ها، به تفکیک بازار و بازهٔ زمانی.</p>
<div class="metrics-grid"><div class="metric-card"><span>سیگنال تکمیل‌شده</span><strong>—</strong><small>داده‌ای ثبت نشده</small></div><div class="metric-card"><span>نرخ موفقیت</span><strong>—</strong><small>نتیجهٔ معتبر موجود نیست</small></div></div>
<x-empty-state icon="pie" title="هنوز گزارشی آماده نیست" description="پس از ثبت نتیجهٔ سیگنال‌ها، آمار و گزارش قابل محاسبه در این صفحه قرار می‌گیرد." />
<div class="note-card"><x-icon name="info" /><p>این گزارش مربوط به عملکرد سیگنال‌هاست و سود واقعی حساب شخصی شما را نشان نمی‌دهد.</p></div>
@endsection
