@extends('layouts.site')
@section('content')
<section class="auth-card"><p class="eyebrow">ورود به فضای اعضا</p><h1>خوش آمدید به برتر</h1><p class="page-description">شماره موبایلی را وارد کنید که اشتراک آن توسط مدیر فعال شده است.</p>
@include('partials.form-messages')
@if(!$ready)<div class="notice notice-warning" role="status">ورود پیامکی هنوز فعال نشده است. برای راهنمایی با پشتیبانی تماس بگیرید.</div>@endif
<form class="admin-form" method="post" action="{{ route('member.otp.request') }}">@csrf<fieldset @disabled(!$ready)><label for="member-phone">شماره موبایل</label><input id="member-phone" name="phone" type="tel" autocomplete="tel" dir="ltr" inputmode="tel" required maxlength="40" placeholder="۰۹…"><button type="submit" class="button button-primary">دریافت کد ورود <x-icon name="arrow-left" /></button></fieldset></form>
<p class="page-description">ثبت‌نام عمومی و پرداخت آنلاین در سایت انجام نمی‌شود. ارسال کد فقط برای شماره مجاز با اشتراک معتبر انجام خواهد شد.</p><a class="text-link" href="{{ route('subscription') }}">روش دریافت اشتراک</a></section>
@endsection
