@extends('layouts.site')
@section('content')
<section class="auth-card"><p class="eyebrow">ورود امن</p><h1>کد تأیید را وارد کنید</h1><p class="page-description">اگر شماره <bdi dir="ltr">{{ $mask }}</bdi> مجاز و دارای اشتراک معتبر باشد، کد برای آن ارسال می‌شود.</p>
@include('partials.form-messages')
<form method="post" action="{{ route('member.otp.verify') }}" class="admin-form">@csrf<label for="member-code">کد شش‌رقمی پیامک</label><input class="otp-code" id="member-code" name="code" type="text" inputmode="numeric" pattern="[0-9۰-۹٠-٩]{6}" minlength="6" maxlength="6" autocomplete="one-time-code" dir="ltr" required><p class="page-description">کد حداکثر {{ config('membership.otp_ttl') }} ثانیه از زمان درخواست معتبر است و فقط یک بار استفاده می‌شود.</p><button class="button button-primary" type="submit" @disabled(!$ready)>تأیید و ورود</button></form>
<form method="post" action="{{ route('member.otp.resend') }}" class="admin-form">@csrf<p class="page-description">ارسال مجدد پس از {{ $resendSeconds }} ثانیه مجاز است.</p><button class="button button-outline" type="submit" @disabled(!$ready)>ارسال مجدد کد</button></form><a class="text-link" href="{{ route('login') }}">تغییر شماره موبایل</a></section>
@endsection
