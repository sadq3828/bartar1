@extends('layouts.site')
@section('content')
<a class="text-link signal-back" href="{{ route('member.signals',['archive'=>in_array($signal->status,['completed','cancelled','expired'])?1:null]) }}"><x-icon name="arrow-left" /> بازگشت به سیگنال‌ها</a>
<article class="signal-detail"><header><div><p class="eyebrow">{{ $signal->market->title }} · <bdi dir="ltr">{{ $signal->asset->symbol }}</bdi></p><h1>{{ $signal->title }}</h1></div><span class="badge {{ $signal->direction==='buy'?'badge-success':'badge-warning' }}">{{ $signal->direction==='buy'?'پیشنهاد خرید':'پیشنهاد فروش' }}</span></header><p class="page-description">نسخه {{ $signal->version }} · انتشار {{ \App\Modules\Foundation\Support\PersianDate::format($signal->published_at,'yyyy/MM/dd HH:mm') }}</p><div class="signal-stat-grid"><div><span>محدوده ورود</span><strong dir="ltr">{{ $signal->entry_low }}{{ $signal->entry_high?' – '.$signal->entry_high:'' }}</strong></div><div><span>حد ضرر</span><strong dir="ltr">{{ $signal->stop_loss??'ثبت نشده' }}</strong></div><div><span>تایم‌فریم</span><strong>{{ $signal->timeframe }}</strong></div><div><span>ریسک</span><strong>{{ $signal->risk_label??'ثبت نشده' }}</strong></div></div><section class="panel-card"><h2>توضیحات</h2><p class="preserve-lines signal-body">{{ $signal->body_sanitized }}</p></section><section class="panel-card"><h2>اهداف</h2><ol class="target-list">@foreach($signal->targets as $target)<li><bdi dir="ltr">{{ $target->price }}</bdi>@if($target->proposed_exit_weight)<small>سهم پیشنهادی {{ $target->proposed_exit_weight }}</small>@endif</li>@endforeach</ol></section>
@if($signal->mediaAttachments->isNotEmpty())
<section class="panel-card signal-media-section"><h2>رسانه‌های تحلیل</h2><div class="media-gallery">
    @foreach($signal->mediaAttachments as $attachment)
        @php($file=$attachment->mediaFile)
        <figure class="media-card"><div class="media-frame">
            @if($attachment->kind==='image')<img src="{{ route('member.media.stream',$file) }}" alt="{{ $attachment->caption?:'تصویر تحلیل' }}" loading="lazy">
            @elseif($attachment->kind==='audio')<audio controls controlslist="nodownload noremoteplayback" preload="metadata" src="{{ route('member.media.stream',$file) }}"></audio>
            @else<video controls controlslist="nodownload noremoteplayback" disablepictureinpicture preload="metadata" src="{{ route('member.media.stream',$file) }}"></video>@endif
        </div>@if($attachment->caption)<figcaption>{{ $attachment->caption }}</figcaption>@endif</figure>
    @endforeach
</div><p class="subtle-note">دسترسی رسانه‌ها خصوصی و وابسته به اعتبار عضویت شماست. از بازنشر محتوای اشتراکی خودداری کنید.</p></section>
@endif
@if($signal->results->isNotEmpty())<section class="panel-card"><h2>آخرین نتیجه ثبت‌شده</h2>@php($result=$signal->results->first())<p class="preserve-lines">{{ $result->note?:'نتیجه بدون توضیح تکمیلی ثبت شده است.' }}</p><ol class="target-list">@foreach($result->exits as $exit)<li><bdi dir="ltr">{{ $exit->exit_price }}</bdi><small>سهم خروج {{ $exit->exit_weight }}</small></li>@endforeach</ol><p class="subtle-note">این نتیجه مربوط به سیگنال است و سود واقعی حساب شخصی شما محسوب نمی‌شود.</p></section>@endif
@if($signal->revisions->isNotEmpty())<section class="panel-card"><h2>تاریخچه اصلاحات</h2>@foreach($signal->revisions as $revision)<div class="history-entry"><strong>نسخه {{ $revision->version }}</strong><small>{{ \App\Modules\Foundation\Support\PersianDate::format($revision->changed_at,'yyyy/MM/dd HH:mm') }} · {{ $revision->reason }}</small></div>@endforeach</section>@endif</article>
@endsection
