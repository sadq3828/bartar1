@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>سیگنال‌ها</h1><span class="badge badge-outline">آرشیو و پیشنهادهای فعال</span></div>
<form class="filter-form" action="{{ route('preview.member', ['page' => 'signals']) }}" method="get">
    <div class="search-field"><x-icon name="search" /><label class="sr-only" for="signal-search">جست‌وجو در سیگنال‌ها</label><input id="signal-search" type="search" name="q" value="{{ $query['q'] ?? '' }}" maxlength="100" placeholder="جست‌وجو در سیگنال‌ها…"><button type="submit" class="search-submit" aria-label="جست‌وجو"><x-icon name="arrow-left" /></button></div>
    <label class="switch-label"><input type="checkbox" name="active" value="1" @checked(($query['active'] ?? '') === '1')><span class="switch-track" aria-hidden="true"></span>فقط پیشنهادهای فعال</label>
    <input type="hidden" name="direction" value="{{ $query['direction'] ?? 'all' }}"><button type="submit" class="button button-outline button-small">اعمال فیلتر</button>
</form>
<nav class="filter-tabs" aria-label="جهت سیگنال">@foreach(['all' => 'همه', 'buy' => 'پیشنهاد خرید', 'sell' => 'پیشنهاد فروش'] as $key => $label)<a href="{{ route('preview.member', array_merge(['page' => 'signals'], $query, ['direction' => $key])) }}" class="{{ ($query['direction'] ?? 'all') === $key ? 'is-active' : '' }}" @if(($query['direction'] ?? 'all') === $key) aria-current="true" @endif>{{ $label }}</a>@endforeach</nav>
<div id="signal-results" aria-live="polite"><x-empty-state icon="signal" :title="!empty($query['q']) ? 'نتیجه‌ای پیدا نشد' : 'هنوز سیگنالی ثبت نشده'" description="پس از ثبت و انتشار سیگنال، پیشنهادهای مجاز در این بخش نمایش داده می‌شوند." /></div>
@if(!empty($query))<a class="text-link reset-filter" href="{{ route('preview.member', ['page' => 'signals']) }}">پاک‌کردن فیلترها <x-icon name="arrow-left" /></a>@endif
@if($errors->any())<div class="message message-error" role="alert"><x-icon name="info" /><p>فیلتر انتخاب‌شده معتبر نیست. دوباره تلاش کنید.</p></div>@endif
@endsection
