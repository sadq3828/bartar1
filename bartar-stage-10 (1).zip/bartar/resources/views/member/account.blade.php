@extends('layouts.site')
@section('content')
<div class="account-heading"><span class="avatar"><x-icon name="user" /></span><h1>حساب کاربری</h1><p>اطلاعات حساب بارگذاری نشده است.</p></div>
<div class="account-links"><a href="{{ route('preview.member', ['page' => 'subscription']) }}"><span class="link-icon"><x-icon name="crown" /></span><span>وضعیت اشتراک</span><x-icon name="arrow-left" /></a><a href="{{ route('preview.member', ['page' => 'notifications']) }}"><span class="link-icon"><x-icon name="bell" /></span><span>اعلان‌ها</span><x-icon name="arrow-left" /></a><a href="{{ route('guide') }}"><span class="link-icon"><x-icon name="book" /></span><span>راهنمای استفاده</span><x-icon name="arrow-left" /></a><a href="{{ route('contact') }}"><span class="link-icon"><x-icon name="headphones" /></span><span>ارتباط با پشتیبانی</span><x-icon name="arrow-left" /></a></div>
<div class="note-card"><x-icon name="shield" /><p>این صفحهٔ توسعه به هیچ حسابی وارد نشده است؛ شماره یا اطلاعات شخصی نمایش داده نمی‌شود.</p></div>
@endsection
