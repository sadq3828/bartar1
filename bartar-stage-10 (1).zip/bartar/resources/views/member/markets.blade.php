@extends('layouts.site')
@section('content')
@if($preview ?? false)
<div class="page-title-row"><h1>نمای بازار</h1><span class="badge badge-muted"><span class="status-dot"></span>بدون اتصال قیمت</span></div>
<form class="filter-form" action="{{ route('preview.member', ['page' => 'markets']) }}" method="get"><div class="search-field"><x-icon name="search" /><label for="market-search" class="sr-only">جست‌وجو در بازار</label><input id="market-search" type="search" name="q" maxlength="100" value="{{ $query['q'] ?? '' }}" placeholder="جست‌وجو در بازار…"><input type="hidden" name="market" value="{{ $query['market'] ?? 'all' }}"><button type="submit" class="search-submit" aria-label="جست‌وجو"><x-icon name="arrow-left" /></button></div></form>
<nav class="market-tabs" aria-label="نوع بازار">@foreach(['all' => 'همه', 'crypto' => 'ارز دیجیتال', 'forex' => 'فارکس', 'gold' => 'طلا', 'domestic' => 'داخلی'] as $key => $label)<a href="{{ route('preview.member', array_merge(['page' => 'markets'], $query ?? [], ['market' => $key])) }}" class="{{ ($query['market'] ?? 'all') === $key ? 'is-active' : '' }}">{{ $label }}</a>@endforeach</nav>
<x-empty-state icon="chart" title="قیمت معتبری دریافت نشده" description="پس از اتصال منبع، قیمت هر دارایی با واحد، منبع و زمان آخرین به‌روزرسانی نمایش داده می‌شود." />
@else
<div class="page-title-row"><h1>نمای بازار</h1><span class="badge badge-muted">قیمت همراه وضعیت تازگی</span></div>
<form class="filter-form" action="{{ route('member.markets') }}" method="get"><div class="search-field"><x-icon name="search" /><label for="market-search" class="sr-only">جست‌وجوی دارایی</label><input id="market-search" type="search" name="q" maxlength="100" value="{{ $query['q'] ?? '' }}" placeholder="نام یا نماد دارایی…"><input type="hidden" name="market" value="{{ $query['market'] ?? 'all' }}"><button type="submit" class="search-submit" aria-label="جست‌وجو"><x-icon name="arrow-left" /></button></div></form>
<nav class="market-tabs" aria-label="بازار"><a href="{{ route('member.markets', array_filter(['q'=>$query['q']??null,'market'=>'all'])) }}" class="{{ ($query['market'] ?? 'all') === 'all' ? 'is-active' : '' }}">همه</a>@foreach($marketTabs as $tab)<a href="{{ route('member.markets', array_filter(['q'=>$query['q']??null,'market'=>$tab->key])) }}" class="{{ ($query['market'] ?? 'all') === $tab->key ? 'is-active' : '' }}">{{ $tab->title }}</a>@endforeach</nav>
<div class="market-price-list">
@forelse($markets as $market)
<section class="market-price-group"><div class="section-heading"><h2>{{ $market->title }}</h2><small class="section-note"><bdi dir="ltr">{{ $market->key }}</bdi></small></div>
@foreach($market->assets as $asset) @php($quote=$quotes[$asset->id])
<article class="market-price-card"><div><strong>{{ $asset->title }}</strong><small><bdi dir="ltr">{{ $asset->symbol }}</bdi></small></div>
@if($quote['available'])<div class="market-price-value"><bdi dir="ltr">{{ $quote['value'] }}</bdi><small><bdi dir="ltr">{{ $quote['unit'] }}</bdi></small></div><div class="price-meta"><span class="badge price-status-{{ $quote['status'] }}">{{ ['fresh'=>'به‌روز','stale'=>'قدیمی','manual'=>'دستی'][$quote['status']] }}</span><small>{{ $quote['source_kind']==='manual'?'ثبت مدیر':($quote['source']??'منبع API') }} · {{ \App\Modules\Foundation\Support\PersianDate::format($quote['observed_at'],'yyyy/MM/dd HH:mm') }}</small></div>
@else<div class="market-price-value unavailable-value">—</div><div class="price-meta"><span class="badge badge-muted">ناموجود</span><small>قیمت معتبر دریافت نشده است</small></div>@endif
</article>
@endforeach</section>
@empty<x-empty-state icon="chart" title="دارایی‌ای پیدا نشد" description="فیلتر را تغییر دهید یا بعداً دوباره بررسی کنید." />@endforelse
</div>
<div class="note-card"><x-icon name="info" /><p>قیمت «قدیمی» یا «دستی» صریحاً برچسب می‌خورد. نبود داده با صفر جایگزین نمی‌شود.</p></div>
@if(($query['q']??null)||(($query['market']??'all')!=='all'))<a class="text-link reset-filter" href="{{ route('member.markets') }}">پاک‌کردن فیلترها <x-icon name="arrow-left" /></a>@endif
@endif
@endsection
