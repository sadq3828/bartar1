@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>اعلان‌ها</h1><x-icon name="bell" /></div>
@if($preview ?? false)
<x-empty-state icon="bell" title="هنوز اعلانی وجود ندارد" description="اطلاعیه‌ها و تغییرات مهم سیگنال‌ها پس از انتشار در این بخش قرار می‌گیرند." />
@else
@include('partials.form-messages')
<div class="section-heading"><p class="page-description">{{ $unread }} اعلان خوانده‌نشده</p>@if($unread)<form method="post" action="{{ route('member.notifications.read-all') }}">@csrf<button class="button button-outline button-small" type="submit">خواندن همه</button></form>@endif</div>
<div class="notification-list">@forelse($notifications as $notification)<article class="panel-card notification-card {{ $notification->read_at?'':'is-unread' }}"><div class="section-heading"><h2>{{ $notification->title }}</h2><span class="badge {{ $notification->read_at?'badge-muted':'badge-success' }}">{{ $notification->read_at?'خوانده‌شده':'جدید' }}</span></div><p class="preserve-lines">{{ $notification->body }}</p><small>{{ \App\Modules\Foundation\Support\PersianDate::format($notification->created_at,'yyyy/MM/dd HH:mm') }}</small><div class="hero-actions">@if($notification->action_url)<a class="text-link" href="{{ $notification->action_url }}">مشاهده <x-icon name="arrow-left" /></a>@endif @if(!$notification->read_at)<form method="post" action="{{ route('member.notifications.read',$notification) }}">@csrf<button class="button button-ghost button-small" type="submit">علامت‌گذاری به‌عنوان خوانده‌شده</button></form>@endif</div></article>@empty<x-empty-state icon="bell" title="هنوز اعلانی وجود ندارد" description="اطلاعیه‌ها و تغییرات مهم سیگنال‌ها پس از انتشار در این بخش قرار می‌گیرند." />@endforelse</div>
{{ $notifications->links('partials.pagination') }}
@endif
@endsection
