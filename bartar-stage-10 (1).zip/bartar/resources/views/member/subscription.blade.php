@extends('layouts.site')
@section('content')
<div class="page-title-row"><h1>وضعیت اشتراک</h1><x-icon name="crown" /></div><x-empty-state icon="crown" title="اطلاعات اشتراک موجود نیست" description="پس از ورود معتبر، تاریخ شروع و پایان و وضعیت اشتراک در این بخش نمایش داده می‌شود."><a class="button button-primary" href="{{ route('subscription') }}">راهنمای فعال‌سازی <x-icon name="arrow-left" /></a></x-empty-state>
@endsection
