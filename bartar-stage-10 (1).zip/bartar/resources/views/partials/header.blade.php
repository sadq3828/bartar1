<header class="site-header">
    <a class="brand" href="{{ route('home') }}" aria-label="{{ $brandSettings['brand_name'] ?? 'برتر' }}؛ صفحه خانه"><span class="brand-symbol" aria-hidden="true"><svg viewBox="0 0 38 32" fill="none"><path d="m2 25 9-17 9 12L31 3M22 3h9v10" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="m6 31 8-14 8 10 13-17" stroke="currentColor" stroke-width="2" opacity=".35"/></svg></span><span class="brand-word">{{ $brandSettings['brand_name'] ?? 'بـرتـر' }}<small>BARTAR</small></span></a>
    <div class="header-actions">
        @if(($area ?? 'public') === 'member')
            <a class="icon-button" href="{{ (($preview ?? false) ? route('preview.member', ['page' => 'notifications']) : route('member.notifications')) }}" aria-label="اعلان‌ها"><x-icon name="bell" /></a>
            <a class="support-pill" href="{{ route('contact') }}"><x-icon name="headphones" /><span>پشتیبانی</span></a>
        @elseif(($area ?? 'public') === 'admin')
            <span class="badge badge-outline"><x-icon name="lock" /> فضای مدیریت</span>
            @if(!($preview ?? false))<form action="{{ route('admin.logout') }}" method="post">@csrf<button class="button button-outline button-small" type="submit">خروج</button></form>@endif
        @else
            <a class="support-pill" href="{{ route('subscription') }}"><x-icon name="crown" /><span>راهنمای اشتراک</span></a>
        @endif
    </div>
</header>
