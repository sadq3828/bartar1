@php
    $isMember = ($area ?? 'public') === 'member';
    $navigation = $isMember ? config('bartar.member_navigation') : (($publicNavigation ?? []) ?: [
        'home' => ['title' => 'خانه', 'icon' => 'home'],
        'guide' => ['title' => 'راهنما', 'icon' => 'book'],
        'subscription' => ['title' => 'عضویت', 'icon' => 'crown'],
        'announcements' => ['title' => 'اطلاعیه', 'icon' => 'bell'],
        'about' => ['title' => 'درباره ما', 'icon' => 'user'],
    ]);
@endphp
<nav class="bottom-nav" aria-label="منوی اصلی"><div class="bottom-nav-inner">
@foreach($navigation as $key => $item)
    <a class="nav-item {{ ($active ?? '') === $key ? 'is-active' : '' }}" href="{{ $isMember ? (($preview ?? false) ? route('preview.member', ['page' => $key]) : route('member.'.$key)) : route($key) }}" @if(($active ?? '') === $key) aria-current="page" @endif><span class="nav-icon"><x-icon :name="$item['icon']" /></span><span>{{ $item['title'] }}</span></a>
@endforeach
</div></nav>
