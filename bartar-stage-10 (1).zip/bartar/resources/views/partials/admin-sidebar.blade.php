@if($preview ?? false)
<aside class="admin-sidebar">
    <a href="{{ route('preview.admin') }}" class="admin-sidebar-brand">برتر <span>مدیریت</span></a>
    <p class="sidebar-caption">فضای کار</p>
    <nav aria-label="بخش‌های مدیریت" class="admin-navigation">
        @foreach(config('bartar.admin_navigation') as $key => $item)
        <a href="{{ route('preview.admin', ['page' => $key]) }}" class="{{ ($active ?? '') === $key ? 'is-active' : '' }}" @if(($active ?? '') === $key) aria-current="page" @endif><x-icon :name="$item['icon']" />{{ $item['title'] }}</a>
        @endforeach
    </nav>
    <div class="sidebar-note"><x-icon name="shield" /><p>داده‌های اعضا در این پیش‌نمایش در دسترس نیستند.</p></div>
    <a href="{{ route('preview.index') }}" class="sidebar-back">فهرست پیش‌نمایش‌ها <x-icon name="arrow-left" /></a>
</aside>
<details class="mobile-admin-menu"><summary>بخش‌های مدیریت <x-icon name="grid" /></summary><nav aria-label="منوی مدیریت موبایل">@foreach(config('bartar.admin_navigation') as $key => $item)<a href="{{ route('preview.admin', ['page' => $key]) }}">{{ $item['title'] }}</a>@endforeach</nav></details>
@else
@include('partials.admin-sidebar-real')
@endif
