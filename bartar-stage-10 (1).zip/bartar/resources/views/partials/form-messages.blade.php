@if(session('status'))<div class="message message-success" role="status"><x-icon name="check" /><p>{{ session('status') }}</p></div>@endif
@if($errors->any())<div class="message message-error" role="alert"><x-icon name="info" /><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
