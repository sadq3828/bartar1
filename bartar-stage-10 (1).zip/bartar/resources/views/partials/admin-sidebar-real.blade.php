@php
$items=[
    'dashboard'=>['داشبورد','grid','admin.dashboard','dashboard.view'],
    'members'=>['شماره‌ها و اشتراک','users','admin.members.index','members.view'],
    'signals'=>['سیگنال‌ها','signal','admin.signals.index','signals.view'],
    'markets'=>['بازارها و دارایی‌ها','chart','admin.markets.index','markets.view'],
    'content'=>['محتوا و اعلان','document','admin.content.index','content'],
    'reports'=>['گزارش عملکرد','pie','admin.reports','reports.view'],
    'backups'=>['بکاپ و بازیابی','shield','admin.backups','backups.view'],
    'health'=>['سلامت سامانه','pulse','admin.health','health.view'],
    'admins'=>['مدیران','users','admin.accounts.index','admins.manage'],
    'roles'=>['نقش‌ها و مجوزها','shield','admin.roles.index','manage_roles'],
    'sessions'=>['نشست‌ها','user','admin.sessions',null],
    'audit'=>['ممیزی عملیات','document','admin.audit','audit'],
    'security'=>['امنیت حساب','lock','admin.security',null],
];
$items=array_filter($items,function($item)use($adminUser){
    if(!$item[3])return true;
    if($item[3]==='audit')return $adminUser->allows('audit.view') || collect(['subscriptions','signals','cms','technical'])->contains(fn($scope)=>$adminUser->allows('audit.'.$scope));
    if($item[3]==='content')return $adminUser->allows('cms.view') || $adminUser->allows('notifications.view');
    return $adminUser->allows($item[3]);
});
@endphp
<aside class="admin-sidebar"><a href="{{ route('admin.dashboard') }}" class="admin-sidebar-brand">برتر <span>مدیریت</span></a><p class="sidebar-caption">فضای کار</p><nav aria-label="بخش‌های مدیریت" class="admin-navigation">@foreach($items as $key=>[$label,$icon,$route,$permission])<a href="{{ route($route) }}" class="{{ $active===$key ? 'is-active' : '' }}" @if($active===$key) aria-current="page" @endif><x-icon :name="$icon" />{{ $label }}</a>@endforeach</nav><div class="sidebar-note"><x-icon name="shield" /><p>دسترسی‌ها بر اساس نقش شما و در سرور بررسی می‌شوند.</p></div><a class="sidebar-back" href="{{ route('home') }}">صفحه عمومی <x-icon name="arrow-left" /></a></aside>
<details class="mobile-admin-menu"><summary>بخش‌های مدیریت <x-icon name="grid" /></summary><nav aria-label="منوی مدیریت موبایل">@foreach($items as [$label,$icon,$route,$permission])<a href="{{ route($route) }}">{{ $label }}</a>@endforeach</nav></details>
